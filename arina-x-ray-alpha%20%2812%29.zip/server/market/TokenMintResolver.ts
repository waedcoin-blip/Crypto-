// server/market/TokenMintResolver.ts
// SINGLE AUTHORITATIVE Solana mint identity/validation service.
import { Connection, PublicKey } from '@solana/web3.js';
import bs58 from 'bs58';
import { getPrimaryRpc } from '../config/rpcRouting.js';

const TOKEN_PROGRAM_ID = 'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA';
const TOKEN_2022_PROGRAM_ID = 'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb';

const KNOWN_PROGRAMS_AND_NON_MINTS = new Set([
  'So11111111111111111111111111111111111111112',
  TOKEN_PROGRAM_ID,
  TOKEN_2022_PROGRAM_ID,
  '11111111111111111111111111111111',
  'ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL',
  'ComputeBudget111111111111111111111111111',
  'SysvarRent111111111111111111111111111111',
  'SysvarC1ock11111111111111111111111111111111',
  '6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P',
  '675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8',
  'CAMMCzo5YL8w4VFF8KVHrK22GGUsp5VTaW7grrKgrWqK',
  'CPMMoo8L3F4NbTegBCKVNunggL7H1ZpdTHKxQB5qKP1C',
  'JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4',
  'JUP4Fb2cqiRUcaTHdrPC8h2gNsA2ETXiPDD33WcGuJB',
  'whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3uctyCc',
  'LBUZKhRxPF3XUpBCjp4YzTKgLccjZhTSDM9YuVaPwxo',
  'srmqPvymJeFKQ4zGQed1GFppgkRHL9kaELCbyksJtPX',
  'MSHOT11111111111111111111111111111111111111',
  'MoonCVVNZFSYkqNXP6bxHLPL6QQJiMagDL3qcqUQTrG',
  'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
  'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB',
]);

export type MintClassification = 'TOKEN_MINT' | 'PROGRAM_ID' | 'UNKNOWN' | 'WSOL';
export interface MintValidationResult {
  ok: boolean;
  code: 'VALID' | 'INVALID_MINT' | 'RPC_RATE_LIMITED' | 'RPC_VALIDATION_UNAVAILABLE';
  reason: string;
  mint: string;
  stage: 'MINT_VALIDATION';
  value?: any;
}

/**
 * Important: a .pump suffix is NOT a special case. It is simply Base58 text.
 * We validate the decoded 32-byte public key and then canonicalize with PublicKey.
 * Synthetic strings such as TestMint... are deliberately NOT accepted here.
 */
export class TokenMintResolver {
  private static instance: TokenMintResolver;
  private positiveCache = new Map<string, { value: any; expiresAt: number }>();
  private negativeCache = new Map<string, { reason: string; expiresAt: number }>();
  private inFlightRequests = new Map<string, Promise<MintValidationResult>>();
  private readonly positiveCacheTtlMs = 10 * 60 * 1000;
  private readonly negativeCacheTtlMs = 5 * 60 * 1000;

  private constructor() {
    const interval = setInterval(() => this.pruneCaches(), 60000);
    interval.unref?.();
  }

  public static getInstance(): TokenMintResolver {
    if (!TokenMintResolver.instance) TokenMintResolver.instance = new TokenMintResolver();
    return TokenMintResolver.instance;
  }

  /** Return the canonical Base58 PublicKey string or null. Never invents a mint. */
  public normalizeMint(address: unknown): string | null {
    if (typeof address !== 'string') return null;
    const trimmed = address.trim();
    if (!trimmed) return null;
    try {
      const decoded = bs58.decode(trimmed);
      if (decoded.length !== 32) return null;
      return new PublicKey(decoded).toBase58();
    } catch {
      return null;
    }
  }

  public isValidPublicKey(address: unknown): boolean {
    return this.normalizeMint(address) !== null;
  }

  /** Fast syntax + known-non-mint check. Does NOT claim on-chain mint ownership. */
  public isValidMint(address: string): boolean {
    const mint = this.normalizeMint(address);
    if (!mint || KNOWN_PROGRAMS_AND_NON_MINTS.has(mint)) return false;
    const neg = this.negativeCache.get(mint);
    return !(neg && Date.now() < neg.expiresAt);
  }

  public classifyAddress(address: string): {
    mint: string;
    classification: MintClassification;
    isValidMint: boolean;
    reason?: string;
  } {
    const mint = this.normalizeMint(address);
    if (!mint) return { mint: typeof address === 'string' ? address.trim() : '', classification: 'UNKNOWN', isValidMint: false, reason: 'INVALID_BASE58_OR_BYTE_LENGTH' };
    if (mint === 'So11111111111111111111111111111111111111112') return { mint, classification: 'WSOL', isValidMint: false, reason: 'WSOL_NOT_TRADABLE' };
    if (KNOWN_PROGRAMS_AND_NON_MINTS.has(mint)) return { mint, classification: 'PROGRAM_ID', isValidMint: false, reason: 'KNOWN_PROGRAM_OR_CORE_ADDRESS' };
    const cached = this.positiveCache.get(mint);
    if (cached && Date.now() < cached.expiresAt) return { mint, classification: 'TOKEN_MINT', isValidMint: true, reason: 'CACHED_VALID_MINT' };
    return { mint, classification: 'TOKEN_MINT', isValidMint: true, reason: 'VALID_PUBLIC_KEY_CANDIDATE' };
  }

  public async validateTokenMint(address: string, connection?: Connection | null): Promise<MintValidationResult> {
    const mint = this.normalizeMint(address);
    if (!mint) return { ok: false, code: 'INVALID_MINT', reason: 'INVALID_PUBLIC_KEY_FORMAT', mint: typeof address === 'string' ? address.trim() : '', stage: 'MINT_VALIDATION' };
    if (KNOWN_PROGRAMS_AND_NON_MINTS.has(mint)) return { ok: false, code: 'INVALID_MINT', reason: 'KNOWN_PROGRAM_OR_SYSVAR', mint, stage: 'MINT_VALIDATION' };

    const cached = this.positiveCache.get(mint);
    if (cached && Date.now() < cached.expiresAt) return { ok: true, code: 'VALID', reason: 'CACHED_VALID_MINT', mint, stage: 'MINT_VALIDATION', value: cached.value };
    const neg = this.negativeCache.get(mint);
    if (neg && Date.now() < neg.expiresAt) return { ok: false, code: 'INVALID_MINT', reason: `CACHED_INVALID_MINT: ${neg.reason}`, mint, stage: 'MINT_VALIDATION' };

    const existing = this.inFlightRequests.get(mint);
    if (existing) return existing;
    const promise = this.executeOnChainValidation(mint, connection);
    this.inFlightRequests.set(mint, promise);
    try { return await promise; } finally { this.inFlightRequests.delete(mint); }
  }

  private async executeOnChainValidation(mint: string, connection?: Connection | null): Promise<MintValidationResult> {
    try {
      const conn = connection || await this.getConnection();
      if (!conn) return { ok: false, code: 'RPC_VALIDATION_UNAVAILABLE', reason: 'NO_RPC_CONNECTION', mint, stage: 'MINT_VALIDATION' };
      const accInfo = await conn.getAccountInfo(new PublicKey(mint), 'confirmed');
      if (!accInfo) return this.cacheNegative(mint, 'ACCOUNT_NOT_FOUND');
      const owner = accInfo.owner.toBase58();
      const isSpl = owner === TOKEN_PROGRAM_ID;
      const is2022 = owner === TOKEN_2022_PROGRAM_ID;
      if (!isSpl && !is2022) return this.cacheNegative(mint, `UNSUPPORTED_ACCOUNT_OWNER: ${owner}`);
      if (accInfo.data.length < 82) return this.cacheNegative(mint, 'INVALID_MINT_ACCOUNT_DATA');
      const decimals = accInfo.data.readUInt8(44);
      const value = { mint, decimals, program: is2022 ? 'Token-2022' : 'SPL Token', validatedAt: Date.now() };
      this.positiveCache.set(mint, { value, expiresAt: Date.now() + this.positiveCacheTtlMs });
      return { ok: true, code: 'VALID', reason: 'ON_CHAIN_VALIDATED', mint, stage: 'MINT_VALIDATION', value };
    } catch (e: any) {
      const msg = e instanceof Error ? e.message : String(e || 'Unknown');
      const rateLimited = /\b429\b|rate.?limit/i.test(msg);
      return { ok: false, code: rateLimited ? 'RPC_RATE_LIMITED' : 'RPC_VALIDATION_UNAVAILABLE', reason: `RPC_ERROR: ${msg}`, mint, stage: 'MINT_VALIDATION' };
    }
  }

  private cacheNegative(mint: string, reason: string): MintValidationResult {
    this.negativeCache.set(mint, { reason, expiresAt: Date.now() + this.negativeCacheTtlMs });
    return { ok: false, code: 'INVALID_MINT', reason, mint, stage: 'MINT_VALIDATION' };
  }

  public extractMintFromLogs(logs: string[]): string | null {
    if (!Array.isArray(logs)) return null;
    for (const log of logs) {
      if (typeof log !== 'string') continue;
      const matches = [
        log.match(/(?:Program log:\s*)?(?:mint|token_mint|mintAddress)\s*:?\s*([1-9A-HJ-NP-Za-km-z]{32,44})/i),
        log.match(/"mint"\s*:\s*"([1-9A-HJ-NP-Za-km-z]{32,44})"/i),
      ];
      for (const match of matches) {
        const mint = this.normalizeMint(match?.[1]);
        if (mint && this.isValidMint(mint)) return mint;
      }
    }
    return null;
  }

  public extractCandidateMintsFromAccountKeys(accountKeys: string[]): string[] {
    if (!Array.isArray(accountKeys)) return [];
    return [...new Set(accountKeys.map(k => this.normalizeMint(k)).filter((k): k is string => !!k && this.isValidMint(k)))];
  }

  private async getConnection(): Promise<Connection | null> {
    try {
      const rpcUrl = getPrimaryRpc('search');
      return rpcUrl ? new Connection(rpcUrl, 'confirmed') : null;
    } catch { return null; }
  }

  private pruneCaches(): void {
    const now = Date.now();
    for (const [key, value] of this.positiveCache) if (now >= value.expiresAt) this.positiveCache.delete(key);
    for (const [key, value] of this.negativeCache) if (now >= value.expiresAt) this.negativeCache.delete(key);
  }
}

export const tokenMintResolver = TokenMintResolver.getInstance();

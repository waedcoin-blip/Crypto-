// src/services/TokenRegistry.ts
import { TradingNetwork } from '../config/network';

export type TokenSignal = 'MOMENTUM' | 'VOLUME_SPIKE' | 'WHALE_BUY' | 'TRENDING' | 'MANUAL' | 'NONE';

export type TokenExecutionState = 
  | 'DISCOVERED'
  | 'VALIDATING'
  | 'EVALUATING'
  | 'ORDER_PENDING'
  | 'POSITION_OPEN'
  | 'EXIT_PENDING'
  | 'CLOSED'
  | 'BLACKLISTED';

export interface TokenRecord {
  mintAddress: string; // Canonical identifier
  symbol?: string;
  name?: string;
  decimals?: number;

  network: TradingNetwork;

  priceSOL?: number;
  priceUSD?: number;
  liquidity?: number;
  marketCap?: number;
  volume24h?: number;

  discoveredAt: number;
  updatedAt: number;

  signal?: TokenSignal;
  signalConfidence?: number;
  executionState?: TokenExecutionState;

  positionId?: string;
  metadata?: Record<string, any>;
}

export type TokenRegistryListener = (token: TokenRecord) => void;

/**
 * TokenRegistry: The SINGLE authoritative token registry for the entire application.
 * Identifies tokens strictly by Solana mint address.
 */
export class TokenRegistry {
  private static instance: TokenRegistry;
  private tokens: Map<string, TokenRecord> = new Map();
  private listeners: Set<TokenRegistryListener> = new Set();

  private constructor() {
    this.loadTokens();
  }

  public static getInstance(): TokenRegistry {
    if (!TokenRegistry.instance) {
      TokenRegistry.instance = new TokenRegistry();
    }
    return TokenRegistry.instance;
  }

  private loadTokens(): void {
    if (typeof localStorage !== 'undefined') {
      try {
        const data = localStorage.getItem('app_token_registry_tokens');
        if (data) {
          const list = JSON.parse(data);
          for (const item of list) {
            if (item && item.mintAddress) {
              this.tokens.set(item.mintAddress, item as TokenRecord);
            }
          }
        }
      } catch (e) {
        console.warn('[TokenRegistry] Failed to load tokens from localStorage:', e);
      }
    }
  }

  private syncServer(record: TokenRecord): void {
    if (typeof localStorage !== 'undefined') {
      try {
        const list = Array.from(this.tokens.values());
        localStorage.setItem('app_token_registry_tokens', JSON.stringify(list));
      } catch (e) {
        console.warn('[TokenRegistry] Failed to sync tokens to localStorage:', e);
      }
    }
  }

  public registerOrUpdate(params: {
    mintAddress: string;
    network?: TradingNetwork;
    symbol?: string;
    name?: string;
    decimals?: number;
    priceSOL?: number;
    priceUSD?: number;
    liquidity?: number;
    marketCap?: number;
    volume24h?: number;
    signal?: TokenSignal;
    signalConfidence?: number;
    executionState?: TokenExecutionState;
    positionId?: string;
    metadata?: Record<string, any>;
  }): TokenRecord {
    const mint = params.mintAddress.trim();
    if (!mint) throw new Error('TokenRegistry: mintAddress is required');

    const now = Date.now();
    const existing = this.tokens.get(mint);
    const resolvedDecimals = params.decimals !== undefined ? params.decimals : existing?.decimals;

    const record: TokenRecord = {
      mintAddress: mint,
      network: params.network || existing?.network || 'paper',
      symbol: params.symbol || existing?.symbol || 'UNKNOWN',
      name: params.name || existing?.name || existing?.symbol || 'Unknown Token',
      decimals: resolvedDecimals !== undefined ? resolvedDecimals : existing?.decimals,
      priceSOL: params.priceSOL !== undefined ? params.priceSOL : existing?.priceSOL,
      priceUSD: params.priceUSD !== undefined ? params.priceUSD : existing?.priceUSD,
      liquidity: params.liquidity !== undefined ? params.liquidity : existing?.liquidity,
      marketCap: params.marketCap !== undefined ? params.marketCap : existing?.marketCap,
      volume24h: params.volume24h !== undefined ? params.volume24h : existing?.volume24h,
      discoveredAt: existing ? existing.discoveredAt : now,
      updatedAt: now,
      signal: params.signal !== undefined ? params.signal : (existing?.signal || 'NONE'),
      signalConfidence: params.signalConfidence !== undefined ? params.signalConfidence : existing?.signalConfidence,
      executionState: params.executionState !== undefined ? params.executionState : (existing?.executionState || 'DISCOVERED'),
      positionId: params.positionId !== undefined ? params.positionId : existing?.positionId,
      metadata: { ...existing?.metadata, ...params.metadata },
    };

    this.tokens.set(mint, record);
    this.syncServer(record);
    this.notify(record);
    return record;
  }

  public get(mintAddress: string): TokenRecord | undefined {
    return this.tokens.get(mintAddress.trim());
  }

  public getToken(mintAddress: string): TokenRecord | undefined {
    return this.get(mintAddress);
  }

  public has(mintAddress: string): boolean {
    return this.tokens.has(mintAddress.trim());
  }

  public getAll(): TokenRecord[] {
    return Array.from(this.tokens.values());
  }

  public getByNetwork(network: TradingNetwork): TokenRecord[] {
    return Array.from(this.tokens.values()).filter(t => t.network === network);
  }

  public setExecutionState(mintAddress: string, state: TokenExecutionState, positionId?: string): void {
    const record = this.tokens.get(mintAddress.trim());
    if (record) {
      record.executionState = state;
      record.updatedAt = Date.now();
      if (positionId !== undefined) {
        record.positionId = positionId;
      }
      this.syncServer(record);
      this.notify(record);
    }
  }

  public updatePrice(mintAddress: string, priceSOL: number, priceUSD?: number): void {
    const record = this.tokens.get(mintAddress.trim());
    if (record) {
      record.priceSOL = priceSOL;
      if (priceUSD !== undefined) record.priceUSD = priceUSD;
      record.updatedAt = Date.now();
      this.syncServer(record);
      this.notify(record);
    }
  }

  public subscribe(listener: TokenRegistryListener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify(token: TokenRecord): void {
    for (const listener of this.listeners) {
      try {
        listener(token);
      } catch (err) {
        console.error('[TokenRegistry] Error in listener:', err);
      }
    }
  }
}

export const tokenRegistry = TokenRegistry.getInstance();

import { useActiveWalletStore } from "./store/activeWalletStore";
import { useTradingEnvironmentStore } from "./store/tradingEnvironmentStore";
import { apiClient } from "./services/ApiClient";
import { getKeypairFromPrivateKey, getSavedSessionKeypair, saveSessionKeypair } from './utils/keypairUtils';
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { 
  Search, 
  Activity, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Clock, 
  Wallet, 
  TrendingUp, 
  TrendingDown,
  RefreshCw,
  Terminal,
  Zap,
  Info,
  ShieldAlert,
  BrainCircuit,
  Globe,
  Copy,
  Check,
  Target,
  Bookmark,
  Users,
  Rocket,
  Maximize2,
  Monitor,
  Smartphone
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Connection, PublicKey } from '@solana/web3.js';
import { cn, detectTokenStage } from './lib/utils';
import { setSolPriceUsd, getSolPriceUsd, calcNetPnl, getDynamicOperationalFeeSol } from './utils/pnlUtils';
import { DEFAULT_HELIUS_RPC, HELIUS_API_KEY } from './constants/solana';
import { encryptPrivateKey, decryptPrivateKey } from './lib/crypto';
import { auth, db, signInWithGoogle, signInWithEmailAndPassword, createUserWithEmailAndPassword, authPersistencePromise } from './lib/firebase';
import { onAuthStateChanged, User, signOut } from 'firebase/auth';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  addDoc, 
  deleteDoc, 
  doc, 
  serverTimestamp,
  getDoc,
  setDoc,
} from 'firebase/firestore';
import { Trash2, Plus, LogOut, LogIn, Scan } from 'lucide-react';
import { useAppStore } from './store/appStore';
import { useBalanceStore, getTradingBalance } from './store/balanceStore';
import { SystemCheckPage } from './components/pages/SystemCheckPage';
import { SafetyPage } from './components/pages/SafetyPage';
import { PredictionPage } from './components/pages/PredictionPage';
import { PnLPage } from './components/pages/PnLPage';
import { WalletStatusWidget } from './components/WalletStatusWidget';
import { marketDataManager } from './services/marketDataManager';
import { rpcHealthManager } from './services/rpcHealthManager';
import { masterMonitorHealthManager } from './services/MasterMonitorHealthManager';
import { syncManager } from './services/SyncService';
import { orderManager } from './services/OrderManager';
import { riskManager } from './services/RiskManager';
import { resolveTokenDecimals } from './services/TokenDecimalsResolver';
import { tradingApi } from './services/ApiClient';
import { entryGate } from './services/EntryGate';
import { parseWalletTransaction } from './services/WalletTransactionParser';
import { unifiedTradePipeline } from './engines/unifiedTradePipeline';


import { useWallet, useConnection } from '@solana/wallet-adapter-react';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import { 
  getJupiterQuote, 
  getLatestBlockhashWithFallback, pollSignatureStatus,
  getTokenBalanceRaw,
  getTokenDecimals,
  percentOfRawAmount, 
  verifyHardenedScannerCriteria,
  rpcPool,
  AdvancedTokenMetrics,
  ActivePosition, 
  PositionStage 
} from './services/jupiterService';
import { opportunityScoreEngine, type TradeCandidate, type SecurityStatus } from './services/OpportunityScoreEngine';
import { recordCandidatePrice, checkTokenInProfitLast2Seconds, clearPriceHistories } from './services/priceTracker';
import { Keypair } from '@solana/web3.js';
import bs58 from 'bs58';

// AI integration removed to save tokens

interface SafetyPreset {
  id: string;
  name: string;
  description: string;
  detail: string;
  badge: { bg: string; text: string; border: string };
  values: {
    hardenedMcapMinPump: number;
    hardenedMcapMinRaydium: number;
    hardenedMcapMax: number;
    hardenedLiquidityMin: number;
    hardenedLiquidityRatio: number;
    hardenedMinProfit5m: number;
    hardenedMinUniqueBuyers30s: number;
    hardenedMinBuyCount30s: number;
    hardenedMaxBuyCount30s: number;
    hardenedMaxRiskScore: number;
    hardenedMaxDevOwnership: number;
    hardenedMaxTop10: number;
    slippage: number;
    hardenedMaxLatency: number;
    enableLatencyGuard: boolean;
    hardenedMinBondingProgress: number;
    hardenedMaxBondingProgress: number;
    hardenedMinAge: number;
    hardenedMaxAge: number;
  };
}

const SAFETY_PRESETS: SafetyPreset[] = [
  {
    id: 'conservative',
    name: 'Conservative',
    description: 'Highly filtered, low false-positive rate. Protects capital.',
    detail: 'Optimal for stable trading windows. Restricts entries to established, high-progress sub-launches.',
    badge: { bg: 'bg-emerald-500/10', text: 'text-emerald-400', border: 'border-emerald-500/30' },
    values: {
      hardenedMcapMinPump: 40000,
      hardenedMcapMinRaydium: 80000,
      hardenedMcapMax: 3000000,
      hardenedLiquidityMin: 20000,
      hardenedLiquidityRatio: 5,
      hardenedMinProfit5m: 1.5,
      hardenedMinUniqueBuyers30s: 4,
      hardenedMinBuyCount30s: 5,
      hardenedMaxBuyCount30s: 30,
      hardenedMaxRiskScore: 18,
      hardenedMaxDevOwnership: 10,
      hardenedMaxTop10: 25.0,
      slippage: 1.0,
      hardenedMaxLatency: 250,
      enableLatencyGuard: true,
      hardenedMinBondingProgress: 65,
      hardenedMaxBondingProgress: 100,
      hardenedMinAge: 0,
      hardenedMaxAge: 240
    }
  },
  {
    id: 'aggressive',
    name: 'Aggressive Sniper',
    description: 'Early momentum capture. Higher frequency but increased risk.',
    detail: 'Loosens safeguards to snipe very early. Greater exposure to failed volume cycles and rug pulls.',
    badge: { bg: 'bg-amber-500/10', text: 'text-amber-400', border: 'border-amber-500/30' },
    values: {
      hardenedMcapMinPump: 12000,
      hardenedMcapMinRaydium: 40000,
      hardenedMcapMax: 10000000,
      hardenedLiquidityMin: 7500,
      hardenedLiquidityRatio: 2.5,
      hardenedMinProfit5m: 8,
      hardenedMinUniqueBuyers30s: 2,
      hardenedMinBuyCount30s: 3,
      hardenedMaxBuyCount30s: 60,
      hardenedMaxRiskScore: 5,
      hardenedMaxDevOwnership: 4,
      hardenedMaxTop10: 25,
      slippage: 4.0,
      hardenedMaxLatency: 400,
      enableLatencyGuard: true,
      hardenedMinBondingProgress: 20,
      hardenedMaxBondingProgress: 100,
      hardenedMinAge: 0,
      hardenedMaxAge: 200
    }
  },
  {
    id: 'ultra',
    name: 'Ultra-Aggressive',
    description: 'Pure high-frequency degeneracy. Targets 50x-100x run rate.',
    detail: 'Extreme high-frequency pipeline. Drastically increases exposure to honeypots, rugs, and drawdowns.',
    badge: { bg: 'bg-rose-500/10', text: 'text-rose-400', border: 'border-rose-500/30' },
    values: {
      hardenedMcapMinPump: 5000,
      hardenedMcapMinRaydium: 20000,
      hardenedMcapMax: 15000000,
      hardenedLiquidityMin: 3000,
      hardenedLiquidityRatio: 1.5,
      hardenedMinProfit5m: 0.2,
      hardenedMinUniqueBuyers30s: 1,
      hardenedMinBuyCount30s: 1,
      hardenedMaxBuyCount30s: 150,
      hardenedMaxRiskScore: 35,
      hardenedMaxDevOwnership: 25,
      hardenedMaxTop10: 50.0,
      slippage: 6.5,
      hardenedMaxLatency: 500,
      enableLatencyGuard: true,
      hardenedMinBondingProgress: 10,
      hardenedMaxBondingProgress: 100,
      hardenedMinAge: 0,
      hardenedMaxAge: 240
    }
  },
  {
    id: 'sustainable_hf',
    name: 'Sustainable HF',
    description: 'Experienced balance model. Fast action with fundamental guards.',
    detail: 'Accelerates trade count through sensible early filters without giving up security screening entirely.',
    badge: { bg: 'bg-indigo-500/10', text: 'text-indigo-400', border: 'border-indigo-500/30' },
    values: {
      hardenedMcapMinPump: 15000,
      hardenedMcapMinRaydium: 50000,
      hardenedMcapMax: 5000000,
      hardenedLiquidityMin: 10000,
      hardenedLiquidityRatio: 4.0,
      hardenedMinProfit5m: 1.2,
      hardenedMinUniqueBuyers30s: 3,
      hardenedMinBuyCount30s: 4,
      hardenedMaxBuyCount30s: 50,
      hardenedMaxRiskScore: 22,
      hardenedMaxDevOwnership: 12,
      hardenedMaxTop10: 30.0,
      slippage: 2.5,
      hardenedMaxLatency: 300,
      enableLatencyGuard: true,
      hardenedMinBondingProgress: 40,
      hardenedMaxBondingProgress: 100,
      hardenedMinAge: 0,
      hardenedMaxAge: 240
    }
  }
];

const NARRATIVE_KEYWORDS = ['AI', 'AGENT', 'GPT', 'ZK', 'PROOF', 'SOL', 'MASK'];

import { SniperTrade, Trade, TokenMetric, TelemetryAlert } from './types';

interface WalletStats {
  balance: number;
  totalTrades: number;
  winRate: number;
  profit24h: number;
  category: string;
}

interface SavedGem {
  address: string;
  symbol: string;
  priceAtSave: number;
  tokensPerDollarAtSave: number;
  savedAt: number;
  marketCapAtSave: number;
  category?: string;
}

const normalizeTimestamp = (ts: number | undefined): number => {
  if (!ts) return Date.now();
  return ts < 1000000000000 ? ts * 1000 : ts;
};

const formatAge = (createdAt: number | undefined, discoveredAt: number | undefined) => {
  const timestamp = createdAt ? normalizeTimestamp(createdAt) : (discoveredAt || Date.now());
  const diff = Date.now() - timestamp;
  
  if (diff < 0) return 'Just now';
  
  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  
  if (days > 0) return `${days}d ${hours % 24}h`;
  if (hours > 0) return `${hours}h ${minutes % 60}m`;
  if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
  return `${seconds}s`;
};

const calculateMinimumSellOutput = (
  initialInvestmentSol: number,
  targetProfitPct: number,
  estimatedFeesSol: number
): number => {
  const desiredReturnSol = initialInvestmentSol * (1.0 + (targetProfitPct / 100.0));
  return desiredReturnSol + estimatedFeesSol;
};

const categorizeToken = (symbol: string | undefined, address: string | undefined): string => {
  const s = (symbol || '').toUpperCase();
  const a = (address || '').toLowerCase();
  
  // 1. AI category - Priorities AI, GPT, Intelligence
  const isAi = s.includes('AI') || s.includes('GPT') || s.includes('NEURO') || 
                s.includes('AGENT') || s.includes('MODEL') || s.includes('BOT') || 
                s.includes('MIND') || s.includes('BRAIN') || s.includes('INTELLIG') ||
                s.includes('GPU') || s.includes('CPU') || s.includes('COMPUTE') ||
                s.includes('GEMINI') || s.includes('LLM') || s.includes('TRAIN') ||
                s.includes('GEN') || s.includes('NEURAL') || s.includes('DEEP') ||
                s.includes('LEARNK') || s.includes('BARD') || s.includes('CLAUDE');

  // AI Meme Fusion - 2026 Trend
  const isMemeRef = s.includes('PEPE') || s.includes('DOGE') || s.includes('SHIB') || s.includes('CAT') || s.includes('FROG');
  if (isAi && isMemeRef) return 'AI_MEME';
  if (isAi) return 'AI';
  
  // 2. PolitiFi - Political narratives
  if (s.includes('TRUMP') || s.includes('MAGA') || s.includes('BIDEN') || 
      s.includes('POLITI') || s.includes('VOTE') || s.includes('USA') ||
      s.includes('ELECTION') || s.includes('DEM') || s.includes('REP')) return 'POLITIFI';

  // 3. DeFI - Swaps, Lending, Yield
  if (s.includes('SWAP') || s.includes('LEND') || s.includes('YIELD') || 
      s.includes('POOL') || s.includes('FINANCE') || s.includes('STAKE') ||
      s.includes('DEX') || s.includes('DAO') || s.includes('STABLE') ||
      s.includes('VAULT') || s.includes('LIQUID') || s.includes('BRIDGE') ||
      s.includes('ORACLE') || s.includes('LRT') || s.includes('LST')) return 'DEFI';

  // 3. DePIN - Infrastructure & Data
  if (s.includes('DEPIN') || s.includes('NET') || s.includes('CHAIN') || 
      s.includes('SCAN') || s.includes('NODE') || s.includes('DATA') ||
      s.includes('HNT') || s.includes('MOBILE') || s.includes('IOT') ||
      s.includes('GPS') || s.includes('MAP') || s.includes('STORAGE') ||
      s.includes('WIFI') || s.includes('RENDER') || s.includes('GRID') ||
      s.includes('MESH') || s.includes('CLOUD')) return 'DEPIN';

  // 4. GameFi - Games & Virtual Worlds
  if (s.includes('GAME') || s.includes('VERSE') || s.includes('PLAY') || 
      s.includes('SKIN') || s.includes('QUEST') || s.includes('META') ||
      s.includes('AXS') || s.includes('GUILD') || s.includes('BATTLE') ||
      s.includes('RPG') || s.includes('LEVEL') || s.includes('GAMER')) return 'GAMEFI';

  // 5. RWA - Assets & Real World
  if (s.includes('RWA') || s.includes('GOLD') || s.includes('PROPERTY') || 
      s.includes('LAND') || s.includes('REAL') || s.includes('ONDO') ||
      s.includes('PENDLE') || s.includes('HOME') || s.includes('RENT') ||
      s.includes('BOND') || s.includes('USDY') || s.includes('USTY') ||
      s.includes('COMMODITY') || s.includes('BTC') || s.includes('ETH')) return 'RWA';

  // 6. Platform specific - Pump.fun tokens (if no sector matched above)
  if (a.endsWith('pump')) return 'MEME';

  // 7. Meme category - Animals, Characters, etc.
  const memeKeywords = [
    'DOGE', 'PEPE', 'SHIB', 'FLOKI', 'PUPPY', 'CAT', 'ELON', 'TRUMP', 
    'MOON', 'INU', 'WIF', 'BONK', 'MEME', 'BULL', 'BEAR', 
    'COIN', 'KITT', 'FROG', 'MOODENG', 'HYPE', 'BABY', 'MINI', 
    'KING', 'CHAD', 'GOAT', 'PUMP', 'ASTR', 'WOJAK', 'PAPA', 'MAMA',
    'COMMUNITY', 'FAN', 'RARE', 'GOLDEN', 'DIAMOND', 'CULT'
  ];
  
  if (memeKeywords.some(key => s.includes(key))) return 'MEME';
      
  return 'DEFI'; // Default to DEFI for non-pump tokens if no other match
};

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [currentPage, setCurrentPage] = useState<'dashboard' | 'high-buy' | 'portfolio' | 'system-check' | 'discovery'>('dashboard');
  const [alphaSubTab, setAlphaSubTab] = useState<'high-buy' | 'safety' | 'prediction' | 'intel'>('high-buy');
  const [viewMode, setViewMode] = useState<'responsive' | 'mobile' | 'laptop'>('responsive');
  const [alphaProtocol, setAlphaProtocol] = useState<'ALL' | 'HIGH_PROFIT' | 'WHALE_BUY' | 'NEW_DISCOVERY' | 'SNIPER' | 'GEMS_100X' | 'MIGRATED'>('ALL');
  
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    if (location.pathname === '/portfolio') {
      setCurrentPage('portfolio');
    }
  }, [location.pathname]);

  const renderAlphaHeader = () => {
    return (
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 bg-slate-900/40 border border-slate-800 p-4 rounded-3xl backdrop-blur-xl mb-4 w-full">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 flex items-center justify-center border border-indigo-500/20">
            <Zap className="w-6 h-6 text-indigo-400" />
          </div>
          <div>
            <h2 className="text-sm font-black text-white uppercase tracking-tighter leading-none mb-1">Arina X-Ray Alpha Hub</h2>
            <p className="text-[9px] text-slate-500 uppercase tracking-widest font-bold">Select mode for real-time intelligence & strategies</p>
          </div>
        </div>
        <div className="flex items-center gap-2 p-1 bg-slate-950/80 rounded-2xl border border-slate-800 overflow-x-auto scrollbar-none">
          {[
            { id: 'high-buy', label: 'Whale Scraper', icon: ArrowUpRight, desc: 'Large buys' },
            { id: 'safety', label: 'Safety Vision', icon: ShieldAlert, desc: 'Rug security' },
            { id: 'prediction', label: '100x Prediction', icon: BrainCircuit, desc: 'AI sentiment' },
            { id: 'intel', label: 'WSS Intel', icon: Activity, desc: 'Live signals' }
          ].map((tab) => {
            const Icon = tab.icon;
            const active = alphaSubTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setAlphaSubTab(tab.id as any)}
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-xl transition-all whitespace-nowrap relative cursor-pointer",
                  active ? "bg-indigo-600 text-white shadow-lg" : "text-slate-500 hover:text-slate-300"
                )}
              >
                <Icon className="w-3.5 h-3.5" />
                <div className="flex flex-col items-start">
                  <span className="text-[9px] font-black uppercase tracking-tight leading-none mb-0.5">{tab.label}</span>
                  <span className="text-[6px] uppercase font-bold tracking-widest opacity-60">{tab.desc}</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    );
  };

  const [manualGemInput, setManualGemInput] = useState('');
  const [tokenSearchValue, setTokenSearchValue] = useState('');
  const [isAddingGem, setIsAddingGem] = useState(false);
  const [sectorFilter, setSectorFilter] = useState<'ALL' | 'AI' | 'MEME' | 'GAMEFI' | 'DEPIN' | 'RWA' | 'DEFI' | 'POLITIFI' | 'AI_MEME'>('ALL');
  const [trackedFilter, setTrackedFilter] = useState<'ALL' | 'PROFIT' | 'LOSS'>('ALL');
  const { telemetryAlerts, tokenMetrics, addTelemetryAlert, setTelemetryAlerts, setTokenMetrics, trades, setTrades, mySniperTrades, setMySniperTrades } = useAppStore();
  const [telemetryBits, setTelemetryBits] = useState<boolean[]>(Array(12).fill(false));
  const [monitoredWallets, setMonitoredWallets] = useState<{id: string, address: string, label: string}[]>([]);
  const alertedTokens = useRef<Set<string>>(new Set());
  const [address, setAddress] = useState('');
  const [walletLabel, setWalletLabel] = useState('');
  const { publicKey, sendTransaction, wallet } = useWallet();
  const { connection } = useConnection();
  
  
  const [autoSniperEnabled, setAutoSniperEnabled] = useState(false);
  const { isLiveTrading, setIsLiveTrading } = useAppStore(); // Synced with appStore & TradeModeContext
  const [buyAmountSol, setBuyAmountSol] = useState(() => Number(localStorage.getItem('app_buyAmountSol')) || 0.1);
  // buyAmountSol also lives in useAppStore (read directly via storeState.buyAmountSol
  // never updated after initial load - so changing the buy amount in the UI here had
  // no effect on live/automated trades until a full page reload. Keep them in sync.
  useEffect(() => {
    useAppStore.setState({ buyAmountSol });
  }, [buyAmountSol]);
  const [minTakeProfit, setMinTakeProfit] = useState(() => Number(localStorage.getItem('app_minTakeProfit')) || 15);
  const [maxTakeProfit, setMaxTakeProfit] = useState(() => Number(localStorage.getItem('app_maxTakeProfit')) || 50);
  const [bondingCurveTakeProfit, setBondingCurveTakeProfit] = useState(() => Number(localStorage.getItem('app_bondingCurveTakeProfit')) || 25);
  const [moonbagStrategy, setMoonbagStrategy] = useState(() => localStorage.getItem('app_moonbagStrategy') === 'true');
  const [stopLoss, setStopLoss] = useState(() => Number(localStorage.getItem('app_stopLoss')) || -15);
  const [bondingCurveStopLoss, setBondingCurveStopLoss] = useState(() => Number(localStorage.getItem('app_bondingCurveStopLoss')) || -15);
  const [pumpSwapStopLoss, setPumpSwapStopLoss] = useState(() => Number(localStorage.getItem('app_pumpSwapStopLoss')) || -15);
  const [unknownStopLoss, setUnknownStopLoss] = useState(() => Number(localStorage.getItem('app_unknownStopLoss')) || -20);
  const [maxPositions, setMaxPositions] = useState(() => Number(localStorage.getItem('app_maxPositions')) || 5);
  
  const updateMasterStopLoss = (val: number) => {
    const sl = -Math.abs(val);
    setStopLoss(sl);
    setBondingCurveStopLoss(sl);
    setPumpSwapStopLoss(sl);
    setUnknownStopLoss(sl);
  };
  const [slippage, setSlippage] = useState(1.0); 
  const [apiKey, setApiKey] = useState(() => localStorage.getItem('jupiter_auto_apiKey') || localStorage.getItem('juipter_auto_apiKey') || '');
  const [jupiterRpcUrl, setJupiterRpcUrl] = useState(() => localStorage.getItem('juipter_auto_jupiterRpcUrl') || '');
  const { activePositions, updateActivePositions: setActivePositions } = useAppStore();
  const activeWalletStore = useActiveWalletStore();
  const sessionWallet = activeWalletStore.activeWallet?.keypair || null;
  const activeAddress = activeWalletStore.activeWallet?.address || null;
  const [privateKey, setPrivateKeyState] = useState(() => {
    const saved = activeWalletStore.activeWallet?.keypair;
    return saved ? bs58.encode(saved.secretKey) : '';
  });
  const [telegramBotToken, setTelegramBotToken] = useState(() => localStorage.getItem('tg_bot_token') || '');
  const [telegramChatId, setTelegramChatId] = useState(() => localStorage.getItem('tg_chat_id') || '');

  const setPrivateKey = useCallback((newKey: string) => {
    setPrivateKeyState(newKey);
    const envNet = useTradingEnvironmentStore.getState().network || 'paper';
    if (newKey && newKey.trim()) {
      try {
        const kp = getKeypairFromPrivateKey(newKey.trim());
        activeWalletStore.switchActiveWallet({ keypair: kp, network: envNet, source: "session" });
      } catch {}
    } else {
      activeWalletStore.switchActiveWallet({ keypair: null, network: envNet, source: "session" });
    }
  }, [activeWalletStore]);

  useEffect(() => {
    if (sessionWallet) {
      const encoded = bs58.encode(sessionWallet.secretKey);
      setPrivateKeyState((prev) => (prev !== encoded ? encoded : prev));
    }
  }, [sessionWallet]);

  useEffect(() => {
    localStorage.setItem('jupiter_auto_apiKey', apiKey);
  }, [apiKey]);
  useEffect(() => {
    localStorage.setItem('juipter_auto_jupiterRpcUrl', jupiterRpcUrl);
  }, [jupiterRpcUrl]);

  // Save encrypted private key to localStorage
  useEffect(() => {
    if (!privateKey) {
      return;
    }
    let active = true;
    const encryptAndStore = async () => {
      const uid = user?.uid || 'default_app_offline_salt';
      const encrypted = await encryptPrivateKey(privateKey, uid);
      if (active) {
        localStorage.setItem('juipter_auto_privateKey', encrypted);
      }
    };
    encryptAndStore();
    return () => { active = false; };
  }, [privateKey, user?.uid]);

  // Load authoritative trading config from backend worker API on mount
  useEffect(() => {
    apiClient.get('/api/trading/config')
      .then(data => {
        if (data && data.config) {
          const cfg = data.config;
          if (cfg.buyAmountSol) setBuyAmountSol(cfg.buyAmountSol);
          if (cfg.minTakeProfit) setMinTakeProfit(cfg.minTakeProfit);
          if (cfg.maxTakeProfit) setMaxTakeProfit(cfg.maxTakeProfit);
          if (cfg.stopLoss) setStopLoss(cfg.stopLoss);
          if (cfg.maxPositions) setMaxPositions(cfg.maxPositions);
          if (cfg.minLiquidityUsd) setHardenedLiquidityMin(cfg.minLiquidityUsd);
          if (cfg.minAgeMinutes !== undefined) setHardenedMinAge(cfg.minAgeMinutes);
          if (cfg.maxAgeMinutes !== undefined) setHardenedMaxAge(cfg.maxAgeMinutes);
        }
      })
      .catch(err => console.warn('[App] Failed to load server trading config:', err));
  }, []);
  useEffect(() => {
    localStorage.setItem('app_buyAmountSol', buyAmountSol.toString());
    localStorage.setItem('app_minTakeProfit', minTakeProfit.toString());
    localStorage.setItem('app_maxTakeProfit', maxTakeProfit.toString());
    localStorage.setItem('app_bondingCurveTakeProfit', bondingCurveTakeProfit.toString());
    localStorage.setItem('app_moonbagStrategy', moonbagStrategy.toString());
    localStorage.setItem('app_stopLoss', stopLoss.toString());
    localStorage.setItem('app_bondingCurveStopLoss', bondingCurveStopLoss.toString());
    localStorage.setItem('app_pumpSwapStopLoss', pumpSwapStopLoss.toString());
    localStorage.setItem('app_unknownStopLoss', unknownStopLoss.toString());
    localStorage.setItem('app_maxPositions', maxPositions.toString());
  }, [buyAmountSol, minTakeProfit, maxTakeProfit, bondingCurveTakeProfit, moonbagStrategy, stopLoss, bondingCurveStopLoss, pumpSwapStopLoss, unknownStopLoss, maxPositions]);

  useEffect(() => {
    localStorage.setItem('tg_bot_token', telegramBotToken);
    localStorage.setItem('tg_chat_id', telegramChatId);
  }, [telegramBotToken, telegramChatId]);
  
  const [isMonitoring, setIsMonitoring] = useState(false);

  // Hardened Entry Scanner Criteria state values (customizable by user)
  const [hardenedMcapMinPump, setHardenedMcapMinPump] = useState(() => Number(localStorage.getItem('hd_mcap_min_pump')) || 40000);
  const [hardenedMcapMinRaydium, setHardenedMcapMinRaydium] = useState(() => Number(localStorage.getItem('hd_mcap_min_raydium')) || 80000);
  const [hardenedMcapMax, setHardenedMcapMax] = useState(() => Number(localStorage.getItem('hd_mcap_max')) || 3000000);
  const [hardenedLiquidityMin, setHardenedLiquidityMin] = useState(() => Number(localStorage.getItem('hd_liquidity_min')) || 20000);
  const [hardenedLiquidityRatio, setHardenedLiquidityRatio] = useState(() => Number(localStorage.getItem('hd_liquidity_ratio')) || 5); // stored as percentage (5%)
  const [hardenedMaxRiskScore, setHardenedMaxRiskScore] = useState(() => Number(localStorage.getItem('hd_max_risk_score')) || 18);
  const [hardenedMaxDevOwnership, setHardenedMaxDevOwnership] = useState(() => Number(localStorage.getItem('hd_max_dev_ownership')) || 10); // stored as percentage (10%)
  const [hardenedMaxTop10, setHardenedMaxTop10] = useState(() => Number(localStorage.getItem('hd_max_top10')) || 25.0); // stored as percentage (25%)
  const [hardenedMinUniqueBuyers30s, setHardenedMinUniqueBuyers30s] = useState(() => Number(localStorage.getItem('hd_min_unique_buyers_30s')) || 4);
  const [hardenedMinBuyCount30s, setHardenedMinBuyCount30s] = useState(() => Number(localStorage.getItem('hd_min_buy_count_30s')) || 5);
  const [hardenedMaxBuyCount30s, setHardenedMaxBuyCount30s] = useState(() => Number(localStorage.getItem('hd_max_buy_count_30s')) || 30);
  const [hardenedMinBuySellRatio, setHardenedMinBuySellRatio] = useState(() => Number(localStorage.getItem('hd_min_buysell_ratio')) || 2.0);
  const [hardenedMaxBuySellRatio, setHardenedMaxBuySellRatio] = useState(() => Number(localStorage.getItem('hd_max_buysell_ratio')) || 10.0);
  const [hardenedMaxPriceChange1m, setHardenedMaxPriceChange1m] = useState(() => Number(localStorage.getItem('hd_max_price_change_1m')) || 15.0);
  const [hardenedMinBondingProgress, setHardenedMinBondingProgress] = useState(() => {
    const saved = localStorage.getItem('hd_min_bonding_progress');
    return saved !== null ? Number(saved) : 65;
  });
  const [hardenedMaxBondingProgress, setHardenedMaxBondingProgress] = useState(() => {
    const saved = localStorage.getItem('hd_max_bonding_progress');
    return saved !== null ? Number(saved) : 100;
  });
  const [hardenedMinAge, setHardenedMinAge] = useState(() => {
    const saved = localStorage.getItem('hd_min_age');
    return saved !== null ? Number(saved) : 0;
  });
  const [hardenedMaxAge, setHardenedMaxAge] = useState(() => {
    const saved = localStorage.getItem('hd_max_age');
    return saved !== null ? Number(saved) : 240;
  });
  const [hardenedMinLatency, setHardenedMinLatency] = useState(() => {
    const saved = localStorage.getItem('hd_min_latency');
    return saved !== null ? Number(saved) : 0;
  });
  const [hardenedMaxLatency, setHardenedMaxLatency] = useState(() => {
    const saved = localStorage.getItem('hd_max_latency');
    return saved !== null ? Number(saved) : 250;
  });

  const [hardenedMatchRequirement, setHardenedMatchRequirement] = useState(() => {
    const saved = localStorage.getItem('hd_match_requirement');
    return saved !== null ? Number(saved) : 50;
  });

  const [enableLatencyGuard, setEnableLatencyGuard] = useState(() => {
    const saved = localStorage.getItem('hd_enable_latency_guard');
    return saved !== null ? saved === 'true' : true;
  });
  const [telemetryWhaleBuyMin, setTelemetryWhaleBuyMin] = useState(() => Number(localStorage.getItem('hd_telemetry_whale_buy')) || 500000);
  const [telemetryHighBuyMin, setTelemetryHighBuyMin] = useState(() => Number(localStorage.getItem('hd_telemetry_high_buy')) || 100000);
  const [telemetryVolumeSpikeMin, setTelemetryVolumeSpikeMin] = useState(() => Number(localStorage.getItem('hd_telemetry_volume_spike')) || 1000);
  const [telemetryAllowWhaleBuy, setTelemetryAllowWhaleBuy] = useState(() => localStorage.getItem('hd_telemetry_allow_whale') !== 'false');
  const [telemetryAllowHighBuy, setTelemetryAllowHighBuy] = useState(() => localStorage.getItem('hd_telemetry_allow_high') !== 'false');
  const [telemetryAllowVolumeSpike, setTelemetryAllowVolumeSpike] = useState(() => localStorage.getItem('hd_telemetry_allow_vol') !== 'false');
  const [telemetryAllowMigrated, setTelemetryAllowMigrated] = useState(() => localStorage.getItem('hd_telemetry_allow_migr') !== 'false');
  const [telemetryAllowGoldenCross, setTelemetryAllowGoldenCross] = useState(() => localStorage.getItem('hd_telemetry_allow_gold') !== 'false');

  const [tradePumpFun, setTradePumpFun] = useState(() => {
    const saved = localStorage.getItem('hd_trade_pump_fun');
    return saved !== null ? saved === 'true' : true;
  });
  const [tradeRaydium, setTradeRaydium] = useState(() => {
    const saved = localStorage.getItem('hd_trade_raydium');
    return saved !== null ? saved === 'true' : true;
  });
  const [tradeBonding, setTradeBonding] = useState(() => {
    const saved = localStorage.getItem('hd_trade_bonding');
    return saved !== null ? saved === 'true' : true;
  });
  const [tradeUnknown, setTradeUnknown] = useState(() => {
    const saved = localStorage.getItem('hd_trade_unknown');
    return saved !== null ? saved === 'true' : true;
  });
  const [hardenedMinProfit5m, setHardenedMinProfit5m] = useState(() => {
    const saved = localStorage.getItem('hd_min_profit_5m');
    return saved !== null ? Number(saved) : 1.5;
  });
  const [maxRebuyTimes, setMaxRebuyTimes] = useState<number>(() => {
    const saved = localStorage.getItem('hd_max_rebuy_times');
    if (saved !== null) {
      const parsed = Number(saved);
      if (!isNaN(parsed) && parsed > 0) return parsed;
    }
    return 1;
  });
  const [tradeOnlyOnce, setTradeOnlyOnce] = useState<boolean>(() => {
    const saved = localStorage.getItem('app_tradeOnlyOnce');
    if (saved !== null) return saved === 'true';
    const savedHd = localStorage.getItem('hd_trade_only_once');
    if (savedHd !== null) return savedHd === 'true';
    return true;
  });

  useEffect(() => {
    // Legacy expert_criteria_v3 initializer removed to prevent destructive resets
  }, []);

  const [rpcLatency, setRpcLatency] = useState<number | null>(null);
  const [rpcUrl, setRpcUrl] = useState(() => {
    const raw = localStorage.getItem('juipter_auto_rpcUrl') || DEFAULT_HELIUS_RPC;
    return raw.includes('winter-methodical-river') ? DEFAULT_HELIUS_RPC : raw;
  });
  const [rpcUrl2, setRpcUrl2] = useState(() => {
    const raw = localStorage.getItem('juipter_auto_rpcUrl2') || DEFAULT_HELIUS_RPC;
    return raw.includes('winter-methodical-river') ? DEFAULT_HELIUS_RPC : raw;
  });
  const [customWsUrl, setCustomWsUrl] = useState(() => localStorage.getItem('juipter_auto_wsUrl') || '');
  const [masterMonitorRpc, setMasterMonitorRpc] = useState(() => {
    const raw = localStorage.getItem('master_monitor_rpc') || '';
    return raw.includes('winter-methodical-river') ? '' : raw;
  });
  const [masterMonitorRpc2, setMasterMonitorRpc2] = useState(() => localStorage.getItem('master_monitor_rpc2') || '');
  const [masterMonitorWs, setMasterMonitorWs] = useState(() => localStorage.getItem('master_monitor_ws') || '');
  const [isSecondaryActive, setIsSecondaryActive] = useState(() => localStorage.getItem('juipter_rpc_secondary_active') === 'true');

  useEffect(() => {
    localStorage.setItem('juipter_auto_rpcUrl', rpcUrl);
  }, [rpcUrl]);

  useEffect(() => {
    localStorage.setItem('juipter_auto_rpcUrl2', rpcUrl2);
  }, [rpcUrl2]);

  useEffect(() => {
    localStorage.setItem('juipter_auto_wsUrl', customWsUrl);
  }, [customWsUrl]);

  useEffect(() => {
    masterMonitorHealthManager.setEndpoints(masterMonitorRpc, masterMonitorRpc2, masterMonitorWs);
    void tradingApi.getPositions().catch(() => {});
  }, [masterMonitorRpc, masterMonitorRpc2, masterMonitorWs, rpcUrl]);
  const [isHardenedCriteriaExpanded, setIsHardenedCriteriaExpanded] = useState(false);
  const [activePreset, setActivePreset] = useState<string>(() => localStorage.getItem('app_active_preset') || 'custom');

  useEffect(() => {
    localStorage.setItem('app_active_preset', activePreset);
    localStorage.setItem('hd_mcap_min_pump', hardenedMcapMinPump.toString());
    localStorage.setItem('hd_mcap_min_raydium', hardenedMcapMinRaydium.toString());
    localStorage.setItem('hd_mcap_max', hardenedMcapMax.toString());
    localStorage.setItem('hd_liquidity_min', hardenedLiquidityMin.toString());
    localStorage.setItem('hd_liquidity_ratio', hardenedLiquidityRatio.toString());
    localStorage.setItem('hd_max_risk_score', hardenedMaxRiskScore.toString());
    localStorage.setItem('hd_max_dev_ownership', hardenedMaxDevOwnership.toString());
    localStorage.setItem('hd_max_top10', hardenedMaxTop10.toString());
    localStorage.setItem('hd_min_unique_buyers_30s', hardenedMinUniqueBuyers30s.toString());
    localStorage.setItem('hd_min_buy_count_30s', hardenedMinBuyCount30s.toString());
    localStorage.setItem('hd_max_buy_count_30s', hardenedMaxBuyCount30s.toString());
    localStorage.setItem('hd_min_buysell_ratio', hardenedMinBuySellRatio.toString());
    localStorage.setItem('hd_max_buysell_ratio', hardenedMaxBuySellRatio.toString());
    localStorage.setItem('hd_max_price_change_1m', hardenedMaxPriceChange1m.toString());
    localStorage.setItem('hd_min_bonding_progress', hardenedMinBondingProgress.toString());
    localStorage.setItem('hd_max_bonding_progress', hardenedMaxBondingProgress.toString());
    localStorage.setItem('hd_min_age', hardenedMinAge.toString());
    localStorage.setItem('hd_max_age', hardenedMaxAge.toString());
    localStorage.setItem('hd_min_latency', hardenedMinLatency.toString());
    localStorage.setItem('hd_max_latency', hardenedMaxLatency.toString());
    localStorage.setItem('hd_match_requirement', hardenedMatchRequirement.toString());
    localStorage.setItem('hd_trade_pump_fun', tradePumpFun.toString());
    localStorage.setItem('hd_trade_raydium', tradeRaydium.toString());
    localStorage.setItem('hd_trade_bonding', tradeBonding.toString());
    localStorage.setItem('hd_trade_unknown', tradeUnknown.toString());
    localStorage.setItem('hd_min_profit_5m', hardenedMinProfit5m.toString());
    localStorage.setItem('hd_max_rebuy_times', maxRebuyTimes.toString());
    localStorage.setItem('hd_trade_only_once', tradeOnlyOnce.toString());
    localStorage.setItem('app_tradeOnlyOnce', tradeOnlyOnce.toString());
    localStorage.setItem('hd_enable_latency_guard', enableLatencyGuard.toString());
    localStorage.setItem('hd_telemetry_allow_whale', telemetryAllowWhaleBuy.toString());
    localStorage.setItem('hd_telemetry_allow_high', telemetryAllowHighBuy.toString());
    localStorage.setItem('hd_telemetry_allow_vol', telemetryAllowVolumeSpike.toString());
    localStorage.setItem('hd_telemetry_allow_migr', telemetryAllowMigrated.toString());
    localStorage.setItem('hd_telemetry_allow_gold', telemetryAllowGoldenCross.toString());
    localStorage.setItem('hd_telemetry_whale_buy', telemetryWhaleBuyMin.toString());
    localStorage.setItem('hd_telemetry_high_buy', telemetryHighBuyMin.toString());
    localStorage.setItem('hd_telemetry_volume_spike', telemetryVolumeSpikeMin.toString());
  }, [
    hardenedMcapMinPump, hardenedMcapMinRaydium, hardenedMcapMax, hardenedLiquidityMin,
    hardenedLiquidityRatio, hardenedMaxRiskScore, hardenedMaxDevOwnership, hardenedMaxTop10,
    hardenedMinUniqueBuyers30s, hardenedMinBuyCount30s, hardenedMaxBuyCount30s,
    hardenedMinBuySellRatio, hardenedMaxBuySellRatio, hardenedMaxPriceChange1m,
    hardenedMinBondingProgress, hardenedMaxBondingProgress, hardenedMinAge, hardenedMaxAge,
    hardenedMinLatency, hardenedMaxLatency, hardenedMatchRequirement, tradePumpFun, tradeRaydium, tradeBonding, tradeUnknown, hardenedMinProfit5m, maxRebuyTimes, tradeOnlyOnce, enableLatencyGuard,
    telemetryAllowWhaleBuy, telemetryAllowHighBuy, telemetryAllowVolumeSpike, telemetryAllowMigrated, telemetryAllowGoldenCross,
    telemetryWhaleBuyMin, telemetryHighBuyMin, telemetryVolumeSpikeMin, activePreset
  ]);

  const applyPreset = (preset: any) => {
    setActivePreset(preset.id);
    setHardenedMcapMinPump(preset.values.hardenedMcapMinPump);
    setHardenedMcapMinRaydium(preset.values.hardenedMcapMinRaydium);
    setHardenedMcapMax(preset.values.hardenedMcapMax);
    setHardenedLiquidityMin(preset.values.hardenedLiquidityMin);
    setHardenedLiquidityRatio(preset.values.hardenedLiquidityRatio);
    setHardenedMinProfit5m(preset.values.hardenedMinProfit5m);
    setHardenedMinUniqueBuyers30s(preset.values.hardenedMinUniqueBuyers30s);
    setHardenedMinBuyCount30s(preset.values.hardenedMinBuyCount30s);
    setHardenedMaxBuyCount30s(preset.values.hardenedMaxBuyCount30s);
    setHardenedMaxRiskScore(preset.values.hardenedMaxRiskScore);
    setHardenedMaxDevOwnership(preset.values.hardenedMaxDevOwnership);
    setHardenedMaxTop10(preset.values.hardenedMaxTop10);
    setSlippage(preset.values.slippage);
    setHardenedMaxLatency(preset.values.hardenedMaxLatency);
    setEnableLatencyGuard(preset.values.enableLatencyGuard);
    setHardenedMinBondingProgress(preset.values.hardenedMinBondingProgress);
    setHardenedMaxBondingProgress(preset.values.hardenedMaxBondingProgress);
    setHardenedMinAge(preset.values.hardenedMinAge);
    setHardenedMaxAge(preset.values.hardenedMaxAge);
    addNotification(`Safety Guard Update: Optimized scanner limits for '${preset.name}' model!`);
  };

  useEffect(() => {
    if (activePreset === 'custom') return;
    const currentPreset = SAFETY_PRESETS.find(p => p.id === activePreset);
    if (!currentPreset) return;
    const v = currentPreset.values;
    const matches = 
      hardenedMcapMinPump === v.hardenedMcapMinPump &&
      hardenedMcapMinRaydium === v.hardenedMcapMinRaydium &&
      hardenedMcapMax === v.hardenedMcapMax &&
      hardenedLiquidityMin === v.hardenedLiquidityMin &&
      hardenedLiquidityRatio === v.hardenedLiquidityRatio &&
      hardenedMinProfit5m === v.hardenedMinProfit5m &&
      hardenedMinUniqueBuyers30s === v.hardenedMinUniqueBuyers30s &&
      hardenedMinBuyCount30s === v.hardenedMinBuyCount30s &&
      hardenedMaxBuyCount30s === v.hardenedMaxBuyCount30s &&
      hardenedMaxRiskScore === v.hardenedMaxRiskScore &&
      hardenedMaxDevOwnership === v.hardenedMaxDevOwnership &&
      hardenedMaxTop10 === v.hardenedMaxTop10 &&
      slippage === v.slippage &&
      hardenedMaxLatency === v.hardenedMaxLatency &&
      enableLatencyGuard === v.enableLatencyGuard &&
      hardenedMinBondingProgress === v.hardenedMinBondingProgress &&
      hardenedMaxBondingProgress === v.hardenedMaxBondingProgress &&
      hardenedMinAge === v.hardenedMinAge &&
      hardenedMaxAge === v.hardenedMaxAge;
    
    if (!matches) {
      setActivePreset('custom');
    }
  }, [
    hardenedMcapMinPump, hardenedMcapMinRaydium, hardenedMcapMax, hardenedLiquidityMin,
    hardenedLiquidityRatio, hardenedMinProfit5m, hardenedMinUniqueBuyers30s, hardenedMinBuyCount30s,
    hardenedMaxBuyCount30s, hardenedMaxRiskScore, hardenedMaxDevOwnership, hardenedMaxTop10,
    slippage, hardenedMaxLatency, enableLatencyGuard, hardenedMinBondingProgress, hardenedMaxBondingProgress,
    hardenedMinAge, hardenedMaxAge,
    activePreset
  ]);

  const [isXRayEnabled, setIsXRayEnabled] = useState(true);
  
  // ... (find the return block and look for currentPage rendering) ...
  const [isExportingKey, setIsExportingKey] = useState(false);
  const [tradingStatus, setTradingStatus] = useState<string | null>(null);
  const [highProfitAlert, setHighProfitAlert] = useState<{ symbol: string, address: string, profit: number } | null>(null);
  const [isAutoExecutionPending, setIsAutoExecutionPending] = useState(false);

  // API Health Check
  useEffect(() => {
    fetch('/api/health')
      .then(async r => {
        const text = await r.text().catch(() => '');
        if (!r.ok) {
          throw new Error(`HTTP ${r.status}: ${text || r.statusText}`);
        }
        try {
          return JSON.parse(text);
        } catch {
          return { status: 'warning', message: text };
        }
      })
      .then(data => console.log('✅ Matrix Backend Connected:', data))
      .catch((err: any) => console.warn('⚠️ Matrix Backend Connectivity Status:', err?.message || err));
  }, []);

  const sendTelegramAlert = async (msg: string, silent = false) => {
    if (!telegramBotToken || !telegramChatId) {
      if (!silent) setTradingStatus('⚠️ Configure Telegram Bot Token and Chat ID first');
      return;
    }
    
    if (!silent) setTradingStatus('📡 Sending Telegram Alert...');
    try {
      const response = await fetch('/api/telegram', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token: telegramBotToken,
          chatId: telegramChatId,
          text: msg
        })
      });
      
      const data = await response.json();
      
      if (response.ok) {
        if (!silent) setTradingStatus('✅ Telegram Alert Sent Successfully');
      } else {
        const errorMsg = data.error || data.description || 'Unknown error';
        if (!silent) {
          setTradingStatus(`❌ Telegram Error: ${errorMsg}`);
          throw new Error(`Telegram Error: ${errorMsg}`);
        } else {
          console.warn('Telegram API notification suppressed:', errorMsg);
        }
      }
    } catch (err: any) {
      if (!silent) {
        setTradingStatus('❌ Telegram Alert Failed');
        console.error('Telegram Proxy Fetch failed:', err);
        throw err;
      } else {
        console.warn('Silent Telegram alert caught:', err.message || err);
      }
    } finally {
      if (!silent) setTimeout(() => setTradingStatus(null), 5000);
    }
  };

  // Wallet Connection Alert
  useEffect(() => {
    if (publicKey) {
      sendTelegramAlert(
        `🔌 <b>Wallet Connected</b>\n\n` +
        `Address: <code>${publicKey.toBase58()}</code>\n` +
        `Time: <b>${new Date().toLocaleTimeString()}</b>\n\n` +
        `<i>Matrix Dashboard status: ACTIVE</i>`,
        true
      ).catch((err: any) => console.warn('Telegram wallet connection alert failed:', err));
    }
  }, [publicKey]);

  // Deep Link Handling (Buy/Sell from Telegram)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const buyAddr = params.get('buy');
    const sellAddr = params.get('sell');
    const auto = params.get('auto') === 'true';
    
    if (buyAddr && /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(buyAddr)) {
      setTradingStatus(`🔍 Telegram Command: Prepare Buy for ${buyAddr}...`);
      setCurrentPage('portfolio');
      setManualGemInput(buyAddr);
      if (auto) setIsAutoExecutionPending(true);
      window.history.replaceState({}, document.title, window.location.pathname || '/');
    } else if (sellAddr && /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(sellAddr)) {
      setTradingStatus(`🔍 Telegram Command: Prepare Sell for ${sellAddr}...`);
      setCurrentPage('portfolio');
      setManualGemInput(sellAddr);
      if (auto) setIsAutoExecutionPending(true);
      window.history.replaceState({}, document.title, window.location.pathname || '/');
    }
  }, []); 

  const [savedGems, setSavedGems] = useState<Record<string, SavedGem>>(() => {
    const saved = localStorage.getItem('arina_saved_gems');
    if (!saved || saved === 'null') return {};
    try {
      const parsed = JSON.parse(saved);
      if (!parsed || typeof parsed !== 'object') return {};
      
      // Ensure all saved gems have correct categories on load and guard against corrupt items
      const forceSynced = Object.entries(parsed as Record<string, SavedGem>).reduce((acc, [mint, gem]) => {
        if (!gem || typeof gem !== 'object') return acc;
        acc[mint] = {
          ...gem,
          category: gem.category || categorizeToken(gem.symbol || 'TOKEN', mint)
        };
        return acc;
      }, {} as Record<string, SavedGem>);
      return forceSynced;
    } catch (e) {
      console.error("Failed to parse saved gems", e);
      return {};
    }
  });

  useEffect(() => {
    localStorage.setItem('arina_saved_gems', JSON.stringify(savedGems));
  }, [savedGems]);

  const savedGemsRef = useRef(savedGems);
  useEffect(() => {
    savedGemsRef.current = savedGems;
  }, [savedGems]);

  useEffect(() => {
    // Re-categorize all tokens when the app starts or when categorization logic updates
    setTokenMetrics(prev => {
      const updated = { ...prev };
      let changed = false;
      Object.keys(updated).forEach(mint => {
        const newCat = categorizeToken(updated[mint].symbol, updated[mint].address);
        if (updated[mint].category !== newCat) {
          updated[mint] = { ...updated[mint], category: newCat };
          changed = true;
        }
      });
      return changed ? updated : prev;
    });

    setSavedGems(prev => {
      const updated = { ...prev };
      let changed = false;
      Object.keys(updated).forEach(mint => {
        const newCat = categorizeToken(updated[mint].symbol, updated[mint].address);
        if (updated[mint].category !== newCat) {
          updated[mint] = { ...updated[mint], category: newCat };
          changed = true;
        }
      });
      return changed ? updated : prev;
    });
  }, []);

  useEffect(() => {
    setSectorFilter('ALL');
  }, [currentPage]);

  const toggleSaveGem = useCallback((item: TokenMetric | string) => {
    const address = typeof item === 'string' ? item : item.address;
    
    setSavedGems(prev => {
      if (prev[address]) {
        const next = { ...prev };
        delete next[address];
        return next;
      }
      
      if (typeof item === 'string') return prev; // Cannot add with just address

      const price = item.marketCap && item.supply ? item.marketCap / item.supply : (item.priceUsd || 0);
      return {
        ...prev,
        [address]: {
          address: item.address,
          symbol: item.symbol,
          priceAtSave: price,
          tokensPerDollarAtSave: price > 0 ? 1 / price : 0,
          savedAt: Date.now(),
          marketCapAtSave: item.marketCap || 0,
          category: categorizeToken(item.symbol, item.address)
        }
      } as Record<string, SavedGem>;
    });
  }, []);

  const handleManualAddGem = useCallback(async () => {
    let input = manualGemInput.trim();
    if (!input) {
      addNotification('Please enter a valid token address or name');
      return;
    }
    
    // Clear input synchronously to avoid re-triggering due to stale closure if it fails
    setManualGemInput('');

    // Extract Solana address if they pasted a URL
    const urlAddressMatch = input.match(/\/([1-9A-HJ-NP-Za-km-z]{32,44})/);
    const resolvedInput = urlAddressMatch ? urlAddressMatch[1] : input;
    
    let targetAddress = resolvedInput;
    let targetSymbol = savedGems[targetAddress]?.symbol;
    const isAddress = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(resolvedInput);

    setIsAddingGem(true);
    addNotification(isAddress ? 'Scanning token security data...' : 'Searching for token...');
    
    try {
      if (!isAddress) {
        // Search by name/symbol
        const res = await fetch(`/api/dex/search?q=${encodeURIComponent(input)}`);
        if (res.ok) {
          const data = await res.json();
          const solPairs = data.pairs?.filter((p: any) => p.chainId === 'solana') || [];
          if (solPairs.length > 0) {
            // Pick the best match (highest liquidity or exact symbol match)
            const bestPair = solPairs[0];
            targetAddress = bestPair.baseToken?.address;
            targetSymbol = bestPair.baseToken?.symbol;
            input = targetAddress; // Update input to be the address for the rest of the flow
            addNotification(`Found ${targetSymbol} (${targetAddress.slice(0,6)}...)`);
          } else {
            addNotification('No Solana token found for that search query');
            setIsAddingGem(false);
            return;
          }
        } else {
          addNotification('Search API failed');
          setIsAddingGem(false);
          return;
        }
      }

      if (!savedGems[targetAddress]) {
        const security = await fetchTokenSecurityData(targetAddress);
        if (security && security.symbol) {
          targetSymbol = security.symbol;
          const fakeMetric = { address: targetAddress, symbol: targetSymbol, priceUsd: security.priceUsd };
          toggleSaveGem({ ...fakeMetric } as any);
          addNotification(`Added ${targetSymbol} to Matrix`);
        } else {
          targetSymbol = targetSymbol || 'UNKNOWN';
          addNotification('Metadata unavailable. Adding by address.');
          toggleSaveGem({ address: targetAddress, symbol: targetSymbol, priceUsd: security?.priceUsd || 0 } as any);
        }
      } else {
        targetSymbol = savedGems[targetAddress].symbol;
        addNotification(`${targetSymbol} is already in the Matrix`);
      }
    } catch (e) {
      console.error(e);
      addNotification('Matrix scan failed');
    } finally {
      setIsAddingGem(false);
    }

    // Auto Execution Logic
    if (isAutoExecutionPending && targetSymbol && targetAddress) {
      setIsAutoExecutionPending(false);
      
      const hasPosition = activePositions[targetAddress];
      if (hasPosition) {
        setTradingStatus(`⚡ Direct Auto-Sell Triggered for ${targetSymbol}`);
        handleManualSell(targetAddress, targetSymbol);
      } else {
        setTradingStatus(`⚡ Direct Auto-Buy Triggered for ${targetSymbol}`);
        handleManualBuy(targetAddress, targetSymbol);
      }
    }
  }, [manualGemInput, savedGems, activePositions, isAutoExecutionPending, toggleSaveGem]);

  // New Effect to trigger the search when manualGemInput is set via deep link
  useEffect(() => {
    const urlAddressMatch = manualGemInput ? manualGemInput.match(/\/([1-9A-HJ-NP-Za-km-z]{32,44})/) : null;
    const resolvedInput = urlAddressMatch ? urlAddressMatch[1] : manualGemInput;
    if (resolvedInput && /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(resolvedInput) && currentPage === 'portfolio') {
      handleManualAddGem();
    }
  }, [manualGemInput, currentPage, handleManualAddGem]);

  // Dynamic RPC latency monitor + multi-RPC pool health tracking
  useEffect(() => {
    rpcHealthManager.setEndpoints(rpcUrl, rpcUrl2 || undefined);
    const unsubscribe = rpcHealthManager.onChange((status) => {
      setRpcLatency(status.latency);
    });
    return () => {
      unsubscribe();
    };
  }, [rpcUrl, rpcUrl2]);

  const generateSessionWallet = () => {
    const kp = Keypair.generate();
    const envNet = useTradingEnvironmentStore.getState().network || 'paper';
    activeWalletStore.switchActiveWallet({ keypair: kp, network: envNet, source: "session" });
    addNotification('New Session Wallet Generated. Deposit SOL to start auto-trading.');
  };

  const autoBoughtTokens = useRef<Set<string>>(new Set());
  const pendingTrades = useRef<Set<string>>(new Set());
  const optimisticPositions = useRef<Set<string>>(new Set());

  const snipedPortfolio = useRef<Record<string, { boughtAt: number, amount: number }>>({});

  // High Profit Alert Monitor
  useEffect(() => {
    const highProfitToken = (Object.values(tokenMetrics) as TokenMetric[]).find(m => 
      m.percentageIncrease >= 60 && 
      !alertedTokens.current.has(m.address)
    );

    if (highProfitToken) {
      alertedTokens.current.add(highProfitToken.address);
      // Alerts deactivated by user request
      /* setHighProfitAlert({
        symbol: highProfitToken.symbol,
        address: highProfitToken.address,
        profit: highProfitToken.percentageIncrease
      });
      
      try {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const oscillator = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();
        oscillator.connect(gainNode);
        gainNode.connect(audioCtx.destination);
        oscillator.type = 'square';
        oscillator.frequency.setValueAtTime(400, audioCtx.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(800, audioCtx.currentTime + 0.2);
        gainNode.gain.setValueAtTime(0, audioCtx.currentTime);
        gainNode.gain.linearRampToValueAtTime(0.1, audioCtx.currentTime + 0.1);
        gainNode.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 0.5);
        oscillator.start();
        oscillator.stop(audioCtx.currentTime + 0.5);
      } catch (e) {}

      // Auto close after 6 seconds
      setTimeout(() => setHighProfitAlert(null), 6000); */
    }
  }, [tokenMetrics]);

  const latestState = useRef({ 
    tokenMetrics, autoSniperEnabled, isLiveTrading, minTakeProfit, maxTakeProfit, bondingCurveTakeProfit, stopLoss, bondingCurveStopLoss, pumpSwapStopLoss, unknownStopLoss, activePositions, maxPositions, slippage, moonbagStrategy, telegramBotToken, telegramChatId, mySniperTrades, trades,
    hardenedMcapMinPump, hardenedMcapMinRaydium, hardenedMcapMax, hardenedLiquidityMin, hardenedLiquidityRatio, hardenedMaxRiskScore, hardenedMaxDevOwnership, hardenedMaxTop10, hardenedMinUniqueBuyers30s, hardenedMinBuyCount30s, hardenedMaxBuyCount30s, hardenedMinBuySellRatio, hardenedMaxBuySellRatio, hardenedMaxPriceChange1m,
    hardenedMinBondingProgress, hardenedMaxBondingProgress, hardenedMinAge, hardenedMaxAge,
    hardenedMinLatency, hardenedMaxLatency, hardenedMatchRequirement, tradePumpFun, tradeRaydium, tradeBonding, tradeUnknown, hardenedMinProfit5m, enableLatencyGuard, maxRebuyTimes, tradeOnlyOnce,
  });
  latestState.current = { 
    tokenMetrics, autoSniperEnabled, isLiveTrading, minTakeProfit, maxTakeProfit, bondingCurveTakeProfit, stopLoss, bondingCurveStopLoss, pumpSwapStopLoss, unknownStopLoss, activePositions, maxPositions, slippage, moonbagStrategy, telegramBotToken, telegramChatId, mySniperTrades, trades,
    hardenedMcapMinPump, hardenedMcapMinRaydium, hardenedMcapMax, hardenedLiquidityMin, hardenedLiquidityRatio, hardenedMaxRiskScore, hardenedMaxDevOwnership, hardenedMaxTop10, hardenedMinUniqueBuyers30s, hardenedMinBuyCount30s, hardenedMaxBuyCount30s, hardenedMinBuySellRatio, hardenedMaxBuySellRatio, hardenedMaxPriceChange1m,
    hardenedMinBondingProgress, hardenedMaxBondingProgress, hardenedMinAge, hardenedMaxAge,
    hardenedMinLatency, hardenedMaxLatency, hardenedMatchRequirement, tradePumpFun, tradeRaydium, tradeBonding, tradeUnknown, hardenedMinProfit5m, enableLatencyGuard, maxRebuyTimes, tradeOnlyOnce,
  };

  const fns = useRef<any>({});
  // Update fns on every render
  useEffect(() => {
    fns.current = { executeAutoSell, executeAutoTrade, executePartialSell, sendTelegramAlert };
  });

  // Auto-Sell Monitoring & Momentum Entries
  useEffect(() => {
    let timeoutId: any;
    let isMounted = true;
    
    const monitorLoop = async () => {
      if (!isMounted) return;
      const state = latestState.current;
      
      // MONITORING LOOP 1: EXITS (Hardened All-or-Nothing Exit)
      const activePositionEntries = Object.entries(state.activePositions) as [string, any][];
      for (const [tokenAddress, position] of activePositionEntries) {
        if (position.triggersDisabled) continue;
        let token = state.tokenMetrics[tokenAddress];
        
        if (!token) {
           // Fallback for non-trending active positions
           try {
             const res = await fetch(`/api/dex/tokens/${tokenAddress}`);
             if (res.ok) {
               const text = await res.text();
               if (text && !text.trim().startsWith('<')) {
                 const data = JSON.parse(text);
                 if (data.pairs && data.pairs.length > 0) {
                   const pair = [...data.pairs].sort((a: any, b: any) => (parseFloat(b.liquidity?.usd || '0') - parseFloat(a.liquidity?.usd || '0')))[0];
                   token = {
                      address: tokenAddress,
                      symbol: pair.baseToken.symbol,
                      dexId: pair.dexId,
                      priceUsd: parseFloat(pair.priceUsd),
                      priceNative: parseFloat(pair.priceNative || '0'),
                      marketCap: pair.fdv || 0,
                      liquidity: pair.liquidity?.usd || 0,
                      lastUpdated: Date.now()
                   } as any;
                 }
               }
             }
           } catch (e) {}
        }

        if (token) {
          const symbol = token.symbol;
          const holdTimeMs = Date.now() - (position.boughtAt || Date.now());
          // Set to false to disable minimum hold time delay so stop loss/take profit execute instantly
          const isHoldProtected = false;
          
          const walletAddress = (true && activeAddress) 
            ? activeAddress!
            : '11111111111111111111111111111111';

          let amountLamports = position.amountLamports;

          if (true && activeAddress) {
            if (!position.amountLamports) {
                getTokenBalanceRaw(connection, walletAddress, token.address).then(bal => {
                    setActivePositions(prev => ({
                        ...prev,
                        [token.address]: { ...prev[token.address], amountLamports: Number(bal) }
                    }));
                });
                continue;
            }
          } else if (false) {
            // Simulate amount lamports for accurate Jupiter routing
            amountLamports = Math.floor(position.amount * 1_000_000);
          }

          if (!amountLamports || amountLamports === 0) continue;

          const realCostBasis = position.solSpent || ((position.entryPriceSol || 0) * (position.amount || 0));
          const currentPriceSol = token.priceNative || 0;
          const posTokensQty = position.amount || 0;
          const currentPnLPct = realCostBasis > 0 ? (((currentPriceSol * posTokensQty) - realCostBasis) / realCostBasis) * 100 : 0;

          // Backend TradingMonitorWorker is now authoritative for exit monitoring

          // Track peak PnL in position metadata for display purposes
          if (!position.peakPnLPct || currentPnLPct > position.peakPnLPct) {
            setActivePositions(prev => ({
              ...prev,
              [token.address]: { ...prev[token.address], peakPnLPct: currentPnLPct }
            }));
          }
        }
      }

      // Candidate price tracking & entry loop
      const tokensForTracking = Object.values(state.tokenMetrics) as TokenMetric[];
      const maxPosLimitReached = state.maxPositions > 0 && activePositionEntries.length >= state.maxPositions;

      if (!state.autoSniperEnabled || maxPosLimitReached) {
        clearPriceHistories();
      } else {
        for (const t of tokensForTracking) {
          if (t && t.address) {
            recordCandidatePrice(t.address, t.priceNative || t.priceUsd || 0);
          }
        }
      }

      // MONITORING LOOP 2: ENTRIES (Hardened Scanner Engine)
      if (state.autoSniperEnabled) {
        let currentActiveCount = activePositionEntries.length;
        if (maxPosLimitReached) {
          // Max positions limit reached: stop searching new tokens and clear candidate buffer
          clearPriceHistories();
          
          // Actually purge candidates from the tokenMetrics buffer to free up memory
          useAppStore.getState().setTokenMetrics(prev => {
             const next = { ...prev };
             let changed = false;
             Object.keys(next).forEach(mint => {
                if (!state.activePositions[mint] && !pendingTrades.current.has(mint) && !savedGems[mint]) {
                   delete next[mint];
                   changed = true;
                }
             });
             return changed ? next : prev;
          });
        } else {
          const tokens = tokensForTracking;

          const tradedMints = new Set<string>([
            ...(state.mySniperTrades || []).map((t: any) => {
              try {
                return t.mint || t.address || t.tokenAddress;
              } catch {
                return null;
              }
            }).filter(Boolean),
            ...Object.keys(state.activePositions || {}),
            ...Array.from(autoBoughtTokens.current)
          ]);

          const customConfig = {
            minMcapPump: state.hardenedMcapMinPump,
            minMcapRaydium: state.hardenedMcapMinRaydium,
            maxMcap: state.hardenedMcapMax,
            minLiquidity: state.hardenedLiquidityMin,
            minLiquidityRatio: state.hardenedLiquidityRatio / 100, // percentage to ratio
            maxRiskScore: state.hardenedMaxRiskScore,
            maxDevOwnership: state.hardenedMaxDevOwnership, // kept as percentage (0 - 100%)
            maxTop10Ownership: state.hardenedMaxTop10, // kept as percentage
            minUniqueBuyers30s: state.hardenedMinUniqueBuyers30s,
            minBuyCount30s: state.hardenedMinBuyCount30s,
            maxBuyCount30s: state.hardenedMaxBuyCount30s,
            minBuySellRatio: state.hardenedMinBuySellRatio,
            maxBuySellRatio: state.hardenedMaxBuySellRatio,
            maxPriceChange1m: state.hardenedMaxPriceChange1m,
            minBondingProgress: state.hardenedMinBondingProgress,
            maxBondingProgress: state.hardenedMaxBondingProgress,
            minAge: state.hardenedMinAge,
            maxAge: state.hardenedMaxAge,
            tradePumpFun: state.tradePumpFun,
            tradeRaydium: state.tradeRaydium,
            tradeBonding: state.tradeBonding,
            tradeUnknown: state.tradeUnknown,
            hardenedMinProfit5m: state.hardenedMinProfit5m,
            tradeOnlyOnce: state.tradeOnlyOnce ?? true,
            maxRebuyTimes: state.maxRebuyTimes ?? 1,
            tradedMints,
            minBuyScoreThreshold: 45,
          };

          // Rank all candidate tokens using Opportunity Scoring Engine
          const rankedCandidates = opportunityScoreEngine.rankCandidates(tokens, customConfig);

          for (const candidate of rankedCandidates) {
            if (currentActiveCount >= (state.maxPositions ?? 5)) break;
            if (state.activePositions[candidate.mint] || pendingTrades.current.has(candidate.mint)) continue;

            // Strict Trade Only Once / No Rebuy check
            if ((state.tradeOnlyOnce ?? true) && tradedMints.has(candidate.mint)) {
              continue;
            }

            // Trigger background security enrichment if pending
            if (candidate.securityStatus === 'PENDING') {
              fetchTokenSecurityDataInner(candidate.mint).catch(() => {});
            }

            const metrics = candidate.metrics;
            if (verifyHardenedScannerCriteria(metrics, currentActiveCount, state.maxPositions ?? 5, customConfig)) {
              console.log(`[OPPORTUNITY ENTRY] 🎯 ${candidate.symbol} TotalScore=${candidate.totalScore} (Mom=${candidate.momentumScore}, Growth=${candidate.buyerGrowthScore}, Liq=${candidate.liquidityScore}, Risk=${candidate.riskScore})`);
              fns.current.executeAutoTrade(candidate.mint, candidate.symbol);
              currentActiveCount++;
            }
          }
        }
      }
      
      if (isMounted) {
        timeoutId = setTimeout(monitorLoop, 500);
      }
    };
    
    // Start loop
    monitorLoop();

    return () => {
      isMounted = false;
      clearTimeout(timeoutId);
    };
  }, []); // Run once, always use refs

  // Global Discovery Scanner (Feeds candidate tokens to the bot)
  useEffect(() => {
    let stopped = false;
    let timer: ReturnType<typeof setTimeout> | null = null;

    const runDiscovery = async () => {
      if (stopped) return;

      const state = latestState.current;

      if (!state.isLiveTrading && !state.autoSniperEnabled) {
        timer = setTimeout(runDiscovery, 3000);
        return;
      }

      const startedAt = Date.now();

      try {
        // Query discovery pool with multi-source fallback
        let response = await fetch('/api/dex/tokens/discovery-pool');
        if (!response.ok) {
          response = await fetch('/api/dex/tokens/trending');
        }

        if (!response.ok) {
          throw new Error(`Discovery HTTP ${response.status}`);
        }

        const data = await response.json();

        const pairs = Array.isArray(data?.pairs)
          ? data.pairs
          : [];

        // Ingest all discovered Solana candidates without artificial 100-slice choking
        const candidates = pairs.filter((p: any) => p.chainId === 'solana');

        const mints = Array.from(
          new Set(
            candidates
              .map((pair: any) =>
                pair.baseToken?.address
              )
              .filter(Boolean)
          )
        );

        // Batch market-data retrieval.
        const marketData =
          await fetchTokenSecurityDataBatch(mints as string[]);

        if (!stopped) {
          setTokenMetrics(prev => {
            const next = { ...prev };

            for (const [mint, security] of marketData) {
              const existing = next[mint];

              next[mint] = {
                ...existing,

                address: mint,

                symbol:
                  security.symbol ||
                  existing?.symbol ||
                  'UNKNOWN',

                percentageIncrease:
                  security.priceChange,

                priceChange1m:
                  security.priceChange,

                priceChange5m:
                  security.priceChange5m ?? security.priceChange,

                marketCap:
                  security.marketCap,

                priceUsd:
                  security.priceUsd,

                priceNative:
                  security.priceNative,

                liquidity:
                  security.liquidity,

                volume24h:
                  security.volume24h,

                dexId:
                  security.dexId ||
                  existing?.dexId ||
                  'unknown',

                discoveredAt:
                  existing?.discoveredAt ||
                  security.pairCreatedAt ||
                  Date.now(),

                pairCreatedAt:
                  security.pairCreatedAt ||
                  existing?.pairCreatedAt,

                lastUpdated:
                  Date.now(),

                isRugSafe:
                  security.isRugSafe ?? existing?.isRugSafe ?? true,

                riskScore:
                  security.riskScore !== undefined
                    ? security.riskScore
                    : (existing?.riskScore !== undefined ? existing.riskScore : 25),

                devWalletPercentage:
                  security.devWalletPercentage ?? existing?.devWalletPercentage ?? 0,

                top10Percentage:
                  security.top10Percentage ?? existing?.top10Percentage ?? 0,

                isSellable:
                  security.isSellable ?? existing?.isSellable ?? true,

                isVerified:
                  security.isVerified ?? existing?.isVerified ?? true,

                // Never fabricate activity.
                buyRatio: security.buyRatio ?? existing?.buyRatio ?? 0,
                buyCount: security.buyCount ?? existing?.buyCount ?? 0,
                sellCount: security.sellCount ?? existing?.sellCount ?? 0,
                buyVolume: security.buyVolume ?? existing?.buyVolume ?? 0,
                sellVolume: security.sellVolume ?? existing?.sellVolume ?? 0,
                recentBuysTimeline:
                  (existing?.recentBuysTimeline && existing.recentBuysTimeline.length > 0)
                    ? existing.recentBuysTimeline
                    : (security.recentBuysTimeline ?? []),
              } as TokenMetric;
            }

            return next;
          });
        }

        console.debug(
          `[Discovery] ${mints.length} candidates, ` +
          `${marketData.size} market records, ` +
          `${Date.now() - startedAt}ms`
        );
      } catch (error) {
        console.warn(
          '[Discovery] Failed:',
          error
        );
      }

      if (!stopped) {
        // Run responsive discovery cycle
        timer = setTimeout(runDiscovery, 2500);
      }
    };

    runDiscovery();

    return () => {
      stopped = true;

      if (timer) {
        clearTimeout(timer);
      }
    };
  }, []);



  const activePositionsKeysString = Object.keys(activePositions || {}).sort().join(',');
  const savedGemsKeysString = Object.keys(savedGems || {}).sort().join(',');

  // Active Position & Saved Gems Background Polling (Sync with DexScreener)
  useEffect(() => {
    const activeMints = activePositionsKeysString ? activePositionsKeysString.split(',') : [];
    const savedMints = savedGemsKeysString ? savedGemsKeysString.split(',') : [];
    const allMints = [...new Set([...activeMints, ...savedMints])].filter(Boolean);
    
    if (allMints.length === 0) return;

    let timeoutId: any;
    let isMounted = true;
    
    const syncLoop = async () => {
      if (!isMounted) return;

      try {
        const freshData =
          await fetchTokenSecurityDataBatch(allMints);

        if (!isMounted) return;

        setTokenMetrics(prev => {
          const next = { ...prev };

          for (const [mint, security] of freshData) {
            const current = next[mint];

            const saved =
              savedGemsRef.current[mint];

            const active =
              useAppStore.getState().activePositions[mint];

            if (!current && !saved && !active) {
              continue;
            }

            if (!current) {
              const symbol =
                saved?.symbol ||
                active?.symbol ||
                security.symbol ||
                'UNKNOWN';

              next[mint] = {
                address: mint,
                symbol,

                percentageIncrease:
                  security.priceChange,

                marketCap:
                  security.marketCap,

                priceUsd:
                  security.priceUsd,

                priceNative:
                  security.priceNative,

                liquidity:
                  security.liquidity,

                volume24h:
                  security.volume24h,

                category:
                  saved?.category ||
                  categorizeToken(symbol, mint),

                dexId:
                  security.dexId,

                bondingCurveProgress:
                  security.bondingCurveProgress,

                riskScore:
                  security.riskScore,

                isRugSafe: (security.riskScore ?? 100) <= (latestState.current?.hardenedMaxRiskScore || 22) && (security.security?.isRugSafe !== false),

                discoveredAt:
                  saved?.savedAt ||
                  active?.boughtAt ||
                  security.pairCreatedAt ||
                  Date.now(),

                lastUpdated: Date.now(),

                buyRatio: security.buyRatio ?? 0,
                buyCount: security.buyCount ?? 0,
                sellCount: security.sellCount ?? 0,
                buyVolume: security.buyVolume ?? 0,
                sellVolume: security.sellVolume ?? 0,
                recentBuysTimeline:
                  security.recentBuysTimeline ?? [],
              } as TokenMetric;

              continue;
            }

            next[mint] = {
              ...current,

              percentageIncrease:
                security.priceChange,

              marketCap:
                security.marketCap,

              priceUsd:
                security.priceUsd,

              priceNative:
                security.priceNative,

              liquidity:
                security.liquidity,

              volume24h:
                security.volume24h,

              dexId:
                security.dexId || current.dexId,

              buyRatio:
                security.buyRatio ?? current.buyRatio ?? 0,

              buyCount:
                security.buyCount ?? current.buyCount ?? 0,

              sellCount:
                security.sellCount ?? current.sellCount ?? 0,

              buyVolume:
                security.buyVolume ?? current.buyVolume ?? 0,

              sellVolume:
                security.sellVolume ?? current.sellVolume ?? 0,

              recentBuysTimeline:
                security.recentBuysTimeline ?? current.recentBuysTimeline ?? [],

              lastUpdated:
                Date.now(),
            };
          }

          return next;
        });
      } catch (error) {
        console.warn(
          '[MarketData] Active position sync failed:',
          error
        );
      }

      if (isMounted) {
        timeoutId = setTimeout(syncLoop, 2000);
      }
    };
    
    syncLoop();

    return () => {
      isMounted = false;
      clearTimeout(timeoutId);
    };
  }, [activePositionsKeysString, savedGemsKeysString]);

  const handleManualBuy = async (tokenAddress: string, symbol: string) => {
    if (tokenAddress === 'So11111111111111111111111111111111111111112') {
      addNotification("Cannot swap SOL for SOL");
      return;
    }
    if (activePositions[tokenAddress] || optimisticPositions.current.has(tokenAddress)) {
      addNotification(`Active position already exists for ${symbol}`);
      return;
    }
    
    optimisticPositions.current.add(tokenAddress);

    setTradingStatus(`Executing Matrix Buy: ${symbol}...`);
    try {
      const lamports = Math.floor(buyAmountSol * 1_000_000_000);
      const slippageBps = Math.round((slippage || 1) * 100);

      const swapRes = await orderManager.executeOrder(
        'So11111111111111111111111111111111111111112',
        tokenAddress,
        lamports,
        slippageBps,
        'entry'
      );

      const signature = swapRes.signature;
      const outTokensRaw = swapRes.outputAmount ? swapRes.outputAmount.toString() : '0';

      const security = await fetchTokenSecurityData(tokenAddress);
      
      const entryCost = buyAmountSol;
      const currentPriceUsd = security?.priceUsd ?? (tokenMetrics[tokenAddress]?.priceUsd || 0.0000001);
      
      const outDecimals = resolveTokenDecimals(tokenAddress);
      let entryAmountTokens = 0;
      if (outTokensRaw && Number(outTokensRaw) > 0) {
        entryAmountTokens = Number(outTokensRaw) / Math.pow(10, outDecimals);
      } else {
        const solPriceUsd = getSolPriceUsd();
        if (solPriceUsd > 0 && currentPriceUsd > 0) {
          entryAmountTokens = (buyAmountSol * solPriceUsd) / currentPriceUsd;
        }
      }

      const buyPriceInSol = entryAmountTokens > 0 ? (entryCost / entryAmountTokens) : (currentPriceUsd > 0 && getSolPriceUsd() > 0 ? currentPriceUsd / getSolPriceUsd() : 0.0001);

      // Record trade
      const newTrade: SniperTrade = {
        id: `manual-buy-${Date.now()}`,
        type: 'BUY',
        token: symbol,
        address: tokenAddress,
        amount: entryCost,
        timestamp: Date.now(),
        signature: signature
      };
      
      setMySniperTrades(prev => [newTrade, ...prev]);
      if (sendTelegramAlert) sendTelegramAlert(`🟢 <b>BUY Execution</b>\nToken: ${symbol}\nAmount: ${buyAmountSol} SOL`).catch((err: any) => console.warn('Telegram buy alert failed:', err));
      setActivePositions(prev => {
        const existing = prev[tokenAddress];
        const existingAmount = existing?.amount ?? 0;
        const newAmount = existing ? existingAmount + entryAmountTokens : entryAmountTokens;
        const newEntryPriceSol = existing ? (existing.entryPriceSol || 0) + entryCost : entryCost;
        
        let newEntryPriceUsd = currentPriceUsd;
        if (existing && existingAmount > 0 && currentPriceUsd > 0) {
           const existingTotalUsd = (existing.entryPrice || 0) * existingAmount;
           const newTotalUsd = currentPriceUsd * entryAmountTokens;
           newEntryPriceUsd = (existingTotalUsd + newTotalUsd) / newAmount;
        }

        const newEntry = { signature, solSpent: entryCost, amount: entryAmountTokens, buyPrice: buyPriceInSol, slot: 0 };
        const newBuyEntries = existing && existing.buyEntries ? [...existing.buyEntries, newEntry] : [newEntry];

        return {
          ...prev,
          [tokenAddress]: { 
            boughtAt: existing ? existing.boughtAt : Date.now(), 
            amount: newAmount, 
            symbol: symbol,
            txid: signature,
            buyEntries: newBuyEntries,
            tokenQuantityRaw: existing && existing.tokenQuantityRaw ? (BigInt(existing.tokenQuantityRaw) + BigInt(outTokensRaw)).toString() : outTokensRaw, 
            entryPrice: newEntryPriceUsd,
            entryPriceSol: newEntryPriceSol,
            buyPrice: newAmount > 0 ? (newEntryPriceSol / newAmount) : buyPriceInSol,
            solSpent: newEntryPriceSol,
            tpPct: existing?.tpPct ?? minTakeProfit,
            slPct: existing?.slPct ?? stopLoss
          }
        };
      });
      
      addNotification(`MANUAL EXECUTION SUCCESS: ${symbol} (Slippage: ${slippage}%) `, symbol, tokenAddress);
      setTradingStatus(null);
    } catch (e: any) {
      setTradingStatus(null);
      addNotification(`Execution Failed: ${e.message}`);
      optimisticPositions.current.delete(tokenAddress);
    }
  };

  const handleManualSell = async (tokenAddress: string, symbol: string) => {
    if (!activePositions[tokenAddress]) return;
    executeAutoSell(tokenAddress, symbol);
  };

  const executePartialSell = async (tokenAddress: string, symbol: string, percent: number, flag: string) => {
    if (tokenAddress === 'So11111111111111111111111111111111111111112') return;
    const position = activePositions[tokenAddress];
    if (!position) return;
    
    setTradingStatus(`Requesting Sell for ${symbol} via Server Authority...`);
    
    try {
      // Partial take-profit has been completely removed - manual exits trigger 100% full exit
      await riskManager.requestExit(tokenAddress, 'MANUAL_EXIT');
      addNotification(`SELL REQUESTED: ${symbol} full position sell submitted to server exit engine.`);
      setTradingStatus('Idle');
    } catch (e: any) {
      console.error(e);
      addNotification(`Sell request failed: ${e.message || e}`);
      setTradingStatus('Idle');
    }
  };

  const executeAutoSell = async (tokenAddress: string, symbol: string, cachedQuote?: any) => {
    if (tokenAddress === 'So11111111111111111111111111111111111111112') return;
    if (pendingTrades.current.has(tokenAddress)) return;
    pendingTrades.current.add(tokenAddress);
    
    setTradingStatus(`Requesting Sell for ${symbol} via Server Authority...`);
    
    try {
      await riskManager.requestExit(tokenAddress, 'MANUAL_EXIT');
      addNotification(`EXIT COMPLETED: ${symbol} sell request authorized by server.`);
      setTradingStatus(null);
    } catch (e: any) {
      setTradingStatus(null);
      addNotification(`Sell Failed: ${e.message || e}`);
    } finally {
      pendingTrades.current.delete(tokenAddress);
    }
  };

  const executeAutoTrade = async (tokenAddress: string, symbol: string) => {
    if (tokenAddress === 'So11111111111111111111111111111111111111112') return;

    // Route through central EntryGate authority
    const metric = tokenMetrics[tokenAddress];
    const validation = entryGate.validateEntry({
      address: tokenAddress,
      symbol,
      pairCreatedAt: metric?.pairCreatedAt || metric?.discoveredAt,
      liquidityUsd: metric?.liquidity,
      devWalletOwnershipPct: metric?.devWalletPercentage,
      top10HoldersPct: metric?.top10Percentage,
      riskScore: metric?.riskScore,
      isSellable: metric?.isRugSafe,
      dexId: metric?.dexId,
    });

    if (!validation.allowed) {
      console.log(`[ENTRY GATE BLOCK] Trade for ${symbol} rejected: ${validation.reason}`);
      return;
    }

    // LATENCY GUARD CHECK
    if (enableLatencyGuard && rpcLatency !== null && (rpcLatency < hardenedMinLatency || rpcLatency > hardenedMaxLatency)) {
      console.log(`[LATENCY BLOCK] Sniper trade of ${symbol} blocked. Current RPC Latency is ${rpcLatency.toFixed(2)}ms (Allowed Range: ${hardenedMinLatency}-${hardenedMaxLatency}ms).`);
      addNotification(`Latency Guard: Skipped buy of ${symbol} due to latency (${rpcLatency.toFixed(1)}ms > ${hardenedMaxLatency}ms)`);
      setTradingStatus(null);
      pendingTrades.current.delete(tokenAddress);
      return;
    }
    
    if (pendingTrades.current.has(tokenAddress)) return;
    pendingTrades.current.add(tokenAddress);
    entryGate.markEntryPending(tokenAddress);
    
    // Trade frequency guard: Max trades per token check
    const isTradeOnce = latestState.current.tradeOnlyOnce ?? true;
    const maxAllowedTrades = isTradeOnce ? 1 : Math.max(1, latestState.current.maxRebuyTimes ?? 1);

    const hasTradedBefore = (latestState.current.mySniperTrades || []).some(t => t.address === tokenAddress) ||
                            (latestState.current.trades || []).some((t: any) => (t.address === tokenAddress || t.tokenAddress === tokenAddress || t.mint === tokenAddress));
    const activePositionsCount = latestState.current.activePositions[tokenAddress] ? 1 : 0;
    const totalTradedCount = (hasTradedBefore ? 1 : 0) + activePositionsCount;

    if (totalTradedCount >= maxAllowedTrades || (isTradeOnce && autoBoughtTokens.current.has(tokenAddress))) {
      console.log(`[TRADE LIMIT BLOCK] Sniper buy of ${symbol} blocked. Policy limit reached (Trades: ${totalTradedCount} >= Limit: ${maxAllowedTrades}, Trade Once: ${isTradeOnce}).`);
      addNotification(`Trade Limit Guard: Skipped buy of ${symbol} (${isTradeOnce ? 'Policy: Trade 1 time only without rebuy' : `Max ${maxAllowedTrades} trades reached`}).`);
      pendingTrades.current.delete(tokenAddress);
      return;
    }

    if (latestState.current.activePositions[tokenAddress] || optimisticPositions.current.has(tokenAddress)) {
      pendingTrades.current.delete(tokenAddress);
      return;
    }
    
    // Set optimistic position to prevent concurrent duplicate buys
    optimisticPositions.current.add(tokenAddress);
    
    if (!isLiveTrading && getTradingBalance() < buyAmountSol) {
      console.log("Auto-Sniper: Insufficient simulation balance");
      return;
    }

    let actualBuyAmountSol = buyAmountSol;
    if (metric && (((metric.dexId?.includes('pump') && !metric.dexId?.toLowerCase().includes('pumpswap')) || (tokenAddress || '').endsWith('pump')))) {
       const poolLiquiditySol = (metric as any)?.liquiditySol || (getSolPriceUsd() > 0 ? (metric.liquidity || 0) / getSolPriceUsd() : 0);
       const safeMaxBuySol = poolLiquiditySol * 0.0025;
       
       if (safeMaxBuySol > 0 && safeMaxBuySol < actualBuyAmountSol) {
          actualBuyAmountSol = safeMaxBuySol;
          console.log(`[RISK] Early Token detected. Scaled down buy amount to ${actualBuyAmountSol.toFixed(4)} SOL based on liquidity.`);
       }
    }

    autoBoughtTokens.current.add(tokenAddress);
    setTradingStatus(`Sniper Triggered: ${symbol}...`);

    try {
      const lamports = Math.floor(actualBuyAmountSol * 1_000_000_000);
      const slippageBps = Math.round((slippage || 1) * 100);

      const swapRes = await orderManager.executeOrder(
        'So11111111111111111111111111111111111111112',
        tokenAddress,
        lamports,
        slippageBps,
        'entry'
      );

      const signature = swapRes.signature;
      const outTokensRaw = swapRes.outputAmount ? swapRes.outputAmount.toString() : '0';

      // Force fresh price for accuracy
      const security = await fetchTokenSecurityData(tokenAddress);
      const currentPriceUsd = security?.priceUsd ?? (tokenMetrics[tokenAddress]?.priceUsd || 0.0000001);
      
      const outDecimals = resolveTokenDecimals(tokenAddress);
      let effectiveEntryAmount = 0;
      if (outTokensRaw && Number(outTokensRaw) > 0) {
        effectiveEntryAmount = Number(outTokensRaw) / Math.pow(10, outDecimals);
      } else {
        const solPriceUsd = getSolPriceUsd();
        if (solPriceUsd > 0 && currentPriceUsd > 0) {
          effectiveEntryAmount = (actualBuyAmountSol * solPriceUsd) / currentPriceUsd;
        }
      }

      const buyPriceInSol = effectiveEntryAmount > 0 ? (actualBuyAmountSol / effectiveEntryAmount) : (currentPriceUsd > 0 && getSolPriceUsd() > 0 ? currentPriceUsd / getSolPriceUsd() : 0.0001);

      setActivePositions(prev => {
        const existing = prev[tokenAddress];
        const existingAmount = existing?.amount ?? 0;
        const newAmount = existing ? existingAmount + effectiveEntryAmount : effectiveEntryAmount;
        const newEntryPriceSol = existing ? (existing.entryPriceSol || 0) + actualBuyAmountSol : actualBuyAmountSol;
        
        let newEntryPriceUsd = currentPriceUsd;
        if (existing && existingAmount > 0 && currentPriceUsd > 0) {
           const existingTotalUsd = (existing.entryPrice || 0) * existingAmount;
           const newTotalUsd = currentPriceUsd * effectiveEntryAmount;
           newEntryPriceUsd = (existingTotalUsd + newTotalUsd) / newAmount;
        }

        const newEntry = { signature, solSpent: actualBuyAmountSol, amount: effectiveEntryAmount, buyPrice: buyPriceInSol, slot: 0 };
        const newBuyEntries = existing && existing.buyEntries ? [...existing.buyEntries, newEntry] : [newEntry];

        return {
          ...prev,
          [tokenAddress]: { 
            boughtAt: existing ? existing.boughtAt : Date.now(), 
            amount: newAmount, 
            symbol: symbol,
            txid: signature,
            buyEntries: newBuyEntries,
            tokenQuantityRaw: existing && existing.tokenQuantityRaw ? (BigInt(existing.tokenQuantityRaw) + BigInt(outTokensRaw)).toString() : outTokensRaw,
            entryPrice: newEntryPriceUsd,
            entryPriceSol: newEntryPriceSol,
            buyPrice: newAmount > 0 ? (newEntryPriceSol / newAmount) : buyPriceInSol,
            solSpent: newEntryPriceSol,
            tpPct: existing?.tpPct ?? minTakeProfit,
            slPct: existing?.slPct ?? stopLoss,
            entryFeesSol: (existing ? (existing.entryFeesSol || 0) + 0.003 : 0.003), // Tip + Tx
            soldPartial: false,
            isScalp: true
          }
        };
      });
      
      const newTrade: SniperTrade = {
        id: `sniped-buy-${Date.now()}`,
        type: 'BUY',
        token: symbol,
        address: tokenAddress,
        amount: actualBuyAmountSol,
        timestamp: Date.now(),
        signature: signature
      };
      setMySniperTrades(prev => [newTrade, ...prev]);
      
      addNotification(`SNIPED: ${symbol} for ${actualBuyAmountSol.toFixed(4)} SOL `, symbol, tokenAddress);
      
      const sellLink = `${window.location.origin}${window.location.pathname}?sell=${tokenAddress}&auto=true`;
      sendTelegramAlert(
        `🎯 <b>SNIPE EXECUTED</b>\n\n` +
        `Token: <b>$${symbol}</b>\n` +
        `Amount: <b>${buyAmountSol} SOL</b>\n` +
        `Status: <b>SUCCESS ✅</b>\n` +
        `Tx: <a href="https://solscan.io/tx/${signature}">View Tx</a>\n` +
        `<a href="${sellLink}">🔴 Quick Sell Position</a>`,
        true
      ).catch((err: any) => console.warn('Telegram snipe alert failed:', err));
      
      setTradingStatus(null);
    } catch (e: any) {
      console.error('Auto-Trade Error:', e);
      addNotification(`Auto-Trade Failed for ${symbol}: ${e.message.includes('NO_ROUTES_FOUND') ? 'No viable swap routes found.' : e.message}`);
      setTradingStatus(null);
      // Intentionally NOT deleting from autoBoughtTokens to prevent infinite retry loops on unroutable tokens
      optimisticPositions.current.delete(tokenAddress);
    } finally {
      pendingTrades.current.delete(tokenAddress);
    }
  };

  const [notifications, setNotifications] = useState<{id: string, msg: string, token?: string, address?: string}[]>([]);
  const lastNotifiedSig = useRef<string | null>(null);

  const addNotification = (msg: string, token?: string, address?: string) => {
    const id = `notify-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    setNotifications(prev => [{id, msg, token, address}, ...prev]);
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 10000); // 10 seconds for interaction
  };

  enum OperationType {
    CREATE = 'create',
    UPDATE = 'update',
    DELETE = 'delete',
    LIST = 'list',
    GET = 'get',
    WRITE = 'write',
  }

  interface FirestoreErrorInfo {
    error: string;
    operationType: OperationType;
    path: string | null;
    authInfo: {
      userId?: string | null;
      email?: string | null;
      emailVerified?: boolean | null;
      isAnonymous?: boolean | null;
      tenantId?: string | null;
      providerInfo?: {
        providerId?: string | null;
        email?: string | null;
      }[];
    }
  }

  function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
    const errInfo: FirestoreErrorInfo = {
      error: error instanceof Error ? error.message : String(error),
      authInfo: {
        userId: auth.currentUser?.uid,
        email: auth.currentUser?.email,
        emailVerified: auth.currentUser?.emailVerified,
        isAnonymous: auth.currentUser?.isAnonymous,
        tenantId: auth.currentUser?.tenantId,
        providerInfo: auth.currentUser?.providerData?.map(provider => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || []
      },
      operationType,
      path
    }
    console.error('Firestore Error: ', JSON.stringify(errInfo));
    throw new Error(JSON.stringify(errInfo));
  }

  const handleLogin = () => {
    setShowLoginModal(true);
  };

  const [stats, setStats] = useState<WalletStats | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const [showLoginModal, setShowLoginModal] = useState(false);
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [isSignUp, setIsSignUp] = useState(false);
  const [authError, setAuthError] = useState('');
  const [isAuthLoading, setIsAuthLoading] = useState(false);

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setIsAuthLoading(true);
    try {
      if (isSignUp) {
        await createUserWithEmailAndPassword(auth, authEmail, authPassword);
      } else {
        await signInWithEmailAndPassword(auth, authEmail, authPassword);
      }
      setShowLoginModal(false);
      setAuthEmail('');
      setAuthPassword('');
    } catch (err: any) {
      console.error("Auth error:", err);
      setAuthError(err.message || 'Authentication failed');
    } finally {
      setIsAuthLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    try {
      await signInWithGoogle();
      setShowLoginModal(false);
    } catch (err: any) {
      const errMsg = err?.message || '';
      const errCode = err?.code || '';
      if (err.message === 'SIGN_IN_POPUP_BLOCKED') {
        setAuthError("Sign-in popup was blocked. Please check your browser settings and try again.");
      } else if (errCode === 'auth/popup-closed-by-user' || errMsg.includes('popup-closed-by-user')) {
        setAuthError("Google Login was closed or blocked. Because this preview is running inside an iframe, standard popup communication can be restricted by your browser's third-party cookie/privacy settings. Please use the Email & Password form below to sign up or sign in directly (fully supported)!");
      } else {
        setAuthError("Google Login failed: " + err.message);
      }
    }
  };

  useEffect(() => {
    localStorage.setItem('app_mySniperTrades', JSON.stringify(mySniperTrades.slice(0, 50)));
  }, [mySniperTrades]);

  useEffect(() => {
    const interval = setInterval(() => {
      setTokenMetrics(prev => {
        const next = { ...prev };
        let changed = false;
        const now = Date.now();
        Object.keys(next).forEach(key => {
          const m = next[key];
          const age = now - m.lastUpdated;
          
          // Pruning logic:
          // 1. Remove if no activity for 10 minutes
          if (age > 10 * 60 * 1000) {
            delete next[key];
            changed = true;
          }
        });

        // Limit maximum items to prevent memory / DOM bloat
        const keys = Object.keys(next);
        if (keys.length > 150) {
          keys.sort((a, b) => next[b].lastUpdated - next[a].lastUpdated);
          for (let i = 150; i < keys.length; i++) {
            delete next[keys[i]];
            changed = true;
          }
        }
        return changed ? next : prev;
      });
    }, 10000);
    // Advanced Price Synchronization for Active Positions via MarketDataManager
    const state = useAppStore.getState();
    const positions = state.activePositions;
    const activeMints = Object.keys(positions);
    
    let unsubscribe: (() => void) | null = null;
    if (activeMints.length > 0) {
      unsubscribe = marketDataManager.subscribe(activeMints, (prices) => {
        useAppStore.getState().setTokenMetrics(prev => {
          const next = { ...prev };
          prices.forEach((tp, addr) => {
            if (positions[addr]) {
              next[addr] = {
                ...next[addr],
                address: addr,
                priceUsd: tp.priceUsd ?? undefined,
                priceNative: tp.priceNative || 0,
                lastUpdated: Date.now()
              };
            }
          });
          return next;
        });
      }, 'activePosition');
    }

    return () => {
      clearInterval(interval);
      if (unsubscribe) unsubscribe();
    };
  }, []);

  const priceFetchLocks = useRef<Map<string, Promise<any>>>(new Map());
  const lastFetchTimes = useRef<Map<string, number>>(new Map());
  const hasPlayedDiscoverySound = useRef<Set<string>>(new Set());

  const playDiscoverySound = () => {
    try {
      // Singleton AudioContext to bypass context limits (Bug 9)
      if (typeof window !== 'undefined') {
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioContextClass) {
          if (!(window as any).__sharedAudioCtx || (window as any).__sharedAudioCtx.state === 'closed') {
            (window as any).__sharedAudioCtx = new AudioContextClass();
          }
          const audioCtx = (window as any).__sharedAudioCtx;
          if (audioCtx.state === 'suspended') {
            audioCtx.resume().catch(() => {});
          }

          const oscillator = audioCtx.createOscillator();
          const gainNode = audioCtx.createGain();

          oscillator.connect(gainNode);
          gainNode.connect(audioCtx.destination);

          oscillator.type = 'sine';
          // Slightly higher pitch, extremely short for subtle discovery feel
          oscillator.frequency.setValueAtTime(1400, audioCtx.currentTime);
          oscillator.frequency.exponentialRampToValueAtTime(1200, audioCtx.currentTime + 0.05);

          gainNode.gain.setValueAtTime(0, audioCtx.currentTime);
          gainNode.gain.linearRampToValueAtTime(0.04, audioCtx.currentTime + 0.002);
          gainNode.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 0.08);

          oscillator.start();
          oscillator.stop(audioCtx.currentTime + 0.08);
        }
      }
    } catch (e) {
      // Browsers often block audio until user interaction
    }
  };

  const playAlertSound = () => {
    try {
      // Singleton AudioContext to bypass context limits (Bug 9)
      if (typeof window !== 'undefined') {
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioContextClass) {
          if (!(window as any).__sharedAudioCtx || (window as any).__sharedAudioCtx.state === 'closed') {
            (window as any).__sharedAudioCtx = new AudioContextClass();
          }
          const audioCtx = (window as any).__sharedAudioCtx;
          if (audioCtx.state === 'suspended') {
            audioCtx.resume().catch(() => {});
          }

          const oscillator = audioCtx.createOscillator();
          const gainNode = audioCtx.createGain();

          oscillator.connect(gainNode);
          gainNode.connect(audioCtx.destination);

          oscillator.type = 'sine';
          oscillator.frequency.setValueAtTime(1000, audioCtx.currentTime);
          
          gainNode.gain.setValueAtTime(0, audioCtx.currentTime);
          gainNode.gain.linearRampToValueAtTime(0.08, audioCtx.currentTime + 0.005);
          gainNode.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 0.15);

          oscillator.start();
          oscillator.stop(audioCtx.currentTime + 0.15);
        }
      }
    } catch (e) {
      // Browsers often block audio until user interaction
    }
  };

  const fetchTokenSecurityDataBatch = async (
    mints: string[]
  ): Promise<Map<string, any>> => {
    const uniqueMints = Array.from(
      new Set(mints.filter(Boolean))
    );

    const result = new Map<string, any>();

    if (uniqueMints.length === 0) {
      return result;
    }

    // Server/DexScreener supports batches of 30.
    for (let i = 0; i < uniqueMints.length; i += 30) {
      const chunk = uniqueMints.slice(i, i + 30);

      try {
        const response = await fetch(
          `/api/dex/tokens/${chunk.join(',')}`
        );

        if (!response.ok) {
          console.warn(
            `[MarketData] Batch request failed: ${response.status}`
          );
          continue;
        }

        const text = await response.text();

        if (!text || text.trim().startsWith('<')) {
          continue;
        }

        const data = JSON.parse(text);

        if (!Array.isArray(data?.pairs)) {
          continue;
        }

        // Group pairs by mint.
        const pairsByMint = new Map<string, any[]>();

        for (const pair of data.pairs) {
          const mint = pair?.baseToken?.address;

          if (!mint) continue;

          if (!pairsByMint.has(mint)) {
            pairsByMint.set(mint, []);
          }

          pairsByMint.get(mint)!.push(pair);
        }

        for (const mint of chunk) {
          const pairs = pairsByMint.get(mint);

          if (!pairs || pairs.length === 0) {
            continue;
          }

          // Prefer SOL pairs.
          const solPairs = pairs.filter(
            (p: any) =>
              p.quoteToken?.address ===
                'So11111111111111111111111111111111111111112' ||
              p.quoteToken?.symbol === 'SOL'
          );

          const candidates =
            solPairs.length > 0 ? solPairs : pairs;

          const pair = [...candidates].sort(
            (a: any, b: any) =>
              Number(b.liquidity?.usd || 0) -
              Number(a.liquidity?.usd || 0)
          )[0];

          if (!pair) continue;

          const buys5m = Number(pair.txns?.m5?.buys || pair.txns?.h1?.buys || 0);
          const sells5m = Number(pair.txns?.m5?.sells || pair.txns?.h1?.sells || 0);
          const buyVolume = Number(pair.volume?.m5 || pair.volume?.h1 || 0);
          const sellVolume = 0;
          const buyRatio = sells5m > 0 ? buys5m / sells5m : (buys5m > 0 ? buys5m : 0);

          result.set(mint, {
            mint,

            symbol: pair.baseToken?.symbol || 'UNKNOWN',
            name: pair.baseToken?.name || 'Unknown',

            priceUsd: Number(pair.priceUsd || 0),
            priceNative: Number(pair.priceNative || 0),

            priceChange:
              Number(pair.priceChange?.m5 || 0),

            priceChange5m:
              Number(pair.priceChange?.m5 || 0),

            priceChange1h:
              Number(pair.priceChange?.h1 || 0),

            marketCap:
              Number(pair.marketCap || pair.fdv || 0),

            liquidity:
              Number(pair.liquidity?.usd || 0),

            volume24h:
              Number(pair.volume?.h24 || 0),

            buyRatio,
            buyCount: buys5m,
            sellCount: sells5m,
            buyVolume,
            sellVolume,
            recentBuysTimeline: [],

            dexId:
              pair.dexId || 'unknown',

            pairAddress:
              pair.pairAddress || '',

            pairCreatedAt:
              Number(pair.pairCreatedAt || 0),

            url:
              pair.url || '',

            rawPair: pair,
          });
        }
      } catch (error) {
        console.warn(
          '[MarketData] Batch fetch error:',
          error
        );
      }
    }

    return result;
  };

  // Fetch token stats and security from DEXScreener
  const fetchTokenSecurityData = (mint: string, retries = 3, backoff = 1000): Promise<any> => {
    const lastFetch = lastFetchTimes.current.get(mint) || 0;
    if (Date.now() - lastFetch < 2000) return Promise.resolve(null);
    
    if (priceFetchLocks.current.has(mint)) {
      return priceFetchLocks.current.get(mint)!;
    }
    
    const promise = (async () => {
      lastFetchTimes.current.set(mint, Date.now());
      try {
        return await fetchTokenSecurityDataInner(mint, retries, backoff);
      } finally {
        priceFetchLocks.current.delete(mint);
      }
    })();
    
    priceFetchLocks.current.set(mint, promise);
    return promise;
  };

  const fetchTokenSecurityDataInner = async (mint: string, retries = 3, backoff = 1000, isRetry = false): Promise<any> => {
    try {
      // Use the server-side proxy to benefit from caching and shared rate limits
      const response = await fetch(`/api/dex/tokens/${mint}`);
      
      if (!response.ok) {
        if (response.status === 429 && retries > 0) {
          console.warn(`DexScreener Rate Limit for ${mint}. Retrying after ${backoff}ms...`);
          // Exponential backoff for rate limits
          await new Promise(res => setTimeout(res, backoff));
          return await fetchTokenSecurityDataInner(mint, retries - 1, backoff * 2, true);
        }
        return null;
      }
      
      const text = await response.text();
      if (!text || text.trim().startsWith('<')) {
        return null;
      }
      const data = JSON.parse(text);
      
      if (data.pairs && data.pairs.length > 0) {
        // Prioritize SOL pairs, then sort by liquidity
        const solPairs = data.pairs.filter((p: any) => 
          p.quoteToken?.address === 'So11111111111111111111111111111111111111112' || 
          p.quoteToken?.symbol === 'SOL'
        );
        
        // Check if any pair in the collection is graduated (Raydium, Pumpswap, Orca, Meteora)
        const graduatedPairsInCollection = data.pairs.filter((p: any) => {
          return !p.baseToken?.address?.toLowerCase().endsWith('pump');
        });

        let candidatePairs = solPairs.length > 0 ? solPairs : data.pairs;
        if (graduatedPairsInCollection.length > 0) {
          const graduatedCandidates = candidatePairs.filter((p: any) => {
            return !p.baseToken?.address?.toLowerCase().endsWith('pump');
          });
          candidatePairs = graduatedCandidates.length > 0 ? graduatedCandidates : graduatedPairsInCollection;
        }

        const sortedPairs = [...candidatePairs].sort((a, b) => (parseFloat(b.liquidity?.usd || '0') - parseFloat(a.liquidity?.usd || '0')));
        const pair = sortedPairs[0];
        const dexId = pair.dexId || "unknown";
        
        const liquidity = pair.liquidity?.usd || 0;
        const volume24h = pair.volume?.h24 || 0;
        const marketCap = pair.fdv || 0;
        const priceUsd = parseFloat(pair.priceUsd || "0");
        
        // If it's a SOL pair, priceNative is the SOL price.
        // If not (e.g. USDC pair), priceNative reflects the quote token (e.g. USDC), which causes huge UI accounting errors.
        // We MUST normalize non-SOL pair prices to SOL natively here!
        let priceNative = parseFloat(pair.priceNative || "0");
        const isSolPair = pair.quoteToken?.address === 'So11111111111111111111111111111111111111112' || pair.quoteToken?.symbol === 'SOL';
        
        if (!isSolPair && priceUsd > 0) {
           // We have the USD price of the token. We need to convert it to SOL.
           // Fetch SOL's current USD price via Jupiter
           try {
             const solRes = await fetch('/api/jup/price?ids=So11111111111111111111111111111111111111112');
             if (solRes.ok) {
               const solText = await solRes.text();
               if (solText && !solText.trim().startsWith('<')) {
                 const solData = JSON.parse(solText);
                 if (solData.data && solData.data['So11111111111111111111111111111111111111112'] && solData.data['So11111111111111111111111111111111111111112'].price) {
                   const solPriceUsd = parseFloat(solData.data['So11111111111111111111111111111111111111112'].price);
                   setSolPriceUsd(solPriceUsd);
                   // Normalize Token's USD price to SOL amount
                   priceNative = priceUsd / solPriceUsd;
                 }
               }
             }
           } catch(e) {
             const solUsd = getSolPriceUsd();
             if (solUsd > 0) {
               priceNative = priceUsd / solUsd;
             } else {
               priceNative = 0;
             }
           }
        }

        let bondingCurveProgress = undefined;
        const isGraduatedLocal = !(mint || '').toLowerCase().endsWith('pump');
        if (isGraduatedLocal) {
          bondingCurveProgress = 100.0;
        } else if ((dexId || '').toLowerCase().includes('pump') && !(dexId || '').toLowerCase().includes('pumpswap')) {
          if (priceNative > 0) {
            const virtualTokenReserves = Math.sqrt(32190000000 / priceNative);
            const calculatedProgress = ((1073000000 - virtualTokenReserves) / 793100000) * 100;
            bondingCurveProgress = Math.min(99.9, Math.max(0, calculatedProgress));
          }
        }

        const priceChange = pair.priceChange?.m5 || 0;
        const pairCreatedAt = pair.pairCreatedAt || 0;
        const symbol = pair.baseToken?.symbol || "TOKEN";
        const category = categorizeToken(symbol, mint);
        
        // Strict deterministic security derivation (No synthetic Math.random)
        const isBurned = pair.liquidity?.base > 0;
        const devPct = pair.info?.devPercentage ?? 0; 
        const top10Pct = pair.info?.top10Percentage ?? 0;
        const holders = pair.info?.holders ?? 0;
        const volMcRatio = marketCap > 0 ? volume24h / marketCap : 0;

        const warnings: string[] = [];
        
        // 1. Sellability check
        const isSellable = pair.priceUsd ? parseFloat(pair.priceUsd) > 0 : true;
        if (!isSellable) warnings.push("NOT SELLABLE");
        
        // 2. Verification check
        const isVerified = Boolean(pair.pairAddress && pair.baseToken?.address);
        if (!isVerified) warnings.push("NOT VERIFIED");
        
        // 3. Low Liquidity
        const hasLowLiquidity = liquidity < 15000;
        if (hasLowLiquidity) warnings.push("LOW LIQUIDITY");
        
        // 4. Low Organic Activity
        const isOrganic = volMcRatio > 0.05 && volMcRatio < 2.5;
        if (!isOrganic) warnings.push("LOW ORGANIC ACTIVITY");
        
        // 5. New Listing
        const isNewListing = pairCreatedAt > 0 ? (Date.now() - pairCreatedAt) < 86400000 : false;
        if (isNewListing) warnings.push("NEW LISTING");
        
        // 6. High Single Ownership
        const highSingleOwnership = top10Pct > 40;
        if (highSingleOwnership) warnings.push("HIGH SINGLE OWNERSHIP");
        
        let riskScore = 0;
        if (!isSellable) riskScore += 50;
        if (!isVerified) riskScore += 15;
        if (hasLowLiquidity) riskScore += 25;
        if (!isOrganic) riskScore += 10;
        if (highSingleOwnership) riskScore += 30;
        if (devPct > 2) riskScore += 20;
        riskScore = Math.min(riskScore, 100);

        const maxAllowedRisk = latestState.current?.hardenedMaxRiskScore || 22;
        const isRugSafe = riskScore <= maxAllowedRisk && isSellable && !hasLowLiquidity;

        // On-chain authority flags: Default to false/undefined if unverified on-chain rather than hardcoding true
        const mintAuthorityRevoked = pair.info?.mintAuthorityRevoked ?? false;
        const freezeAuthorityRevoked = pair.info?.freezeAuthorityRevoked ?? false;
        const metadataImmutable = pair.info?.metadataImmutable ?? false;
        
        const socialMentionsGrowth = 0;
        const socialSentiment = 50;
        const isAiAgentControlled = category === 'AI_MEME' || category === 'AI';
        const botRisk = 'LOW';
        const narrativeScore = 50;

        const marketCapActual = marketCap;
        const volumeActual = volume24h;
        const priceUsdActual = priceUsd;
        
        const liquidityRatio = marketCapActual > 0 ? (liquidity / marketCapActual) * 100 : 0;
        const holderGrowthHr = 0;
        const devPctActual = devPct;
        const top10PctActual = top10Pct;

        const buys5m = Number(pair.txns?.m5?.buys || pair.txns?.h1?.buys || 0);
        const sells5m = Number(pair.txns?.m5?.sells || pair.txns?.h1?.sells || 0);
        const buyVolume = Number(pair.volume?.m5 || pair.volume?.h1 || 0);
        const buyRatio = sells5m > 0 ? buys5m / sells5m : (buys5m > 0 ? buys5m : 0);

        return {
          liquidity: liquidity,
          volume24h: volumeActual,
          marketCap: marketCapActual,
          priceUsd: priceUsdActual,
          priceNative: priceNative,
          supply: (marketCapActual > 0 && priceUsdActual > 0) ? (marketCapActual / priceUsdActual) : 0,
          priceChange: parseFloat(priceChange.toString()),
          liquidityBurned: isBurned,
          devWalletPercentage: devPctActual,
          top10Percentage: top10PctActual,
          holderCount: holders,
          volMcRatio: marketCapActual > 0 ? volumeActual / marketCapActual : 0,
          pairCreatedAt,
          category,
          symbol,
          dexId,
          bondingCurveProgress,
          buyRatio,
          buyCount: buys5m,
          sellCount: sells5m,
          buyVolume,
          sellVolume: 0,
          recentBuysTimeline: [],
          socialMentionsGrowth,
          socialSentiment,
          botRisk,
          isAiAgentControlled,
          narrativeScore,
          mintAuthorityRevoked,
          freezeAuthorityRevoked,
          metadataImmutable,
          liquidityRatio,
          holderGrowthHr,
          riskScore,
          security: {
            isSellable,
            isVerified,
            isRugSafe,
            hasLowLiquidity,
            isOrganic,
            isNewListing,
            highSingleOwnership,
            riskScore,
            warnings
          }
        };
      }
    } catch (e) {
      // console.error('DexScreener fetch failed', e);
    }
    return null;
  };

  const processedSigs = useRef<Set<string>>(new Set());
  const pendingDiscovery = useRef<Set<string>>(new Set());

  const processIncomingTrade = (trade: Trade) => {
    if (processedSigs.current.has(trade.signature)) return;
    processedSigs.current.add(trade.signature);
    
        // Update Token Metrics for BOTH buys and sells
        setTokenMetrics(prev => {
          const isNew = !prev[trade.tokenAddress];
          if (isNew && trade.type === 'buy' && !hasPlayedDiscoverySound.current.has(trade.tokenAddress)) {
            playDiscoverySound();
            hasPlayedDiscoverySound.current.add(trade.tokenAddress);
          }

          const current = prev[trade.tokenAddress] || {
            address: trade.tokenAddress,
            symbol: trade.token,
            buyCount: 0,
            percentageIncrease: 0,
            lastUpdated: Date.now(),
            recentBuysTimeline: [],
            buyVolume: 0,
            sellCount: 0,
            sellVolume: 0,
            discoveredAt: Date.now(),
            uniqueWallets: new Set(),
            latestAlert: 'NORMAL',
            category: categorizeToken(trade.token, trade.tokenAddress)
          };
          
          const updatedTimeline = [
            ...(current.recentBuysTimeline || []), 
            { t: Date.now(), a: trade.amount, w: trade.fromAccount, type: trade.type }
          ].filter(item => Date.now() - item.t < 5 * 60 * 1000);

          const ageMins = (Date.now() - (current.discoveredAt || Date.now())) / 60000;
          const isRaydiumListed = !(trade.tokenAddress || '').toLowerCase().endsWith('pump');
          const mc = current.marketCap || 0;
          const liq = current.liquidity || 0;
          const liqRatio = mc > 0 ? liq / mc : 0;
          const isRugScanPassed = !!current.isRugSafe && !!current.mintAuthorityRevoked && !!current.liquidityBurned;

          let alertType: 'VOLUME_SPIKE' | 'WHALE_BUY' | 'HIGH_BUY' | 'MIGRATED' | 'NORMAL' = 'NORMAL';

          if (trade.type === 'buy' && ageMins >= 0.5) {
            // Detect Migration
            if ((trade.token || '').toLowerCase().includes('migrating') || (current.bondingCurveProgress || 0) >= 99.5) {
              alertType = 'MIGRATED';
            }

            // Detect Volume Spike (📈)
            const buyCount5m = updatedTimeline.filter((t: any) => t.type === 'buy').length;
            if (buyCount5m >= 5 && liq >= 30000 && (current.riskScore || 0) < 22) {
              alertType = 'VOLUME_SPIKE';
            }

            // Detect High Buy / Whale Buy with strict MC & Liquidity filters
            const calibratedMinMcap = isRaydiumListed ? 65000 : 110000;
            const buy30s = updatedTimeline.filter((t: any) => t.type === 'buy' && (Date.now() - t.t < 30000)).length;

            // HIGH_BUY (🔥)
            if (trade.amount > telemetryHighBuyMin || buy30s > 8) {
              if (mc >= calibratedMinMcap && liq >= 55000 && liqRatio >= 0.07 && isRugScanPassed) {
                alertType = 'HIGH_BUY';
              }
            }

            // WHALE_BUY (🐋)
            if (trade.amount > telemetryWhaleBuyMin) {
              if (mc >= 250000 && (current.top10Percentage || 0) < 14.0 && (current.devWalletPercentage || 0) < 0.8) {
                alertType = 'WHALE_BUY';
              }
            }
            
            if (alertType !== 'NORMAL' && !alertedTokens.current.has(trade.tokenAddress + '_' + alertType)) {
              alertedTokens.current.add(trade.tokenAddress + '_' + alertType);
              
              let emoji = '🚨';
              let title = 'ALPHA ALERT';
              if (alertType === 'WHALE_BUY') { emoji = '🐋'; title = 'WHALE BUY'; }
              if (alertType === 'HIGH_BUY') { emoji = '🔥'; title = 'HIGH BUY'; }
              if (alertType === 'MIGRATED') { emoji = '🚀'; title = 'TOKEN MIGRATED'; }
              if (alertType === 'VOLUME_SPIKE') { emoji = '📈'; title = 'VOLUME SPIKE'; }

              const buyLink = `${window.location.origin}${window.location.pathname}?buy=${trade.tokenAddress}&auto=true`;
              const sellLink = `${window.location.origin}${window.location.pathname}?sell=${trade.tokenAddress}&auto=true`;
              const msg = `${emoji} <b>${title}</b>\n\n` +
                          `Token: <b>$${trade.token}</b>\n` +
                          `Amount: <b>${trade.amount.toLocaleString()} tokens</b>\n` +
                          `Address: <code>${trade.tokenAddress}</code>\n\n` +
                          `<b>ACTIONS:</b>\n` +
                          `<a href="${buyLink}">🎯 QUICK BUY IN MATRIX</a>\n` +
                          `<a href="${sellLink}">🔴 QUICK SELL / VIEW PORTFOLIO</a>\n\n` +
                          `<a href="https://dexscreener.com/solana/${trade.tokenAddress}">📊 View on DexScreener</a>`;
              fns.current.sendTelegramAlert(msg, true).catch((err: any) => console.warn('Telegram alert failed:', err));
              
              if (alertType === 'WHALE_BUY' || alertType === 'HIGH_BUY') {
                setTelemetryAlerts(prev => [
                  {
                    id: `alert-${Date.now()}-${Math.random()}`,
                    token: trade.token,
                    address: trade.tokenAddress,
                    type: alertType as 'WHALE_BUY' | 'HIGH_BUY',
                    message: `${alertType === 'WHALE_BUY' ? 'Legendary' : 'Massive'} Buy: ${trade.amount.toLocaleString()} ${trade.token}`,
                    timestamp: Date.now()
                  },
                  ...prev.slice(0, 19)
                ]);
              }
            }
          }
          
          // Compute dynamic fallback percentage increase statistic from buy/sell timeline momentum to prevent flat 0% display on lag
          const buysCount = updatedTimeline.filter(x => x.type === 'buy').length;
          const sellsCount = updatedTimeline.filter(x => x.type === 'sell').length;
          const netTradesCount = buysCount - sellsCount;
          const dynamicFallbackPct = Math.max(-95, Math.min(350, netTradesCount * 1.5));

          let calculatedPct = current.percentageIncrease;
          if (calculatedPct === undefined || calculatedPct === 0) {
            calculatedPct = dynamicFallbackPct;
          } else {
            calculatedPct = trade.type === 'buy' ? calculatedPct + 0.6 : calculatedPct - 0.5;
          }
          
          return {
            ...prev,
            [trade.tokenAddress]: {
              ...current,
              buyCount: trade.type === 'buy' ? current.buyCount + 1 : current.buyCount,
              buyVolume: trade.type === 'buy' ? current.buyVolume + trade.amount : current.buyVolume,
              sellCount: trade.type === 'sell' ? current.sellCount + 1 : current.sellCount,
              sellVolume: trade.type === 'sell' ? current.sellVolume + trade.amount : current.sellVolume,
              buyRatio: (trade.type === 'buy' ? current.buyCount + 1 : current.buyCount) / Math.max(1, trade.type === 'sell' ? current.sellCount + 1 : current.sellCount),
              percentageIncrease: parseFloat(calculatedPct.toFixed(2)),
              lastUpdated: Date.now(),
              recentBuysTimeline: updatedTimeline,
              latestAlert: (trade.type === 'buy' && alertType !== 'NORMAL') ? alertType : current.latestAlert,
              isSurging: trade.type === 'buy' && calculatedPct <= 10 && ageMins > 30,
              whaleEntranceTime: (trade.type === 'buy' && (alertType === 'WHALE_BUY' || alertType === 'HIGH_BUY')) && !current.whaleEntranceTime 
                ? Date.now() 
                : current.whaleEntranceTime
            }
          };
        });

        if (trade.type === 'buy') {
          // Reset surge flag after 10s
          setTimeout(() => {
            setTokenMetrics(p => {
              const m = p[trade.tokenAddress];
              if (!m) return p;
              return { ...p, [trade.tokenAddress]: { ...m, isSurging: false } };
            });
          }, 10000);

          // Async update security & safety data
          const now = Date.now();
          const currentMetric = tokenMetrics[trade.tokenAddress];
          const needsUpdate = !currentMetric || (now - (currentMetric.lastUpdated || 0) > 2000) || !currentMetric.liquidity;

          if (needsUpdate && !pendingDiscovery.current.has(trade.tokenAddress)) {
            pendingDiscovery.current.add(trade.tokenAddress);
            fetchTokenSecurityData(trade.tokenAddress).then(security => {
              pendingDiscovery.current.delete(trade.tokenAddress);
              if (!security) return;

              // Keep simulation prices anchored to real on-chain prices when available
              if (security.priceNative && security.priceNative > 0) {
              }
              
              setTokenMetrics(m => {
                const existing = m[trade.tokenAddress];
                if (!existing) return m;

                const isRugSafe = security.security.isRugSafe;

                const updated = { 
                  ...existing, 
                  ...security.security,
                  percentageIncrease: security.priceChange,
                  liquidity: security.liquidity,
                  volume24h: security.volume24h,
                  marketCap: security.marketCap,
                  priceUsd: security.priceUsd,
                  priceNative: security.priceNative,
                  supply: security.supply,
                  holderCount: security.holderCount,
                  pairCreatedAt: security.pairCreatedAt,
                  bondingCurveProgress: security.bondingCurveProgress,
                  devWalletPercentage: security.devWalletPercentage,
                  top10Percentage: security.top10Percentage,
                  volMcRatio: security.volMcRatio,
                  isRugSafe: isRugSafe,
                  riskScore: security.riskScore,
                  botRisk: security.botRisk,
                  isAiAgentControlled: security.isAiAgentControlled,
                  liquidityBurned: security.liquidityBurned,
                  mintAuthorityRevoked: security.mintAuthorityRevoked,
                  freezeAuthorityRevoked: security.freezeAuthorityRevoked,
                  metadataImmutable: security.metadataImmutable,
                  liquidityRatio: security.liquidityRatio,
                  holderGrowthHr: security.holderGrowthHr,
                  lastUpdated: Date.now()
                };

                // 100x Gem Detection for Telegram
                const mc = updated.marketCap || 0;
                const liq = updated.liquidity || 0;
                const liqRatio = updated.liquidityRatio || 0;
                const tokensPerDollar = (updated.priceUsd || 0) > 0 ? (1 / updated.priceUsd!) : 0;
                
                const is100xGem = updated.mintAuthorityRevoked && 
                                  updated.freezeAuthorityRevoked && 
                                  updated.liquidityBurned && 
                                  mc >= 100000 && mc <= 5000000 &&
                                  tokensPerDollar >= 2000 && tokensPerDollar <= 150000;

                if (is100xGem && !alertedTokens.current.has(trade.tokenAddress + '_100x')) {
                  alertedTokens.current.add(trade.tokenAddress + '_100x');
                  const buyLinkX = `https://jup.ag/swap/SOL-${trade.tokenAddress}`;
                  const sellLinkX = `https://jup.ag/swap/${trade.tokenAddress}-SOL`;
                  const msg = `💎 <b>MATRIX 100x GEM DISCOVERED</b>\n\n` +
                              `Token: <b>$${trade.token}</b>\n` +
                              `Market Cap: <b>$${Math.floor(mc).toLocaleString()}</b>\n` +
                              `Liquidity: <b>$${Math.floor(liq).toLocaleString()} (${liqRatio.toFixed(1)}%)</b>\n` +
                              `Density: <b>${Math.floor(tokensPerDollar).toLocaleString()} tokens/$1</b>\n\n` +
                              `Security: <b>VERIFIED ✅</b>\n` +
                              `Address: <code>${trade.tokenAddress}</code>\n\n` +
                              `<b>ACTIONS:</b>\n` +
                              `<a href="${buyLinkX}">🎯 BUY ON JUPITER</a>\n` +
                              `<a href="${sellLinkX}">🔴 SELL ON JUPITER</a>\n\n` +
                              `<a href="https://dexscreener.com/solana/${trade.tokenAddress}">📊 View on DexScreener</a>`;
                  fns.current.sendTelegramAlert(msg, true).catch((err: any) => console.warn('Telegram alert failed:', err));
                }

                // TRIGGER AUTO-SNIPE (High-Frequency Scalper Mode)
                const buys15s = (updated.recentBuysTimeline || []).filter((t: any) => t.type === 'buy' && Date.now() - t.t < 15000).length;
                const sells15s = (updated.recentBuysTimeline || []).filter((t: any) => t.type === 'sell' && Date.now() - t.t < 15000).length;
                const buy3s = (updated.recentBuysTimeline || []).filter((t: any) => t.type === 'buy' && Date.now() - t.t < 3000).length;
                const buy30s = (updated.recentBuysTimeline || []).filter((t: any) => t.type === 'buy' && Date.now() - t.t < 30000).length;
                
                const buyVolume = updated.buyVolume || 0;
                const sellVolume = updated.sellVolume || 0;
                const isHighVolume = buyVolume > (sellVolume * 3);
                const currentBuyRatio = updated.buyCount / (updated.sellCount || 1);
                
                const marketCap = updated.marketCap || 0;
                const liquidity = updated.liquidity || 0;
                const top10Percent = updated.top10Percentage || 0;
                const progress = updated.bondingCurveProgress;
                
                // ANTI-FOMO & SCALPER GATES
                const priceChange1m = updated.percentageIncrease || 0; // Using DEXScreener m5/h1 proxy or last update
                const liquidityRatio = liquidity / marketCap;
                const blockVelocityRatio = buys15s / Math.max(sells15s, 1);
                
                // USER CRITERIA: Progress above 90%, High Buy Volume, Strict Scalper Entry
                const stage = detectTokenStage({
                  address: trade.tokenAddress,
                  dexId: updated.dexId,
                  bondingCurveProgress: progress,
                  isRaydiumListed: (updated as any).isRaydiumListed
                });
                const isGraduatedLive = stage.isMigrated;
                const hasHighProgress = isGraduatedLive || (progress !== undefined && progress >= latestState.current.hardenedMinBondingProgress && progress <= latestState.current.hardenedMaxBondingProgress);
                const isHealthyPool = liquidity >= 55000 && liquidityRatio >= 0.07;
                const hasVelocity = buys15s >= 8 && blockVelocityRatio >= 4.0; // Hardened velocity for short-term hits
                const notOverextended = priceChange1m <= 18.0 && priceChange1m >= 1.5; // Raised cap for vertical runners
                
                const maxRisk = latestState.current.hardenedMaxRiskScore ?? 22;
                const minLiq = latestState.current.hardenedLiquidityMin ?? 20000;
                const minLiqRatio = (latestState.current.hardenedLiquidityRatio ?? 5) / 100;
                const tokenRisk = updated.riskScore !== undefined ? updated.riskScore : 20;
                const isRiskValid = tokenRisk <= maxRisk;
                const isLiquidityValid = liquidity >= minLiq && liquidityRatio >= minLiqRatio;

                const createdAtRaw = updated.pairCreatedAt || security.security?.pairCreatedAt;
                const normCreatedAt = createdAtRaw ? (createdAtRaw < 1000000000000 ? createdAtRaw * 1000 : createdAtRaw) : null;
                const minAge = latestState.current.hardenedMinAge ?? 0;
                const maxAge = latestState.current.hardenedMaxAge ?? 120;
                const tokenAgeMin = normCreatedAt && normCreatedAt > 0 ? (now - normCreatedAt) / 60000 : -1;
                const isAgeValid = tokenAgeMin >= 0 && tokenAgeMin >= minAge && tokenAgeMin <= maxAge;

                const isMassiveStrength = hasHighProgress && 
                                          isHealthyPool &&
                                          hasVelocity &&
                                          notOverextended &&
                                          top10Percent < 14.0 &&
                                          marketCap >= 70000 && marketCap <= 1500000;

                if (latestState.current.autoSniperEnabled && isRugSafe && isRiskValid && isLiquidityValid && isAgeValid && security.security.isOrganic && isMassiveStrength) {
                  fns.current.executeAutoTrade(trade.tokenAddress, trade.token);
                }

                return { ...m, [trade.tokenAddress]: updated };
              });
            });
          }
        }
  }

  const processIncomingTradeRef = useRef<(trade: Trade) => void>(() => undefined);
  processIncomingTradeRef.current = processIncomingTrade;

  useEffect(() => {
    return unifiedTradePipeline.subscribe((event) => {
      const trade: Trade = event.rawTrade || {
        id: event.eventId,
        type: event.type.toLowerCase() as 'buy' | 'sell',
        token: event.symbol,
        tokenAddress: event.mint,
        amount: event.amount,
        timestamp: new Date(event.timestamp).toISOString(),
        signature: event.signature || 'synthetic',
        status: 'confirmed',
        fromAccount: event.wallet,
      };
      processIncomingTradeRef.current(trade);
    });
  }, []);

  const connectionRef = useRef<Connection | null>(null);
  const masterConnectionRef = useRef<Connection | null>(null);
  const subscriptionIds = useRef<Record<string, number>>({});
  // Separate wallet-signature registry so wallet events cannot race React state updates.
  const processedWalletSignatures = useRef<Set<string>>(new Set());
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 1024);
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const [authLoaded, setAuthLoaded] = useState(false);

  // Auth & Database Sync
  useEffect(() => {
    let unsubscribeAuth: () => void;
    authPersistencePromise.then(() => {
      unsubscribeAuth = onAuthStateChanged(auth, async (currentUser) => {
        if (!currentUser) {
          setUser(null);
          setMonitoredWallets([]);
          setIsMonitoring(false);
        } else {
          setUser(currentUser);
          setIsMonitoring(false);
          
          // Hydrate local UI state from authoritative backend criteria now that auth is ready
          syncManager.fetchAuthoritativeCriteria().then((res) => {
            if (res && res.criteria) {
              const c = res.criteria;
              
              if (c.buyAmountSol !== undefined) {
                localStorage.setItem('app_buyAmountSol', String(c.buyAmountSol));
                useAppStore.setState({ buyAmountSol: c.buyAmountSol });
              }
              if (c.minTakeProfit !== undefined) {
                localStorage.setItem('app_minTakeProfit', String(c.minTakeProfit));
                useAppStore.setState({ minTakeProfit: c.minTakeProfit });
              }
              if (c.maxTakeProfit !== undefined) {
                localStorage.setItem('app_maxTakeProfit', String(c.maxTakeProfit));
                useAppStore.setState({ maxTakeProfit: c.maxTakeProfit });
              }
              if (c.stopLoss !== undefined) {
                localStorage.setItem('app_stopLoss', String(c.stopLoss));
                useAppStore.setState({ stopLoss: c.stopLoss });
              }
              if (c.maxPositions !== undefined) {
                localStorage.setItem('app_maxPositions', String(c.maxPositions));
                useAppStore.setState({ maxPositions: c.maxPositions });
              }
              
              console.log(`✅ [CRITERIA HYDRATED] Successfully loaded authoritative criteria v${res.version}`);
            }
          });
        }
        setAuthLoaded(true);
      });
    }).catch((err) => {
      console.error(err);
      setAuthLoaded(true); // Ensure app unblocks if auth fails
    });

    return () => {
      if (unsubscribeAuth) unsubscribeAuth();
    };
  }, []);

  useEffect(() => {
    if (!user) return;

    const q = query(collection(db, 'wallets'), where('userId', '==', user.uid));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const wallets = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as {id: string, address: string, label: string}[];
      setMonitoredWallets(wallets);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'wallets');
    });

    return () => unsubscribe();
  }, [user]);

  // Firestore Loading & Saving for App.tsx States
  const isFirestoreLoading = useRef(false);
  useEffect(() => {
    if (!user) return;

    const loadSettings = async () => {
      try {
        isFirestoreLoading.current = true;
        const docRef = doc(db, 'settings', user.uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          if (data.buyAmountSol !== undefined) setBuyAmountSol(Number(data.buyAmountSol));
          if (data.minTakeProfit !== undefined) setMinTakeProfit(Number(data.minTakeProfit));
          if (data.maxTakeProfit !== undefined) setMaxTakeProfit(Number(data.maxTakeProfit));
          if (data.bondingCurveTakeProfit !== undefined) setBondingCurveTakeProfit(Number(data.bondingCurveTakeProfit));
          if (data.stopLoss !== undefined) setStopLoss(Number(data.stopLoss));
          if (data.bondingCurveStopLoss !== undefined) setBondingCurveStopLoss(Number(data.bondingCurveStopLoss));
          if (data.pumpSwapStopLoss !== undefined) setPumpSwapStopLoss(Number(data.pumpSwapStopLoss));
          if (data.unknownStopLoss !== undefined) setUnknownStopLoss(Number(data.unknownStopLoss));
          if (data.maxPositions !== undefined) setMaxPositions(Number(data.maxPositions));
          if (data.telegramBotToken !== undefined) setTelegramBotToken(String(data.telegramBotToken));
          if (data.telegramChatId !== undefined) setTelegramChatId(String(data.telegramChatId));
          if (data.hardenedMcapMinPump !== undefined) setHardenedMcapMinPump(Number(data.hardenedMcapMinPump));
          if (data.hardenedMcapMinRaydium !== undefined) setHardenedMcapMinRaydium(Number(data.hardenedMcapMinRaydium));
          if (data.hardenedMcapMax !== undefined) setHardenedMcapMax(Number(data.hardenedMcapMax));
          if (data.hardenedLiquidityMin !== undefined) setHardenedLiquidityMin(Number(data.hardenedLiquidityMin));
          if (data.hardenedLiquidityRatio !== undefined) setHardenedLiquidityRatio(Number(data.hardenedLiquidityRatio));
          if (data.hardenedMaxRiskScore !== undefined) setHardenedMaxRiskScore(Number(data.hardenedMaxRiskScore));
          if (data.hardenedMaxDevOwnership !== undefined) setHardenedMaxDevOwnership(Number(data.hardenedMaxDevOwnership));
          if (data.hardenedMaxTop10 !== undefined) setHardenedMaxTop10(Number(data.hardenedMaxTop10));
          if (data.hardenedMinUniqueBuyers30s !== undefined) setHardenedMinUniqueBuyers30s(Number(data.hardenedMinUniqueBuyers30s));
          if (data.hardenedMinBuyCount30s !== undefined) setHardenedMinBuyCount30s(Number(data.hardenedMinBuyCount30s));
          if (data.hardenedMaxBuyCount30s !== undefined) setHardenedMaxBuyCount30s(Number(data.hardenedMaxBuyCount30s));
          if (data.hardenedMinBuySellRatio !== undefined) setHardenedMinBuySellRatio(Number(data.hardenedMinBuySellRatio));
          if (data.hardenedMaxBuySellRatio !== undefined) setHardenedMaxBuySellRatio(Number(data.hardenedMaxBuySellRatio));
          if (data.hardenedMaxPriceChange1m !== undefined) setHardenedMaxPriceChange1m(Number(data.hardenedMaxPriceChange1m));
          if (data.hardenedMinBondingProgress !== undefined) setHardenedMinBondingProgress(Number(data.hardenedMinBondingProgress));
          if (data.hardenedMaxBondingProgress !== undefined) setHardenedMaxBondingProgress(Number(data.hardenedMaxBondingProgress));
          if (data.hardenedMinAge !== undefined) setHardenedMinAge(Number(data.hardenedMinAge));
          if (data.hardenedMaxAge !== undefined) setHardenedMaxAge(Number(data.hardenedMaxAge));
          if (data.hardenedMinLatency !== undefined) setHardenedMinLatency(Number(data.hardenedMinLatency));
          if (data.hardenedMaxLatency !== undefined) setHardenedMaxLatency(Number(data.hardenedMaxLatency));
          if (data.hardenedMatchRequirement !== undefined) setHardenedMatchRequirement(Number(data.hardenedMatchRequirement));
          if (data.enableLatencyGuard !== undefined) setEnableLatencyGuard(data.enableLatencyGuard === true);
          if (data.telemetryWhaleBuyMin !== undefined) setTelemetryWhaleBuyMin(Number(data.telemetryWhaleBuyMin));
          if (data.telemetryHighBuyMin !== undefined) setTelemetryHighBuyMin(Number(data.telemetryHighBuyMin));
          if (data.telemetryVolumeSpikeMin !== undefined) setTelemetryVolumeSpikeMin(Number(data.telemetryVolumeSpikeMin));
          if (data.telemetryAllowWhaleBuy !== undefined) setTelemetryAllowWhaleBuy(data.telemetryAllowWhaleBuy === true);
          if (data.telemetryAllowHighBuy !== undefined) setTelemetryAllowHighBuy(data.telemetryAllowHighBuy === true);
          if (data.telemetryAllowVolumeSpike !== undefined) setTelemetryAllowVolumeSpike(data.telemetryAllowVolumeSpike === true);
          if (data.telemetryAllowMigrated !== undefined) setTelemetryAllowMigrated(data.telemetryAllowMigrated === true);
          if (data.telemetryAllowGoldenCross !== undefined) setTelemetryAllowGoldenCross(data.telemetryAllowGoldenCross === true);
          if (data.tradePumpFun !== undefined) setTradePumpFun(data.tradePumpFun === true);
          if (data.tradeRaydium !== undefined) setTradeRaydium(data.tradeRaydium === true);
          if (data.tradeBonding !== undefined) setTradeBonding(data.tradeBonding === true);
          if (data.tradeUnknown !== undefined) setTradeUnknown(data.tradeUnknown === true);
          if (data.hardenedMinProfit5m !== undefined) setHardenedMinProfit5m(Number(data.hardenedMinProfit5m));
          if (data.maxRebuyTimes !== undefined) {
            const val = Number(data.maxRebuyTimes);
            setMaxRebuyTimes(val === 2 ? 3 : val);
          }
          if (data.tradeOnlyOnce !== undefined) {
            setTradeOnlyOnce(data.tradeOnlyOnce === true);
          }
          if (data.rpcUrl !== undefined) setRpcUrl(String(data.rpcUrl));
          if (data.rpcUrl2 !== undefined) setRpcUrl2(String(data.rpcUrl2));
          if (data.customWsUrl !== undefined) setCustomWsUrl(String(data.customWsUrl));
          if (data.apiKey !== undefined) setApiKey(String(data.apiKey));
          if (data.jupiterRpcUrl !== undefined) setJupiterRpcUrl(String(data.jupiterRpcUrl));
        }
      } catch (err) {
        console.error('Error loading settings from Firestore in App.tsx:', err);
      } finally {
        isFirestoreLoading.current = false;
      }
    };

    loadSettings();
  }, [user]);

  useEffect(() => {
    if (isFirestoreLoading.current) return;

    const payload = {
      buyAmountSol,
      minTakeProfit,
      maxTakeProfit,
      bondingCurveTakeProfit,
      stopLoss,
      bondingCurveStopLoss,
      pumpSwapStopLoss,
      unknownStopLoss,
      maxPositions,
      telegramBotToken,
      telegramChatId,
      hardenedMcapMinPump,
      hardenedMcapMinRaydium,
      hardenedMcapMax,
      hardenedLiquidityMin,
      hardenedLiquidityRatio,
      hardenedMaxRiskScore,
      hardenedMaxDevOwnership,
      hardenedMaxTop10,
      hardenedMinUniqueBuyers30s,
      hardenedMinBuyCount30s,
      hardenedMaxBuyCount30s,
      hardenedMinBuySellRatio,
      hardenedMaxBuySellRatio,
      hardenedMaxPriceChange1m,
      hardenedMinBondingProgress,
      hardenedMaxBondingProgress,
      hardenedMinAge,
      hardenedMaxAge,
      hardenedMinLatency,
      hardenedMaxLatency,
      hardenedMatchRequirement,
      enableLatencyGuard,
      telemetryWhaleBuyMin,
      telemetryHighBuyMin,
      telemetryVolumeSpikeMin,
      telemetryAllowWhaleBuy,
      telemetryAllowHighBuy,
      telemetryAllowVolumeSpike,
      telemetryAllowMigrated,
      telemetryAllowGoldenCross,
      tradePumpFun,
      tradeRaydium,
      tradeBonding,
      tradeUnknown,
      hardenedMinProfit5m,
      maxRebuyTimes,
      tradeOnlyOnce,
      rpcUrl,
      rpcUrl2,
      customWsUrl,
      apiKey,
      jupiterRpcUrl,
      updatedAt: new Date().toISOString()
    };

    // Immediately sync to Render and Firebase database
    syncManager.triggerSync(payload, user?.uid, false);
  }, [
    user, buyAmountSol, minTakeProfit, maxTakeProfit, bondingCurveTakeProfit, stopLoss, bondingCurveStopLoss, pumpSwapStopLoss, unknownStopLoss, maxPositions,
    telegramBotToken, telegramChatId, hardenedMcapMinPump, hardenedMcapMinRaydium, hardenedMcapMax,
    hardenedLiquidityMin, hardenedLiquidityRatio, hardenedMaxRiskScore, hardenedMaxDevOwnership,
    hardenedMaxTop10, hardenedMinUniqueBuyers30s, hardenedMinBuyCount30s, hardenedMaxBuyCount30s,
    hardenedMinBuySellRatio, hardenedMaxBuySellRatio, hardenedMaxPriceChange1m, hardenedMinBondingProgress,
    hardenedMaxBondingProgress, hardenedMinAge, hardenedMaxAge, hardenedMinLatency, hardenedMaxLatency,
    hardenedMatchRequirement, enableLatencyGuard, telemetryWhaleBuyMin, telemetryHighBuyMin,
    telemetryVolumeSpikeMin, telemetryAllowWhaleBuy, telemetryAllowHighBuy, telemetryAllowVolumeSpike,
    telemetryAllowMigrated, telemetryAllowGoldenCross, tradePumpFun, tradeRaydium, tradeBonding, tradeUnknown, hardenedMinProfit5m, maxRebuyTimes, tradeOnlyOnce,
    rpcUrl, rpcUrl2, customWsUrl, apiKey, jupiterRpcUrl
  ]);

  const safePublicKey = (addr: string) => {
    try {
      if (!addr || typeof addr !== 'string') return null;
      return new PublicKey(addr.trim());
    } catch (e) {
      return null;
    }
  };

  const addWallet = async () => {
    if (!user || !address) return;
    const pubKey = safePublicKey(address);
    if (!pubKey) {
      setError('Invalid Solana Public Key');
      return;
    }

    try {
      await addDoc(collection(db, 'wallets'), {
        address: address.trim(),
        label: walletLabel || `محفظة ${monitoredWallets.length + 1}`,
        userId: user.uid,
        createdAt: serverTimestamp()
      });
      setAddress('');
      setWalletLabel('');
    } catch (err: any) {
      if (err.message && err.message.includes('permission')) {
        handleFirestoreError(err, OperationType.WRITE, 'wallets');
      }
      setError(err.message || 'Error adding wallet');
    }
  };

  const removeWallet = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'wallets', id));
    } catch (err: any) {
      if (err.message && err.message.includes('permission')) {
        handleFirestoreError(err, OperationType.DELETE, `wallets/${id}`);
      }
      setError(err.message || 'Error removing wallet');
    }
  };

  const activeRequests = useRef(0);
  const MAX_CONCURRENT_RPC = 3;

  const fetchTransactionWithRetry = async (signature: string, retries = 3, delay = 300): Promise<any> => {
    if (activeRequests.current >= MAX_CONCURRENT_RPC) {
      // If busy, wait a bit or skip purely background telemetry
      await new Promise(res => setTimeout(res, Math.random() * 2000));
      if (activeRequests.current >= MAX_CONCURRENT_RPC) return null;
    }

    activeRequests.current++;
    try {
      for (let i = 0; i < retries; i++) {
          try {
            // Prioritize Master Monitor RPC connection first if configured
            const connToUse = masterConnectionRef.current || connectionRef.current;
            if (connToUse) {
                const tx = await connToUse.getParsedTransaction(signature, { maxSupportedTransactionVersion: 0, commitment: 'confirmed' });
                if (tx) return tx;
            }

            // Fallback to Helius Enriched Transactions API if key is present
            const heliusKey = HELIUS_API_KEY;
            if (heliusKey) {
              const response = await fetch(`https://api-mainnet.helius-rpc.com/v0/transactions/?api-key=${heliusKey}`, {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({ transactions: [signature] })
              });

              if (response.ok) {
                  const data = await response.json();
                  if (data && data.length > 0) {
                      return data[0]; // Return Helius parsed transaction
                  }
              }
            }

            // Polling with capped backoff
            const backoffDelay = delay * Math.pow(1.5, i);
            await new Promise(res => setTimeout(res, backoffDelay + (Math.random() * 100)));
          } catch (e: any) {
            if (i === retries - 1) return null; // Don't throw, just return null on fail to keep feed alive
            const backoffDelay = delay * Math.pow(1.5, i);
            await new Promise(res => setTimeout(res, backoffDelay));
          }
      }
    } finally {
      activeRequests.current--;
    }
    return null;
  };

  const xRaySubscriptionId = useRef<number | null>(null);

  useEffect(() => {
    // Global X-Ray Monitor (Telemetry Style - Master Monitor RPC)
    const conn = masterConnectionRef.current || connectionRef.current;
    if (isXRayEnabled && conn) {
      const RAYDIUM_PROGRAM_ID = safePublicKey('675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8');
      if (!RAYDIUM_PROGRAM_ID) return;
      
      const subId = conn.onLogs(RAYDIUM_PROGRAM_ID, async (logs) => {
        // Bit Test Pulse
        setTelemetryBits(prev => {
          const next = [...prev];
          const idx = Math.floor(Math.random() * next.length);
          next[idx] = true;
          // TRENDING PING
          if (Math.random() > 0.98) {
            console.log("TELEMETRY BIT TEST: SYSTEM NOMINAL");
          }
          return next;
        });
        setTimeout(() => {
          setTelemetryBits(prev => {
            const next = [...prev];
            const idx = Math.floor(Math.random() * next.length);
            next[idx] = false;
            return next;
          });
        }, 150);

        const isSwap = logs.logs?.some(l => l.includes('Instruction: Swap'));
        if (!isSwap) return;

        // Rate limit global fetches to avoid hitting RPC limits quickly
        // Only fetch if it looks like a big buy or randomly sampled
        const signature = logs.signature;
        if (processedSigs.current.has(signature)) return;

        const isMigration = logs.logs?.some(l => l.includes('Instruction: Initialize2'));
        const samplingRate = isMigration ? 1.0 : 0.05;

        // Skip most trades to stay within free tier/demo context, but pick enough to feel "live"
        // Reduced sampling from 15% to 5% to avoid 429 errors from RPC, with 100% sampling for migrations
        if (Math.random() > samplingRate && !monitoredWallets.some(w => logs.logs?.some(l => l.includes(w.address)))) return;

        processedSigs.current.add(signature);

        try {
          const tx = await fetchTransactionWithRetry(signature, 3, 500);
          let amount = 0;
          let diff = 0;
          let mintStr = '';
          
          if (tx && tx.meta) {
            const postTokenBalances = tx.meta.postTokenBalances || [];
            if (postTokenBalances.length > 0) {
              const balance = postTokenBalances[0];
              const preTokenBalances = tx.meta.preTokenBalances || [];
              const preBalance = preTokenBalances.find((b: any) => b.accountIndex === balance.accountIndex);
              const preAmt = preBalance ? Number(preBalance.uiTokenAmount.uiAmount) : 0;
              const postAmt = Number(balance.uiTokenAmount.uiAmount);
              diff = postAmt - preAmt;
              amount = Math.abs(diff);
              mintStr = balance.mint;
            }
          } else if (tx && tx.tokenTransfers && tx.tokenTransfers.length > 0) {
            // Helius API format
            const transfer = tx.tokenTransfers.find((t: any) => t.mint !== 'So11111111111111111111111111111111111111112') || tx.tokenTransfers[0];
            amount = transfer.tokenAmount;
            diff = amount; // assume positive diff (BUY) for discovery pulses involving tokens 
            mintStr = transfer.mint;
          }

          if (mintStr) {
              // Discovery logic
              if (diff > 0 && (amount > 1000 || isMigration)) { 
                const token = resolveTokenName(mintStr);
                const mint = mintStr;
                
                // Initial simple momentum check for X-Ray Alert
                const existingMetric = tokenMetrics[mint];
                const ageMins = existingMetric ? (Date.now() - (existingMetric.discoveredAt || Date.now())) / 60000 : 0;
                const mc = existingMetric?.marketCap || 0;
                const liq = existingMetric?.liquidity || 0;
                const liqRatio = mc > 0 ? liq / mc : 0;
                const isRugScanPassed = !!existingMetric?.isRugSafe && !!existingMetric?.mintAuthorityRevoked && !!existingMetric?.liquidityBurned;

                let isGoldenCross = false;
                if (existingMetric && existingMetric.recentBuysTimeline && ageMins > 30) {
                  const recentBuys = (existingMetric.recentBuysTimeline || []).filter((t: any) => Date.now() - t.t < 30000);
                  const uniqueBuyers30s = new Set(recentBuys.map(t => t.w).filter(Boolean)).size;
                  const buyFrequency5m = existingMetric.recentBuysTimeline.length;
                  const holdersPerMin = (existingMetric.holdersPerMin || 0);
                  const buySellRatio = existingMetric.buyCount / Math.max(existingMetric.sellCount, 1);

                  isGoldenCross = buyFrequency5m > 15 && holdersPerMin >= 10 && uniqueBuyers30s >= 6 &&
                                  mc >= 110000 && mc <= 2500000 &&
                                  buySellRatio >= 2.5 && buySellRatio <= 5.5;
                }

                // Determine alert type - Prioritize MIGRATED
                let alertType: 'WHALE_BUY' | 'HIGH_BUY' | 'VOLUME_SPIKE' | 'MIGRATED' | 'GOLDEN_CROSS' = 'VOLUME_SPIKE';
                const isRaydiumListed = !(mint || '').toLowerCase().endsWith('pump');
                const calibratedMinMcap = isRaydiumListed ? 65000 : 110000;

                if (isMigration) {
                  alertType = 'MIGRATED';
                } else if (isGoldenCross) {
                  alertType = 'GOLDEN_CROSS';
                } else if (amount > telemetryWhaleBuyMin && ageMins > 30 && mc >= 250000 && (existingMetric?.top10Percentage || 0) < 14.0 && (existingMetric?.devWalletPercentage || 0) < 0.8) {
                  alertType = 'WHALE_BUY';
                } else if (amount > telemetryHighBuyMin && ageMins > 30 && mc >= calibratedMinMcap && liq >= 55000 && liqRatio >= 0.07 && isRugScanPassed) {
                  alertType = 'HIGH_BUY';
                } else if (amount > telemetryVolumeSpikeMin && ageMins > 30 && liq >= 30000 && (existingMetric?.riskScore || 0) < 22) {
                  alertType = 'VOLUME_SPIKE';
                } else {
                  alertType = 'VOLUME_SPIKE'; // Fallback for basic activity
                }

                if ((alertType === 'MIGRATED' || alertType === 'WHALE_BUY' || alertType === 'HIGH_BUY' || alertType === 'GOLDEN_CROSS' || alertType === 'VOLUME_SPIKE') && (alertType === 'MIGRATED' || ageMins >= 30)) {
                   // playAlertSound(); // Disabled per request
                   setTelemetryAlerts(prev => [
                    {
                      id: `xray-${signature}-${Date.now()}`,
                      token: token,
                      address: mint,
                      type: alertType,
                      message: alertType === 'MIGRATED' 
                        ? `X-RAY: 🚀 NEW MIGRATION DETECTED: ${token}`
                        : alertType === 'GOLDEN_CROSS'
                        ? `X-RAY: ⚡ GOLDEN CROSS MOMENTUM: ${token}`
                        : `X-RAY: ${alertType === 'WHALE_BUY' ? 'Legendary' : 'Massive'} Buy: ${amount.toLocaleString()} ${token}`,
                      timestamp: Date.now()
                    },
                    ...prev.slice(0, 19)
                  ]);
                }

                // IMPORTANT: Populate Token Metrics table with this discovery
                setTokenMetrics(prev => {
                  const current = prev[mint] || ({
                    symbol: token,
                    name: 'Discovered via X-Ray',
                    address: mint,
                    buyCount: 0,
                    sellCount: 0,
                    buyVolume: 0,
                    sellVolume: 0,
                    percentageIncrease: 0,
                    lastPrice: 0,
                    lastUpdated: Date.now(),
                    discoveredAt: Date.now(),
                    recentBuysTimeline: [],
                    isSurging: true,
                    prevBuyCount: 0,
                    prevHolderCount: 0,
                    uniqueWallets: new Set(),
                    holderCount: 0
                  } as TokenMetric);

                  const updatedTimeline = [...(current.recentBuysTimeline || []), {t: Date.now(), a: amount}].filter(item => Date.now() - item.t < 5 * 60 * 1000);
                  
                  // Track unique holders (approximate via trade signatures/accounts)
                  // In real app we'd track the actual wallet address associated with the trade
                  const newUniqueWallets = new Set(current.uniqueWallets);
                  // For the sake of this demo, we'll simulate unique holder growth
                  if (Math.random() > 0.5) newUniqueWallets.add(`wallet-${Math.random()}`);

                  const holders5m = newUniqueWallets.size;
                  const holdersPerMin = holders5m / 5;

                  // Calculate volume spike (momentum)
                  // Golden Cross Check: 5m volume spike > 300% of 30m average
                  // In this simplified client-side logic, we look at the frequency of buys and holder growth
                  const buyFrequency5m = updatedTimeline.length;
                  const isGoldenCross = buyFrequency5m > 15 && holdersPerMin >= 10; 

                  // Compute dynamic fallback percentage increase statistic from buy/sell timeline momentum to prevent flat 0% display on lag
                  const secondaryBuys = updatedTimeline.filter((x: any) => x && x.type === 'buy').length || updatedTimeline.length;
                  const secondarySells = updatedTimeline.filter((x: any) => x && x.type === 'sell').length;
                  const secondaryNet = secondaryBuys - secondarySells;
                  const secondaryFallbackPct = Math.max(-95, Math.min(350, secondaryNet * 1.5));

                  let secondaryCalculatedPct = current.percentageIncrease;
                  if (secondaryCalculatedPct === undefined || secondaryCalculatedPct === 0) {
                     secondaryCalculatedPct = secondaryFallbackPct;
                  } else {
                     secondaryCalculatedPct = secondaryCalculatedPct + 0.6;
                  }

                  return {
                    ...prev,
                    [mint]: {
                      ...current,
                      buyCount: current.buyCount + 1,
                      buyVolume: current.buyVolume + (typeof amount === 'number' ? amount : 0),
                      percentageIncrease: parseFloat(secondaryCalculatedPct.toFixed(2)),
                      lastUpdated: Date.now(),
                      prevBuyCount: current.buyCount,
                      prevHolderCount: current.holderCount || 0,
                      recentBuysTimeline: updatedTimeline,
                      isSurging: true,
                      latestAlert: alertType,
                      uniqueWallets: newUniqueWallets,
                      holdersPerMin: holdersPerMin
                    }
                  };
                });

                // Trigger background safety check
                fetchTokenSecurityData(mint).then(security => {
                   if (!security) return;

                   // X-RAY Telegram Alerts
                   const alertKey = mint + '_' + alertType;
                   if (!alertedTokens.current.has(alertKey)) {
                     alertedTokens.current.add(alertKey);
                     let emoji = '🚨';
                     let title = 'X-RAY ALPHA';
                     if (alertType === 'WHALE_BUY') { emoji = '🐋'; title = 'X-RAY WHALE'; }
                     if (alertType === 'HIGH_BUY') { emoji = '🔥'; title = 'X-RAY HIGH BUY'; }
                     if (alertType === 'MIGRATED') { emoji = '🚀'; title = 'X-RAY MIGRATION'; }
                     if (alertType === 'GOLDEN_CROSS') { emoji = '⚡'; title = 'X-RAY GOLDEN CROSS'; }

                     const buyLinkXR = `${window.location.origin}${window.location.pathname}?buy=${mint}&auto=true`;
                     const sellLinkXR = `${window.location.origin}${window.location.pathname}?sell=${mint}&auto=true`;
                     const msg = `${emoji} <b>${title}</b>\n\n` +
                                 `Token: <b>$${token}</b>\n` +
                                 `Action: <b>Massive Buy Detected</b>\n` +
                                 `Market Cap: <b>$${Math.floor(security.marketCap || 0).toLocaleString()}</b>\n` +
                                 `Liquidity: <b>$${Math.floor(security.liquidity || 0).toLocaleString()}</b>\n` +
                                 `Address: <code>${mint}</code>\n\n` +
                                 `<b>ACTIONS:</b>\n` +
                                 `<a href="${buyLinkXR}">🎯 QUICK BUY IN MATRIX</a>\n` +
                                 `<a href="${sellLinkXR}">🔴 QUICK SELL / VIEW PORTFOLIO</a>\n\n` +
                                 `<a href="https://dexscreener.com/solana/${mint}">📊 View on DexScreener</a>`;
                     sendTelegramAlert(msg, true).catch((err: any) => console.warn('Telegram alert failed:', err));
                   }

                   setTokenMetrics(m => {
                     const existing = m[mint];
                     if (!existing) return m;

                     // 100x Gem Detection for X-Ray
                     const mcX = security.marketCap || 0;
                     const tpDX = (security.priceUsd || 0) > 0 ? (1 / security.priceUsd!) : 0;
                     const is100xGemX = security.mintAuthorityRevoked && 
                                        security.freezeAuthorityRevoked && 
                                        security.liquidityBurned && 
                                        mcX >= 100000 && mcX <= 5000000 &&
                                        tpDX >= 2000 && tpDX <= 150000;

                     if (is100xGemX && !alertedTokens.current.has(mint + '_100x')) {
                       alertedTokens.current.add(mint + '_100x');
                       const buyLink100 = `https://jup.ag/swap/SOL-${mint}`;
                       const sellLink100 = `https://jup.ag/swap/${mint}-SOL`;
                       const msg100x = `💎 <b>X-RAY 100x GEM DISCOVERED</b>\n\n` +
                                       `Token: <b>$${token}</b>\n` +
                                       `Market Cap: <b>$${Math.floor(mcX).toLocaleString()}</b>\n` +
                                       `Liquidity: <b>$${Math.floor(security.liquidity || 0).toLocaleString()}</b>\n\n` +
                                       `Security: <b>VERIFIED ✅</b>\n` +
                                       `Address: <code>${mint}</code>\n\n` +
                                       `<b>ACTIONS:</b>\n` +
                                       `<a href="${buyLink100}">🎯 QUICK BUY IN MATRIX</a>\n` +
                                       `<a href="${sellLink100}">🔴 QUICK SELL / VIEW PORTFOLIO</a>`;
                       sendTelegramAlert(msg100x, true).catch((err: any) => console.warn('Telegram alert failed:', err));
                     }
                     
                     const isRugSafe = (security.security?.riskScore ?? 100) <= (latestState.current?.hardenedMaxRiskScore || 22) && (security.security?.isRugSafe !== false);

                     return {
                       ...m,
                       [mint]: {
                         ...existing,
                         liquidity: security.liquidity,
                         volume24h: security.volume24h,
                         marketCap: security.marketCap,
                         holderCount: security.holderCount,
                         devWalletPercentage: security.devWalletPercentage,
                         top10Percentage: security.top10Percentage,
                         volMcRatio: security.volMcRatio,
                         isRugSafe: isRugSafe,
                         mintAuthorityRevoked: security.mintAuthorityRevoked,
                         freezeAuthorityRevoked: security.freezeAuthorityRevoked,
                         metadataImmutable: security.metadataImmutable,
                         liquidityRatio: security.liquidityRatio,
                         holderGrowthHr: security.holderGrowthHr
                       }
                     };
                   });
                });

                // Reset surge flag
                setTimeout(() => {
                  setTokenMetrics(p => {
                    const m = p[mint];
                    if (!m) return p;
                    return { ...p, [mint]: { ...m, isSurging: false } };
                  });
                }, 10000);
              }
            }
        } catch (e) {
          // Silent fail for network issues
        }
      }, 'confirmed');
      
      xRaySubscriptionId.current = subId;
    }

    return () => {
      if (xRaySubscriptionId.current && conn) {
        conn.removeOnLogsListener(xRaySubscriptionId.current);
      }
    };
  }, [isXRayEnabled, monitoredWallets, telegramBotToken, telegramChatId, rpcUrl, masterMonitorRpc, customWsUrl]);

  useEffect(() => {
    // Multi-wallet monitoring: each wallet gets an explicit subscription and
    // every signature is deduplicated before any RPC work or UI mutation.
    const conn = masterConnectionRef.current || connectionRef.current;
    if (!isMonitoring || monitoredWallets.length === 0 || !conn) return;

    const activeSubscriptionIds: Record<string, number> = {};
    let cancelled = false;

    const persistWalletEvent = async (wallet: { id: string; address: string; label: string }, signature: string, trade: Trade) => {
      if (!user) return;
      try {
        await setDoc(
          doc(db, 'walletTransactions', `${user.uid}_${wallet.id}_${signature}`),
          {
            userId: user.uid,
            walletId: wallet.id,
            walletAddress: wallet.address,
            walletLabel: wallet.label,
            signature,
            side: trade.type,
            tokenMint: trade.tokenAddress,
            token: trade.token,
            amount: trade.amount,
            status: trade.status,
            timestamp: trade.timestamp,
            syncedAt: serverTimestamp(),
            source: 'master-monitor',
          },
          { merge: true }
        );
      } catch (error) {
        // Persistence failure must not fabricate a trade or stop live monitoring.
        console.warn('[WALLET_MONITOR] Failed to persist transaction event', { signature, error });
      }
    };

    for (const wallet of monitoredWallets) {
      const pubKey = safePublicKey(wallet.address);
      if (!pubKey) {
        console.error('[WALLET_MONITOR] Invalid monitored wallet', wallet.address);
        continue;
      }

      const subscriptionId = conn.onLogs(pubKey, async (logs) => {
        const signature = logs.signature;
        const dedupeKey = `${wallet.address}:${signature}`;
        if (cancelled || processedWalletSignatures.current.has(dedupeKey)) return;
        processedWalletSignatures.current.add(dedupeKey);

        // Keep the in-memory registry bounded without weakening near-term dedupe.
        if (processedWalletSignatures.current.size > 10000) {
          const oldest = processedWalletSignatures.current.values().next().value;
          if (oldest) processedWalletSignatures.current.delete(oldest);
        }

        try {
          const tx = await fetchTransactionWithRetry(signature);
          if (cancelled) return;
          const parsed = parseWalletTransaction(tx, wallet.address);
          if (!parsed) {
            console.warn('[WALLET_MONITOR] Ignoring transaction without a verified wallet-owned token delta', { wallet: wallet.address, signature });
            return;
          }

          const newTrade: Trade = {
            id: `wallet-${wallet.id}-${signature}`,
            type: parsed.type,
            token: resolveTokenName(parsed.mint),
            tokenAddress: parsed.mint,
            amount: parsed.amount,
            timestamp: new Date(parsed.timestampMs).toISOString(),
            signature,
            status: 'confirmed',
            fromAccount: wallet.address,
          };

          const targetMetric = tokenMetrics[newTrade.tokenAddress];
          const liqRatio = (targetMetric?.liquidity || 0) / (targetMetric?.marketCap || 1);
          const hasLiqWarning = liqRatio < 0.07;

          setTelemetryAlerts(prev => [{
            id: `wallet-alert-${wallet.id}-${signature}`,
            token: newTrade.token,
            address: newTrade.tokenAddress,
            type: 'WALLET_TRADE',
            message: `[${wallet.label || wallet.address.slice(0, 8)}] ${newTrade.type.toUpperCase()}: ${newTrade.token}${hasLiqWarning ? ' (LOW LIQUIDITY RATIO)' : ''}`,
            timestamp: Date.now(),
          }, ...prev.slice(0, 19)]);

          // Do not perform side effects inside a React state updater.
          unifiedTradePipeline.ingestPulseFeed(newTrade);
          setTrades(prev => prev.some(t => t.signature === signature && t.fromAccount === wallet.address)
            ? prev
            : [newTrade, ...prev].slice(0, 50));
          setStats(prev => prev ? { ...prev, totalTrades: prev.totalTrades + 1 } : null);
          void persistWalletEvent(wallet, signature, newTrade);
        } catch (error) {
          console.error('[WALLET_MONITOR] Transaction synchronization failed', { wallet: wallet.address, signature, error });
        }
      }, 'confirmed');

      activeSubscriptionIds[wallet.address] = subscriptionId;
    }

    subscriptionIds.current = activeSubscriptionIds;
    return () => {
      cancelled = true;
      Object.values(activeSubscriptionIds).forEach(id => {
        try { void conn.removeOnLogsListener(id); } catch {}
      });
      if (subscriptionIds.current === activeSubscriptionIds) subscriptionIds.current = {};
    };
  }, [isMonitoring, monitoredWallets, user, rpcUrl, masterMonitorRpc, customWsUrl]);

  const copyToClipboard = async (text: string, id: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch (err) {
      console.error('Failed to copy!', err);
    }
  };

  useEffect(() => {
    // Master Monitor Connection Hook (Independent onLogs, getParsedTransaction, Discovery & Metrics)
    try {
      const activeMasterRpc = masterMonitorHealthManager.getActiveEndpoint();
      const activeWs = masterMonitorHealthManager.getActiveWsEndpoint() || undefined;
      masterConnectionRef.current = new Connection(activeMasterRpc, {
        wsEndpoint: activeWs,
        commitment: 'confirmed',
        confirmTransactionInitialTimeout: 90000,
        disableRetryOnRateLimit: false,
        httpHeaders: {
          'Content-Type': 'application/json',
        },
      });
      const isIndependent = !!(masterMonitorRpc && masterMonitorRpc.trim() !== "" && masterMonitorRpc.trim() !== rpcUrl);
      console.log(`[MASTER MONITOR RPC] ${isIndependent ? 'INDEPENDENT NODE ENGAGED' : 'SHARED NODE'}: ${activeMasterRpc}`);
    } catch (err) {
      console.error('Failed to initialize Master Monitor Connection', err);
    }
  }, [masterMonitorRpc, masterMonitorRpc2, masterMonitorWs, rpcUrl, customWsUrl]);

  useEffect(() => {
    // Dynamic execution connection hook reacting to user RPC and WS configuration
    try {
      const HELIUS_RPC = rpcUrl;
      const HELIUS_WS = (customWsUrl && customWsUrl.trim() !== "") ? customWsUrl.trim() : HELIUS_RPC.replace('https://', 'wss://').replace('http://', 'ws://');
      connectionRef.current = new Connection(HELIUS_RPC, {
        wsEndpoint: HELIUS_WS,
        commitment: 'confirmed',
        confirmTransactionInitialTimeout: 90000,
        disableRetryOnRateLimit: false,
        httpHeaders: {
          'Content-Type': 'application/json',
        },
      });
      console.log('Solana connection established:', HELIUS_RPC);
    } catch (err) {
      console.error('Failed to initialize Solana connection', err);
    }
    
    return () => {
      const conn = connectionRef.current;
      if (conn) {
        Object.values(subscriptionIds.current).forEach(id => {
          conn.removeOnLogsListener(id);
        });
      }
    };
  }, [rpcUrl, customWsUrl]);

  const resolveTokenName = (mint: string) => {
    const knownMints: Record<string, string> = {
      'So11111111111111111111111111111111111111112': 'SOL',
      'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v': 'USDC',
      'Es9vMFrzaDCSTMdUiJcxHDXnR73WcnMTeyLukpEbvpsn': 'USDT',
      'JUPyiTV99uAtvXR9hh7cMRgVAsTpxAnAK8W8gcNoJ3': 'JUP',
      'DezXAZ8z7PnrnMcZE2z4LSW6SAbR9ifRscZ6tx8GqqM': 'BONK',
      'mSoLzpyruYKy6AeG9Bhqyfy5QDQJpYhS3F5RToz94Q': 'mSOL'
    };
    return knownMints[mint] || (mint.slice(0, 4) + '...');
  };

  const handleStartMonitoring = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!address) return;
    
    if (user) {
      await addWallet();
    } else {
      setError('يرجى تسجيل الدخول أولاً لإضافة محفظة.');
    }
  };

  const analyzeTrader = async () => {
    if (trades.length === 0) return;
    setIsAnalyzing(true);
    try {
      // Simulate analysis delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      setAnalysis("ميزة الذكاء الاصطناعي معطلة حالياً لتوفير التوكنز (تم إزالتها بناءً على طلبك).");
    } catch (err) {
      console.error(err);
      setAnalysis("خطأ في التحليل.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#020202] flex flex-col items-center">
      {/* Viewport Switcher */}
      <div className="w-full bg-[#050608] border-b border-slate-800 p-2 flex justify-center gap-2 z-[200]">
        <button 
          onClick={() => setViewMode('responsive')}
          className={cn("px-3 py-1.5 rounded-lg flex items-center gap-2 text-xs font-bold transition-all", viewMode === 'responsive' ? "bg-indigo-600 text-white" : "bg-slate-900 text-slate-400 hover:text-slate-200")}
        >
          <Maximize2 className="w-3.5 h-3.5" /> Full
        </button>
        <button 
          onClick={() => setViewMode('laptop')}
          className={cn("px-3 py-1.5 rounded-lg flex items-center gap-2 text-xs font-bold transition-all", viewMode === 'laptop' ? "bg-indigo-600 text-white" : "bg-slate-900 text-slate-400 hover:text-slate-200")}
        >
          <Monitor className="w-3.5 h-3.5" /> Laptop
        </button>
        <button 
          onClick={() => setViewMode('mobile')}
          className={cn("px-3 py-1.5 rounded-lg flex items-center gap-2 text-xs font-bold transition-all", viewMode === 'mobile' ? "bg-indigo-600 text-white" : "bg-slate-900 text-slate-400 hover:text-slate-200")}
        >
          <Smartphone className="w-3.5 h-3.5" /> Mobile
        </button>
      </div>

      {/* Main Container Container */}
      <div 
        className={cn(
          "w-full bg-[#050608] text-slate-300 font-sans selection:bg-indigo-500/30 selection:text-white relative mx-auto overflow-hidden",
          viewMode === 'mobile' ? "max-w-[480px] shadow-2xl min-h-[calc(100vh-45px)] border-x border-slate-800" :
          viewMode === 'laptop' ? "max-w-[1024px] shadow-2xl min-h-[calc(100vh-45px)] border-x border-slate-800" :
          "w-full min-h-[calc(100vh-45px)]"
        )}
        style={{ 
          backgroundImage: 'radial-gradient(circle at 50% -20%, #1e293b 0%, #050608 100%)',
          transform: (viewMode === 'mobile' || viewMode === 'laptop') ? 'translateZ(0)' : 'none' // Creates new stacking context for fixed elements!
        }}
      >
        {/* Mobile Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 lg:hidden bg-slate-900 border-t border-slate-800 z-[100] flex items-center overflow-x-auto h-16 pb-safe backdrop-blur-md px-2 gap-2 scrollbar-none">
        <button 
          onClick={() => setCurrentPage('dashboard')}
          className={cn(
            "flex shrink-0 flex-col items-center gap-1 transition-all px-3 py-2 rounded-xl",
            currentPage === 'dashboard' ? "text-indigo-400" : "text-slate-500"
          )}
        >
          <Activity className={cn("w-5 h-5", currentPage === 'dashboard' && "animate-pulse")} />
          <span className="text-[10px] font-bold uppercase tracking-tighter">Terminal</span>
        </button>
        <button 
          onClick={() => setCurrentPage('high-buy')}
          className={cn(
            "flex shrink-0 flex-col items-center gap-1 transition-all px-3 py-2 rounded-xl",
            currentPage === 'high-buy' ? "text-indigo-400" : "text-slate-500"
          )}
        >
          <ArrowUpRight className={cn("w-5 h-5", currentPage === 'high-buy' && "animate-pulse")} />
          <span className="text-[10px] font-bold uppercase tracking-tighter">Alpha</span>
        </button>
        <button 
          onClick={() => setCurrentPage('portfolio')}
          className={cn(
            "flex shrink-0 flex-col items-center gap-1 transition-all px-3 py-2 rounded-xl",
            currentPage === 'portfolio' ? "text-indigo-400" : "text-slate-500"
          )}
        >
          <Wallet className={cn("w-5 h-5", currentPage === 'portfolio' && "animate-pulse")} />
          <span className="text-[10px] font-bold uppercase tracking-tighter">PnL</span>
        </button>
        <div className="w-px h-8 bg-slate-800 mx-1 shrink-0" />
        <button 
          onClick={() => user ? signOut(auth) : handleLogin()}
          className="flex shrink-0 flex-col items-center gap-1 text-slate-500 hover:text-white transition-all px-3 py-2 rounded-xl"
        >
          {user ? (
            <>
              <LogOut className="w-5 h-5" />
              <span className="text-[10px] font-bold uppercase tracking-tighter font-mono truncate max-w-[50px]">{user.displayName?.split(' ')[0] || 'User'}</span>
            </>
          ) : (
            <>
              <LogIn className="w-5 h-5" />
              <span className="text-[10px] font-bold uppercase tracking-tighter">Auth</span>
            </>
          )}
        </button>
      </nav>

      {/* Header / Search */}
      <header className="relative z-[70] border-b border-slate-800/60 bg-slate-900/40 backdrop-blur-md sticky top-0">
        <div className="max-w-7xl mx-auto px-4 lg:px-8 h-16 lg:h-20 flex items-center gap-4 lg:gap-8">
          <div className="flex items-center gap-2 lg:gap-4 shrink-0">
            <div className="relative group">
              <div className="absolute -inset-1 bg-indigo-500 rounded-lg blur opacity-20 group-hover:opacity-40 transition duration-1000"></div>
              <div className="relative w-8 h-8 lg:w-10 lg:h-10 rounded-lg bg-indigo-600 flex items-center justify-center shadow-lg transform rotate-3 transition-transform hover:rotate-0">
                 <Zap className="w-4 lg:w-5 h-4 lg:h-5 text-white fill-white" />
              </div>
            </div>
            <h1 className="text-base lg:text-xl font-black tracking-[-0.05em] text-white uppercase hidden sm:block">
              Arina <span className="text-indigo-400">X-Ray Alpha</span>
            </h1>
          </div>

          <div className="flex-1 lg:max-w-3xl lg:mx-4 flex gap-4 items-center">
            {/* Wallet Tracker */}
            <form onSubmit={handleStartMonitoring} className="flex-1 flex gap-1.5">
              <div className="relative flex-1 group">
                <div className={cn(
                  "absolute left-3 lg:left-4 top-1/2 -translate-y-1/2 w-1.5 lg:w-2 h-1.5 lg:h-2 rounded-full",
                  isMonitoring ? "bg-emerald-500 animate-pulse" : "bg-slate-700"
                )} />
                <input 
                  type="text"
                  placeholder="Monitor Wallet..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-full py-1.5 lg:py-2 px-8 lg:px-10 text-[10px] lg:text-xs font-mono text-indigo-300 focus:outline-none focus:border-indigo-500/50 transition-all placeholder:text-slate-700"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                />
              </div>
              <button 
                type="submit"
                title="Add Wallet to Monitor"
                className="bg-indigo-600 hover:bg-indigo-500 text-white p-2 rounded-full shadow-lg transition-all active:scale-90 flex items-center justify-center shrink-0 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5 lg:w-4 lg:h-4" />
              </button>
            </form>

            <div className="h-6 w-px bg-slate-800 hidden sm:block" />

            {/* Token Scanner */}
            <div className="flex-1 flex gap-1.5">
              <div className="relative flex-1 group">
                <Search className="absolute left-3 lg:left-4 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#64748b]" />
                <input 
                  type="text"
                  placeholder="Search Token (Name or Address)..."
                  value={tokenSearchValue}
                  onChange={(e) => setTokenSearchValue(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && tokenSearchValue.trim()) {
                      setCurrentPage('portfolio');
                      setManualGemInput(tokenSearchValue.trim());
                      setTokenSearchValue('');
                    }
                  }}
                  className="w-full bg-slate-950 border border-slate-800 rounded-full py-1.5 lg:py-2 px-8 lg:px-10 text-[10px] lg:text-xs font-mono text-[#c7f284] focus:outline-none focus:border-[#c7f284]/50 transition-all placeholder:text-slate-700"
                />
              </div>
              <button 
                onClick={() => {
                  if (tokenSearchValue.trim()) {
                    setCurrentPage('portfolio');
                    setManualGemInput(tokenSearchValue.trim());
                    setTokenSearchValue('');
                  }
                }}
                title="Scan Token Details & Trade"
                className="bg-emerald-600/20 hover:bg-emerald-500/30 text-[#c7f284] px-3.5 py-2 rounded-full border border-emerald-500/40 text-[9px] font-bold uppercase transition-all hover:scale-105 active:scale-95 flex items-center justify-center shrink-0 cursor-pointer"
              >
                Scan
              </button>
            </div>
          </div>

          <div className="hidden lg:flex items-center gap-6 text-[10px] font-black uppercase tracking-widest whitespace-nowrap">
            <nav className="flex items-center bg-slate-900/40 border border-slate-800 rounded-full p-1 mr-4 shadow-inner">
              <button 
                onClick={() => setCurrentPage('dashboard')}
                className={cn(
                  "px-5 py-2 rounded-full transition-all text-[10px] font-black",
                  currentPage === 'dashboard' ? "bg-indigo-600 text-white shadow-lg" : "text-slate-500 hover:text-slate-300"
                )}
              >
                DASHBOARD
              </button>
              <button 
                onClick={() => {
                  setCurrentPage('high-buy');
                }}
                className={cn(
                  "px-5 py-2 rounded-full transition-all text-[10px] font-black",
                  currentPage === 'high-buy' ? "bg-indigo-600 text-white shadow-lg" : "text-slate-500 hover:text-slate-300"
                )}
              >
                ALPHA
              </button>
              <button 
                onClick={() => setCurrentPage('portfolio')}
                className={cn(
                  "px-5 py-2 rounded-full transition-all text-[10px] font-black",
                  currentPage === 'portfolio' ? "bg-indigo-600 text-white shadow-lg" : "text-slate-500 hover:text-slate-300"
                )}
              >
                PORTFOLIO / PNL
              </button>
              <button 
                onClick={() => setCurrentPage('system-check')}
                className={cn(
                  "px-5 py-2 rounded-full transition-all text-[10px] font-black flex items-center gap-1",
                  currentPage === 'system-check' ? "bg-slate-700 text-white shadow-lg" : "text-slate-500 hover:text-slate-300"
                )}
              >
                <Terminal className="w-3 h-3" /> TEST
              </button>
            </nav>

            <div className="flex items-center gap-3">
              <WalletStatusWidget />
              
              {user ? (
                <div className="flex items-center gap-3 bg-slate-900/40 border border-slate-800 rounded-full pl-4 pr-1 py-1">
                  <div className="flex flex-col items-end">
                    <span className="text-white text-[10px] font-black lowercase">{user.displayName}</span>
                    <button 
                      onClick={() => signOut(auth)}
                      className="text-[8px] text-rose-500 border-b border-rose-500/0 hover:border-rose-500/50 transition-all font-mono"
                    >
                      DISCONNECT
                    </button>
                  </div>
                  {user.photoURL && <img src={user.photoURL} className="w-8 h-8 rounded-full border border-indigo-500/30 p-0.5" alt="avatar" />}
                </div>
              ) : (
                <button 
                  onClick={handleLogin}
                  className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-5 py-2 rounded-full font-black transition-all shadow-lg active:scale-95"
                >
                  <LogIn className="w-3.5 h-3.5" /> LOGIN
                </button>
              )}
            </div>
          </div>

          <div className="flex lg:hidden items-center gap-2">
            <WalletStatusWidget />
            <button 
              onClick={() => handleStartMonitoring()}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-indigo-400"
            >
              <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
            </button>
          </div>
        </div>
      </header>


      <main className="relative z-10 max-w-[1440px] mx-auto px-4 lg:px-8 py-4 lg:py-6 flex flex-col flex-1 lg:h-[calc(100vh-104px)] lg:overflow-hidden pb-24 lg:pb-0">
        
        {/* Alpha Protocol Selector - Central focus for user selection */}
        {currentPage !== 'dashboard' && currentPage !== 'high-buy' && (
          <div className="flex flex-col lg:flex-row items-center justify-between gap-4 mb-6 bg-slate-900/60 border border-slate-800 p-4 rounded-3xl backdrop-blur-xl">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 flex items-center justify-center border border-indigo-500/20">
                <BrainCircuit className="w-6 h-6 text-indigo-400" />
              </div>
              <div>
                <h2 className="text-sm font-black text-white uppercase tracking-tighter leading-none mb-1">Matrix Protocol</h2>
                <p className="text-[9px] text-slate-500 uppercase tracking-widest font-bold">Select strategy for optimal discovery</p>
              </div>
            </div>
            
            <div className="flex flex-col lg:flex-row items-center gap-4 w-full lg:w-auto">
              <div className="flex items-center gap-2 p-1 bg-slate-950/80 rounded-2xl border border-slate-800 overflow-x-auto scrollbar-none w-full lg:w-auto">
                {[
                  { id: 'MIGRATED', label: 'Migrations', icon: Rocket, desc: 'Raydium Graduations' },
                  { id: 'SNIPER', label: 'Sniper / Flash', icon: Target, desc: 'Early Momentum' },
                  { id: 'GEMS_100X', label: 'Prediction App', icon: BrainCircuit, desc: 'AI Sentiment & Momentum' },
                  { id: 'HIGH_PROFIT', label: 'Profit Max', icon: TrendingUp, desc: '60%+ Gains' },
                  { id: 'WHALE_BUY', label: 'Whale Influx', icon: Zap, desc: 'Big Entries' },
                  { id: 'NEW_DISCOVERY', label: 'New Gems', icon: Search, desc: 'Recent Mints' },
                  { id: 'ALL', label: 'All Alpha', icon: Globe, desc: 'Full Stream' }
                ].map((p) => {
                  const Icon = p.icon;
                  const active = alphaProtocol === p.id;
                  return (
                    <button
                      key={p.id}
                      onClick={() => setAlphaProtocol(p.id as any)}
                      className={cn(
                        "flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all whitespace-nowrap group relative overflow-hidden",
                        active ? "bg-indigo-600 text-white shadow-[0_0_20px_rgba(79,70,229,0.3)]" : "text-slate-500 hover:text-slate-300 hover:bg-slate-900"
                      )}
                    >
                      {active && (
                        <motion.div 
                          layoutId="protocol-bg"
                          className="absolute inset-0 bg-indigo-600 z-0"
                          transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                        />
                      )}
                      <Icon className={cn("w-4 h-4 relative z-10", active ? "text-white" : "text-slate-600 group-hover:text-indigo-400")} />
                      <div className="flex flex-col items-start relative z-10">
                        <span className="text-[10px] font-black uppercase tracking-tight leading-none mb-0.5">{p.label}</span>
                        <span className={cn("text-[7px] uppercase font-bold tracking-widest", active ? "text-indigo-200" : "text-slate-700")}>{p.desc}</span>
                      </div>
                    </button>
                  )
                })}
              </div>

              {/* Wallet Integration Buttons */}
              <div className="flex items-center gap-2 h-[50px]">
                <WalletMultiButton className="!bg-indigo-600 hover:!bg-indigo-500 !rounded-xl !h-full !px-4 !text-[10px] !font-black !uppercase !tracking-widest !shadow-lg transition-all" />
                <button 
                  onClick={() => setAutoSniperEnabled(!autoSniperEnabled)}
                  className={cn(
                    "h-full px-4 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-lg flex items-center gap-2",
                    autoSniperEnabled ? "bg-rose-600 text-white animate-pulse" : "bg-emerald-600 text-white"
                  )}
                >
                  {autoSniperEnabled ? <Activity className="w-4 h-4" /> : <Zap className="w-4 h-4" />}
                  {autoSniperEnabled ? "Auto-Alpha: ON" : "Auto-Alpha: OFF"}
                </button>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 flex-1 lg:overflow-hidden">
        {currentPage === 'dashboard' ? (
          <>
            {/* Left Column: Identity & Portfolio */}
            <section className="col-span-1 lg:col-span-3 flex flex-col gap-6 lg:overflow-y-auto scrollbar-none">
          {/* Multi-Wallet Control */}
          {user && (
            <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-5 backdrop-blur-sm">
              <h2 className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest mb-4 flex items-center justify-between">
                <span>Manage Wallets</span>
                <button 
                  onClick={() => setIsXRayEnabled(!isXRayEnabled)}
                  className={cn(
                    "px-2 py-0.5 rounded text-[8px] transition-colors border",
                    isXRayEnabled ? "bg-indigo-500/20 text-indigo-300 border-indigo-500/30" : "bg-slate-800 text-slate-500 border-slate-700"
                  )}
                >
                  X-RAY PROTOCOL {isXRayEnabled ? 'ON' : 'OFF'}
                </button>
              </h2>
              
              <div className="space-y-4 mb-6">
                <div>
                  <input 
                    type="text"
                    placeholder="Address (0x...)"
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-[10px] font-mono text-indigo-300 focus:outline-none focus:border-indigo-500 transition-colors mb-2"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                  />
                  <input 
                    type="text"
                    placeholder="Label (Optional)"
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-[10px] text-slate-300 focus:outline-none focus:border-indigo-500 transition-colors mb-2"
                    value={walletLabel}
                    onChange={(e) => setWalletLabel(e.target.value)}
                  />
                  <button 
                    onClick={addWallet}
                    className="w-full bg-indigo-600 hover:bg-indigo-500 text-white text-[10px] font-bold py-2 rounded-lg transition-all flex items-center justify-center gap-2 mt-1 shadow-lg"
                  >
                    <Plus className="w-3.5 h-3.5" /> ADD TO MONITOR
                  </button>
                </div>
              </div>

              <div className="space-y-2 max-h-[200px] lg:max-h-[300px] overflow-y-auto pr-1 scrollbar-none">
                {monitoredWallets.map(wallet => (
                  <div key={wallet.id} className="group/wallet bg-slate-950/50 border border-slate-800/50 p-3 rounded-xl flex items-center justify-between gap-3 hover:border-indigo-500/30 transition-all">
                    <div className="min-w-0">
                      <p className="text-[10px] font-black text-white uppercase truncate">{wallet.label}</p>
                      <p className="text-[9px] font-mono text-slate-500 truncate">{wallet.address.slice(0, 8)}...{wallet.address.slice(-8)}</p>
                    </div>
                    <button 
                      onClick={() => removeWallet(wallet.id)}
                      className="p-1.5 rounded-md hover:bg-rose-500/10 text-slate-600 hover:text-rose-400 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
                {monitoredWallets.length === 0 && (
                  <div className="text-center py-8 opacity-20 italic text-[10px]">No wallets added</div>
                )}
              </div>

              <div className="mt-6 pt-4 border-t border-slate-800 space-y-4">
                <div className="flex items-center justify-between">
                   <div className="flex flex-col">
                     <span className="text-[9px] font-black text-white uppercase tracking-widest">Anti-MEV Protection</span>
                     <span className="text-[7px] text-slate-500 uppercase">Jito Bundle Execution</span>
                   </div>
                   <button 
                     onClick={() => addNotification("Anti-MEV Protection Enabled (Jito Node Syncing)")}
                     className="w-10 h-5 bg-slate-800 rounded-full relative p-1 transition-all hover:bg-slate-700"
                   >
                     <div className="w-3 h-3 bg-indigo-500 rounded-full translate-x-5" />
                   </button>
                </div>

                <div className="flex items-center justify-between">
                   <div className="flex flex-col">
                     <span className="text-[9px] font-black text-white uppercase tracking-widest">Auto Take-Profit</span>
                     <span className="text-[7px] text-slate-500 uppercase">TP: 60% @ 2x Gain</span>
                   </div>
                   <button 
                     onClick={() => addNotification("Automated Take-Profit Protocol Set to 2x")}
                     className="w-10 h-5 bg-slate-800 rounded-full relative p-1 transition-all hover:bg-slate-700"
                   >
                     <div className="w-3 h-3 bg-indigo-500 rounded-full translate-x-5" />
                   </button>
                </div>

                <button 
                  onClick={() => setIsMonitoring(!isMonitoring)}
                  disabled={monitoredWallets.length === 0}
                  className={cn(
                    "w-full py-3 rounded-xl font-black text-[11px] tracking-[0.2em] transition-all shadow-xl flex items-center justify-center gap-3",
                    isMonitoring 
                      ? "bg-rose-500/10 text-rose-500 border border-rose-500/20 hover:bg-rose-500/20" 
                      : "bg-emerald-500 text-white hover:bg-emerald-400"
                  )}
                >
                  {isMonitoring ? (
                    <>STAGING STATUS: LIVE <Zap className="w-4 h-4 animate-pulse fill-rose-500" /></>
                  ) : (
                    <>ENGAGE MASTER MONITOR <Activity className="w-4 h-4" /></>
                  )}
                </button>
              </div>
            </div>
          )}

          {!user && (
            <div className="bg-indigo-600/10 border border-indigo-500/20 rounded-2xl p-6 text-center backdrop-blur-md">
              <ShieldAlert className="w-10 h-10 text-indigo-400 mx-auto mb-4" />
              <h3 className="text-sm font-bold text-white uppercase mb-2">Auth Required</h3>
              <p className="text-[10px] text-slate-400 leading-relaxed mb-4">Please login to save wallets and enable multi-monitor capabilities.</p>
              <button 
                onClick={handleLogin}
                className="w-full bg-indigo-600 hover:bg-indigo-500 text-white text-[10px] font-bold py-2.5 rounded-xl transition-all shadow-lg"
              >
                Login with Google
              </button>
            </div>
          )}

          <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-5 flex flex-col">
            <h2 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-4">Asset Matrix</h2>
            <div className="space-y-6 py-2">
              {[
                { name: 'SOL', color: 'bg-indigo-500', pct: 62 },
                { name: 'JUP', color: 'bg-blue-500', pct: 21 },
                { name: 'USDC', color: 'bg-emerald-500', pct: 17 }
              ].map((coin, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className={cn("w-1 h-8 rounded-full", coin.color)}></div>
                  <div className="flex-1">
                    <div className="flex justify-between text-[10px] font-mono mb-1.5 uppercase">
                      <span className="text-slate-400 font-bold">{coin.name}</span>
                      <span className="text-white">{coin.pct}%</span>
                    </div>
                    <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
                      <div className={cn("h-full rounded-full transition-all duration-1000", coin.color)} style={{ width: `${coin.pct}%` }}></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Center Column: Pulse Feed */}
        <section className="col-span-1 lg:col-span-6 flex flex-col gap-4 min-h-[400px] lg:min-h-0">
          <div className="flex items-center justify-between px-2">
            <h2 className="text-[10px] font-bold text-indigo-400 uppercase tracking-[0.2em] flex items-center gap-2">
              <Terminal className="w-3 h-3" />
              Pulse Feed
            </h2>
            <div className="flex gap-2">
              <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-500 text-[9px] font-bold border border-emerald-500/20 uppercase tracking-tighter">BUYS</span>
              <span className="px-2 py-0.5 rounded bg-rose-500/10 text-rose-500 text-[9px] font-bold border border-rose-500/20 uppercase tracking-tighter">SELLS</span>
            </div>
          </div>

          <div className="flex-1 bg-slate-900/10 border border-slate-800/40 rounded-2xl backdrop-blur-sm overflow-hidden flex flex-col min-h-0">
            <div className="p-4 lg:p-6 flex-1 overflow-y-auto scrollbar-none">
              {!isMonitoring && !loading && !error && (
                <div className="h-full flex flex-col items-center justify-center text-center opacity-30 space-y-4 py-8">
                  <div className="relative w-16 lg:w-20 h-16 lg:h-20 flex items-center justify-center">
                    <div className="absolute inset-0 rounded-full border border-slate-700 animate-[spin_10s_linear_infinite]"></div>
                    <Search className="w-6 lg:w-8 h-6 lg:h-8 text-indigo-400" />
                  </div>
                  <div className="arabic px-4">
                    <h3 className="text-base lg:text-lg font-bold text-white uppercase tracking-tight">جاهز للمراقبة</h3>
                    <p className="text-[11px] lg:text-xs max-w-xs mx-auto text-slate-500 leading-relaxed">أدخل عنوان محفظة Solana للاتصال بنبض الشبكة المباشر</p>
                  </div>
                </div>
              )}

              {loading && (
                <div className="h-full flex flex-col items-center justify-center space-y-6 py-8">
                  <div className="relative w-12 lg:w-16 h-12 lg:h-16 flex items-center justify-center">
                    <div className="absolute inset-0 rounded-full border-4 border-slate-800"></div>
                    <div className="absolute inset-0 rounded-full border-t-4 border-indigo-500 animate-spin"></div>
                    <Activity className="w-4 lg:w-5 h-4 lg:h-5 text-indigo-400 animate-pulse" />
                  </div>
                  <p className="text-[9px] lg:text-[10px] font-mono uppercase tracking-[0.2em] text-slate-500">Establishing Stream...</p>
                </div>
              )}

              {error && (
                <div className="h-full flex flex-col items-center justify-center space-y-4 text-rose-400 py-8 px-4">
                  <ShieldAlert className="w-8 lg:w-10 h-8 lg:h-10" />
                  <p className="text-[10px] lg:text-[11px] font-mono border border-rose-500/20 bg-rose-500/5 px-4 py-2 rounded-lg text-center max-w-sm uppercase">{error}</p>
                </div>
              )}

              <div className="space-y-3">
                <AnimatePresence mode="popLayout">
                  {trades.map((trade) => (
                    <motion.div
                      key={trade.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.98 }}
                      className={cn(
                        "group p-3 lg:p-4 border rounded-xl transition-all cursor-pointer backdrop-blur-sm flex items-center justify-between gap-3",
                        trade.type === 'buy' 
                          ? "border-emerald-500/30 bg-emerald-500/5" 
                          : "border-rose-500/30 bg-rose-500/5"
                      )}
                    >
                      <div className="flex items-center gap-3 lg:gap-4 overflow-hidden">
                        <div className={cn(
                          "w-8 lg:w-10 h-8 lg:h-10 rounded-lg flex items-center justify-center font-black text-[10px] shrink-0",
                          trade.type === 'buy' ? "bg-emerald-500/20 text-emerald-400" : "bg-rose-500/20 text-rose-400"
                        )}>
                          {trade.type === 'buy' ? 'BUY' : 'SELL'}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className={cn("font-mono text-xs lg:text-sm font-bold", trade.type === 'buy' ? "text-emerald-400" : "text-rose-400")}>
                              {trade.type === 'buy' ? '+' : '-'}{trade.amount.toLocaleString()} {trade.token}
                            </span>
                            <span className="text-[9px] text-slate-500 font-mono">(${(trade.amount * 145).toLocaleString()})</span>
                          </div>
                          
                          <div className="flex items-center gap-2 mt-1">
                            <div className="flex items-center gap-1.5 bg-slate-950/50 px-2 py-0.5 rounded border border-slate-800 group/addr font-mono">
                              <span className="text-[8px] lg:text-[9px] text-indigo-400 font-medium">ADDR:</span>
                              <p 
                                onClick={(e) => {
                                  e.stopPropagation();
                                  window.open(`https://solscan.io/token/${trade.tokenAddress}`, '_blank');
                                }}
                                className="text-[8px] lg:text-[9px] text-slate-400 hover:text-white transition-colors truncate max-w-[120px] lg:max-w-none cursor-pointer"
                              >
                                {trade.tokenAddress}
                              </p>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  copyToClipboard(trade.tokenAddress, `${trade.id}-token`);
                                }}
                                className="p-0.5 rounded bg-slate-900 border border-slate-800 hover:bg-slate-800 transition-colors text-slate-500 font-sans"
                              >
                                {copiedId === `${trade.id}-token` ? <Check className="w-2.5 h-2.5 text-emerald-400" /> : <Copy className="w-2.5 h-2.5" />}
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          window.open(`https://solscan.io/tx/${trade.signature}`, '_blank');
                        }}
                        className="px-2 lg:px-3 py-1 bg-slate-800 border border-slate-700/50 rounded text-[8px] font-bold text-slate-400 hover:bg-slate-700 hover:text-white transition-all whitespace-nowrap"
                      >
                        TX INFO
                      </button>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            </div>
          </div>
        </section>

        {/* Right Column: Signal & Intelligence */}
        <section className="col-span-1 lg:col-span-3 flex flex-col gap-6 lg:overflow-y-auto scrollbar-none pb-12 lg:pb-0">
          <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-sm flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <h2 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Session Stats</h2>
              <div className="flex gap-2">
                <button 
                  onClick={generateSessionWallet}
                  className="p-1.5 bg-slate-800 hover:bg-slate-700 rounded-lg transition-all"
                  title="Gen New Key"
                >
                  <RefreshCw className="w-3 h-3 text-slate-400" />
                </button>
                <button 
                  onClick={() => setIsExportingKey(!isExportingKey)}
                  className="p-1.5 bg-slate-800 hover:bg-slate-700 rounded-lg transition-all"
                  title="Export Private Key"
                >
                  <Scan className="w-3 h-3 text-slate-400" />
                </button>
              </div>
            </div>
            
            <div className="p-4 bg-slate-900/50 rounded-xl border border-slate-800/50 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800/50">
                <div className="flex flex-col">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest leading-tight">SIM Wallet Balance</span>
                  <span className="text-[8px] text-amber-500/80 font-bold uppercase mt-0.5 tracking-tighter">Immediate Feedback Active</span>
                </div>
                <div className="text-right">
                   <div className="text-[9px] text-slate-500 font-bold uppercase tracking-widest">Simulation Assets</div>
                </div>
              </div>

              
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-bold text-slate-500">SESSION ADDRESS</span>
                <span className="text-[10px] font-mono text-indigo-400">Mainnet-Beta</span>
              </div>
              <div className="flex items-center gap-2 mb-4">
                <input 
                  readOnly
                  value={sessionWallet ? sessionWallet.publicKey.toString() : 'No Wallet Generated'}
                  className="bg-transparent text-[10px] font-mono text-slate-300 w-full outline-none"
                />
                <button onClick={() => {
                  if (sessionWallet) {
                    navigator.clipboard.writeText(sessionWallet.publicKey.toString());
                    addNotification('Address Copied');
                  }
                }}>
                  <Copy className="w-3 h-3 text-slate-500 hover:text-white" />
                </button>
              </div>
              
              <div className="flex flex-col gap-2">
                <div className="flex justify-between items-center text-[10px] font-bold mb-1">
                  <span className="text-slate-500 uppercase">Buy Size (SOL)</span>
                  <span className="text-white">{buyAmountSol} SOL</span>
                </div>
                <input 
                  type="range" 
                  min="0.05" 
                  max="1" 
                  step="0.01" 
                  value={buyAmountSol}
                  onChange={(e) => setBuyAmountSol(parseFloat(e.target.value))}
                  className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                />
                
                <div className="flex justify-between items-center text-[10px] font-bold mt-2 mb-1">
                  <span className="text-slate-500 uppercase">Min Profit Floor (Raydium)</span>
                  <span className="text-emerald-400">{minTakeProfit}%</span>
                </div>
                <input 
                  type="range" 
                  min="5" 
                  max="100" 
                  step="5" 
                  value={minTakeProfit}
                  onChange={(e) => setMinTakeProfit(parseInt(e.target.value))}
                  className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                />

                <div className="flex justify-between items-center text-[10px] font-bold mt-2 mb-1">
                  <span className="text-slate-500 uppercase">Profit Floor (Bonding Curve)</span>
                  <span className="text-emerald-400">{bondingCurveTakeProfit}%</span>
                </div>
                <input 
                  type="range" 
                  min="5" 
                  max="100" 
                  step="5" 
                  value={bondingCurveTakeProfit}
                  onChange={(e) => setBondingCurveTakeProfit(parseInt(e.target.value))}
                  className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                />

                <div className="flex justify-between items-center text-[10px] font-bold mt-2 mb-1">
                  <span className="text-slate-500 uppercase">Max Profit Target (TP 2)</span>
                  <span className="text-emerald-500">{maxTakeProfit}%</span>
                </div>
                <input 
                  type="range" 
                  min="10" 
                  max="500" 
                  step="5" 
                  value={maxTakeProfit}
                  onChange={(e) => setMaxTakeProfit(parseInt(e.target.value))}
                  className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-600 shadow-[0_0_10px_rgba(16,185,129,0.1)]"
                />

                <div className="flex justify-between items-center text-[10px] font-bold mt-2 mb-1">
                  <span className="text-slate-500 uppercase">Stop Loss — Raydium / Migrated Tokens</span>
                  <span className="text-rose-400">{stopLoss}%</span>
                </div>
                <div className="flex items-center gap-2">
                  <input 
                    type="range" 
                    min="-99" 
                    max="-1" 
                    step="1" 
                    value={stopLoss}
                    onChange={(e) => updateMasterStopLoss(parseInt(e.target.value))}
                    className="flex-1 h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-rose-500 shadow-[0_0_10px_rgba(244,63,94,0.1)]"
                  />
                  <input
                    type="number"
                    min="1"
                    max="99"
                    step="1"
                    value={Math.abs(stopLoss)}
                    onChange={(e) => {
                      const v = parseInt(e.target.value);
                      if (!isNaN(v)) {
                        const bounded = Math.max(1, Math.min(99, v));
                        updateMasterStopLoss(-bounded);
                      }
                    }}
                    className="w-16 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-rose-400 text-right focus:outline-none focus:border-rose-500"
                  />
                </div>
                <p className="text-[9px] text-slate-600 mt-1">
                  Applies to tokens already on Raydium/PumpSwap (fully migrated, 99.5%+ bonding or graduated).
                </p>

                <div className="flex justify-between items-center text-[10px] font-bold mt-3 mb-1">
                  <span className="text-slate-500 uppercase">Stop Loss — Pump.fun / Bonding Tokens</span>
                  <span className="text-rose-400">{bondingCurveStopLoss}%</span>
                </div>
                <div className="flex items-center gap-2">
                  <input 
                    type="range" 
                    min="-99" 
                    max="-1" 
                    step="1" 
                    value={bondingCurveStopLoss}
                    onChange={(e) => setBondingCurveStopLoss(parseInt(e.target.value))}
                    className="flex-1 h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-rose-500 shadow-[0_0_10px_rgba(244,63,94,0.1)]"
                  />
                  <input
                    type="number"
                    min="1"
                    max="99"
                    step="1"
                    value={Math.abs(bondingCurveStopLoss)}
                    onChange={(e) => {
                      const v = parseInt(e.target.value);
                      if (!isNaN(v)) {
                        const bounded = Math.max(1, Math.min(99, v));
                        setBondingCurveStopLoss(-bounded);
                      }
                    }}
                    className="w-16 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-rose-400 text-right focus:outline-none focus:border-rose-500"
                  />
                </div>
                <p className="text-[9px] text-slate-600 mt-1">
                  Applies to tokens still bonding on Pump.fun (pre-migration).
                </p>

                <div className="flex justify-between items-center text-[10px] font-bold mt-3 mb-1">
                  <span className="text-slate-500 uppercase">Stop Loss — PumpSwap Tokens</span>
                  <span className="text-rose-400">{pumpSwapStopLoss}%</span>
                </div>
                <div className="flex items-center gap-2">
                  <input 
                    type="range" 
                    min="-99" 
                    max="-1" 
                    step="1" 
                    value={pumpSwapStopLoss}
                    onChange={(e) => setPumpSwapStopLoss(parseInt(e.target.value))}
                    className="flex-1 h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-rose-500 shadow-[0_0_10px_rgba(244,63,94,0.1)]"
                  />
                  <input
                    type="number"
                    min="1"
                    max="99"
                    step="1"
                    value={Math.abs(pumpSwapStopLoss)}
                    onChange={(e) => {
                      const v = parseInt(e.target.value);
                      if (!isNaN(v)) {
                        const bounded = Math.max(1, Math.min(99, v));
                        setPumpSwapStopLoss(-bounded);
                      }
                    }}
                    className="w-16 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-rose-400 text-right focus:outline-none focus:border-rose-500"
                  />
                </div>
                <p className="text-[9px] text-slate-600 mt-1">
                  Applies to tokens trading on PumpSwap.
                </p>

                <div className="flex justify-between items-center text-[10px] font-bold mt-3 mb-1">
                  <span className="text-slate-500 uppercase">Stop Loss — Unknown / External Tokens</span>
                  <span className="text-rose-400">{unknownStopLoss}%</span>
                </div>
                <div className="flex items-center gap-2">
                  <input 
                    type="range" 
                    min="-99" 
                    max="-1" 
                    step="1" 
                    value={unknownStopLoss}
                    onChange={(e) => setUnknownStopLoss(parseInt(e.target.value))}
                    className="flex-1 h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-rose-500 shadow-[0_0_10px_rgba(244,63,94,0.1)]"
                  />
                  <input
                    type="number"
                    min="1"
                    max="99"
                    step="1"
                    value={Math.abs(unknownStopLoss)}
                    onChange={(e) => {
                      const v = parseInt(e.target.value);
                      if (!isNaN(v)) {
                        const bounded = Math.max(1, Math.min(99, v));
                        setUnknownStopLoss(-bounded);
                      }
                    }}
                    className="w-16 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-rose-400 text-right focus:outline-none focus:border-rose-500"
                  />
                </div>
                <p className="text-[9px] text-slate-600 mt-1">
                  Applies to unknown or external tokens without clear liquidity mappings or platform identifiers.
                </p>


                <div className="flex justify-between items-center text-[10px] font-bold mt-4 mb-1">
                  <span className="text-slate-500 uppercase">100x Moonbag Strategy</span>
                </div>
                <div className="flex items-center gap-2 mb-4">
                  <div 
                    onClick={() => setMoonbagStrategy(!moonbagStrategy)}
                    className={"w-10 h-5 rounded-full p-1 cursor-pointer transition-colors relative " + (moonbagStrategy ? "bg-emerald-500" : "bg-slate-700")}
                  >
                    <div className={"w-3 h-3 bg-white rounded-full transition-transform " + (moonbagStrategy ? "translate-x-5" : "")} />
                  </div>
                  <span className="text-xs text-slate-400">
                    {moonbagStrategy ? `Active: Tiered Take Profit ${minTakeProfit}% (50% out) / ${maxTakeProfit}% (Final out)` : 'Inactive: Sell all at profit target'}
                  </span>
                </div>

                <div className="flex justify-between items-center text-[10px] font-bold mt-4 mb-1">
                  <span className="text-slate-500 uppercase">Trade Tokens Only Once (No Rebuy)</span>
                  <span className={tradeOnlyOnce ? "text-emerald-400" : "text-amber-400"}>
                    {tradeOnlyOnce ? "Single Trade" : `Rebuy: max ${maxRebuyTimes}x`}
                  </span>
                </div>
                <div className="flex items-center gap-2 mb-4">
                  <div 
                    id="btn-toggle-trade-only-once"
                    onClick={() => {
                      const next = !tradeOnlyOnce;
                      setTradeOnlyOnce(next);
                      if (next) setMaxRebuyTimes(1);
                    }}
                    className={"w-10 h-5 rounded-full p-1 cursor-pointer transition-colors relative " + (tradeOnlyOnce ? "bg-emerald-500" : "bg-slate-700")}
                  >
                    <div className={"w-3 h-3 bg-white rounded-full transition-transform " + (tradeOnlyOnce ? "translate-x-5" : "")} />
                  </div>
                  <span className="text-xs text-slate-400">
                    {tradeOnlyOnce ? 'Active: Never rebuy tokens already traded once' : `Inactive: Rebuys permitted (limit: ${maxRebuyTimes} trades)`}
                  </span>
                </div>
                
                <div className="flex justify-between items-center text-[10px] font-bold mt-4 mb-1">
                  <span className="text-slate-500 uppercase">Max Slippage</span>


                  <span className="text-indigo-400">{slippage}%</span>
                </div>
                <input 
                  type="range" 
                  min="0.1" 
                  max="15" 
                  step="0.1" 
                  value={slippage}
                  onChange={(e) => setSlippage(parseFloat(e.target.value))}
                  className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                />
                
                <div className="flex gap-2 mb-3">
                  {[1, 2, 3].map(val => (
                    <button
                      key={val}
                      onClick={() => setSlippage(val)}
                      className={"flex-1 py-1 rounded border text-[10px] font-black transition-colors " + (slippage === val ? "bg-indigo-600 border-indigo-500 text-white" : "bg-slate-900 border-slate-800 text-slate-500 hover:text-slate-300")}
                    >{val}%</button>
                  ))}
                </div>

<p className="text-[8px] text-slate-600 mt-1 uppercase tracking-tighter italic">Includes Price Impact + Fixed Fees</p>
              </div>
            </div>

            {isExportingKey && sessionWallet && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="p-3 bg-rose-950/30 border border-rose-900/50 rounded-xl"
              >
                <p className="text-[8px] text-rose-400 font-bold uppercase mb-2">SECRET (PRIVATE KEY) - DO NOT SHARE</p>
                <div className="flex items-center gap-2">
                  <input 
                    readOnly
                    type="password"
                    value={bs58.encode(sessionWallet.secretKey)}
                    className="bg-transparent text-[9px] font-mono text-rose-300 w-full outline-none"
                  />
                  <button onClick={() => navigator.clipboard.writeText(bs58.encode(sessionWallet.secretKey))}>
                    <Copy className="w-3 h-3 text-rose-500" />
                  </button>
                </div>
              </motion.div>
            )}

            {/* Hardened Scanner Criteria Customizer Card */}
            <div className="bg-slate-900/40 p-4 rounded-xl border border-slate-800/50 mb-6">
              <button 
                onClick={() => setIsHardenedCriteriaExpanded(!isHardenedCriteriaExpanded)}
                className="w-full flex items-center justify-between text-left group"
              >
                <div className="flex flex-col">
                  <span className="text-[10px] font-black uppercase text-indigo-400 tracking-widest leading-tight">Hardened Entry Criteria</span>
                  <span className="text-[8px] text-slate-500 uppercase mt-0.5 font-bold tracking-tight">Expand to customize screening limits</span>
                </div>
                <div className="text-slate-500 group-hover:text-slate-300 transition-colors">
                  {isHardenedCriteriaExpanded ? (
                    <span className="inline-block text-xs font-bold font-mono">▲</span>
                  ) : (
                    <span className="inline-block text-xs font-bold font-mono">▼</span>
                  )}
                </div>
              </button>

              <AnimatePresence>
                {isHardenedCriteriaExpanded && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.25 }}
                    className="overflow-hidden mt-4 pt-4 border-t border-slate-800/60"
                  >
                    <div className="space-y-4">
                      {/* Section: Preset Templates */}
                      <div className="space-y-3 pb-3 border-b border-slate-800/60">
                        <label className="text-[8px] font-black uppercase tracking-widest text-indigo-400">⚡ Risk preset profiles</label>
                        <div className="grid grid-cols-2 gap-1.5">
                          {SAFETY_PRESETS.map((p) => {
                            const isSelected = activePreset === p.id;
                            const badgeColor = isSelected ? p.badge.text : 'text-slate-500';
                            const badgeBg = isSelected ? p.badge.bg : 'bg-slate-950/20';
                            const badgeBorder = isSelected ? p.badge.border : 'border-slate-900';
                            return (
                              <button
                                key={p.id}
                                type="button"
                                onClick={() => applyPreset(p)}
                                className={cn(
                                  "flex flex-col text-left p-2 rounded-lg border transition-all cursor-pointer h-[54px] justify-between",
                                  isSelected 
                                    ? "bg-slate-900/50 border-indigo-500 shadow-md ring-1 ring-indigo-500/10" 
                                    : "bg-slate-950/40 border-slate-800 hover:border-slate-700 hover:bg-slate-900/30"
                                )}
                              >
                                <span className={cn("text-[9px] font-black", isSelected ? "text-white" : "text-slate-400")}>{p.name}</span>
                                <span className={cn("text-[7px] font-medium leading-none px-1.5 py-0.5 rounded border mt-1 select-none whitespace-nowrap self-start", badgeBg, badgeColor, badgeBorder)}>
                                  {isSelected ? "Active Config" : p.description.split('.')[0]}
                                </span>
                              </button>
                            );
                          })}
                        </div>
                        
                        {/* Display Detailed Explanation of chosen preset */}
                        {activePreset !== 'custom' && (
                          <div className="p-2 bg-slate-950/30 border border-slate-900 rounded-lg">
                            {SAFETY_PRESETS.map(p => p.id === activePreset && (
                              <div key={p.id} className="space-y-1">
                                <p className="text-[8px] font-bold text-white uppercase flex items-center gap-1">
                                  <span>ℹ️</span> {p.name} Strategy
                                </p>
                                <p className="text-[7.5px] leading-relaxed text-slate-400 font-medium">{p.detail}</p>
                              </div>
                            ))}
                          </div>
                        )}

                        {activePreset === 'custom' && (
                          <div className="p-2 bg-indigo-950/20 border border-indigo-900/30 rounded-lg">
                            <div className="space-y-1">
                              <p className="text-[8px] font-bold text-indigo-400 uppercase flex items-center gap-1">
                                <span>🛠️</span> Custom Settings
                              </p>
                              <p className="text-[7.5px] leading-relaxed text-indigo-300/80 font-medium">
                                Parameters diverged from templates. Slide/type on any criteria below to refine fine-tuned scanners.
                              </p>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Section: MCAP Customizer */}
                      <div className="space-y-2">
                        <label className="text-[8px] font-black uppercase tracking-widest text-slate-500">Market Cap Limits (USD)</label>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <span className="text-[8px] font-bold text-slate-400 uppercase">Min Pump.fun</span>
                            <input 
                              type="number" 
                              value={hardenedMcapMinPump}
                              onChange={(e) => setHardenedMcapMinPump(Math.max(0, Number(e.target.value)))}
                              className="w-full bg-slate-950 border border-slate-850 rounded px-2 py-1 text-[10px] font-mono text-white mt-1 h-7"
                            />
                          </div>
                          <div>
                            <span className="text-[8px] font-bold text-slate-400 uppercase">Min Raydium</span>
                            <input 
                              type="number" 
                              value={hardenedMcapMinRaydium}
                              onChange={(e) => setHardenedMcapMinRaydium(Math.max(0, Number(e.target.value)))}
                              className="w-full bg-slate-950 border border-slate-850 rounded px-2 py-1 text-[10px] font-mono text-white mt-1 h-7"
                            />
                          </div>
                        </div>
                        <div>
                          <span className="text-[8px] font-bold text-slate-400 uppercase">Max Market Cap</span>
                          <input 
                            type="number" 
                            value={hardenedMcapMax}
                            onChange={(e) => setHardenedMcapMax(Math.max(0, Number(e.target.value)))}
                            className="w-full bg-slate-950 border border-slate-850 rounded px-2 py-1 text-[10px] font-mono text-white mt-1 h-7"
                          />
                        </div>
                      </div>

                      {/* Section: Liquidity Protection */}
                      <div className="space-y-2 pt-2 border-t border-slate-850">
                        <label className="text-[8px] font-black uppercase tracking-widest text-slate-500">Liquidity & Depth Protection</label>
                        <div>
                          <span className="text-[8px] font-bold text-slate-400 uppercase">Min Liquidity (USD)</span>
                          <input 
                            type="number" 
                            value={hardenedLiquidityMin}
                            onChange={(e) => setHardenedLiquidityMin(Math.max(0, Number(e.target.value)))}
                            className="w-full bg-slate-950 border border-slate-850 rounded px-2 py-1 text-[10px] font-mono text-white mt-1 h-7"
                          />
                        </div>
                        <div>
                          <div className="flex justify-between items-center text-[8px] font-bold text-slate-400 uppercase">
                            <span>Min Liquidity / Cap Ratio</span>
                            <span className="font-mono text-indigo-400">{hardenedLiquidityRatio}%</span>
                          </div>
                          <input 
                            type="range" 
                            min="1" 
                            max="25" 
                            value={hardenedLiquidityRatio}
                            onChange={(e) => setHardenedLiquidityRatio(Number(e.target.value))}
                            className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500 mt-1"
                          />
                        </div>
                      </div>

                      {/* Section: Pump.fun Bonding Progress Limits */}
                      <div className="space-y-2 pt-2 border-t border-slate-850">
                        <label className="text-[8px] font-black uppercase tracking-widest text-slate-500">Pump.fun Bonding Curve Limits</label>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <span className="text-[8px] font-bold text-slate-400 uppercase">Min Bonding %</span>
                            <input 
                              type="number" 
                              step="0.5"
                              min="0"
                              max="100"
                              value={hardenedMinBondingProgress}
                              onChange={(e) => setHardenedMinBondingProgress(Math.min(100, Math.max(0, Number(e.target.value))))}
                              className="w-full bg-slate-950 border border-slate-850 rounded px-2 py-1 text-[10px] font-mono text-white mt-1 h-7"
                              placeholder="0"
                            />
                          </div>
                          <div>
                            <span className="text-[8px] font-bold text-slate-400 uppercase">Max Bonding %</span>
                            <input 
                              type="number" 
                              step="0.5"
                              min="0"
                              max="100"
                              value={hardenedMaxBondingProgress}
                              onChange={(e) => setHardenedMaxBondingProgress(Math.min(100, Math.max(0, Number(e.target.value))))}
                              className="w-full bg-slate-950 border border-slate-850 rounded px-2 py-1 text-[10px] font-mono text-white mt-1 h-7"
                              placeholder="100"
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <span className="text-[8px] font-bold text-slate-400 uppercase">Min Age (min)</span>
                            <input 
                              type="number" 
                              step="1"
                              min="0"
                              value={hardenedMinAge}
                              onChange={(e) => setHardenedMinAge(Math.max(0, Number(e.target.value)))}
                              className="w-full bg-slate-950 border border-slate-850 rounded px-2 py-1 text-[10px] font-mono text-white mt-1 h-7"
                              placeholder="0"
                            />
                          </div>
                          <div>
                            <span className="text-[8px] font-bold text-slate-400 uppercase">Max Age (min)</span>
                            <input 
                              type="number" 
                              step="1"
                              min="0"
                              value={hardenedMaxAge}
                              onChange={(e) => setHardenedMaxAge(Math.max(0, Number(e.target.value)))}
                              className="w-full bg-slate-950 border border-slate-850 rounded px-2 py-1 text-[10px] font-mono text-white mt-1 h-7"
                              placeholder="120"
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <span className="text-[8px] font-bold text-slate-400 uppercase">Min Latency (ms)</span>
                            <input 
                              disabled={!enableLatencyGuard}
                              type="number" 
                              step="5"
                              min="0"
                              value={hardenedMinLatency}
                              onChange={(e) => setHardenedMinLatency(Math.max(0, Number(e.target.value)))}
                              className="w-full bg-slate-950 border border-slate-850 rounded px-2 py-1 text-[10px] font-mono text-white mt-1 h-7 disabled:opacity-50"
                              placeholder="0"
                            />
                          </div>
                          <div>
                            <span className="text-[8px] font-bold text-slate-400 uppercase flex justify-between font-mono">
                              <span>Max Latency</span>
                              {rpcLatency !== null && (
                                <span className={!enableLatencyGuard ? 'text-slate-500' : rpcLatency > hardenedMaxLatency ? 'text-red-400 font-bold' : 'text-emerald-400 font-bold'}>
                                  {rpcLatency.toFixed(0)} ms
                                </span>
                              )}
                            </span>
                            <input 
                              disabled={!enableLatencyGuard}
                              type="number" 
                              step="5"
                              min="0"
                              value={hardenedMaxLatency}
                              onChange={(e) => setHardenedMaxLatency(Math.max(0, Number(e.target.value)))}
                              className="w-full bg-slate-950 border border-slate-850 rounded px-2 py-1 text-[10px] font-mono text-white mt-1 h-7 disabled:opacity-50"
                              placeholder="250"
                            />
                          </div>
                        </div>
                        <div className="mt-2 flex items-center justify-between bg-slate-950 border border-slate-850 rounded px-2 py-1 h-7 select-none">
                          <span className="text-[8px] font-bold text-slate-400 uppercase">Latency Guard Active</span>
                          <label className="flex items-center gap-1.5 cursor-pointer">
                            <input 
                              type="checkbox" 
                              checked={enableLatencyGuard} 
                              onChange={(e) => setEnableLatencyGuard(e.target.checked)} 
                              className="rounded border-slate-800 bg-slate-950 text-[#c7f284] focus:ring-0 focus:ring-offset-0 h-3 w-3"
                            />
                            <span className="text-[9px] text-white font-mono uppercase font-bold">{enableLatencyGuard ? 'ON' : 'OFF'}</span>
                          </label>
                        </div>
                      </div>

                      {/* Section: RugCheck & Security caps */}
                      <div className="space-y-2 pt-2 border-t border-slate-850">
                        <label className="text-[8px] font-black uppercase tracking-widest text-slate-500">Security & Anti-Rug Thresholds</label>
                        <div>
                          <div className="flex justify-between items-center text-[8px] font-bold text-slate-400 uppercase">
                            <span>Max RugCheck Risk Score</span>
                            <span className="font-mono text-indigo-400">{hardenedMaxRiskScore}</span>
                          </div>
                          <input 
                            type="range" 
                            min="0" 
                            max="100" 
                            value={hardenedMaxRiskScore}
                            onChange={(e) => setHardenedMaxRiskScore(Number(e.target.value))}
                            className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500 mt-1"
                          />
                        </div>
                        <div>
                          <div className="flex justify-between items-center text-[8px] font-bold text-slate-400 uppercase">
                            <span>Max Dev Wallet Share</span>
                            <span className="font-mono text-indigo-400">{hardenedMaxDevOwnership}%</span>
                          </div>
                          <input 
                            type="range" 
                            min="0" 
                            max="100" 
                            value={hardenedMaxDevOwnership}
                            onChange={(e) => setHardenedMaxDevOwnership(Number(e.target.value))}
                            className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500 mt-1"
                          />
                        </div>
                        <div>
                          <div className="flex justify-between items-center text-[8px] font-bold text-slate-400 uppercase">
                            <span>Max Top 10 Holders Share</span>
                            <span className="font-mono text-indigo-400">{hardenedMaxTop10}%</span>
                          </div>
                          <input 
                            type="range" 
                            min="0" 
                            max="100" 
                            step="0.5"
                            value={hardenedMaxTop10}
                            onChange={(e) => setHardenedMaxTop10(Number(e.target.value))}
                            className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500 mt-1"
                          />
                        </div>
                      </div>

                      {/* Section: Momentum & Synergy Velocity */}
                      <div className="space-y-2 pt-2 border-t border-slate-850">
                        <label className="text-[8px] font-black uppercase tracking-widest text-slate-500">Momentum & Velocity Gates (30s)</label>
                        <div>
                          <span className="text-[8px] font-bold text-slate-400 uppercase">Min Unique Buyers (30s)</span>
                          <input 
                            type="number" 
                            value={hardenedMinUniqueBuyers30s}
                            onChange={(e) => setHardenedMinUniqueBuyers30s(Math.max(1, Number(e.target.value)))}
                            className="w-full bg-slate-950 border border-slate-850 rounded px-2 py-1 text-[10px] font-mono text-white mt-1 h-7"
                          />
                        </div>
                        <div>
                          <span className="text-[8px] font-bold text-slate-400 uppercase">5m Profit Momentum (%)</span>
                          <input 
                            type="number" 
                            step="0.05"
                            value={hardenedMinProfit5m}
                            onChange={(e) => setHardenedMinProfit5m(Math.max(0, Number(e.target.value)))}
                            className="w-full bg-slate-950 border border-slate-855 rounded px-2 py-1 text-[10px] font-mono text-white mt-1 h-7"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <span className="text-[8px] font-bold text-slate-400 uppercase">Min Buys (30s)</span>
                            <input 
                              type="number" 
                              value={hardenedMinBuyCount30s}
                              onChange={(e) => setHardenedMinBuyCount30s(Math.max(1, Number(e.target.value)))}
                              className="w-full bg-slate-950 border border-slate-855 rounded px-2 py-1 text-[10px] font-mono text-white mt-1 h-7"
                            />
                          </div>
                          <div>
                            <span className="text-[8px] font-bold text-slate-400 uppercase">Max Buys (30s)</span>
                            <input 
                              type="number" 
                              value={hardenedMaxBuyCount30s}
                              onChange={(e) => setHardenedMaxBuyCount30s(Math.max(1, Number(e.target.value)))}
                              className="w-full bg-slate-950 border border-slate-855 rounded px-2 py-1 text-[10px] font-mono text-white mt-1 h-7"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Section: Ratio and Spikes */}
                      <div className="space-y-2 pt-2 border-t border-slate-850">
                        <label className="text-[8px] font-black uppercase tracking-widest text-slate-500">Activity and Spike Filters</label>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <span className="text-[8px] font-bold text-slate-400 uppercase">Min VelRatio</span>
                            <input 
                              type="number" 
                              step="0.1"
                              value={hardenedMinBuySellRatio}
                              onChange={(e) => setHardenedMinBuySellRatio(Math.max(0.1, Number(e.target.value)))}
                              className="w-full bg-slate-950 border border-slate-855 rounded px-2 py-1 text-[10px] font-mono text-white mt-1 h-7"
                            />
                          </div>
                          <div>
                            <span className="text-[8px] font-bold text-slate-400 uppercase">Max VelRatio</span>
                            <input 
                              type="number" 
                              step="0.1"
                              value={hardenedMaxBuySellRatio}
                              onChange={(e) => setHardenedMaxBuySellRatio(Math.max(0.1, Number(e.target.value)))}
                              className="w-full bg-slate-950 border border-slate-855 rounded px-2 py-1 text-[10px] font-mono text-white mt-1 h-7"
                            />
                          </div>
                        </div>
                        <div>
                          <div className="flex justify-between items-center text-[8px] font-bold text-slate-400 uppercase">
                            <span>Max Price Change 1-min</span>
                            <span className="font-mono text-indigo-400">{hardenedMaxPriceChange1m}%</span>
                          </div>
                          <input 
                            type="range" 
                            min="1" 
                            max="50" 
                            value={hardenedMaxPriceChange1m}
                            onChange={(e) => setHardenedMaxPriceChange1m(Number(e.target.value))}
                            className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500 mt-1"
                          />
                        </div>
                      </div>

                      {/* Restore Defaults button */}
                      <button 
                        type="button"
                        onClick={() => {
                          applyPreset(SAFETY_PRESETS[0]);
                        }}
                        className="w-full mt-2 border border-slate-800 hover:border-slate-705 bg-slate-950/40 hover:bg-slate-900/50 text-[8px] font-black uppercase text-slate-500 hover:text-slate-300 tracking-widest py-1.5 rounded transition-all cursor-pointer"
                      >
                        Restore Defaults (Conservative)
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <div className="bg-slate-900/40 p-4 rounded-xl border border-slate-800/50 mb-6">
              <h4 className="text-[10px] font-black uppercase text-slate-500 tracking-widest mb-3">Telegram Bot Integration</h4>
              <div className="space-y-3">
                <div>
                  <input
                    type="password"
                    placeholder="Bot Token"
                    value={telegramBotToken}
                    onChange={(e) => {
                      setTelegramBotToken(e.target.value);
                      localStorage.setItem('tg_bot_token', e.target.value);
                    }}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-[10px] text-white outline-none focus:border-indigo-500 transition-colors"
                  />
                </div>
                <div>
                  <input
                    type="text"
                    placeholder="Chat ID"
                    value={telegramChatId}
                    onChange={(e) => {
                      setTelegramChatId(e.target.value);
                      localStorage.setItem('tg_chat_id', e.target.value);
                    }}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-[10px] text-white outline-none focus:border-indigo-500 transition-colors"
                  />
                </div>
                <button
                  onClick={() => sendTelegramAlert('🔔 <b>Matrix Test Alert</b>\nYour Telegram bot is successfully connected!').catch((err: any) => console.warn('Telegram test alert failed:', err))}
                  className="w-full bg-indigo-600/10 hover:bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 font-black uppercase text-[9px] tracking-widest py-2 rounded-lg transition-colors"
                >
                  Test Connection
                </button>
              </div>
            </div>
            <button 
              onClick={() => setAutoSniperEnabled(!autoSniperEnabled)}
              className={cn(
                "w-full py-3 rounded-xl text-[11px] font-black uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-2 mb-2",
                autoSniperEnabled ? "bg-rose-600 hover:bg-rose-500 shadow-[0_0_20px_rgba(225,29,72,0.3)] animate-pulse" : "bg-emerald-600 hover:bg-emerald-500 shadow-[0_0_20px_rgba(16,185,129,0.3)]"
              )}
            >
              {autoSniperEnabled ? <Activity className="w-4 h-4" /> : <Zap className="w-4 h-4" />}
              {autoSniperEnabled ? 'Deactivate Sniper' : 'Activate Sniper'}
            </button>
            <div className="w-full py-2 rounded-xl text-[10px] font-black uppercase tracking-[0.1em] transition-all flex items-center justify-center gap-2 border border-slate-800 text-slate-500 bg-slate-900/40">
              Trading Mode: Simulated
            </div>
            {tradingStatus && (
              <div className="flex items-center gap-2 justify-center py-2 bg-indigo-950/30 rounded-lg border border-indigo-900/50">
                <RefreshCw className="w-3 h-3 text-indigo-400 animate-spin" />
                <span className="text-[9px] font-bold text-indigo-300 uppercase animate-pulse">{tradingStatus}</span>
              </div>
            )}
          </div>

          <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-5 flex flex-col overflow-hidden min-h-[300px]">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <BrainCircuit className="w-4 h-4 text-indigo-400" />
                <h3 className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-500">AI Matrix</h3>
              </div>
              <button 
                onClick={analyzeTrader}
                disabled={!isMonitoring || isAnalyzing || trades.length === 0}
                className="px-3 py-1 bg-indigo-600 text-white text-[10px] font-bold rounded hover:bg-indigo-500 transition-all disabled:opacity-30 shadow-[0_4px_12px_rgba(79,70,229,0.3)] uppercase"
              >
                {isAnalyzing ? <RefreshCw className="w-3 h-3 animate-spin" /> : 'Execute'}
              </button>
            </div>

            <div className={cn(
              "p-4 rounded-xl font-mono text-[10px] lg:text-[11px] leading-relaxed border flex-1 overflow-hidden flex flex-col",
              analysis ? "bg-slate-950/50 border-slate-800 text-slate-300" : "bg-slate-900/20 border-dashed border-slate-800 text-slate-600 flex items-center justify-center text-center italic"
            )}>
              {isAnalyzing ? (
                <div className="space-y-3 w-full">
                  <div className="h-1.5 bg-slate-800 rounded-full animate-pulse w-3/4" />
                  <div className="h-1.5 bg-slate-800 rounded-full animate-pulse w-full" />
                  <div className="h-1.5 bg-slate-800 rounded-full animate-pulse w-5/6" />
                </div>
              ) : analysis ? (
                <div className="whitespace-pre-wrap arabic scrollbar-none overflow-y-auto max-h-full leading-6">
                  {analysis}
                </div>
              ) : (
                <div className="arabic text-[10px] px-2 text-center">
                  في انتظار المدخلات... اضغط "Execute" لتشغيل مصفوفة الذكاء الاصطناعي.
                </div>
              )}
            </div>
          </div>
        </section>
      </>
    ) : currentPage === 'high-buy' && alphaSubTab === 'safety' ? (
      <section className="col-span-12 flex flex-col gap-6 h-full overflow-y-auto">
        {renderAlphaHeader()}
        <SafetyPage tokenMetrics={tokenMetrics} />
      </section>
    ) : currentPage === 'high-buy' && alphaSubTab === 'prediction' ? (
      <section className="col-span-12 flex flex-col gap-6 h-full overflow-y-auto">
        {renderAlphaHeader()}
        <PredictionPage tokenMetrics={tokenMetrics} />
      </section>
    ) : currentPage === 'high-buy' && alphaSubTab === 'high-buy' ? (
      <section className="col-span-12 flex flex-col gap-6 h-full overflow-hidden">
        {renderAlphaHeader()}
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between px-2 gap-4">
          <div>
            <h2 className="text-xl lg:text-3xl font-black text-white uppercase tracking-tighter flex items-center gap-3">
              <Zap className="w-8 h-8 text-indigo-500 bg-indigo-500/10 p-1 rounded-lg" />
              High Capacity Whales
            </h2>
            <p className="text-[10px] text-slate-500 uppercase tracking-widest mt-1">
              Whale Entry Mode: Large Buy Pressure • Multi-Wallet Accumulation
            </p>
          </div>
          
          <div className="flex flex-wrap items-center gap-2">
            {(['ALL', 'AI', 'AI_MEME', 'POLITIFI', 'MEME', 'GAMEFI', 'DEPIN', 'RWA', 'DEFI'] as const).map((sector) => (
              <button
                key={sector}
                onClick={() => setSectorFilter(sector)}
                className={cn(
                  "px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all border",
                  sectorFilter === sector 
                    ? "bg-indigo-600 border-indigo-500 text-white shadow-[0_0_15px_rgba(79,70,229,0.4)]" 
                    : "bg-slate-900 border-slate-800 text-slate-500 hover:text-slate-300 hover:border-slate-700"
                )}
              >
                {sector.replace('_', ' ')}
              </button>
            ))}
          </div>

          <div className="hidden lg:flex items-center gap-6">
            <div className="flex flex-col items-end">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Global Telemetry Stream</span>
              <span className="text-xs font-mono text-indigo-400 font-black animate-pulse">LATENCY: 1ms</span>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center">
              <Zap className="w-6 h-6 text-indigo-400 fill-indigo-400" />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 overflow-y-auto pr-2 pb-12 scrollbar-none">
          {(Object.values(tokenMetrics) as TokenMetric[])
            .filter(m => {
              // Applied sector filter
              if (sectorFilter !== 'ALL' && m.category !== sectorFilter) return false;

              // Strict page-level filters
              const now = Date.now();
              const ageMs = now - (m.discoveredAt || now);
              
              // 1. Core Entry Criteria & Liquidity Floor
              const agePass = ageMs >= 1800000; // 30m
              const volPass = (m.volume24h || 0) >= 150000;
              const liqPass = (m.liquidity || 0) >= 50000;
              const mc = m.marketCap || 0;
              const mcPass = mc >= 150000 && mc <= 2500000;
              
              let bondingProgressPass = true;
              if (mc < 100000 && m.bondingCurveProgress !== undefined) {
                 bondingProgressPass = m.bondingCurveProgress >= 80 && m.bondingCurveProgress <= 98;
              }

              // 2. Market Momentum & "Sprinting" Triggers
              const buyCount = m.buyCount || 0;
              const sellCount = m.sellCount || 0;
              const buySellRatio = buyCount / Math.max(1, sellCount);
              
              const conditionA = (buyCount / 5) > 1.0; 
              const conditionB = (m.percentageIncrease || 0) >= 20 && (m.percentageIncrease || 0) <= 50;
              
              const buy30sCount = (m.recentBuysTimeline || []).filter((t: any) => t && t.t && (now - t.t < 30000)).length;
              const conditionCSprinting = buy30sCount > 8; 
              const conditionCMetrics = buySellRatio >= 1.5 && buyCount >= 2;
              const conditionC = conditionCSprinting && conditionCMetrics;

              const momentumPass = conditionA || conditionB || conditionC;

              // 3. Security
              const securityPass = m.mintAuthorityRevoked && 
                                   m.freezeAuthorityRevoked && 
                                   m.liquidityBurned && 
                                   (m.top10Percentage || 100) <= 15 &&
                                   m.isRugSafe === true;

              return agePass && volPass && liqPass && mcPass && bondingProgressPass && momentumPass && securityPass;
            })
          .sort((a, b) => {
            // Priority sorting for 100x: Absolute Newest + Momentum
            if (alphaProtocol === 'GEMS_100X') {
              const getNarrativeScore = (metric: TokenMetric) => {
                let score = 0;
                const symbol = (metric.symbol || '').toUpperCase();
                if (NARRATIVE_KEYWORDS.some(key => symbol.includes(key))) score += 50;
                if (metric.category === 'AI' || metric.category === 'AI_MEME') score += 30;
                return score;
              };

              const scoreA = getNarrativeScore(a);
              const scoreB = getNarrativeScore(b);
              
              if (scoreB !== scoreA) return scoreB - scoreA;

              // If narrative score is same, show newer
              const aTime = savedGems[a.address]?.savedAt || a.discoveredAt || 0;
              const bTime = savedGems[b.address]?.savedAt || b.discoveredAt || 0;
              if (Math.abs(bTime - aTime) > 300000) {
                return bTime - aTime;
              }
              
              const a30sCount = (a.recentBuysTimeline || []).filter((t: any) => t && t.t && (Date.now() - t.t < 30000)).length;
              const b30sCount = (b.recentBuysTimeline || []).filter((t: any) => t && t.t && (Date.now() - t.t < 30000)).length;
              
              if (b30sCount !== a30sCount) return b30sCount - a30sCount;
              return (a.marketCap || 999999999) - (b.marketCap || 999999999);
            }

            // In sniper mode, sort by buy velocity first
            if (alphaProtocol === 'SNIPER') {
              const a30sCount = (a.recentBuysTimeline || []).filter((t: any) => t && t.t && (Date.now() - t.t < 30000)).length;
              const b30sCount = (b.recentBuysTimeline || []).filter((t: any) => t && t.t && (Date.now() - t.t < 30000)).length;
              if (b30sCount !== a30sCount) return b30sCount - a30sCount;
            }

            const aRatio = (a.buyCount || 0) / (a.sellCount || 1);
            const bRatio = (b.buyCount || 0) / (b.sellCount || 1);
            if (Math.abs(bRatio - aRatio) > 0.5) return bRatio - aRatio;

            const a30s = (a.recentBuysTimeline || []).filter((t: any) => t && t.t && (Date.now() - t.t < 30000)).reduce((acc, curr) => acc + (curr.a || 0), 0);
            const b30s = (b.recentBuysTimeline || []).filter((t: any) => t && t.t && (Date.now() - t.t < 30000)).reduce((acc, curr) => acc + (curr.a || 0), 0);
            if (b30s !== a30s) return b30s - a30s;
            return (b.whaleEntranceTime || b.lastUpdated || 0) - (a.whaleEntranceTime || a.lastUpdated || 0);
          })
            .slice(0, 30).map((metric) => {
              const last30sVol = (metric.recentBuysTimeline || []).filter((t: any) => t && t.t && (Date.now() - t.t < 30000)).reduce((acc, curr) => acc + (curr.a || 0), 0);
              const isHeated = last30sVol > 50000;

              return (
              <motion.div
                key={metric.address}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className={cn(
                  "relative group bg-slate-900/40 border rounded-3xl p-6 transition-all hover:bg-slate-900/60",
                  isHeated ? "border-emerald-500/40 shadow-[0_0_40px_rgba(16,185,129,0.1)]" :
                  metric.latestAlert === 'WHALE_BUY' 
                    ? "border-indigo-500/40 shadow-[0_0_40px_rgba(99,102,241,0.1)]" 
                    : "border-amber-500/30 shadow-[0_0_30px_rgba(245,158,11,0.05)]"
                )}
              >
                <div className="absolute top-4 right-4 flex gap-2">
                   {isHeated && (
                     <div className="px-2 py-1 bg-emerald-500 text-white text-[7px] font-black uppercase rounded-lg animate-bounce">
                       30s Momentum
                     </div>
                   )}
                   <div className={cn(
                     "px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest animate-pulse border",
                     metric.latestAlert === 'WHALE_BUY' ? "bg-indigo-500/20 text-indigo-400 border-indigo-500/30" : "bg-amber-500/20 text-amber-400 border-amber-500/30"
                   )}>
                     {metric.latestAlert?.replace('_', ' ')}
                   </div>
                   {alphaProtocol === 'GEMS_100X' && (
                     <div className="px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 animate-pulse">
                       SWING POTENTIAL
                     </div>
                   )}
                   {(() => {
                     const timestamp = metric.pairCreatedAt ? normalizeTimestamp(metric.pairCreatedAt) : (metric.discoveredAt || Date.now());
                     const age = Date.now() - timestamp;
                     if (age < 600000) {
                       return (
                         <div className="px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest bg-amber-500/20 text-amber-400 border border-amber-500/30 animate-pulse">
                           JUST LAUNCHED
                         </div>
                       );
                     }
                     return null;
                   })()}
                   {metric.category && (
                     <div className={cn(
                       "px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border",
                       metric.category === 'AI' ? "bg-purple-500/20 text-purple-400 border-purple-500/30" : 
                       metric.category === 'MEME' ? "bg-blue-500/20 text-blue-400 border-blue-500/30" :
                       metric.category === 'GAMEFI' ? "bg-amber-500/20 text-amber-400 border-amber-500/30" :
                       metric.category === 'DEPIN' ? "bg-cyan-500/20 text-cyan-400 border-cyan-500/30" :
                       metric.category === 'RWA' ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/30" :
                       "bg-slate-800 text-slate-300 border-slate-700"
                     )}>
                       {metric.category}
                     </div>
                   )}
                </div>

                <div className="flex items-center gap-4 mb-6">
                  <div className={cn(
                    "w-16 h-16 rounded-2xl flex items-center justify-center font-black text-2xl shadow-2xl transition-all",
                    metric.latestAlert === 'WHALE_BUY' ? "bg-indigo-600 text-white" : "bg-emerald-600 text-white"
                  )}>
                    {metric.symbol?.slice(0, 3) || 'TKN'}
                  </div>
                  <div>
                    <h3 className="text-xl font-black text-white uppercase leading-none mb-1">{metric.symbol || 'Unknown Token'}</h3>
                    <div className="flex items-center gap-2">
                       <span className="text-[10px] font-mono text-slate-500">{metric.address?.slice(0, 12)}...</span>
                       <button onClick={() => copyToClipboard(metric.address, metric.address)} className="text-slate-600 hover:text-white transition-colors">
                         <Copy className="w-3 h-3" />
                       </button>
                    </div>
                  </div>
                </div>

                <div className="space-y-4 mb-6">
                  <div className="flex justify-between items-center border-b border-white/5 pb-2">
                    <div className="flex flex-col">
                      <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest leading-tight">30s Volume Influx</span>
                      <span className="text-[8px] text-emerald-400 font-bold uppercase tracking-widest">High Profit Signal</span>
                    </div>
                    <span className={cn(
                      "text-xl font-black transition-all",
                      last30sVol > 0 ? "text-emerald-400" : "text-white"
                    )}>${(last30sVol * 145).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-end border-b border-white/5 pb-2">
                    <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Buy Velocity</span>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-emerald-400">+{metric.buyCount} Buys (5m)</span>
                      {metric.buyCount > (metric.prevBuyCount || 0) && (
                        <div className="bg-emerald-500/20 text-emerald-400 text-[8px] font-black px-1.5 py-0.5 rounded animate-bounce">
                          INCREASING
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex justify-between items-end border-b border-white/5 pb-2">
                    <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Holders Monitor</span>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-indigo-400">{metric.holderCount?.toLocaleString() || '---'}</span>
                      {(metric.holdersPerMin || 0) > 5 && (
                        <div className="bg-indigo-500/20 text-indigo-400 text-[8px] font-black px-1.5 py-0.5 rounded animate-pulse">
                          FAST GROWTH
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex justify-between items-end border-b border-white/5 pb-2">
                    <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Total Entry Vol</span>
                    <span className="text-sm font-black text-white">${(metric.buyVolume * 145).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-end border-b border-white/5 pb-2">
                    <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Token Age</span>
                    <span className="text-sm font-bold text-amber-400">
                      {formatAge(metric.pairCreatedAt, metric.discoveredAt)}
                    </span>
                  </div>

                  {/* Social Intelligence HUD */}
                  <div className="bg-slate-950/50 rounded-2xl p-3 border border-white/5 space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Attention Index</span>
                      <div className="flex items-center gap-1">
                        <Users className="w-2.5 h-2.5 text-indigo-400" />
                        <span className="text-[10px] font-bold text-white">+{Math.floor(metric.socialMentionsGrowth || 0)}% Mentions</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Sentiment Profile</span>
                      <div className="flex items-center gap-1">
                        <div className="w-12 h-1 bg-slate-800 rounded-full overflow-hidden">
                          <div className="h-full bg-indigo-500" style={{ width: `${metric.socialSentiment || 50}%` }} />
                        </div>
                        <span className={cn(
                          "text-[9px] font-bold",
                          (metric.socialSentiment || 50) > 70 ? "text-emerald-400" : "text-white"
                        )}>{Math.floor(metric.socialSentiment || 50)}/100</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Bot Risk Analysis</span>
                      <span className={cn(
                        "text-[9px] font-bold uppercase",
                        metric.botRisk === 'LOW' ? "text-emerald-400" : 
                        metric.botRisk === 'MEDIUM' ? "text-amber-400" : "text-rose-400"
                      )}>{metric.botRisk || 'CHECKING...'}</span>
                    </div>
                    {metric.isAiAgentControlled && (
                      <div className="flex items-center gap-2 pt-1 border-t border-white/5">
                        <div className="w-2 h-2 bg-pink-500 rounded-full animate-pulse shadow-[0_0_5px_rgba(236,72,153,1)]" />
                        <span className="text-[8px] font-black text-pink-400 uppercase tracking-widest">AI Agent Controlled</span>
                      </div>
                    )}
                  </div>

                  { (alphaProtocol === 'GEMS_100X') && (
                    <div className="bg-slate-950/80 rounded-2xl p-4 border border-emerald-500/30 space-y-3 shadow-[0_0_15px_rgba(16,185,129,0.1)] mb-4">
                      <div className="flex items-center justify-between border-b border-white/5 pb-2">
                        <div className="flex items-center gap-2">
                          <BrainCircuit className="w-4 h-4 text-emerald-400" />
                          <span className="text-[10px] font-black text-white uppercase tracking-tighter">Matrix 100x Analysis</span>
                        </div>
                        <span className="text-[8px] font-black text-emerald-400 uppercase bg-emerald-500/10 px-1.5 py-0.5 rounded">Early Entry</span>
                      </div>
                      <div className="grid grid-cols-2 gap-x-4 gap-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-[8px] font-bold text-slate-500 uppercase">Security</span>
                          <span className="text-[8px] font-black text-emerald-400 uppercase">VERIFIED</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-[8px] font-bold text-slate-500 uppercase">Velocity</span>
                          <span className="text-[8px] font-black text-emerald-400 uppercase">{( (metric.volume24h || 0) / (metric.marketCap || 1) ).toFixed(1)}x</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-[8px] font-bold text-slate-500 uppercase">Liq/MC Ratio</span>
                          <span className="text-[8px] font-black text-emerald-400 uppercase">{Math.floor(metric.liquidityRatio || 0)}%</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-[8px] font-bold text-slate-500 uppercase">Holder Growth</span>
                          <span className="text-[8px] font-black text-emerald-400 uppercase">+{Math.floor(metric.holderGrowthHr || 0)}%/hr</span>
                        </div>
                        <div className="flex items-center justify-between col-span-2 pt-1 border-t border-white/5">
                          <span className="text-[8px] font-bold text-slate-500 uppercase">Tokens / $1 USD</span>
                          <span className="text-[8px] font-black text-emerald-400 uppercase text-right">
                            {Math.floor((metric.priceUsd || 0) > 0 ? (1 / metric.priceUsd!) : 0).toLocaleString()}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between pt-1">
                        <span className="text-[8px] font-bold text-slate-500 uppercase">Age</span>
                        <span className="text-[8px] font-black text-white uppercase">
                          {Math.floor((Date.now() - (metric.discoveredAt || 0)) / 3600000)}H {Math.floor(((Date.now() - (metric.discoveredAt || 0)) % 3600000) / 60000)}M
                        </span>
                      </div>
                      {NARRATIVE_KEYWORDS.some(key => (metric.symbol || '').toUpperCase().includes(key)) && (
                        <div className="pt-2 border-t border-white/5 flex items-center justify-between">
                          <span className="text-[8px] font-bold text-emerald-400 uppercase animate-pulse">Narrative Alpha Match</span>
                          <span className="text-[8px] font-black text-emerald-400 uppercase">+50% BOOST</span>
                        </div>
                      )}
                      {((metric.volume24h || 0) / (metric.marketCap || 1)) > 4.0 && (
                        <div className="pt-2 border-t border-rose-500/30 flex items-center justify-between">
                          <span className="text-[8px] font-bold text-rose-400 uppercase animate-bounce">Pulse Alpha Alert</span>
                          <span className="text-[8px] font-black text-rose-400 uppercase">VOL &gt; 4.0x</span>
                        </div>
                      )}
                    </div>
                  )}

                  <div className="flex justify-between items-end">
                    <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Market Status</span>
                    <div className="flex items-center gap-2">
                      {metric.isRugSafe ? (
                        <span className="text-[9px] font-black text-emerald-400 uppercase bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 flex items-center gap-1">
                          <Check className="w-3 h-3" /> RUG-SAFE
                        </span>
                      ) : (
                        <span className="text-[9px] font-black text-rose-400 uppercase bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20">
                          {metric.liquidity ? 'HIGH RISK' : 'SCANNING...'}
                        </span>
                      )}
                    </div>
                  </div>

                  {savedGems[metric.address] && (
                    <div className="mt-4 pt-4 border-t border-indigo-500/20 bg-indigo-500/5 -mx-6 px-6 py-3 space-y-1">
                      <div className="flex justify-between items-center text-[9px] font-black uppercase text-indigo-400/60 tracking-widest">
                        <span>Save Snapshot</span>
                        <span>{new Date(savedGems[metric.address].savedAt).toLocaleDateString()}</span>
                      </div>
                      <div className="flex justify-between items-end">
                        <span className="text-[10px] font-black text-white uppercase tracking-widest">$1 Invested =</span>
                        <span className="text-xs font-black text-emerald-400">
                          {savedGems[metric.address].tokensPerDollarAtSave.toLocaleString(undefined, { maximumFractionDigits: 0 })} Tokens
                        </span>
                      </div>
                      <div className="flex justify-between items-end">
                        <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Perf Since Save</span>
                        <span className={cn(
                          "text-xs font-black",
                          ((metric.priceUsd || 0) - savedGems[metric.address].priceAtSave) / savedGems[metric.address].priceAtSave >= 0 ? "text-emerald-400" : "text-rose-400"
                        )}>
                          {(((metric.priceUsd || 0) - savedGems[metric.address].priceAtSave) / (savedGems[metric.address].priceAtSave || 1) * 100).toFixed(2)}%
                        </span>
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex gap-2">
                  <button 
                    onClick={() => {
                      if (alphaProtocol === 'GEMS_100X') {
                        window.open(`https://dexscreener.com/solana/${metric.address}`, '_blank');
                      } else {
                        window.open(`https://dexscreener.com/solana/${metric.address}`, '_blank');
                      }
                    }}
                    className={cn(
                      "flex-1 border rounded-xl py-3 text-[10px] font-black uppercase tracking-widest transition-all active:scale-95 flex items-center justify-center gap-2",
                      alphaProtocol === 'GEMS_100X' 
                        ? "bg-emerald-600/10 border-emerald-500/30 text-emerald-400 hover:bg-emerald-600/20" 
                        : "bg-white/5 border-white/10 text-white hover:bg-white/10"
                    )}
                  >
                    {alphaProtocol === 'GEMS_100X' ? <Zap className="w-3 h-3" /> : <TrendingUp className="w-3 h-3" />}
                    {alphaProtocol === 'GEMS_100X' ? 'Snipe Charts' : 'View Chart'}
                  </button>
                  <button 
                    onClick={() => toggleSaveGem(metric)}
                    className={cn(
                      "w-12 border rounded-xl flex items-center justify-center transition-all active:scale-90",
                      savedGems[metric.address] 
                        ? "bg-emerald-500 border-emerald-400 text-white shadow-[0_0_15px_rgba(16,185,129,0.3)]" 
                        : "bg-slate-950 border-slate-800 text-slate-500 hover:text-emerald-400"
                    )}
                    title={savedGems[metric.address] ? "Saved for Tracking" : "Save for Tracking"}
                  >
                    <Bookmark className={cn("w-4 h-4", savedGems[metric.address] && "fill-current")} />
                  </button>
                  <button 
                    onClick={() => window.open(`https://bubblemaps.io/solana/token/${metric.address}`, '_blank')}
                    className="w-12 bg-slate-950 border border-slate-800 rounded-xl flex items-center justify-center text-slate-500 hover:text-indigo-400 transition-all active:scale-90"
                    title="Check Bubblemaps"
                  >
                    <Scan className="w-4 h-4" />
                  </button>
                </div>
              </motion.div>
            )})}
          
          {((Object.values(tokenMetrics) as TokenMetric[]).filter(m => {
            if (!m) return false;
            if (sectorFilter !== 'ALL' && m.category !== sectorFilter) return false;
            
            return m.latestAlert === 'WHALE_BUY' || m.latestAlert === 'HIGH_BUY';
          })).length === 0 && (
            <div className="col-span-full h-80 flex flex-col items-center justify-center text-center opacity-20 py-20 grayscale">
              <div className="relative mb-6">
                <Activity className="w-16 h-16 text-slate-500" />
                <div className="absolute inset-0 border-2 border-slate-700 animate-ping rounded-full" />
              </div>
              <h3 className="text-xl font-black uppercase tracking-tighter">
                {sectorFilter !== 'ALL' ? `Searching AI-Driven ${sectorFilter} Streams` : 'Searching Deep Streams'}
              </h3>
              <p className="text-xs uppercase tracking-widest font-mono">
                {sectorFilter !== 'ALL' ? `No ${sectorFilter} signals detected in current timeframe` :
                 currentPage === 'high-buy' ? 'Scanning for massive buy volume...' : 
                 currentPage === 'discovery' ? 'Filtering for safe new discovery tokens...' : 
                 'Hunting for low-cap moonshots...'}
              </p>
            </div>
          )}
        </div>
      </section>
    ) : null}
    <section className={cn("col-span-12 flex-col h-full overflow-hidden", currentPage === 'portfolio' ? "flex" : "hidden")}>
      <PnLPage 
        tokenMetrics={tokenMetrics} 
        telemetryAlerts={telemetryAlerts}
        user={user}
        externalSettings={{
          setCurrentPage,
          manualGemInput, setManualGemInput,
          buyAmountSol, setBuyAmountSol,
          minTakeProfit, setMinTakeProfit,
          maxTakeProfit, setMaxTakeProfit,
          bondingCurveTakeProfit, setBondingCurveTakeProfit,
          stopLoss, setStopLoss,
          bondingCurveStopLoss, setBondingCurveStopLoss,
          pumpSwapStopLoss, setPumpSwapStopLoss,
          unknownStopLoss, setUnknownStopLoss,
          maxPositions, setMaxPositions,
          slippage, setSlippage,
          hardenedMinBondingProgress,
          setHardenedMinBondingProgress,
          hardenedMaxBondingProgress,
          setHardenedMaxBondingProgress,
          hardenedMinAge,
          setHardenedMinAge,
          hardenedMaxAge,
          setHardenedMaxAge,
          hardenedMinLatency,
          setHardenedMinLatency,
          hardenedMaxLatency,
          setHardenedMaxLatency,
          hardenedMatchRequirement,
          setHardenedMatchRequirement,
          rpcLatency,
          rpcUrl,
          setRpcUrl,
          rpcUrl2,
          setRpcUrl2,
          masterMonitorRpc,
          setMasterMonitorRpc,
          masterMonitorRpc2,
          setMasterMonitorRpc2,
          masterMonitorWs,
          setMasterMonitorWs,
          isSecondaryActive,
          setIsSecondaryActive,
          customWsUrl,
          setCustomWsUrl,
          hardenedMcapMinPump,
          setHardenedMcapMinPump,
          hardenedMcapMinRaydium,
          setHardenedMcapMinRaydium,
          hardenedMcapMax,
          setHardenedMcapMax,
          hardenedLiquidityMin,
          setHardenedLiquidityMin,
          hardenedLiquidityRatio,
          setHardenedLiquidityRatio,
          hardenedMaxRiskScore,
          setHardenedMaxRiskScore,
          hardenedMaxDevOwnership,
          setHardenedMaxDevOwnership,
          hardenedMaxTop10,
          setHardenedMaxTop10,
          hardenedMinUniqueBuyers30s,
          setHardenedMinUniqueBuyers30s,
          hardenedMinBuyCount30s,
          setHardenedMinBuyCount30s,
          hardenedMaxBuyCount30s,
          setHardenedMaxBuyCount30s,
          hardenedMinBuySellRatio,
          setHardenedMinBuySellRatio,
          hardenedMaxBuySellRatio,
          setHardenedMaxBuySellRatio,
          hardenedMaxPriceChange1m,
          setHardenedMaxPriceChange1m,
          tradePumpFun,
          setTradePumpFun,
          tradeRaydium,
          setTradeRaydium,
          tradeBonding,
          setTradeBonding,
          tradeUnknown,
          setTradeUnknown,
          hardenedMinProfit5m,
          setHardenedMinProfit5m,
          enableLatencyGuard,
          setEnableLatencyGuard,
          telemetryWhaleBuyMin,
          setTelemetryWhaleBuyMin,
          telemetryHighBuyMin,
          setTelemetryHighBuyMin,
          telemetryVolumeSpikeMin,
          setTelemetryVolumeSpikeMin,
          telemetryAllowWhaleBuy,
          setTelemetryAllowWhaleBuy,
          telemetryAllowHighBuy,
          setTelemetryAllowHighBuy,
          telemetryAllowVolumeSpike,
          setTelemetryAllowVolumeSpike,
          telemetryAllowMigrated,
          setTelemetryAllowMigrated,
          telemetryAllowGoldenCross,
          setTelemetryAllowGoldenCross,
          maxRebuyTimes,
          setMaxRebuyTimes,
          tradeOnlyOnce,
          setTradeOnlyOnce,
          apiKey,
          setApiKey,
          jupiterRpcUrl,
          setJupiterRpcUrl,
          privateKey,
          setPrivateKey,
        }}

      />
    </section>
    <section className={cn("col-span-12 flex-col h-full overflow-auto", currentPage === 'system-check' ? "flex" : "hidden")}>
      <SystemCheckPage rpcUrl={rpcUrl} />
    </section>
    {currentPage === 'high-buy' && alphaSubTab === 'intel' ? (
      <section className="col-span-12 flex flex-col gap-6 lg:overflow-hidden">
        {renderAlphaHeader()}
        <div className="flex flex-col gap-6 flex-1 lg:overflow-hidden">
          {/* Market Signal Summary Bar (Optional ticker style) */}
          {telemetryAlerts.length > 0 && (
            <div className="bg-indigo-500/10 border border-indigo-500/20 rounded-xl px-4 py-2 flex items-center overflow-hidden">
              <div className="flex items-center gap-2 mr-6 shrink-0">
                <Activity className="w-3.5 h-3.5 text-indigo-400" />
                <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Live Signals:</span>
              </div>
              <div className="flex gap-8 animate-marquee whitespace-nowrap">
                {telemetryAlerts.map(alert => (
                  <button 
                    key={alert.id} 
                    onClick={() => copyToClipboard(alert.address, alert.id)}
                    className={cn(
                      "text-[10px] font-medium transition-all active:scale-95 group relative flex items-center gap-1",
                      alert.type === 'WHALE_BUY' || alert.type === 'HIGH_BUY' ? "text-indigo-300 scale-110 origin-left" : 
                      alert.type === 'GOLDEN_CROSS' ? "text-amber-300" :
                      alert.type === 'VOLUME_SPIKE' ? "text-emerald-300" : "text-slate-300"
                    )}
                  >
                    <span className={cn(
                      "font-black mr-1",
                      alert.type === 'VOLUME_SPIKE' ? "text-emerald-400" : 
                      alert.type === 'WHALE_BUY' ? "text-indigo-400 underline decoration-indigo-400/30" : 
                      alert.type === 'HIGH_BUY' ? "text-amber-400" :
                      alert.type === 'GOLDEN_CROSS' ? "text-amber-500" :
                      alert.type === 'TRENDING' ? "text-rose-400 animate-pulse" :
                      "text-indigo-400"
                    )}>[{alert.type.replace('_', ' ')}]</span>
                    {alert.message}
                    {copiedId === alert.id && (
                      <span className="absolute -top-6 left-1/2 -translate-x-1/2 bg-emerald-500 text-slate-950 px-2 py-0.5 rounded text-[8px] font-bold animate-bounce whitespace-nowrap">
                        COPIED
                      </span>
                    )}
                    <Copy className="w-2.5 h-2.5 opacity-0 group-hover:opacity-100 transition-opacity ml-1 text-indigo-400" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Main Table Container */}
          <div className="flex flex-col gap-4 lg:overflow-hidden flex-1">
            <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between px-2 gap-4">
              <div className="flex flex-col">
                <h2 className="text-xl lg:text-2xl font-black text-white uppercase tracking-tighter flex items-center gap-3">
                  <Zap className="w-6 h-6 text-indigo-500 fill-indigo-500" />
                  Arina X-Ray Alpha
                </h2>
                <p className="text-[10px] text-slate-500 uppercase tracking-widest mt-1">Alpha Mode: 60%+ Gains • 2+ Buys • $8k+ Liq</p>
              </div>
                  <div className="bg-indigo-500/10 border border-indigo-500/20 px-4 py-2 rounded-xl flex items-center gap-4">
                <button 
                  onClick={() => {
                    // Logic for manual BIT TEST
                    setTelemetryBits(Array(12).fill(true));
                    setTimeout(() => setTelemetryBits(Array(12).fill(false)), 200);
                    setTimeout(() => setTelemetryBits(Array(12).fill(true)), 400);
                    setTimeout(() => setTelemetryBits(Array(12).fill(false)), 600);
                    
                    setTelemetryAlerts(prev => [
                      {
                        id: `test-${Date.now()}`,
                        type: 'TRENDING',
                        token: 'SYSTEM',
                        address: 'TEST_ADDRESS',
                        message: 'TELEMETRY BIT TEST: SYSTEM NOMINAL',
                        timestamp: Date.now()
                      },
                      ...prev.slice(0, 19)
                    ]);
                  }}
                  className="text-[8px] font-black bg-indigo-500/20 hover:bg-indigo-500/40 text-indigo-400 px-2 py-1 rounded border border-indigo-500/30 transition-all active:scale-90"
                >
                  RUN BIT TEST
                </button>
                <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse" />
                <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest flex items-center gap-2">
                  <Activity className="w-3 h-3 text-indigo-400" />
                  WSS Telemetry Active
                  <div className="flex items-center gap-0.5 ml-1">
                    {telemetryBits.map((bit, idx) => (
                      <div 
                        key={idx} 
                        className={cn(
                          "w-1 h-1 rounded-full transition-all duration-75",
                          bit ? "bg-indigo-400 scale-125 shadow-[0_0_5px_rgba(129,140,248,0.8)]" : "bg-slate-800"
                        )} 
                      />
                    ))}
                  </div>
                  <span className="text-[9px] text-slate-600 ml-2 font-mono tabular-nums">
                    {Math.floor(Math.random() * 5 + 1)}ms
                  </span>
                </span>
              </div>
            </div>

            <div className="bg-slate-900/30 border border-slate-800/60 rounded-3xl backdrop-blur-xl overflow-hidden flex flex-col flex-1 shadow-2xl min-h-0">
              {/* Desktop Table View */}
              <div className="hidden lg:block overflow-x-auto overflow-y-auto scrollbar-none flex-1">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b border-slate-800 text-left sticky top-0 bg-slate-950/80 backdrop-blur-md z-10">
                      <th className="p-6 text-[10px] font-black text-slate-500 uppercase tracking-widest">Token Info</th>
                      <th className="p-6 text-[10px] font-black text-slate-500 uppercase tracking-widest text-center">Score</th>
                      <th className="p-6 text-[10px] font-black text-slate-500 uppercase tracking-widest text-center">Liquidity</th>
                      <th className="p-6 text-[10px] font-black text-slate-500 uppercase tracking-widest text-center">Holders</th>
                      <th className="p-6 text-[10px] font-black text-slate-500 uppercase tracking-widest text-center">Safety</th>
                      <th className="p-6 text-[10px] font-black text-slate-500 uppercase tracking-widest text-center">Velocity</th>
                      <th className="p-6 text-[10px] font-black text-slate-500 uppercase tracking-widest text-right">Growth (5m)</th>
                      <th className="p-6 text-[10px] font-black text-slate-500 uppercase tracking-widest text-right">Last Alert</th>
                      <th className="p-6 text-[10px] font-black text-slate-500 uppercase tracking-widest text-center italic">Flash Sniper</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(Object.values(tokenMetrics || {}) as TokenMetric[])
                      .filter(m => {
                        if (!m || !m.address) return false;
                        const buy30s = (m.recentBuysTimeline || []).filter((t: any) => t && Date.now() - t.t < 30000).length;
                        
                        const saved = savedGems ? savedGems[m.address] : undefined;
                        if (saved) {
                          const currentPrice = m.priceUsd || (m.marketCap && m.supply ? m.marketCap / m.supply : 0);
                          const gain = (saved.priceAtSave > 0 && currentPrice > 0) ? ((currentPrice / saved.priceAtSave) - 1) * 100 : 0;
                          if (gain < 0) return false;
                        }

                        if (alphaProtocol === 'GEMS_100X') {
                          const mc = m.marketCap || 0; 
                          const vol = m.volume24h || 0; 
                          const liq = m.liquidity || 0; 
                          const isMcValid = mc >= 0; 
                          const isVolValid = vol >= 0; 
                          const isLiqValid = liq >= 0;
                          const buySellRatio = (m.buyCount || 0) / (m.sellCount || 1); 
                          const hasHolders = (m.holderCount || 0) >= 0;
                          const safeDev = true;
                          const hasVelocity = true;
                          return isMcValid && isVolValid && isLiqValid && buySellRatio >= 0 && hasHolders && safeDev && m.isRugSafe !== false && hasVelocity;
                        }

                        if (alphaProtocol === 'MIGRATED') {
                          return m.latestAlert === 'MIGRATED' || (m.bondingCurveProgress || 0) >= 99.5 || !(m.address && m.address.toLowerCase().endsWith('pump'));
                        }

                        const baseFilter = (m.buyCount || 0) >= 2;
                        if (!baseFilter) return false;

                        const isBuyingMore = (m.buyCount || 0) > (m.sellCount || 0);
                        if (!isBuyingMore) return false;
                        
                        if (alphaProtocol === 'SNIPER') {
                          return (m.percentageIncrease || 0) >= 15 && (buy30s >= 2 || ((m.buyCount || 0) / (m.sellCount || 1)) >= 3);
                        }
                        if (alphaProtocol === 'HIGH_PROFIT') return (m.percentageIncrease || 0) >= 60 && m.isRugSafe !== false && (((m.volume24h || 0) / (m.marketCap || 1)) >= 1.0);
                        if (alphaProtocol === 'WHALE_BUY') return m.latestAlert === 'WHALE_BUY' || m.latestAlert === 'HIGH_BUY';
                        if (alphaProtocol === 'NEW_DISCOVERY') return (Date.now() - (m.discoveredAt || Date.now())) < 300000;
                        if (alphaProtocol === 'ALL') return (m.percentageIncrease || 0) >= 40;
                        return true;
                      })
                      .sort((a, b) => {
                        if (!a || !b) return 0;
                        if (alphaProtocol === 'SNIPER' || alphaProtocol === 'GEMS_100X') {
                          const a30sCount = (a.recentBuysTimeline || []).filter((t: any) => t && Date.now() - t.t < 30000).length;
                          const b30sCount = (b.recentBuysTimeline || []).filter((t: any) => t && Date.now() - t.t < 30000).length;
                          
                          if (alphaProtocol === 'GEMS_100X') {
                            if (b30sCount !== a30sCount) return b30sCount - a30sCount;
                            return (a.marketCap || 999999999) - (b.marketCap || 999999999);
                          }
                          
                          if (b30sCount !== a30sCount) return b30sCount - a30sCount;
                        }
                        const bRatio = (b.buyCount || 0) / (b.sellCount || 1);
                        const aRatio = (a.buyCount || 0) / (a.sellCount || 1);
                        if (Math.abs(bRatio - aRatio) > 0.5) return bRatio - aRatio;
                        return (b.discoveredAt || 0) - (a.discoveredAt || 0);
                      })
                      .slice(0, 30).map((metric: TokenMetric) => {
                        if (!metric || !metric.address) return null;
                        const buyFreq30s = (metric.recentBuysTimeline || []).filter((t: any) => t && Date.now() - t.t < 30000).length;
                        const isSprinting = buyFreq30s > 8;
                        const alphaScore = Math.min(100, Math.floor(
                          (((metric.liquidity || 0) / 8000) * 30) + 
                          (((metric.volume24h || 0) / 20000) * 30) + 
                          (((metric.holderCount || 0) / 100) * 20) +
                          (buyFreq30s * 2)
                        ));
                        const symbol = metric.symbol || 'UNK';
                        const address = metric.address;
                        const buyCount = metric.buyCount || 0;
                        const sellCount = metric.sellCount || 0;
                        const pctInc = metric.percentageIncrease || 0;

                        return (
                        <tr 
                          key={metric.address} 
                          className={cn(
                            "border-b border-slate-800/30 hover:bg-slate-800/40 transition-all group relative",
                            alphaScore > 80 && "bg-indigo-500/5",
                            (metric.latestAlert === 'WHALE_BUY' || metric.latestAlert === 'HIGH_BUY') && "bg-indigo-500/10",
                            metric.isSurging && "bg-emerald-500/5"
                          )}
                        >
                          <td className="p-6">
                            <div className="flex items-center gap-4">
                              <div className={cn(
                                "w-10 h-10 rounded-xl flex items-center justify-center font-black text-xs shadow-inner border transition-all",
                                metric.latestAlert === 'WHALE_BUY' ? "bg-indigo-600 text-white border-indigo-400 shadow-[0_0_15px_rgba(79,70,229,0.4)]" :
                                metric.latestAlert === 'HIGH_BUY' ? "bg-amber-500 text-white border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.4)]" :
                                "bg-indigo-500/10 border-indigo-500/20 text-indigo-400"
                              )}>
                                {(metric.symbol || 'UNK').slice(0, 3)}
                              </div>
                              <div>
                                <div className="flex items-center gap-2">
                                  <p className="text-sm font-black text-white group-hover:text-indigo-400 transition-colors uppercase">{metric.symbol}</p>
                                  {isSprinting && (
                                    <div className="flex items-center gap-1 bg-emerald-500 text-white text-[7px] font-black px-1.5 py-0.5 rounded shadow-[0_0_10px_rgba(16,185,129,0.5)] animate-pulse">
                                      SPRINTING
                                    </div>
                                  )}
                                  {metric.latestAlert === 'GOLDEN_CROSS' && (
                                    <div className="flex items-center gap-1 bg-amber-500/20 text-amber-400 text-[8px] font-black px-2 py-0.5 rounded border border-amber-500/30 animate-pulse">
                                      <Zap className="w-2.5 h-2.5 fill-amber-400" /> GOLDEN CROSS
                                    </div>
                                  )}
                                  {metric.latestAlert === 'MIGRATED' && (
                                    <div className="flex items-center gap-1 bg-rose-500/20 text-rose-400 text-[8px] font-black px-2 py-0.5 rounded border border-rose-500/30 animate-bounce">
                                      🚀 MIGRATED X-RAY
                                    </div>
                                  )}
                                  {(metric.isRugSafe) && (
                                    <div className="flex items-center gap-1 bg-violet-500/20 text-violet-400 text-[8px] font-black px-2 py-0.5 rounded border border-violet-500/30">
                                      🛡️ NO-MINT
                                    </div>
                                  )}
                                  {metric.category && (
                                    <div className="flex items-center gap-1 bg-slate-800 text-slate-300 text-[8px] font-black px-2 py-0.5 rounded border border-slate-700">
                                      {metric.category}
                                    </div>
                                  )}
                                </div>
                                <div className="flex items-center gap-1">
                                  <span className="text-[10px] font-mono text-slate-500">{(metric.address || '').slice(0, 6)}...{(metric.address || '').slice(-4)}</span>
                                  <button onClick={() => copyToClipboard(metric.address, metric.address)} className="text-slate-600 hover:text-white transition-colors">
                                    {copiedId === metric.address ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                                  </button>
                                </div>
                              </div>
                            </div>
                          </td>
                          <td className="p-6 text-center">
                            <div className={cn(
                              "inline-flex items-center justify-center px-4 py-1.5 rounded-lg text-xs font-black border",
                              alphaScore > 80 ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/30 shadow-[0_0_15px_rgba(16,185,129,0.3)] animate-pulse" :
                              alphaScore > 50 ? "bg-indigo-500/10 text-indigo-400 border-indigo-500/20 shadow-[0_0_10px_rgba(99,102,241,0.2)]" :
                              "bg-slate-800 text-slate-500 border-slate-700"
                            )}>
                              {alphaScore}%
                            </div>
                          </td>
                          <td className="p-6 text-center">
                            {metric.liquidity ? (
                              <div className="flex flex-col items-center">
                                <span className={cn(
                                  "text-sm font-black text-white",
                                  metric.liquidity < 8000 ? "text-rose-400" : "text-emerald-400"
                                )}>
                                  ${metric.liquidity.toLocaleString()}
                                </span>
                                {metric.volMcRatio && (
                                  <span className="text-[8px] text-slate-500 uppercase font-bold">V/MC: {metric.volMcRatio.toFixed(2)}</span>
                                )}
                              </div>
                            ) : (
                              <RefreshCw className="w-3 h-3 animate-spin text-slate-700 mx-auto" />
                            )}
                          </td>
                          <td className="p-6 text-center">
                            <div className="flex flex-col items-center">
                              <span className="text-sm font-black text-white">{metric.holderCount?.toLocaleString() || '124'}+</span>
                              {((metric.holdersPerMin || 0) > 10 || (metric.holderCount || 0) > (metric.prevHolderCount || 0)) && (
                                <span className="text-[7px] text-indigo-400 font-black animate-pulse">↑ ESCALATING</span>
                              )}
                              <div className="w-8 h-1 bg-slate-800 rounded-full mt-1 overflow-hidden">
                                <div className="h-full bg-indigo-500" style={{ width: '65%' }} />
                              </div>
                            </div>
                          </td>
                          <td className="p-6 text-center">
                            <div className="flex flex-col items-center gap-1">
                              {metric.isRugSafe ? (
                                <div className="flex items-center gap-1 bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded text-[8px] font-black border border-emerald-500/30">
                                  <ShieldAlert className="w-2.5 h-2.5 text-emerald-400" /> RUG SAFE
                                </div>
                              ) : metric.liquidity ? (
                                <div className="flex items-center gap-1 bg-rose-500/20 text-rose-400 px-2 py-0.5 rounded text-[8px] font-black border border-rose-500/30">
                                  <ShieldAlert className="w-2.5 h-2.5 text-rose-400" /> HIGH RISK
                                </div>
                              ) : (
                                <span className="text-[8px] text-slate-700 animate-pulse font-black uppercase">Scanning...</span>
                              )}
                            </div>
                          </td>
                          <td className="p-6 text-center">
                            <div className="flex flex-col items-center">
                              <span className={cn(
                                "text-sm font-black transition-all",
                                isSprinting ? "text-emerald-400 scale-110" : "text-white"
                              )}>
                                {metric.buyCount}B / {metric.sellCount}S
                              </span>
                              <div className="flex items-center gap-1 mt-1">
                                <span className="text-[10px] font-black text-emerald-400">{(metric.buyCount / (metric.sellCount || 1)).toFixed(1)}x</span>
                                {buyFreq30s > 0 && <span className="text-[8px] text-emerald-400 font-bold">+{buyFreq30s} in 30s</span>}
                              </div>
                              {metric.buyCount > (metric.sellCount || 0) * 2 && (
                                <span className="text-[7px] text-emerald-400 font-black opacity-80 animate-bounce">BUY PRESSURE</span>
                              )}
                            </div>
                          </td>
                          <td className="p-6 text-right">
                            <div className={cn(
                              "inline-flex items-center gap-2 px-3 py-1.5 rounded-xl font-black text-xs shadow-inner",
                              (metric.percentageIncrease || 0) >= 0 
                                ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" 
                                : "bg-rose-500/10 text-rose-400 border border-rose-500/20"
                            )}>
                              {(metric.percentageIncrease ?? 0).toFixed(2)}%
                            </div>
                          </td>
                          <td className="p-6 text-right">
                            <span className="text-[10px] font-mono text-slate-500 font-bold bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                              {new Date(metric.lastUpdated).toLocaleTimeString()}
                            </span>
                          </td>
                          <td className="p-6 text-center">
                             <div className="flex items-center justify-center gap-2">
                               <button 
                                 onClick={(e) => {
                                   e.stopPropagation();
                                   handleManualBuy(metric.address, metric.symbol);
                                 }}
                                 className="p-2 rounded-lg bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 hover:bg-emerald-500 hover:text-white transition-all shadow-lg active:scale-90 flex items-center gap-2 px-3"
                                 title="Execute Manual Buy"
                               >
                                 <Zap className="w-3.5 h-3.5" />
                                 <span className="text-[8px] font-black uppercase">BUY SOL</span>
                               </button>
                               <button 
                                 onClick={(e) => {
                                   e.stopPropagation();
                                   window.open(`https://jup.ag/swap/SOL-${metric.address}`, '_blank');
                                 }}
                                 className="p-2 rounded-lg bg-slate-800 border border-slate-700 text-slate-400 hover:bg-slate-700 hover:text-white transition-all active:scale-95 px-3"
                                 title="View on Jupiter"
                               >
                                 <Globe className="w-3.5 h-3.5" />
                               </button>
                             </div>
                           </td>
                        </tr>
                      );
                    })}
                    {(Object.values(tokenMetrics || {}) as TokenMetric[]).filter(m => {
                      if (!m || !m.address) return false;
                      const buy30s = (m.recentBuysTimeline || []).filter((t: any) => t && Date.now() - t.t < 30000).length;
                      
                      const saved = savedGems ? savedGems[m.address] : undefined;
                      if (saved) {
                        const currentPrice = m.priceUsd || (m.marketCap && m.supply ? m.marketCap / m.supply : 0);
                        const gain = (saved.priceAtSave > 0 && currentPrice > 0) ? ((currentPrice / saved.priceAtSave) - 1) * 100 : 0;
                        if (gain < 0) return false;
                      }

                      if (alphaProtocol === 'GEMS_100X') {
                        const mc = m.marketCap || 0; 
                        const vol = m.volume24h || 0; 
                        const liq = m.liquidity || 0; 
                        const isMcValid = mc >= 0; 
                        const isVolValid = vol >= 0; 
                        const isLiqValid = liq >= 0;
                        const buySellRatio = (m.buyCount || 0) / (m.sellCount || 1); 
                        const hasHolders = (m.holderCount || 0) >= 0;
                        const safeDev = true;
                        const hasVelocity = true;
                        return isMcValid && isVolValid && isLiqValid && buySellRatio >= 0 && hasHolders && safeDev && m.isRugSafe !== false && hasVelocity;
                      }

                      if (alphaProtocol === 'MIGRATED') {
                        return m.latestAlert === 'MIGRATED' || (m.bondingCurveProgress || 0) >= 99.5 || !(m.address && m.address.toLowerCase().endsWith('pump'));
                      }

                      const baseFilter = (m.buyCount || 0) >= 2;
                      if (!baseFilter) return false;
                      const isBuyingMore = (m.buyCount || 0) > (m.sellCount || 0);
                      if (!isBuyingMore) return false;

                      if (alphaProtocol === 'SNIPER') {
                        return (m.percentageIncrease || 0) >= 15 && (buy30s >= 2 || ((m.buyCount || 0) / (m.sellCount || 1)) >= 3);
                      }
                      if (alphaProtocol === 'HIGH_PROFIT') return (m.percentageIncrease || 0) >= 60 && m.isRugSafe !== false && (((m.volume24h || 0) / (m.marketCap || 1)) >= 1.0);
                      if (alphaProtocol === 'WHALE_BUY') return m.latestAlert === 'WHALE_BUY' || m.latestAlert === 'HIGH_BUY';
                      if (alphaProtocol === 'NEW_DISCOVERY') return (Date.now() - (m.discoveredAt || Date.now())) < 300000;
                      return (m.percentageIncrease || 0) >= 40;
                    }).length === 0 && (
                      <tr>
                        <td colSpan={9} className="p-20 text-center opacity-10 italic text-sm tracking-widest font-black uppercase font-sans">
                          {alphaProtocol === 'GEMS_100X' ? 'Scanning for 100x Potential Gems...' : 
                           alphaProtocol === 'MIGRATED' ? 'Waiting for graduation... No Active Migrations in timeframe' :
                           'Scanning Deep Streams... No High Profit Alpha Detected'}
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* Mobile Card View */}
              <div className="lg:hidden overflow-y-auto scrollbar-none flex-1 p-4 space-y-4">
                {(Object.values(tokenMetrics || {}) as TokenMetric[])
                  .filter(m => {
                    if (!m || !m.address) return false;
                    const buy30s = (m.recentBuysTimeline || []).filter((t: any) => t && Date.now() - t.t < 30000).length;
                    
                    const saved = savedGems ? savedGems[m.address] : undefined;
                    if (saved) {
                      const currentPrice = m.priceUsd || (m.marketCap && m.supply ? m.marketCap / m.supply : 0);
                      const gain = (saved.priceAtSave > 0 && currentPrice > 0) ? ((currentPrice / saved.priceAtSave) - 1) * 100 : 0;
                      if (gain < 0) return false;
                    }

                    if (alphaProtocol === 'GEMS_100X') {
                      const mc = m.marketCap || 0; 
                      const vol = m.volume24h || 0; 
                      const liq = m.liquidity || 0; 
                      const isMcValid = mc >= 0; 
                      const isVolValid = vol >= 0; 
                      const isLiqValid = liq >= 0;
                      const buySellRatio = (m.buyCount || 0) / (m.sellCount || 1); 
                      const hasHolders = (m.holderCount || 0) >= 0;
                      const safeDev = true;
                      const hasVelocity = true;
                      return isMcValid && isVolValid && isLiqValid && buySellRatio >= 0 && hasHolders && safeDev && m.isRugSafe !== false && hasVelocity;
                    }

                    if (alphaProtocol === 'MIGRATED') {
                      return m.latestAlert === 'MIGRATED' || (m.bondingCurveProgress || 0) >= 99.5 || !(m.address && m.address.toLowerCase().endsWith('pump'));
                    }

                    const baseFilter = (m.buyCount || 0) >= 2;
                    if (!baseFilter) return false;
                    
                    const isBuyingMore = (m.buyCount || 0) > (m.sellCount || 0);
                    if (!isBuyingMore) return false;

                    if (alphaProtocol === 'SNIPER') {
                      return (m.percentageIncrease || 0) >= 15 && (buy30s >= 2 || ((m.buyCount || 0) / (m.sellCount || 1)) >= 3);
                    }
                    if (alphaProtocol === 'HIGH_PROFIT') return (m.percentageIncrease || 0) >= 60 && m.isRugSafe !== false && (((m.volume24h || 0) / (m.marketCap || 1)) >= 1.0);
                    if (alphaProtocol === 'WHALE_BUY') return m.latestAlert === 'WHALE_BUY' || m.latestAlert === 'HIGH_BUY';
                    if (alphaProtocol === 'NEW_DISCOVERY') return (Date.now() - (m.discoveredAt || Date.now())) < 300000;
                    return (m.percentageIncrease || 0) >= 40;
                  })
                  .sort((a, b) => {
                    if (!a || !b) return 0;
                    if (alphaProtocol === 'SNIPER' || alphaProtocol === 'GEMS_100X') {
                      const a30sCount = (a.recentBuysTimeline || []).filter((t: any) => t && Date.now() - t.t < 30000).length;
                      const b30sCount = (b.recentBuysTimeline || []).filter((t: any) => t && Date.now() - t.t < 30000).length;
                      
                      if (alphaProtocol === 'GEMS_100X') {
                        if (b30sCount !== a30sCount) return b30sCount - a30sCount;
                        return (a.marketCap || 999999999) - (b.marketCap || 999999999);
                      }
                      
                      if (b30sCount !== a30sCount) return b30sCount - a30sCount;
                    }
                    const bRatio = (b.buyCount || 0) / (b.sellCount || 1);
                    const aRatio = (a.buyCount || 0) / (a.sellCount || 1);
                    if (Math.abs(bRatio - aRatio) > 0.5) return bRatio - aRatio;
                    return (b.discoveredAt || 0) - (a.discoveredAt || 0);
                  })
                  .map((metric: TokenMetric) => (
                    <motion.div 
                      key={metric.address}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={cn(
                        "border rounded-2xl p-4 shadow-xl transition-all",
                        metric.latestAlert === 'WHALE_BUY' ? "bg-indigo-600/10 border-indigo-500/40" :
                        metric.latestAlert === 'HIGH_BUY' ? "bg-amber-500/10 border-amber-500/40" :
                        metric.latestAlert === 'MIGRATED' ? "bg-rose-500/10 border-rose-500/40" :
                        metric.isSurging ? "bg-emerald-500/10 border-emerald-500/40" :
                        "bg-slate-950/60 border-slate-800"
                      )}
                    >
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <div className={cn(
                            "w-10 h-10 rounded-xl flex items-center justify-center font-black text-xs shadow-inner transition-all",
                            metric.latestAlert === 'WHALE_BUY' ? "bg-indigo-600 text-white border border-indigo-400" :
                            metric.latestAlert === 'HIGH_BUY' ? "bg-amber-500 text-white border border-amber-400" :
                            metric.latestAlert === 'MIGRATED' ? "bg-rose-600 text-white border border-rose-400 shadow-[0_0_15px_rgba(225,29,72,0.4)]" :
                            "bg-indigo-500/10 border border-indigo-500/20 text-indigo-400"
                          )}>
                            {(metric.symbol || 'UNK').slice(0, 3)}
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <p className="text-sm font-black text-white uppercase leading-none truncate">{metric.symbol || 'UNKNOWN'}</p>
                              {metric.latestAlert === 'MIGRATED' && (
                                <span className="text-[7px] text-rose-400 font-black animate-bounce shrink-0">🚀</span>
                              )}
                            </div>
                            <div className={cn(
                              "inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[8px] font-black uppercase tracking-widest",
                              metric.latestAlert === 'VOLUME_SPIKE' ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30" : 
                              metric.latestAlert === 'WHALE_BUY' ? "bg-indigo-500/20 text-indigo-400 border border-indigo-500/30" :
                              metric.latestAlert === 'GOLDEN_CROSS' ? "bg-amber-500/20 text-amber-400 border border-amber-500/30" :
                              metric.latestAlert === 'MIGRATED' ? "bg-rose-500/20 text-rose-400 border border-rose-500/30" :
                              "bg-slate-800 text-slate-500"
                            )}>
                              {metric.latestAlert?.replace('_', ' ') || 'STABLE'}
                            </div>
                            
                            <div className="flex gap-2 mt-2">
                               {metric.liquidity && (
                                 <span className={cn(
                                   "px-1.5 py-0.5 rounded bg-slate-900 border text-[7px] font-bold uppercase",
                                   metric.liquidity >= 8000 ? "text-emerald-400 border-emerald-500/30" : "text-rose-400 border-rose-500/30"
                                 )}>
                                   Liq: ${metric.liquidity.toLocaleString()}
                                 </span>
                               )}
                               {metric.isRugSafe && (
                                 <span className="px-1.5 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[6px] font-black uppercase flex items-center gap-1">
                                   <ShieldAlert className="w-2 h-2" /> SAFE
                                 </span>
                               )}
                            </div>
                            {metric.whaleEntranceTime && (
                               <div className="text-[8px] text-emerald-400/80 font-black uppercase mt-2 flex items-center gap-1">
                                <Clock className="w-2.5 h-2.5" />
                                Whale: {new Date(metric.whaleEntranceTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className={cn(
                            "inline-flex items-center gap-1 font-black text-sm",
                            (metric.percentageIncrease || 0) >= 0 ? "text-emerald-400" : "text-rose-400"
                          )}>
                            {(metric.percentageIncrease || 0).toFixed(2)}%
                          </div>
                          <div className="flex flex-col items-end gap-0.5 mt-1">
                            <p className="text-[9px] text-slate-500 font-mono font-bold uppercase tracking-widest">{metric.buyCount || 0}B / {metric.sellCount || 0}S</p>
                            <p className="text-[10px] font-black text-emerald-400">{((metric.buyCount || 0) / (metric.sellCount || 1)).toFixed(1)}x Ratio</p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-3 pt-3 border-t border-slate-800/50">
                        <div className="flex items-center gap-2 bg-slate-900/50 px-2 py-1.5 rounded-xl border border-slate-700 min-w-0">
                          <code className="text-[10px] font-mono text-indigo-200 truncate flex-1 leading-relaxed">
                            {(metric.address || '').slice(0, 6)}...{(metric.address || '').slice(-6)}
                          </code>
                          <button 
                            onClick={() => copyToClipboard(metric.address, metric.address)}
                            className="p-1 rounded bg-slate-800 text-slate-500 active:text-indigo-400 transition-colors"
                          >
                            {copiedId === metric.address ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                          </button>
                        </div>
                        <button 
                          onClick={() => handleManualBuy(metric.address, metric.symbol)}
                          className="px-3 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-lg shadow-indigo-600/20 active:scale-95 flex items-center justify-center gap-1"
                        >
                          <Zap className="w-3 h-3" /> Execute
                        </button>
                      </div>
                    </motion.div>
                  ))}
                
                {(Object.values(tokenMetrics) as TokenMetric[]).filter(m => {
                  const baseFilter = (m.buyCount || 0) >= 2;
                  if (!baseFilter) return false;
                  if (alphaProtocol === 'HIGH_PROFIT') return (m.percentageIncrease || 0) >= 60 && m.isRugSafe !== false && ((m.volume24h || 0) / (m.marketCap || 1)) >= 1.0;
                  if (alphaProtocol === 'WHALE_BUY') return m.latestAlert === 'WHALE_BUY' || m.latestAlert === 'HIGH_BUY';
                  if (alphaProtocol === 'NEW_DISCOVERY') return (Date.now() - m.discoveredAt) < 300000;
                  return (m.percentageIncrease || 0) >= 60;
                }).length === 0 && (
                   <div className="py-20 text-center opacity-10 italic text-xs tracking-[0.2em] font-black uppercase px-4">
                    Searching Depths... No Tokens Found for Current Protocol
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
    ) : null}
      </div>
    </main>

      {/* Footer / Status Rail */}
      <footer className="fixed bottom-16 lg:bottom-0 left-0 right-0 h-8 lg:h-10 bg-slate-900/80 border-t border-slate-800 flex items-center justify-between px-4 lg:px-8 text-[8px] lg:text-[10px] text-slate-500 font-mono z-[60] backdrop-blur-sm">
        <div className="flex items-center gap-3 lg:gap-6">
          <div className="flex items-center gap-1.5 lg:gap-2">
            <div className="w-1 lg:w-1.5 h-1 lg:h-1.5 rounded-full bg-emerald-500 shadow-[0_0_5px_rgba(16,185,129,1)]" />
            <span className="uppercase tracking-widest">LIVE</span>
          </div>
          <span className="opacity-40 whitespace-nowrap hidden sm:inline">LAST BLOCK: 254,192,012</span>
        </div>
        <div className="flex items-center gap-4 lg:gap-8 uppercase tracking-widest">
          <span className="flex items-center gap-1 text-indigo-400/80">
            <Globe className="w-2.5 h-2.5 lg:w-3 lg:h-3" />
            42ms
          </span>
          <span className="hidden sm:inline italic">PULSE TERMINAL v2.4.1</span>
        </div>
      </footer>
      
      {/* High Profit Alert Overlay */}
      <AnimatePresence>
        {highProfitAlert && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.1 }}
            className="fixed inset-0 z-[1000] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md"
            onClick={() => setHighProfitAlert(null)}
          >
            <div className="bg-gradient-to-br from-emerald-500 to-indigo-600 p-1.5 rounded-3xl animate-pulse shadow-[0_0_120px_rgba(16,185,129,0.3)] cursor-default" onClick={e => e.stopPropagation()}>
              <div className="bg-slate-950 rounded-[20px] p-8 lg:p-12 flex flex-col items-center text-center max-w-2xl w-full">
                <Target className="w-20 h-20 text-emerald-400 mb-6 animate-bounce" />
                <h2 className="text-4xl lg:text-5xl border-b-2 border-emerald-500/30 pb-4 font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-white uppercase tracking-tighter mb-4">
                  Buy Now!
                </h2>
                <div className="text-2xl lg:text-3xl font-black text-emerald-400 mb-2">
                  +{(highProfitAlert.profit ?? 0).toFixed(2)}% POTENTIAL PROFIT
                </div>
                <p className="text-lg text-indigo-300 font-bold uppercase mb-4">
                  {highProfitAlert.symbol} is showing massive strength
                </p>
                <div className="flex items-center gap-2 mb-8 bg-slate-900 px-4 py-2 rounded-xl border border-indigo-500/30 group">
                  <span className="text-xs font-mono text-slate-400 truncate max-w-[200px]">
                    {highProfitAlert.address}
                  </span>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      copyToClipboard(highProfitAlert.address, 'profit-alert');
                    }}
                    className="p-1.5 hover:bg-slate-800 rounded-lg text-indigo-400 transition-colors"
                  >
                    {copiedId === 'profit-alert' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
                <div className="flex flex-col sm:flex-row gap-4 w-full">
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      handleManualBuy(highProfitAlert.address, highProfitAlert.symbol);
                      setHighProfitAlert(null);
                    }}
                    className="flex-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 py-4 rounded-xl text-xl font-black uppercase transition-all shadow-[0_0_30px_rgba(16,185,129,0.3)] hover:shadow-[0_0_50px_rgba(16,185,129,0.5)] active:scale-95"
                  >
                    Execute Buy
                  </button>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      setHighProfitAlert(null);
                    }}
                    className="px-8 py-4 sm:py-0 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-lg font-bold uppercase transition-all active:scale-95"
                  >
                    Dismiss
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showLoginModal && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[2000] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md"
            onClick={() => setShowLoginModal(false)}
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-slate-900 border border-slate-700 rounded-2xl p-6 max-w-sm w-full shadow-2xl relative"
              onClick={e => e.stopPropagation()}
            >
              <button 
                onClick={() => setShowLoginModal(false)}
                className="absolute top-4 right-4 text-slate-500 hover:text-white"
              >
                ✕
              </button>
              
              <h2 className="text-xl font-bold text-white mb-2">
                {isSignUp ? 'Create Account' : 'Welcome Back'}
              </h2>
              <p className="text-xs text-slate-400 mb-6">
                Sign in to sync your settings and monitors.
              </p>

              {authError && (
                <div className="mb-4 p-3 bg-rose-500/10 border border-rose-500/30 rounded-lg text-[11px] text-rose-400 font-mono">
                  {authError}
                </div>
              )}

              <form onSubmit={handleEmailAuth} className="space-y-4 mb-6">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Email</label>
                  <input 
                    type="email" 
                    required
                    value={authEmail}
                    onChange={(e) => setAuthEmail(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500 transition-colors"
                    placeholder="Enter your email"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Password</label>
                  <input 
                    type="password" 
                    required
                    value={authPassword}
                    onChange={(e) => setAuthPassword(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500 transition-colors"
                    placeholder="••••••••"
                  />
                </div>
                
                <button 
                  type="submit"
                  disabled={isAuthLoading}
                  className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold py-2.5 rounded-lg transition-all"
                >
                  {isAuthLoading ? 'Processing...' : (isSignUp ? 'Sign Up' : 'Sign In')}
                </button>
              </form>

              <div className="relative mb-6">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-slate-800"></div>
                </div>
                <div className="relative flex justify-center text-[10px] uppercase">
                  <span className="bg-slate-900 px-2 text-slate-500">Or continue with</span>
                </div>
              </div>

              <button 
                onClick={handleGoogleLogin}
                className="w-full bg-slate-800 hover:bg-slate-700 text-white font-bold py-2.5 rounded-lg transition-all flex items-center justify-center gap-2 mb-4"
              >
                <Globe className="w-4 h-4" /> Google
              </button>

              <div className="mb-4 p-3 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-[11px] text-indigo-300 leading-relaxed text-left">
                <span className="font-semibold block text-indigo-200 mb-0.5">💡 Preview Environment Tip:</span>
                If Google login fails or is blocked due to iframe/third-party cookie restrictions, please sign up or sign in using the Email & Password option above. It runs fully in-frame and works perfectly!
              </div>

              <div className="text-center">
                <button 
                  onClick={() => {
                    setIsSignUp(!isSignUp);
                    setAuthError('');
                  }}
                  className="text-xs text-indigo-400 hover:text-indigo-300 transition-colors"
                >
                  {isSignUp ? 'Already have an account? Sign in' : "Don't have an account? Sign up"}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <style>{`
        .arabic {
          direction: rtl;
        }
        .scrollbar-none::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-none {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
      </div> {/* End Main Container Container */}
    </div>
  );
}
export default App;

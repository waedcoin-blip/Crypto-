import { useActiveWalletStore } from "../../store/activeWalletStore";
import { getKeypairFromPrivateKey } from '../../utils/keypairUtils';
import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { apiClient } from '../../services/ApiClient';
import { tradingApi, pipelineApi } from '../../services/ApiClient';
import { auth } from '../../lib/firebase';
import { useNavigate } from 'react-router-dom';
import { Play, Square, Search, ShieldCheck, ShieldAlert, AlertTriangle, Shield, TrendingUp, ChevronDown, ChevronUp, BookOpen, X, Zap, Activity, ChevronRight, Download, Trash2, Settings, Pause, Database, Copy, Check, Terminal, ArrowUpDown, SlidersHorizontal, Eye, EyeOff, Clock, Info, Bug, Filter, Server, Globe, RefreshCw, Wifi, CloudUpload } from 'lucide-react';
import { Connection, Keypair, VersionedTransaction, PublicKey } from '@solana/web3.js';
import bs58 from 'bs58';
import { Buffer } from 'buffer';
import { TokenMetric, TelemetryAlert, Trade, SniperTrade } from '../../types';
import { useAppStore } from '../../store/appStore';

export interface ScannedToken {
  address: string;
  symbol: string;
  name: string;
  priceUsd: number;
  priceChange5m?: number;
  priceChange1h?: number;
  priceChange24h?: number;
  volume24h?: number;
  liquidityUsd: number;
  fdv?: number;
  marketCap?: number;
  pairCreatedAt?: number;
  dexId?: string;
  pairAddress?: string;
  url?: string;
}
import { DEFAULT_CRITERIA } from '../../config/tokenCriteria';
import { getTradeCount } from '../../config/rebuyGuard';
import { getJupiterQuote, getTokenBalanceRaw, getLatestBlockhashWithFallback, pingJupiterApi } from '../../services/jupiterService';
import { db } from '../../lib/firebase';
import { detectTokenStage } from '../../lib/utils';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { checkTokenInProfitLast2Seconds, clearPriceHistories } from '../../services/priceTracker';
import { encryptPrivateKey, decryptPrivateKey } from '../../lib/crypto';
import { getSolPriceUsd, setSolPriceUsd, calcNetPnl, getDynamicOperationalFeeSol } from '../../utils/pnlUtils';
import { TradingSettings } from '../TradingSettings';
import { WalletStatusWidget } from '../WalletStatusWidget';
import { MasterMonitorPanel } from '../MasterMonitorPanel';
import { marketDataManager, TokenPrice } from '../../services/marketDataManager';
import { rpcHealthManager } from '../../services/rpcHealthManager';
import { useTradeMode } from '../../context/TradeModeContext';
import { masterMonitorHealthManager } from '../../services/MasterMonitorHealthManager';
import { syncManager } from '../../services/SyncService';
import { SyncStatusBadge } from '../SyncStatusBadge';
import { useBalanceStore } from '../../store/balanceStore';
import { useTradingEnvironmentStore } from '../../store/tradingEnvironmentStore';
import { useWalletBridge } from '../../services/walletBridge';
import { resolveTokenDecimals } from '../../services/TokenDecimalsResolver';
import { unifiedTradePipeline, NormalizedTradeEvent } from '../../engines/unifiedTradePipeline';
import { isMintOnCurve } from '../../utils/solanaValidators';

import { DEFAULT_HELIUS_RPC, DEFAULT_HELIUS_WS, HELIUS_API_KEY, SOL_MINT, USDC_MINT } from '../../constants/solana';

if (typeof window !== 'undefined') {
  try {
    if (!(window as any).Buffer) {
      (window as any).Buffer = Buffer;
    }
  } catch {}
}

const JUPITER_SWAP = 'https://api.jup.ag/swap/v1/swap';
const JUPITER_PRICE = 'https://api.jup.ag/price/v2';
const DEXSCREENER = 'https://api.dexscreener.com/latest/dex';

const decimalsCache: Record<string, number> = {};

const fetchMintDecimals = async (mint: string, rpcUrl?: string): Promise<number> => {
  const normalized = mint.trim();
  if (normalized.toLowerCase().startsWith('sim')) return 6;
  if (decimalsCache[normalized] !== undefined && decimalsCache[normalized] >= 0) return decimalsCache[normalized];

  if (rpcUrl) {
    try {
      const conn = new Connection(rpcUrl, 'confirmed');
      const info = await conn.getParsedAccountInfo(new PublicKey(normalized));
      if (info?.value?.data && 'parsed' in info.value.data) {
        const decimals = info.value.data.parsed?.info?.decimals;
        if (typeof decimals === 'number') {
          decimalsCache[normalized] = decimals;
          return decimals;
        }
      }
    } catch (e) {
      console.warn("Solana RPC decimals fetch note:", e);
    }
  }

  // Public Jupiter Token API fallback.
  try {
    const res = await fetch(`https://tokens.jup.ag/token/${normalized}`);
    if (res.ok) {
      const data = await res.json();
      if (data && typeof data.decimals === 'number') {
        decimalsCache[normalized] = data.decimals;
        return data.decimals;
      }
    }
  } catch (e) {
    console.warn("Jupiter token decimals fetch failed:", e);
  }

  // 2. Try Solana RPC
  if (rpcUrl) {
    try {
      const conn = new Connection(rpcUrl, 'confirmed');
      const info = await conn.getParsedAccountInfo(new PublicKey(normalized));
      if (info?.value?.data && 'parsed' in info.value.data) {
        const decimals = info.value.data.parsed?.info?.decimals;
        if (typeof decimals === 'number') {
          decimalsCache[normalized] = decimals;
          return decimals;
        }
      }
    } catch (e) {
      console.warn("Solana RPC decimals fetch failed:", e);
    }
  }

  // Return -1 to force heuristic calculation at the call site
  return -1;
};

const resolveDecimals = async (mint: string, rpcUrl: string | undefined): Promise<number> => {
  const cleanMint = mint.trim();
  if (decimalsCache[cleanMint] !== undefined && decimalsCache[cleanMint] >= 0) {
    return decimalsCache[cleanMint];
  }
  if (cleanMint.toLowerCase().endsWith('pump')) {
    decimalsCache[cleanMint] = 6;
    return 6;
  }
  try {
    const metricDecimals = await fetchMintDecimals(cleanMint, rpcUrl);
    if (metricDecimals >= 0 && metricDecimals <= 18) {
      decimalsCache[cleanMint] = metricDecimals;
      return metricDecimals;
    }
  } catch (e) {}
  
  const fallback = 6;
  decimalsCache[cleanMint] = fallback;
  return fallback;
};

interface Position {
  symbol: string;
  buyPrice: number;
  currentPrice: number;
  solSpent: number;
  amount: number;
  amountLamports?: number;
  entryTime: number;
  txid: string; // The primary/most recent transaction
  buySlot?: number;
  buyEntries?: { signature: string; solSpent: number; amount: number; buyPrice: number; slot: number }[];
  positionId?: string;
  recoveryMode?: boolean;
  triggersDisabled?: boolean;
  isScalp?: boolean;
  isStale?: boolean;
  realNetPnl?: number;
  realNetSol?: number;
  decimals?: number;
  tpPct?: number;
  slPct?: number;
  hasCustomTpSl?: boolean;
  signalEmitted?: boolean;
  entryPriceUsd?: number;
  currentPriceUsd?: number;
  liquidityUsd?: number;
  volume24h?: number;

  // Authoritative server valuation fields
  entryCostSol?: number;
  currentPriceSol?: number;
  marketValueSol?: number;
  marketPnlSol?: number;
  marketPnlPercent?: number;
  executableValueSol?: number;
  executablePnlSol?: number;
  executablePnlPercent?: number;
  pnlSol?: number;
  pnlPercent?: number;
  source?: string;
  lastMarketPriceAt?: number;
  lastExecutableQuoteAt?: number;
  quoteAgeMs?: number;
  status?: 'LIVE' | 'STALE' | 'UNAVAILABLE';
}

interface LogEvent {
  id: string;
  time: string;
  timestamp: number;
  msg: string;
  type: string;
  category: string;
  metadata?: Record<string, any>;
  count?: number;
}

interface TerminalConsoleProps {
  logs: LogEvent[];
  setLogs: React.Dispatch<React.SetStateAction<LogEvent[]>>;
  retentionLimit: number;
  setRetentionLimit: (limit: number) => void;
  positions?: Record<string, any>;
  onQuickTrade?: (mint: string, symbol?: string) => void;
  onQuickSell?: (mint: string, currentPrice?: number, pnlPct?: number, reason?: string) => void;
}

const TerminalConsole: React.FC<TerminalConsoleProps> = ({ logs, setLogs, retentionLimit, setRetentionLimit, positions, onQuickTrade, onQuickSell }) => {
  const [logSearch, setLogSearch] = useState('');
  const [logCategoryFilter, setLogCategoryFilter] = useState('all');
  const [logLevelFilter, setLogLevelFilter] = useState('all');
  const [isPaused, setIsPaused] = useState(false);
  const [isRegex, setIsRegex] = useState(false);
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc'); // desc = Newest First, asc = Oldest First
  const [fontSize, setFontSize] = useState<'xs' | 'sm' | 'md'>('sm');
  const [showSettings, setShowSettings] = useState(false);
  const [expandedLogId, setExpandedLogId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [autoScroll, setAutoScroll] = useState(true);
  const [showScrollBanner, setShowScrollBanner] = useState(false);

  // Freeze buffer when paused
  const [pausedLogs, setPausedLogs] = useState<LogEvent[]>([]);

  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Stats calculation
  const stats = useMemo(() => {
    let errs = 0;
    let warns = 0;
    let success = 0;
    let info = 0;
    let trades = 0;

    logs.forEach(l => {
      if (l.type === 'err' || l.type === 'error' || l.type === 'critical') errs++;
      else if (l.type === 'warn') warns++;
      else if (l.type === 'success' || l.type === 'buy' || l.type === 'sell') {
        success++;
        if (l.category === 'trade') trades++;
      }
      else if (l.type === 'info') info++;
    });

    return { total: logs.length, errs, warns, success, info, trades };
  }, [logs]);

  // Capture snapshot of logs ONLY when frozen starts
  useEffect(() => {
    if (isPaused) {
      setPausedLogs(logs);
    }
  }, [isPaused, logs]);

  const activeLogsSource = isPaused ? pausedLogs : logs;

  const highlightText = (text: string, search: string) => {
    if (!search.trim()) return <span>{text}</span>;
    
    try {
      let regex: RegExp;
      if (isRegex) {
        regex = new RegExp(`(${search})`, 'gi');
      } else {
        const keywords = search.trim().split(/\s+/).filter(Boolean);
        if (keywords.length === 0) return <span>{text}</span>;
        const escapedKws = keywords.map(kw => kw.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'));
        regex = new RegExp(`(${escapedKws.join('|')})`, 'gi');
      }
      
      const parts = text.split(regex);
      return (
        <>
          {parts.map((part, idx) => {
            const isMatch = isRegex 
              ? new RegExp(search, 'i').test(part)
              : search.trim().toLowerCase().split(/\s+/).filter(Boolean).some(kw => part.toLowerCase() === kw.toLowerCase());
              
            return isMatch ? (
              <mark key={idx} className="bg-[#c7f284]/25 text-[#c7f284] px-0.5 rounded font-bold font-mono">
                {part}
              </mark>
            ) : (
              <span key={idx}>{part}</span>
            );
          })}
        </>
      );
    } catch (e) {
      // Fallback if regex is malformed while typing
      return <span>{text}</span>;
    }
  };

  const filteredLogs = useMemo(() => {
    let src = activeLogsSource;
    
    // Support Regex state
    let searchMatcher = (log: LogEvent): boolean => {
      if (!logSearch.trim()) return true;
      const terms = logSearch.trim().toLowerCase().split(/\s+/).filter(Boolean);
      return terms.every(kw => {
        const inMsg = String(log.msg || '').toLowerCase().includes(kw);
        const inCategory = String(log.category || '').toLowerCase().includes(kw);
        const inType = String(log.type || '').toLowerCase().includes(kw);
        const inTime = String(log.time || '').toLowerCase().includes(kw);
        return inMsg || inCategory || inType || inTime;
      });
    };

    if (isRegex && logSearch.trim()) {
      try {
        const rx = new RegExp(logSearch, 'i');
        searchMatcher = (log: LogEvent) => {
          return rx.test(log.msg || '') || rx.test(log.category || '') || rx.test(log.type || '');
        };
        } catch (err) {
        // invalid regex, ignore querying
      }
    }
    
    const res = src.filter((log) => {
      const matchesSearch = searchMatcher(log);
      const matchesCategory = logCategoryFilter === 'all' || log.category === logCategoryFilter;
      const matchesLevel = logLevelFilter === 'all' || 
                           (logLevelFilter === 'err' && (log.type === 'err' || log.type === 'error' || log.type === 'critical')) ||
                           (logLevelFilter === 'warn' && log.type === 'warn') ||
                           (logLevelFilter === 'success' && (log.type === 'success' || log.type === 'buy' || log.type === 'sell')) ||
                           (logLevelFilter === 'info' && log.type === 'info');

      return matchesSearch && matchesCategory && matchesLevel;
    });

    // Handle interactive sorting
    if (sortOrder === 'asc') {
      return [...res].reverse(); // Oldest first
    }
    return res; // Newest first
  }, [activeLogsSource, logSearch, logCategoryFilter, logLevelFilter, isRegex, sortOrder]);

  // Local Storage logs pruning moved to parent to avoid infinite render cycles

  // Auto Scroll logic
  const handleScroll = () => {
    const el = scrollContainerRef.current;
    if (!el) return;

    // Detect if user has scrolled away
    const threshold = 45;
    if (sortOrder === 'asc') {
      const isAtBottom = el.scrollHeight - el.scrollTop - el.clientHeight < threshold;
      if (isAtBottom) {
        setAutoScroll(true);
        setShowScrollBanner(false);
      } else {
        setAutoScroll(false);
        setShowScrollBanner(true);
      }
    } else {
      const isAtTop = el.scrollTop < threshold;
      if (isAtTop) {
        setAutoScroll(true);
        setShowScrollBanner(false);
      } else {
        setAutoScroll(false);
        setShowScrollBanner(true);
      }
    }
  };

  const executeScroll = useCallback(() => {
    const el = scrollContainerRef.current;
    if (!el) return;
    if (sortOrder === 'asc') {
      el.scrollTop = el.scrollHeight;
    } else {
      el.scrollTop = 0;
    }
    setShowScrollBanner(false);
  }, [sortOrder]);

  useEffect(() => {
    if (autoScroll) {
      executeScroll();
    }
  }, [filteredLogs.length, autoScroll, executeScroll]);

  const handleCopyMetadata = (meta: any, id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      navigator.clipboard.writeText(JSON.stringify(meta, null, 2));
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
      } catch (err) {
      console.warn("Failed to copy metadata", err);
    }
  };

  const handleExportText = () => {
    let text = `TRADING BOT SYSTEM LOG REPORT\n`;
    text += `Generated: ${new Date().toLocaleString()}\n`;
    text += `Total Logs Event Count: ${logs.length}\n`;
    text += `==================================================\n\n`;
    
    logs.forEach((log) => {
      text += `[${log.time}] [${log.category.toUpperCase()}] [${log.type.toUpperCase()}] ${log.msg}\n`;
      if (log.metadata) {
        text += `  Metadata: ${JSON.stringify(log.metadata)}\n`;
      }
    });

    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `trading_agent_logs_${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleExportCsv = () => {
    let csv = `"Timestamp","Category","Level","Message","Metadata"\n`;
    
    logs.forEach((log) => {
      const row = [
        log.time || '',
        log.category || '',
        log.type || '',
        log.msg.replace(/"/g, '""'),
        log.metadata ? JSON.stringify(log.metadata).replace(/"/g, '""') : ''
      ];
      csv += row.map(cell => `"${cell}"`).join(',') + '\n';
    });

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `trading_agent_logs_${Date.now()}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Font size styles 
  const fontStyle = fontSize === 'xs' ? 'text-[9.5px]' : fontSize === 'sm' ? 'text-[11px]' : 'text-[13px]';

  return (
    <div className="flex flex-col h-full bg-[#0d0e16]/85 rounded-xl border border-[#1f212e]/80 overflow-hidden relative">
      
      {/* 1. Terminal Mini Live Diagnostics Dashboard */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5 p-3 bg-[#0a0b10] border-b border-[#1f212e]/50">
        <div className="bg-[#121420] border border-[#1f212e]/40 rounded-lg p-2 flex flex-col justify-between">
          <span className="text-[9px] text-[#64748b] uppercase font-bold tracking-wider flex items-center gap-1">
            <Terminal className="w-2.5 h-2.5 text-[#c7f284]" /> Total Buffer
          </span>
          <span className="text-sm font-bold text-slate-200 mt-1">{stats.total} <span className="text-[10px] text-[#475569]">/ {retentionLimit}</span></span>
        </div>
        
        <div className="bg-[#121420] border border-[#1f212e]/40 rounded-lg p-2 flex flex-col justify-between">
          <span className="text-[9px] text-[#ff4d4d] uppercase font-bold tracking-wider flex items-center gap-1">
            <Bug className="w-2.5 h-2.5" /> Failures
          </span>
          <span className="text-sm font-bold text-red-400 mt-1">
            {stats.errs} 
            {stats.total > 0 && (
              <span className="text-[9px] text-[#64748b] font-normal ml-1">
                ({Math.round((stats.errs / stats.total) * 100)}%)
              </span>
            )}
          </span>
        </div>

        <div className="bg-[#121420] border border-[#1f212e]/40 rounded-lg p-2 flex flex-col justify-between">
          <span className="text-[9px] text-[#ffb300] uppercase font-bold tracking-wider flex items-center gap-1">
            <AlertTriangle className="w-2.5 h-2.5" /> Warnings
          </span>
          <span className="text-sm font-bold text-[#ffb300] mt-1">{stats.warns}</span>
        </div>

        <div className="bg-[#121420] border border-[#1f212e]/40 rounded-lg p-2 flex flex-col justify-between">
          <span className="text-[9px] text-[#34d399] uppercase font-bold tracking-wider flex items-center gap-1">
            <Zap className="w-2.5 h-2.5" /> Signal Hits
          </span>
          <span className="text-sm font-bold text-emerald-400 mt-1">{stats.success}</span>
        </div>

        <div className="bg-[#121420] border border-[#1f212e]/40 rounded-lg p-2 flex flex-col justify-between col-span-2 sm:col-span-1">
          <span className="text-[9px] text-[#c7f284] uppercase font-bold tracking-wider flex items-center gap-1">
            <Activity className="w-2.5 h-2.5" /> Core Trades
          </span>
          <span className="text-sm font-bold text-[#c7f284] mt-1">{stats.trades}</span>
        </div>
      </div>

      {/* 2. Controls and Search Bar */}
      <div className="p-3 bg-[#0d0e16]/65 border-b border-[#1f212e] flex flex-col gap-2 shrink-0">
        <div className="flex flex-wrap sm:flex-nowrap gap-2 items-center">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-[#64748b]" />
            <input 
              type="text" 
              value={logSearch} 
              onChange={(e) => setLogSearch(e.target.value)} 
              placeholder={isRegex ? "Regex Search (e.g. SOL.*USDC|FAIL)..." : "Search live logs (terms, symbols, cat)..."} 
              className="w-full bg-[#10111a] border border-[#1f212e] rounded-lg pl-8 pr-16 py-1.5 text-[11px] text-[#e2e8f0] focus:outline-none focus:border-[#c7f284]/50 font-mono"
            />
            <div className="absolute right-2 top-2 flex items-center gap-1">
              <button
                onClick={() => setIsRegex(!isRegex)}
                className={`text-[9px] px-1 py-0.5 rounded uppercase font-bold transition-colors cursor-pointer ${isRegex ? 'bg-[#c7f284]/20 text-[#c7f284] border border-[#c7f284]/40' : 'bg-[#1a1c29] text-[#64748b] border border-[#1f212e] hover:text-[#e2e8f0]'}`}
                title="Toggle Regular Expression Search"
              >
                rx
              </button>
              {logSearch && (
                <button 
                  onClick={() => setLogSearch('')}
                  className="text-[#64748b] hover:text-[#e2e8f0] text-[11px] px-1 cursor-pointer"
                >
                  ✕
                </button>
              )}
            </div>
          </div>
          
          <div className="flex gap-1.5 shrink-0">
            {/* Run state controls */}
            <button
              onClick={() => setIsPaused(!isPaused)}
              className={`p-1.5 border rounded-lg transition-colors flex items-center justify-center gap-1 text-[11px] font-mono font-bold uppercase cursor-pointer ${isPaused ? 'bg-amber-500/15 text-amber-400 border-amber-500/35 hover:bg-amber-500/25' : 'bg-[#10111a] text-[#94a3b8] border-[#1f212e] hover:bg-[#1a1c29] hover:text-white'}`}
              title={isPaused ? "Resume real-time logging" : "Freeze dashboard updates"}
            >
              {isPaused ? <Play className="w-3.5 h-3.5 text-amber-400 fill-amber-400/20" /> : <Pause className="w-3.5 h-3.5" />}
              <span>{isPaused ? "Frozen" : "Freeze"}</span>
            </button>

            {/* Sort Toggle */}
            <button
              onClick={() => {
                setSortOrder(prev => prev === 'desc' ? 'asc' : 'desc');
                setAutoScroll(true);
              }}
              className="p-1.5 bg-[#10111a] border border-[#1f212e] rounded-lg transition-colors flex items-center justify-center text-[#94a3b8] hover:text-white hover:bg-[#1a1c29] cursor-pointer"
              title={sortOrder === 'desc' ? "Showing Newest First (Top to Bottom). Click to flip." : "Showing Oldest First (Tail at Bottom). Click to flip."}
            >
              <ArrowUpDown className="w-3.5 h-3.5" />
              <span className="text-[10px] font-mono font-bold uppercase ml-1 block sm:hidden md:block">
                {sortOrder === 'desc' ? "Newest" : "Oldest"}
              </span>
            </button>

            {/* Settings button */}
            <button 
              onClick={() => setShowSettings(!showSettings)}
              className={`p-1.5 border rounded-lg transition-colors flex items-center justify-center cursor-pointer ${showSettings ? 'bg-[#c7f284]/15 text-[#c7f284] border-[#c7f284]/30' : 'bg-[#10111a] text-[#94a3b8] border-[#1f212e] hover:text-white hover:bg-[#1a1c29]'}`}
              title="Configure logger retention & size presets"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
            </button>

            {/* Clear logs */}
            <button 
              onClick={() => {
                setLogs([]);
                localStorage.removeItem('juipter_auto_logs');
              }}
              className="p-1.5 bg-[#10111a] border border-[#1f212e] rounded-lg transition-colors hover:bg-rose-950/30 hover:border-rose-800/40 hover:text-rose-400 text-[#64748b] flex items-center justify-center cursor-pointer"
              title="Clear all logs"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>

            {/* Export choices */}
            <div className="relative group">
              <button 
                className="p-1.5 bg-[#10111a] border border-[#1f212e] rounded-lg text-[#94a3b8] hover:text-white hover:bg-[#1a1c29] cursor-pointer flex items-center gap-1"
                title="Download log logs in multiple formats"
              >
                <Download className="w-3.5 h-3.5" />
              </button>
              <div className="absolute right-0 top-full mt-1.5 w-32 bg-[#0d0e16] border border-[#1f212e] rounded-lg shadow-xl hidden group-hover:block z-50 text-[10px]">
                <button 
                  onClick={() => {
                    const exportContent = JSON.stringify(logs, null, 2);
                    const blob = new Blob([exportContent], { type: 'application/json' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `trading_agent_logs_${Date.now()}.json`;
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    URL.revokeObjectURL(url);
                  }}
                  className="w-full text-left px-3 py-2 hover:bg-[#151622] text-[#94a3b8] hover:text-white cursor-pointer font-bold uppercase transition-colors"
                >
                  Export JSON
                </button>
                <button 
                  onClick={handleExportCsv}
                  className="w-full text-left px-3 py-2 border-t border-[#1f212e]/50 hover:bg-[#151622] text-[#94a3b8] hover:text-white cursor-pointer font-bold uppercase transition-colors"
                >
                  Export CSV
                </button>
                <button 
                  onClick={handleExportText}
                  className="w-full text-left px-3 py-2 border-t border-[#1f212e]/50 hover:bg-[#151622] text-[#94a3b8] hover:text-white cursor-pointer font-bold uppercase transition-colors"
                >
                  Export Text
                </button>
              </div>
            </div>

          </div>
        </div>

        {/* Real-time Category filters */}
        <div className="flex flex-wrap items-center gap-1 text-[9px] font-mono leading-none pt-1">
          <span className="text-[#64748b] mr-1 uppercase flex items-center gap-1 font-bold">
            <Filter className="w-2.5 h-2.5" /> Category:
          </span>
          {['all', 'scanner', 'trade', 'risk', 'dexscreener', 'wallet', 'system'].map((cat) => (
            <button
              key={cat}
              onClick={() => setLogCategoryFilter(cat)}
              className={`px-1.5 py-0.5 rounded uppercase font-bold tracking-tight border transition-all cursor-pointer ${logCategoryFilter === cat ? 'bg-[#c7f284]/12 text-[#c7f284] border-[#c7f284]/35' : 'bg-transparent text-[#64748b] border-[#1f212e] hover:text-[#94a3b8]'}`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Real-time Level filters */}
        <div className="flex flex-wrap items-center gap-1 text-[9px] font-mono leading-none">
          <span className="text-[#64748b] mr-1 uppercase flex items-center gap-1 font-bold">
            <SlidersHorizontal className="w-2.5 h-2.5" /> Level:
          </span>
          {['all', 'success', 'info', 'warn', 'err'].map((lvl) => (
            <button
              key={lvl}
              onClick={() => setLogLevelFilter(lvl)}
              className={`px-1.5 py-0.5 rounded uppercase font-bold tracking-tight border transition-all cursor-pointer ${logLevelFilter === lvl ? 'bg-indigo-500/15 text-indigo-400 border-indigo-500/35' : 'bg-transparent text-[#64748b] border-[#1f212e] hover:text-[#94a3b8]'}`}
            >
              {lvl === 'err' ? 'error' : lvl === 'warn' ? 'warning' : lvl}
            </button>
          ))}
          {(logSearch || logCategoryFilter !== 'all' || logLevelFilter !== 'all') && (
            <button 
              onClick={() => {
                setLogSearch('');
                setLogCategoryFilter('all');
                setLogLevelFilter('all');
              }}
              className="ml-auto px-1.5 py-0.5 text-[8px] uppercase font-bold text-[#c7f284] hover:text-white border border-[#c7f284]/23 rounded bg-[#c7f284]/5 cursor-pointer"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* 3. Dropdown / Sliding Terminal Settings Option drawer */}
      {showSettings && (
        <div className="bg-[#0b0c12] border-b border-[#1f212e] p-3 text-[11px] font-mono grid grid-cols-1 sm:grid-cols-3 gap-4 shrink-0 transition-all">
          <div>
            <span className="block text-[#64748b] font-bold uppercase tracking-wider text-[9px] mb-1.5 flex items-center gap-1">
              <Database className="w-2.5 h-2.5 text-sky-400" /> Retention Buffer Max
            </span>
            <div className="flex items-center gap-2">
              {[100, 300, 500, 1000].map(lim => (
                <button
                  key={lim}
                  onClick={() => setRetentionLimit(lim)}
                  className={`px-1.5 py-0.5 rounded text-[10px] font-bold border cursor-pointer transition-colors ${retentionLimit === lim ? 'bg-[#c7f284]/12 border-[#c7f284]/40 text-[#c7f284]' : 'bg-[#10111a] border-[#1f212e] text-[#64748b] hover:text-slate-300'}`}
                >
                  {lim}
                </button>
              ))}
            </div>
          </div>

          <div>
            <span className="block text-[#64748b] font-bold uppercase tracking-wider text-[9px] mb-1.5 flex items-center gap-1">
              <SlidersHorizontal className="w-2.5 h-2.5 text-indigo-400" /> Text Size
            </span>
            <div className="flex items-center gap-2">
              {(['xs', 'sm', 'md'] as const).map(sz => (
                <button
                  key={sz}
                  onClick={() => setFontSize(sz)}
                  className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase border cursor-pointer lg:px-2.5 transition-colors ${fontSize === sz ? 'bg-[#c7f284]/12 border-[#c7f284]/40 text-[#c7f284]' : 'bg-[#10111a] border-[#1f212e] text-[#64748b] hover:text-slate-300'}`}
                >
                  {sz === 'xs' ? 'Min (9.5px)' : sz === 'sm' ? 'Mid (11px)' : 'Max (13px)'}
                </button>
              ))}
            </div>
          </div>

          <div>
            <span className="block text-[#64748b] font-bold uppercase tracking-wider text-[9px] mb-1.5 flex items-center gap-1">
              <Clock className="w-2.5 h-2.5 text-emerald-400" /> Auto-Scroll Behavior
            </span>
            <label className="flex items-center gap-1.5 cursor-pointer text-[#94a3b8] hover:text-white pt-0.5 select-none">
              <input
                type="checkbox"
                checked={autoScroll}
                onChange={(e) => {
                  setAutoScroll(e.target.checked);
                  if (e.target.checked) executeScroll();
                }}
                className="rounded bg-[#10111a] border-[#1f212e] text-[#c7f284] focus:ring-0 focus:ring-offset-0"
              />
              <span className="text-[10px]">Jump to terminal stream endpoint</span>
            </label>
          </div>
        </div>
      )}

      {/* 4. Scroll Log List Container */}
      <div 
        ref={scrollContainerRef}
        onScroll={handleScroll}
        className="p-4 overflow-y-auto max-h-[480px] space-y-1.5 font-mono flex-1 break-words"
      >
        {isPaused && (
          <div className="bg-amber-500/10 border border-amber-500/20 text-amber-500 text-[10px] py-1 px-2.5 rounded-lg mb-2 flex items-center gap-1 w-fit select-none">
            <Info className="w-3 h-3 shrink-0" />
            <span>Updates frozen. Viewing snapshot from {new Date().toLocaleTimeString()}</span>
          </div>
        )}

        {filteredLogs.length === 0 ? (
          <div className="text-[#64748b] text-center py-12 flex flex-col items-center justify-center gap-2 select-none">
            <Info className="w-6 h-6 text-[#1f212e]" />
            <span>No matching telemetry log entries found.</span>
          </div>
        ) : (
          filteredLogs.map((log) => {
            let colorClass = 'text-[#e2e8f0]';
            let prefix = '';
            let lineAccent = 'border-l-2 border-transparent';

            if (log.type === 'err' || log.type === 'error' || log.type === 'critical') {
              colorClass = 'text-[#ff4d4d]';
              prefix = 'FAIL: ';
              lineAccent = 'border-l-2 border-red-500/80 pl-1.5';
            } else if (log.type === 'priority') {
              colorClass = 'text-emerald-300 font-bold bg-emerald-950/20 px-1 py-0.5 rounded';
              prefix = 'PRIORITY: ';
              lineAccent = 'border-l-2 border-emerald-400 pl-1.5 bg-emerald-950/30';
            } else if (log.type === 'buy') {
              colorClass = 'text-[#c7f284]';
              prefix = 'BUY: ';
              lineAccent = 'border-l-2 border-[#c7f284]/80 pl-1.5';
            } else if (log.type === 'sell') {
              colorClass = 'text-[#f43f5e]';
              prefix = 'SELL: ';
              lineAccent = 'border-l-2 border-rose-500/80 pl-1.5';
            } else if (log.type === 'success') {
              colorClass = 'text-[#34d399]';
              prefix = 'WIN: ';
              lineAccent = 'border-l-2 border-emerald-500/80 pl-1.5';
            } else if (log.type === 'warn' || log.type === 'warning') {
              colorClass = 'text-[#ffb300]';
              prefix = 'WARN: ';
              lineAccent = 'border-l-2 border-amber-500/80 pl-1.5';
            } else if (log.type === 'info') {
              colorClass = 'text-[#94a3b8]';
              prefix = 'INFO: ';
            }

            const catLabels: Record<string, string> = {
              trade: 'TRADE',
              scanner: 'SCAN',
              risk: 'RISK',
              priority: 'PRIO',
              dexscreener: 'DEX',
              wallet: 'WAL',
              system: 'SYS'
            };

            const catColor: Record<string, string> = {
              trade: 'text-[#c7f284] bg-[#c7f284]/10 border-[#c7f284]/25',
              scanner: 'text-indigo-400 bg-indigo-500/10 border-indigo-500/25',
              risk: 'text-rose-400 bg-rose-500/10 border-rose-500/25',
              priority: 'text-emerald-300 bg-emerald-500/20 border-emerald-400/50 animate-pulse font-black',
              dexscreener: 'text-sky-400 bg-sky-500/10 border-sky-500/25',
              wallet: 'text-teal-400 bg-teal-500/10 border-teal-500/25',
              system: 'text-[#94a3b8] bg-[#1f212e] border-slate-700/50'
            };

            const categoryLabel = catLabels[log.category || ''] || (log.type === 'priority' ? 'PRIO' : 'SYS');
            const categoryStyle = catColor[log.category || ''] || (log.type === 'priority' ? catColor.priority : catColor.system);
            const hasMetadata = log.metadata && Object.keys(log.metadata).length > 0;
            const isExpanded = expandedLogId === log.id;

            // Extract token information for Quick Buy/Sell button from System Logs
            const tokenInfo = (() => {
              if (log.metadata) {
                const mint = log.metadata.tokenAddress || log.metadata.mint || log.metadata.address;
                if (mint && typeof mint === 'string' && mint.length >= 25 && mint !== 'So11111111111111111111111111111111111111112') {
                  return {
                    mint,
                    symbol: log.metadata.symbol || log.metadata.token || 'TOKEN'
                  };
                }
              }
              const msg = log.msg || '';
              const matchPair = msg.match(/(?:\[NEW PAIR MATCH\]|Candidate:)\s+([A-Z0-9_$]+)/i);
              const matchAddr = msg.match(/(?:address:\s*|mint:\s*|contract:\s*|\/tokens\/|token Address:\s*)([a-zA-Z0-9]{32,44})/i) ||
                                msg.match(/\b([a-zA-Z0-9]{32,44}(?:pump)?)\b/);

              if (matchAddr && matchAddr[1] && matchAddr[1] !== 'So11111111111111111111111111111111111111112') {
                const mint = matchAddr[1];
                const symbol = matchPair && matchPair[1] ? matchPair[1] : (mint.toLowerCase().endsWith('pump') ? 'PUMP' : 'TOKEN');
                return { mint, symbol };
              }
              return null;
            })();

            const activePos = tokenInfo && positions ? positions[tokenInfo.mint] : undefined;
            const isPositionOpen = activePos && (activePos.state === 'OPEN' || activePos.amount > 0);
            const posPnlPct = activePos ? (
              activePos.pnlPercent !== undefined 
                ? activePos.pnlPercent 
                : (activePos.buyPrice > 0 && activePos.currentPrice > 0 ? ((activePos.currentPrice - activePos.buyPrice) / activePos.buyPrice) * 100 : 0)
            ) : 0;
            const isPosProfit = posPnlPct > 0;

            return (
              <div 
                key={log.id} 
                className={`flex flex-col select-text leading-relaxed tracking-normal py-0.5 transition-colors border-b border-[#1f212e]/10 group/item ${lineAccent} ${hasMetadata ? 'cursor-pointer hover:bg-[#121421]/30' : ''}`}
                onClick={() => {
                  if (hasMetadata) {
                    setExpandedLogId(isExpanded ? null : log.id);
                  }
                }}
              >
                <div className="flex items-start gap-1.5">
                  <span className="text-[#475569] shrink-0 text-[9.5px] font-bold select-none pt-0.5">[{log.time}]</span>
                  <span className={`px-1 py-0.2 text-[7.5px] font-black tracking-wider rounded border shrink-0 select-none ${categoryStyle}`}>
                    {categoryLabel}
                  </span>
                  
                  <span className={`${colorClass} flex-1 ${fontStyle}`}>
                    <span className="font-semibold opacity-75">{prefix}</span>
                    {highlightText(String(log.msg || ''), logSearch)}
                    
                    {log.count && log.count > 1 ? (
                      <span className="ml-1.5 px-1 py-0.1 text-[7.5px] rounded bg-white/10 text-white font-black select-none">
                        x{log.count}
                      </span>
                    ) : null}
                  </span>

                  {/* Inline Action Buttons: Priority Profit Sell for active positions, Buy for new discovered tokens */}
                  {tokenInfo && isPositionOpen && onQuickSell ? (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onQuickSell(tokenInfo.mint, activePos?.currentPrice, posPnlPct, isPosProfit ? 'PRIORITY_PROFIT_EXIT' : 'MANUAL_SELL');
                      }}
                      className={`px-2 py-0.5 rounded text-[8.5px] font-black uppercase tracking-wider transition-all flex items-center gap-1 shrink-0 active:scale-95 cursor-pointer z-10 shadow-sm ${
                        isPosProfit
                          ? 'bg-emerald-500/25 hover:bg-emerald-500/40 text-emerald-300 border border-emerald-400/60 animate-pulse shadow-emerald-950/40'
                          : 'bg-rose-500/20 hover:bg-rose-500/35 text-rose-300 border border-rose-500/40'
                      }`}
                      title={isPosProfit ? `Priority Exit: Lock in +${posPnlPct.toFixed(2)}% profit now before price drops` : `Execute exit for ${tokenInfo.symbol}`}
                    >
                      <ShieldAlert className={`w-2.5 h-2.5 ${isPosProfit ? 'text-emerald-400' : 'text-rose-400'}`} />
                      <span>{isPosProfit ? `LOCK PROFIT (+${posPnlPct.toFixed(1)}%)` : `SELL ${tokenInfo.symbol}`}</span>
                    </button>
                  ) : tokenInfo && onQuickTrade ? (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onQuickTrade(tokenInfo.mint, tokenInfo.symbol);
                      }}
                      className="px-2 py-0.5 rounded text-[8.5px] font-black uppercase tracking-wider bg-emerald-500/20 hover:bg-emerald-500/35 text-emerald-300 border border-emerald-500/40 transition-all flex items-center gap-1 shrink-0 active:scale-95 cursor-pointer z-10 shadow-sm"
                      title={`Instantly execute sniper buy for ${tokenInfo.symbol} (${tokenInfo.mint})`}
                    >
                      <Zap className="w-2.5 h-2.5 text-emerald-400 animate-pulse" />
                      <span>BUY {tokenInfo.symbol}</span>
                    </button>
                  ) : null}

                </div>
              </div>
            );
          })
        )}
      </div>

      {/* 5. Autoscroll paused overlay indicator alert bar */}
      {showScrollBanner && (
        <button
          onClick={() => {
            setAutoScroll(true);
            executeScroll();
          }}
          className="absolute bottom-3 left-1/2 -translate-x-1/2 bg-[#c7f284] hover:bg-[#b0f554] text-black font-extrabold text-[9.5px] uppercase py-1.5 px-3.5 rounded-full shadow-lg flex items-center gap-1 animate-bounce cursor-pointer z-50 border border-black/10 select-none"
        >
          <ArrowUpDown className="w-2.5 h-2.5" />
          <span>New entries stream paused • Tap to SNAP to {sortOrder === 'desc' ? 'top' : 'bottom'}</span>
        </button>
      )}
    </div>
  );
};

const RISK_PROFILES = {
  low: { minVol24h: 100000, minLiq: 50000, momentumThresh: 0, label: 'Low', icon: ShieldCheck },
  medium: { minVol24h: 10000, minLiq: 5000, momentumThresh: -10, label: 'Medium', icon: Shield },
  high: { minVol24h: 100, minLiq: 100, momentumThresh: -100, label: 'High', icon: ShieldAlert },
};

const isValidPosition = (pos: any): boolean => {
  return !!(
    pos &&
    typeof pos.symbol === 'string' &&
    pos.symbol.trim() !== '' &&
    pos.symbol !== 'Unknown' &&
    typeof pos.buyPrice === 'number' &&
    !isNaN(pos.buyPrice) &&
    pos.buyPrice > 0 &&
    typeof pos.amount === 'number' &&
    !isNaN(pos.amount) &&
    pos.amount > 0 &&
    typeof pos.solSpent === 'number' &&
    !isNaN(pos.solSpent) &&
    pos.solSpent > 0
  );
};

export const PnLPage = ({ 
  tokenMetrics, 
  telemetryAlerts,
  user,
  externalSettings
}: { 
  tokenMetrics: Record<string, TokenMetric>; 
  telemetryAlerts?: TelemetryAlert[]; 
  user?: any;
  externalSettings: {
    manualGemInput?: string;
    setManualGemInput?: (v: string) => void;
    buyAmountSol: number;
    setBuyAmountSol: (v: number) => void;
    minTakeProfit: number;
    setMinTakeProfit: (v: number) => void;
    maxTakeProfit: number;
    setMaxTakeProfit: (v: number) => void;
    bondingCurveTakeProfit?: number;
    setBondingCurveTakeProfit?: (v: number) => void;
    stopLoss: number;
    setStopLoss: (v: number) => void;
    bondingCurveStopLoss?: number;
    setBondingCurveStopLoss?: (v: number) => void;
    pumpSwapStopLoss?: number;
    setPumpSwapStopLoss?: (v: number) => void;
    unknownStopLoss?: number;
    setUnknownStopLoss?: (v: number) => void;
    maxPositions: number;
    setMaxPositions: (v: number) => void;
    slippage: number;
    setSlippage: (v: number) => void;
    hardenedMinBondingProgress?: number;
    setHardenedMinBondingProgress?: (v: number) => void;
    hardenedMaxBondingProgress?: number;
    setHardenedMaxBondingProgress?: (v: number) => void;
    hardenedMinAge?: number;
    setHardenedMinAge?: (v: number) => void;
    hardenedMaxAge?: number;
    setHardenedMaxAge?: (v: number) => void;
    hardenedMcapMinPump?: number;
    setHardenedMcapMinPump?: (v: number) => void;
    hardenedMcapMinRaydium?: number;
    setHardenedMcapMinRaydium?: (v: number) => void;
    hardenedMcapMax?: number;
    setHardenedMcapMax?: (v: number) => void;
    hardenedLiquidityMin?: number;
    setHardenedLiquidityMin?: (v: number) => void;
    hardenedLiquidityRatio?: number;
    setHardenedLiquidityRatio?: (v: number) => void;
    hardenedMaxRiskScore?: number;
    setHardenedMaxRiskScore?: (v: number) => void;
    hardenedMaxDevOwnership?: number;
    setHardenedMaxDevOwnership?: (v: number) => void;
    hardenedMaxTop10?: number;
    setHardenedMaxTop10?: (v: number) => void;
    hardenedMinUniqueBuyers30s?: number;
    setHardenedMinUniqueBuyers30s?: (v: number) => void;
    hardenedMinBuyCount30s?: number;
    setHardenedMinBuyCount30s?: (v: number) => void;
    hardenedMaxBuyCount30s?: number;
    setHardenedMaxBuyCount30s?: (v: number) => void;
    hardenedMinBuySellRatio?: number;
    setHardenedMinBuySellRatio?: (v: number) => void;
    hardenedMaxBuySellRatio?: number;
    setHardenedMaxBuySellRatio?: (v: number) => void;
    hardenedMaxPriceChange1m?: number;
    setHardenedMaxPriceChange1m?: (v: number) => void;
    hardenedMinLatency?: number;
    setHardenedMinLatency?: (v: number) => void;
    hardenedMaxLatency?: number;
    setHardenedMaxLatency?: (v: number) => void;
    hardenedMatchRequirement?: number;
    setHardenedMatchRequirement?: (v: number) => void;
    tradePumpFun?: boolean;
    setTradePumpFun?: (v: boolean) => void;
    tradeRaydium?: boolean;
    setTradeRaydium?: (v: boolean) => void;
    tradeBonding?: boolean;
    setTradeBonding?: (v: boolean) => void;
    tradeUnknown?: boolean;
    setTradeUnknown?: (v: boolean) => void;
    hardenedMinProfit5m?: number;
    setHardenedMinProfit5m?: (v: number) => void;
    enableLatencyGuard?: boolean;
    setEnableLatencyGuard?: (v: boolean) => void;
    rpcLatency?: number | null;
    rpcUrl: string;
    setRpcUrl: (v: string) => void;
    rpcUrl2: string;
    setRpcUrl2: (v: string) => void;
    masterMonitorRpc?: string;
    setMasterMonitorRpc?: (v: string) => void;
    masterMonitorRpc2?: string;
    setMasterMonitorRpc2?: (v: string) => void;
    masterMonitorWs?: string;
    setMasterMonitorWs?: (v: string) => void;
    isSecondaryActive?: boolean;
    setIsSecondaryActive?: (v: boolean) => void;
    customWsUrl: string;
    setCustomWsUrl: (v: string) => void;
    telemetryWhaleBuyMin?: number;
    setTelemetryWhaleBuyMin?: (v: number) => void;
    telemetryHighBuyMin?: number;
    setTelemetryHighBuyMin?: (v: number) => void;
    telemetryVolumeSpikeMin?: number;
    setTelemetryVolumeSpikeMin?: (v: number) => void;
    telemetryAllowWhaleBuy?: boolean;
    setTelemetryAllowWhaleBuy?: (v: boolean) => void;
    telemetryAllowHighBuy?: boolean;
    setTelemetryAllowHighBuy?: (v: boolean) => void;
    telemetryAllowVolumeSpike?: boolean;
    setTelemetryAllowVolumeSpike?: (v: boolean) => void;
    telemetryAllowMigrated?: boolean;
    setTelemetryAllowMigrated?: (v: boolean) => void;
    telemetryAllowGoldenCross?: boolean;
    setTelemetryAllowGoldenCross?: (v: boolean) => void;
    maxRebuyTimes?: number;
    setMaxRebuyTimes?: (v: number) => void;
    tradeOnlyOnce?: boolean;
    setTradeOnlyOnce?: (v: boolean) => void;
    apiKey?: string;
    setApiKey?: (v: string) => void;
    jupiterRpcUrl?: string;
    setJupiterRpcUrl?: (v: string) => void;
    privateKey?: string;
    setPrivateKey?: (v: string) => void;
    onPositionsChange?: (v: Record<string, any>) => void;
    setCurrentPage?: (page: any) => void;
  }
}) => {
  const {
    buyAmountSol: tradeAmount, setBuyAmountSol: setTradeAmount,
    maxTakeProfit: takeProfitPct, setMaxTakeProfit: setTakeProfitPct,
    minTakeProfit, setMinTakeProfit,
    bondingCurveTakeProfit = 25, setBondingCurveTakeProfit = () => {},
    stopLoss, setStopLoss,
    bondingCurveStopLoss = -15, setBondingCurveStopLoss = () => {},
    pumpSwapStopLoss = -15, setPumpSwapStopLoss = () => {},
    unknownStopLoss = -20, setUnknownStopLoss = () => {},
    maxPositions, setMaxPositions,
    slippage, setSlippage,
    hardenedMinBondingProgress = 0, setHardenedMinBondingProgress = () => {},
    hardenedMaxBondingProgress = 100, setHardenedMaxBondingProgress = () => {},
    hardenedMinAge = 0, setHardenedMinAge = () => {},
    hardenedMaxAge = 120, setHardenedMaxAge = () => {},
    hardenedMinLatency = 0, setHardenedMinLatency = () => {},
    hardenedMaxLatency = 250, setHardenedMaxLatency = () => {},
    hardenedMatchRequirement = 100, setHardenedMatchRequirement = () => {},
    rpcLatency = null,
    hardenedMcapMinPump = 65000, setHardenedMcapMinPump = () => {},
    hardenedMcapMinRaydium = 110000, setHardenedMcapMinRaydium = () => {},
    hardenedMcapMax = 2500000, setHardenedMcapMax = () => {},
    hardenedLiquidityMin = 55000, setHardenedLiquidityMin = () => {},
    hardenedLiquidityRatio = 7, setHardenedLiquidityRatio = () => {},
    hardenedMaxRiskScore = 22, setHardenedMaxRiskScore = () => {},
    hardenedMaxDevOwnership = 80, setHardenedMaxDevOwnership = () => {},
    hardenedMaxTop10 = 14.0, setHardenedMaxTop10 = () => {},
    hardenedMinUniqueBuyers30s = 6, setHardenedMinUniqueBuyers30s = () => {},
    hardenedMinBuyCount30s = 4, setHardenedMinBuyCount30s = () => {},
    hardenedMaxBuyCount30s = 12, setHardenedMaxBuyCount30s = () => {},
    hardenedMinBuySellRatio = 2.5, setHardenedMinBuySellRatio = () => {},
    hardenedMaxBuySellRatio = 5.5, setHardenedMaxBuySellRatio = () => {},
    hardenedMaxPriceChange1m = 10.0, setHardenedMaxPriceChange1m = () => {},
    tradePumpFun = true, setTradePumpFun = () => {},
    tradeRaydium = true, setTradeRaydium = () => {},
    tradeBonding = true, setTradeBonding = () => {},
    tradeUnknown = true, setTradeUnknown = () => {},
    hardenedMinProfit5m = 1.5, setHardenedMinProfit5m = () => {},
    enableLatencyGuard = true, setEnableLatencyGuard = () => {},
    rpcUrl, setRpcUrl,
    rpcUrl2, setRpcUrl2,
    masterMonitorRpc: propMasterMonitorRpc = '',
    setMasterMonitorRpc: propSetMasterMonitorRpc = () => {},
    masterMonitorRpc2: propMasterMonitorRpc2 = '',
    setMasterMonitorRpc2: propSetMasterMonitorRpc2 = () => {},
    masterMonitorWs: propMasterMonitorWs = '',
    setMasterMonitorWs: propSetMasterMonitorWs = () => {},
    isSecondaryActive = false, setIsSecondaryActive = () => {},
    customWsUrl, setCustomWsUrl,
    telemetryWhaleBuyMin = 500000, setTelemetryWhaleBuyMin = () => {},
    telemetryHighBuyMin = 100000, setTelemetryHighBuyMin = () => {},
    telemetryVolumeSpikeMin = 1000, setTelemetryVolumeSpikeMin = () => {},
    telemetryAllowWhaleBuy = true, setTelemetryAllowWhaleBuy = () => {},
    telemetryAllowHighBuy = true, setTelemetryAllowHighBuy = () => {},
    telemetryAllowVolumeSpike = true, setTelemetryAllowVolumeSpike = () => {},
    telemetryAllowMigrated = true, setTelemetryAllowMigrated = () => {},
    telemetryAllowGoldenCross = true, setTelemetryAllowGoldenCross = () => {},
    manualGemInput = '',
    setManualGemInput = () => {},
    maxRebuyTimes = 3,
    setMaxRebuyTimes = () => {},
    tradeOnlyOnce = true,
    setTradeOnlyOnce = () => {},
    apiKey = '',
    setApiKey = () => {},
    jupiterRpcUrl = '',
    setJupiterRpcUrl = () => {},
    privateKey = '',
    setPrivateKey = () => {},
    onPositionsChange
  } = externalSettings;
  
  const jupRpcUrlToUse = jupiterRpcUrl && jupiterRpcUrl.trim() !== "" ? jupiterRpcUrl.trim() : rpcUrl;
  const navigate = useNavigate();

  const [localMasterMonitorRpc, setLocalMasterMonitorRpc] = useState(() => propMasterMonitorRpc || '');
  const masterMonitorRpc = propMasterMonitorRpc || localMasterMonitorRpc;
  const setMasterMonitorRpc = (val: string) => {
    setLocalMasterMonitorRpc(val);
    propSetMasterMonitorRpc(val);
  };

  const [localMasterMonitorRpc2, setLocalMasterMonitorRpc2] = useState(() => propMasterMonitorRpc2 || '');
  const masterMonitorRpc2 = propMasterMonitorRpc2 || localMasterMonitorRpc2;
  const setMasterMonitorRpc2 = (val: string) => {
    setLocalMasterMonitorRpc2(val);
    propSetMasterMonitorRpc2(val);
  };

  const [localMasterMonitorWs, setLocalMasterMonitorWs] = useState(() => propMasterMonitorWs || '');
  const masterMonitorWs = propMasterMonitorWs || localMasterMonitorWs;
  const setMasterMonitorWs = (val: string) => {
    setLocalMasterMonitorWs(val);
    propSetMasterMonitorWs(val);
  };
  
  const signaledPositions = useRef<Set<string>>(new Set());
  const latestPricesRef = useRef<Record<string, number>>({});

  // ── Simulation Store & Background Scan Refs ──

  const discoveryAbortRef = useRef<AbortController | null>(null);
  const monitoredTokensRef = useRef<Map<string, ScannedToken>>(new Map());
  
  const stopLossPct = Math.abs(stopLoss);
  const bondingCurveStopLossPct = Math.abs(bondingCurveStopLoss);
  const pumpSwapStopLossPct = Math.abs(pumpSwapStopLoss);
  const unknownStopLossPct = Math.abs(unknownStopLoss);

  const [unifyStopLoss, setUnifyStopLoss] = useState(false);

  const propagateSlChange = useCallback((value: number, source: 'raydium' | 'bonding' | 'pumpswap' | 'unknown') => {
    const absVal = -Math.abs(Number(value) || 0);
    if (unifyStopLoss) {
      setStopLoss(absVal);
      setBondingCurveStopLoss(absVal);
      setPumpSwapStopLoss(absVal);
      setUnknownStopLoss(absVal);
    } else {
      if (source === 'raydium') setStopLoss(absVal);
      if (source === 'bonding') setBondingCurveStopLoss(absVal);
      if (source === 'pumpswap') setPumpSwapStopLoss(absVal);
      if (source === 'unknown') setUnknownStopLoss(absVal);
    }
  }, [unifyStopLoss, setStopLoss, setBondingCurveStopLoss, setPumpSwapStopLoss, setUnknownStopLoss]);

  const getEngineSl = useCallback((netSlPct: number): number => {
    const netAbs = Math.abs(netSlPct);
    const buffer = slippage || 0;
    return Math.max(0.5, netAbs - buffer);
  }, [slippage]);
  
  // Helius Sender (Ultra-Low Latency Broadcast) Configurations
  const [senderEnabled, setSenderEnabled] = useState(false);
  const [senderApiKey, setSenderApiKey] = useState('');
  const [senderEndpoint, setSenderEndpoint] = useState('https://sender.helius-rpc.com/fast');
  const [senderSwqos, setSenderSwqos] = useState(false);

  // Helius LaserStream (Ultra-Low Latency Ingestion gRPC) Configurations
  const [laserstreamEnabled, setLaserstreamEnabled] = useState(true);
  const [laserstreamApiKey, setLaserstreamApiKey] = useState(HELIUS_API_KEY);
  const [laserstreamEndpoint, setLaserstreamEndpoint] = useState('auto');
  const [laserstreamStatus, setLaserstreamStatus] = useState<
    'connected' | 'degraded' | 'stale' | 'disconnected' | 'replaying' | 'connecting'
  >('disconnected');
  const [laserstreamIsFallback, setLaserstreamIsFallback] = useState(false);
  const [laserstreamIsSimulated, setLaserstreamIsSimulated] = useState(false);
  const [laserstreamActiveEndpoint, setLaserstreamActiveEndpoint] = useState<string | null>(null);
  const [laserstreamSlotMetrics, setLaserstreamSlotMetrics] = useState<{
    lastReceivedSlot: number;
    lastProcessedSlot: number;
    slotLag: number;
    processingLagMs: number;
    lastEventMs: number;
    queueDepth: number;
    isReplaying: boolean;
    replayFromSlot: number | null;
    ingestionState?: 'active' | 'idle' | 'replaying';
    connectedAt?: number | null;
  }>({
    lastReceivedSlot: 0,
    lastProcessedSlot: 0,
    slotLag: 0,
    processingLagMs: 0,
    lastEventMs: 0,
    queueDepth: 0,
    isReplaying: false,
    replayFromSlot: null,
    ingestionState: 'idle',
    connectedAt: null,
  });

  // DexScreener Engine Configurations
  const [dexScreenerEnabled, setDexScreenerEnabled] = useState(true);
  const [forceDexRefresh, setForceDexRefresh] = useState(0);

  // USDC Routing Configuration
  const [forceUsdcRouting, setForceUsdcRouting] = useState(false);

  const [selectedRisk, setSelectedRisk] = useState<keyof typeof RISK_PROFILES>('medium');
  const [isAuditingOpen, setIsAuditingOpen] = useState(false);
  const [showDocsModal, setShowDocsModal] = useState(false);
  const [isRunning, setIsRunning] = useState(false);
  const isPausedRef = useRef(false);
  const { manager: tradeManager } = useTradeMode();
  const [isPausedState, setIsPausedState] = useState(false);
  const setPaused = (val: boolean) => {
    isPausedRef.current = val;
    setIsPausedState(val);
  };

  // Cloud FTP Hosting State Variables
  const [ftpHost, setFtpHost] = useState('');
  const [ftpUser, setFtpUser] = useState('');
  const [ftpPass, setFtpPass] = useState('');
  const [ftpDir, setFtpDir] = useState('/htdocs');
  const [ftpWebUrl, setFtpWebUrl] = useState('');
  const [ftpSecure, setFtpSecure] = useState(false);
  const [showFtpPass, setShowFtpPass] = useState(false);

  const [ftpTesting, setFtpTesting] = useState(false);
  const [ftpBackingUp, setFtpBackingUp] = useState(false);
  const [ftpDeploying, setFtpDeploying] = useState(false);
  const [ftpConsoleLogs, setFtpConsoleLogs] = useState<{ time: string; text: string; type: 'default' | 'success' | 'error' | 'info' }[]>([]);

  const addFtpLog = (text: string, type: 'default' | 'success' | 'error' | 'info' = 'default') => {
    const time = new Date().toLocaleTimeString();
    setFtpConsoleLogs(prev => [...prev, { time, text, type }]);
  };

  const handleTestFtp = async () => {
    setFtpTesting(true);
    addFtpLog(`📡 [FTP]: Initiating TCP handshake with host ${ftpHost}...`, 'info');
    try {
      const res = await fetch('/api/hosting/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
      });
      const data = await res.json();
      if (data.success) {
        addFtpLog(`✅ [SUCCESS]: ${data.message}`, 'success');
        if (data.files && data.files.length > 0) {
          addFtpLog(`📂 Found existing files in remote '${ftpDir}':`, 'info');
          data.files.forEach((f: string) => addFtpLog(`   ${f}`, 'default'));
        } else {
          addFtpLog(`📂 Remote target directory '${ftpDir}' is currently empty. Ready for transmission.`, 'info');
        }
      } else {
        addFtpLog(`❌ [CONNECTION FAILED]: ${data.message || 'Verification failed.'}`, 'error');
      }
    } catch (e: any) {
      addFtpLog(`❌ [ERROR]: Network fetch failed: ${e.message}`, 'error');
    } finally {
      setFtpTesting(false);
    }
  };

  const handleBackupFtp = async () => {
    setFtpBackingUp(true);
    addFtpLog(`📡 [BACKUP]: Capturing system state snapshots (configurations, active positions, terminal logs)...`, 'info');
    try {
      const snapshot = {
        positions,
        stats: {
          uptime,
          totalTrades: tradeHistory.length,
          lastSync: new Date().toISOString()
        },
        logs: logs.map(l => `[${l.timestamp || Date.now()}] [${l.type.toUpperCase()}] ${l.msg || ''}`).join('\n'),
        timestamp: new Date().toISOString()
      };

      const res = await fetch('/api/hosting/backup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          data: snapshot
        })
      });
      const data = await res.json();
      if (data.success) {
        addFtpLog(`✅ [SUCCESS]: Uploaded backup archive successfully!`, 'success');
        addFtpLog(`📄 Snapshots stored at: ${ftpDir}/backups/`, 'info');
      } else {
        addFtpLog(`❌ [BACKUP FAILED]: ${data.message}`, 'error');
      }
    } catch (e: any) {
      addFtpLog(`❌ [ERROR]: Network request failed: ${e.message}`, 'error');
    } finally {
      setFtpBackingUp(false);
    }
  };

  const handleDeployFtp = async () => {
    setFtpDeploying(true);
    addFtpLog(`🚀 [DEPLOYMENT]: Compiling web static assets and setting up transmission channel...`, 'info');
    try {
      addFtpLog(`📡 Launching remote directory build synchronization... This will recursively overwrite matching assets.`, 'info');
      const res = await fetch('/api/hosting/deploy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
      });
      const data = await res.json();
      if (data.success) {
        addFtpLog(`✅ [DEPLOY COMPLETE]: ${data.message}`, 'success');
        addFtpLog(`🌐 Live hosted web app: ${ftpWebUrl}`, 'success');
      } else {
        addFtpLog(`❌ [DEPLOY FAILED]: ${data.message}`, 'error');
        addFtpLog(`💡 Tip: Make sure the project built successfully. Run "Building applet" to build dist folder first.`, 'info');
      }
    } catch (e: any) {
      addFtpLog(`❌ [ERROR]: Deployment request failed: ${e.message}`, 'error');
    } finally {
      setFtpDeploying(false);
    }
  };

  const [positions, setPositions] = useState<Record<string, Position>>({});

  useEffect(() => {
    if (onPositionsChange) {
      onPositionsChange(positions);
    }
    useAppStore.getState().updateActivePositions(() => positions as any);
  }, [positions, onPositionsChange]);

  // Listen to appStore activePositions updates (e.g. from StartupReconciliation)
  useEffect(() => {
    const unsub = useAppStore.subscribe((state) => {
      const storePositions = (state.activePositions || {}) as Record<string, Position>;
      setPositions(prev => {
        const storeMints = Object.keys(storePositions);
        const prevMints = Object.keys(prev);
        if (storeMints.length !== prevMints.length || storeMints.some(m => !prev[m])) {
          return storePositions;
        }
        return prev;
      });
    });
    return unsub;
  }, []);

  const [stats, setStats] = useState({
    trades: 0,
    wins: 0,
    losses: 0,
    pnl: 0,
    bestTrade: null as number | null
  });
  const { solBalance, availableSolBalance } = useBalanceStore();
  const realSolBalance = solBalance;
  const [retentionLimit, setRetentionLimit] = useState<number>(1000);

  // --- MANUAL CONTRACT DIRECT SEARCH & TRADING ---
  const [manualSearchInput, setManualSearchInput] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [scannedResult, setScannedResult] = useState<any | null>(null);
  const [searchError, setSearchError] = useState('');
  const [discretionaryBuyAmount, setDiscretionaryBuyAmount] = useState('0.1');
  const [isBuyingDiscretionary, setIsBuyingDiscretionary] = useState(false);

  // --- JUPITER WALLET STATUS, BALANCE, & LOGGING MONITOR ---
  const [jupiterStatus, setJupiterStatus] = useState<'DISCONNECTED' | 'CONNECTING' | 'CONNECTED' | 'ERROR'>('DISCONNECTED');
  const [jupiterAddress, setJupiterAddress] = useState<string>('');
  const [jupiterBalance, setJupiterBalance] = useState<number | null>(null);
  const [jupApiStatus, setJupApiStatus] = useState<'IDLE'|'HEALTHY'|'DEGRADED'|'ERROR'>('IDLE');
  const [jupApiPing, setJupApiPing] = useState<number>(0);
  const lastLoggedKeyRef = useRef<string>('');

  useEffect(() => {
    let isMounted = true;
    const checkJupApi = async () => {
      const res = await pingJupiterApi();
      if (!isMounted) return;
      setJupApiPing(res.pingMs);
      if (res.healthy) {
        if (res.pingMs > 1000) setJupApiStatus('DEGRADED');
        else setJupApiStatus('HEALTHY');
      } else {
        setJupApiStatus('ERROR');
      }
    };
    checkJupApi();
    const interval = setInterval(checkJupApi, 30000); // Check every 30 seconds
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, [apiKey]);

  const handleManualScan = async (overrideAddress?: string) => {
    let rawInput = (overrideAddress || manualSearchInput).trim();
    if (!rawInput) {
      setSearchError('Please enter a contract address or name');
      return;
    }

    // Extract Solana address if they pasted a URL
    const urlAddressMatch = rawInput.match(/\/([1-9A-HJ-NP-Za-km-z]{32,44})/);
    let rawAddress = urlAddressMatch ? urlAddressMatch[1] : rawInput;

    setSearchError('');
    setIsSearching(true);
    setScannedResult(null);

    const isAddress = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(rawAddress);
    addLog(`🔍 Initiating manual DexScreener scan for SOL ${isAddress ? 'contract' : 'token search'}: ${rawAddress}...`, 'info');

    try {
      if (!isAddress) {
        const searchRes = await fetch(`/api/dex/search?q=${encodeURIComponent(rawAddress)}`);
        if (!searchRes.ok) throw new Error('Search proxy error');
        const searchData = await searchRes.json();
        const solPairs = searchData.pairs?.filter((p: any) => p.chainId === 'solana') || [];
        if (solPairs.length === 0) {
          addLog(`❌ Manual scan failed: No search results found for ${rawAddress}.`, 'warn');
          setSearchError('No search results found.');
          setIsSearching(false);
          return;
        }
        rawAddress = solPairs[0].baseToken?.address;
        addLog(`✅ Search resolved to address: ${rawAddress}`, 'success');
      }

      const res = await fetch(`/api/dex/tokens/${rawAddress}`);
      if (!res.ok) {
        throw new Error(`Proxy error code: ${res.status}`);
      }
      const data = await res.json();
      if (!data || !data.pairs || data.pairs.length === 0) {
        addLog(`❌ Manual scan failed: No active trading pairs on DexScreener for ${rawAddress}.`, 'warn');
        setSearchError('Address not found or no active pairings on DexScreener.');
        return;
      }

      // Sort pairs by liquidity to fetch the primary pool
      const solPairs = data.pairs.filter((p: any) => 
        (p.quoteToken?.address === SOL_MINT || p.quoteToken?.symbol === 'SOL') &&
        (p.chainKb === 'solana' || p.chainId === 'solana' || p.dexId)
      );
      const targetPairs = solPairs.length > 0 ? solPairs : data.pairs;
      const sortedPairs = [...targetPairs].sort((a, b) => parseFloat(b.liquidity?.usd || '0') - parseFloat(a.liquidity?.usd || '0'));
      const bestPair = sortedPairs[0];

      if (!bestPair) {
        addLog(`❌ Manual scan failed: No valid Solana pairing found for ${rawAddress}.`, 'warn');
        setSearchError('No active Solana pairing found.');
        return;
      }

      const baseToken = bestPair.baseToken || {};
      const quoteToken = bestPair.quoteToken || {};
      const symbol = baseToken.symbol || 'UNKNOWN';
      const name = baseToken.name || 'Unknown Token';
      const priceUsd = parseFloat(bestPair.priceUsd || '0');
      const fdv = bestPair.fdv || 0;
      const liquidityUsd = bestPair.liquidity?.usd || 0;
      const volume24h = bestPair.volume?.h24 || 0;
      const dexId = bestPair.dexId || 'unknown';

      // Infer SOL price
      let priceNative = parseFloat(bestPair.priceNative || '0');
      const isQuoteSol = quoteToken.address === SOL_MINT || quoteToken.symbol === 'SOL';
      
      if (!isQuoteSol && priceUsd > 0) {
        try {
          const solRes = await fetch('https://api.jup.ag/price/v2?ids=So11111111111111111111111111111111111111112');
          if (solRes.ok) {
            const solData = await solRes.json();
            const solPrice = parseFloat(solData?.data?.['So11111111111111111111111111111111111111112']?.price || '');
            priceNative = priceUsd / solPrice;
          }
          } catch (err) {
          console.warn("Pricing index unreachable", err);
        }
      }

      // Setup structured metrics object
      const formattedMetric: TokenMetric = {
        address: rawAddress,
        symbol,
        priceUsd,
        priceNative,
        marketCap: fdv || (priceUsd * 1000000000), // standard fallback if not present
        liquidity: liquidityUsd,
        volume24h,
        discoveredAt: Date.now(),
        lastUpdated: Date.now(),
        buyCount: bestPair.txns?.h24?.buys || 0,
        sellCount: bestPair.txns?.h24?.sells || 0,
        buyVolume: bestPair.volume?.h24 || 0,
        sellVolume: 0,
        priceChange5m: bestPair.priceChange?.m5 !== undefined ? parseFloat(String(bestPair.priceChange.m5)) : (bestPair.priceChange?.h1 !== undefined ? parseFloat(String(bestPair.priceChange.h1)) / 12 : 0),
        priceChange1m: bestPair.priceChange?.m5 !== undefined ? parseFloat(String(bestPair.priceChange.m5)) * 0.2 : 0,
        percentageIncrease: bestPair.priceChange?.m5 !== undefined ? parseFloat(String(bestPair.priceChange.m5)) : (bestPair.priceChange?.h1 !== undefined ? parseFloat(String(bestPair.priceChange.h1)) / 12 : 0),
        recentBuysTimeline: [],
        category: rawAddress.toLowerCase().endsWith('pump') ? 'PUMP_FUN' : 'RAYDIUM',
        isRugSafe: false,
        mintAuthorityRevoked: false,
        freezeAuthorityRevoked: false,
        liquidityBurned: false,
        top10Percentage: 100,
        requiresManualReview: true
      };

      // Push into AppStore's tokenMetrics so the entire app can identify and load it!
      useAppStore.getState().setTokenMetrics(prev => ({
        ...prev,
        [rawAddress]: formattedMetric
      }));

      setScannedResult({
        address: rawAddress,
        symbol,
        name,
        priceUsd,
        priceNative,
        fdv,
        liquidityUsd,
        volume24h,
        dexId,
        isGraduated: !rawAddress.toLowerCase().endsWith('pump')
      });

      addLog(`✨ [DEXSCREENER INGESTED] Successfully scanned & tracked ${symbol} (${name})! Price: ${priceNative.toFixed(8)} SOL | Liq: $${liquidityUsd.toLocaleString()}`, 'success');

      // Evaluate active bot criteria on manual scan
      const criteriaCheck = checkTokenCriteria(rawAddress);
      if (criteriaCheck.pass) {
        addLog(`🎯 [CRITERIA MATCH] ${symbol} matches 100% of your configured Hardened Entry Criteria!`, 'success');
      } else {
        addLog(`⚠️ [CRITERIA MISMATCH] ${symbol} does NOT match all configured Hardened Entry Criteria:`, 'warn');
        if (criteriaCheck.reason) {
          addLog(`  ↳ Reason: ${criteriaCheck.reason}`, 'warn');
        }
        if (criteriaCheck.breakdown) {
          const failing = criteriaCheck.breakdown.filter(c => !c.pass);
          if (failing.length > 0) {
            addLog(`  ↳ Failing Criteria: ${failing.map(c => `${c.name}: ${c.actual} (Limit Req: ${c.limit})`).join(' | ')}`, 'warn');
          }
        }
      }
      
    } catch (error: any) {
      addLog(`❌ Manual scan error: ${error.message}`, 'err');
      setSearchError(`Scanning failed: ${error.message}`);
    } finally {
      setIsSearching(false);
    }
  };

  const handleDiscretionaryBuyTrigger = async () => {
    if (!scannedResult) return;
    const { address, symbol, priceNative } = scannedResult;
    const amount = parseFloat(discretionaryBuyAmount);

    if (isNaN(amount) || amount <= 0) {
      addLog(`❌ Trade size must be a positive number of SOL.`, 'err');
      return;
    }

    setIsBuyingDiscretionary(true);
    addLog(`⚡ [MANUAL ORDER REQUEST] Sending discretionary swap for ${symbol} with ${amount} SOL...`, 'buy');
    
    try {
      await executeBuy(address, symbol, priceNative, amount);
    } catch (e: any) {
      addLog(`❌ Discretionary order failed: ${e.message}`, 'err');
    } finally {
      setIsBuyingDiscretionary(false);
    }
  };

  useEffect(() => {
    if (manualGemInput) {
      const urlAddressMatch = manualGemInput.match(/\/([1-9A-HJ-NP-Za-km-z]{32,44})/);
      const resolvedInput = urlAddressMatch ? urlAddressMatch[1] : manualGemInput;
      if (/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(resolvedInput)) {
        setManualSearchInput(resolvedInput);
        handleManualScan(resolvedInput);
        setManualGemInput('');
      }
    }
  }, [manualGemInput]);

  useEffect(() => {
    localStorage.setItem('juipter_auto_retentionLimit', retentionLimit.toString());
  }, [retentionLimit]);

  const pipelineCountersRef = useRef({
    discovered: 0,
    solana: 0,
    validMetrics: 0,
    criteriaPass: 0,
    buyCandidates: 0,
    buyAttempts: 0,
    buySuccess: 0,
    buyFailed: 0,
    discoveryScansStarted: 0,
    discoveryTokensFound: 0,
    discoveryNewTokens: 0,
    discoveryMetricsUpdated: 0,
    discoveryQualified: 0,
    discoveryRejected: 0,
    discoveryBuyTriggered: 0
  });

  const [logs, setLogs] = useState<LogEvent[]>([]);

  // Safe parent-level logs trimming
  useEffect(() => {
    setLogs(prev => {
      if (prev.length > retentionLimit) {
        return prev.slice(0, retentionLimit);
      }
      return prev;
    });
  }, [retentionLimit]);

  const [activeLogTab, setActiveLogTab] = useState<'terminal' | 'diagnostics' | 'leaderboard' | 'telemetry' | 'hosting' | 'advisor'>('terminal');
  const [tradeHistory, setTradeHistory] = useState<{
    id: string;
    mint: string;
    buyTime: number;
    sellTime: number;
    buyAmountSol: number;
    sellAmountSol: number;
    pnlPct: number;
  }[]>([]);

  const tradeHistoryRef = useRef(tradeHistory);
  useEffect(() => {
    tradeHistoryRef.current = tradeHistory;
  }, [tradeHistory]);

  const [uptime, setUptime] = useState(0);
  const [blacklistedMints, setBlacklistedMints] = useState<string[]>([]);
  
  const blacklistedMintsRef = useRef<string[]>(blacklistedMints);
  useEffect(() => {
    blacklistedMintsRef.current = blacklistedMints;
  }, [blacklistedMints]);

  const configRef = useRef({
    takeProfitPct, minTakeProfit, bondingCurveTakeProfit, stopLossPct, bondingCurveStopLossPct, pumpSwapStopLossPct, unknownStopLossPct, slippage, privateKey, tradeAmount, maxPositions,
    hardenedMcapMinPump, hardenedMcapMinRaydium, hardenedMcapMax,
    hardenedLiquidityMin, hardenedLiquidityRatio, hardenedMaxRiskScore,
    hardenedMaxDevOwnership, hardenedMaxTop10, hardenedMinUniqueBuyers30s,
    hardenedMinBuyCount30s, hardenedMaxBuyCount30s, hardenedMinBuySellRatio,
    hardenedMaxBuySellRatio, hardenedMaxPriceChange1m,
    hardenedMinBondingProgress, hardenedMaxBondingProgress, hardenedMinAge, hardenedMaxAge,
    hardenedMinLatency, hardenedMaxLatency, tradePumpFun, tradeRaydium, tradeBonding, tradeUnknown,
    hardenedMinProfit5m, enableLatencyGuard, rpcLatency, hardenedMatchRequirement, maxRebuyTimes, tradeOnlyOnce
  });

  configRef.current = {
    takeProfitPct, minTakeProfit, bondingCurveTakeProfit, stopLossPct, bondingCurveStopLossPct, pumpSwapStopLossPct, unknownStopLossPct, slippage, privateKey, tradeAmount, maxPositions,
    hardenedMcapMinPump, hardenedMcapMinRaydium, hardenedMcapMax,
    hardenedLiquidityMin, hardenedLiquidityRatio, hardenedMaxRiskScore,
    hardenedMaxDevOwnership, hardenedMaxTop10, hardenedMinUniqueBuyers30s,
    hardenedMinBuyCount30s, hardenedMaxBuyCount30s, hardenedMinBuySellRatio,
    hardenedMaxBuySellRatio, hardenedMaxPriceChange1m,
    hardenedMinBondingProgress, hardenedMaxBondingProgress, hardenedMinAge, hardenedMaxAge,
    hardenedMinLatency, hardenedMaxLatency, tradePumpFun, tradeRaydium, tradeBonding, tradeUnknown,
    hardenedMinProfit5m, enableLatencyGuard, rpcLatency, hardenedMatchRequirement, maxRebuyTimes, tradeOnlyOnce
  };

  const checkDexPlatformSourcesAllowed = useCallback((mint: string, dexId?: string) => {
    const metric = tokenMetricsRef.current[mint];
    const stage = detectTokenStage({
      address: mint,
      dexId: dexId || metric?.dexId,
      bondingCurveProgress: metric?.bondingCurveProgress,
      isRaydiumListed: metric?.isRaydiumListed
    });

    const { tradePumpFun, tradeRaydium, tradeBonding, tradeUnknown } = configRef.current;

    if (stage.isBonding && !tradeBonding) {
      return { pass: false, reason: "Bonding stage tokens are unselected in DEX Platform Sources" };
    }
    if (stage.platform === 'PUMP_FUN' && !tradePumpFun) {
      return { pass: false, reason: "Pump.fun tokens are unselected in DEX Platform Sources" };
    }
    if (stage.platform === 'RAYDIUM' && !tradeRaydium) {
      return { pass: false, reason: "Raydium tokens are unselected in DEX Platform Sources" };
    }
    if (stage.platform === 'PUMPSWAP' && !tradeRaydium) {
      return { pass: false, reason: "PumpSwap tokens are unselected in DEX Platform Sources" };
    }
    if (stage.platform === 'UNKNOWN' && !tradeUnknown) {
      return { pass: false, reason: "Unknown tokens are unselected in DEX Platform Sources" };
    }

    return { pass: true, reason: "" };
  }, []);

  const [walletTokens, setWalletTokens] = useState<{mint: string, amount: number, symbol?: string, price?: number, pnl?: number, costBasis?: number}[]>([]);
  const [isFetchingTokens, setIsFetchingTokens] = useState(false);

  useEffect(() => {
    localStorage.setItem('juipter_auto_apiKey', apiKey);
  }, [apiKey]);
  useEffect(() => {
    if (!privateKey) {
      localStorage.removeItem('juipter_auto_privateKey');
      return;
    }
    let active = true;
    const encryptAndStore = async () => {
      const uid = user?.uid || 'default_app_offline_salt';
      const encrypted = await encryptPrivateKey(privateKey, uid);
      if (active) {
        localStorage.setItem('juipter_auto_privateKey', encrypted);
      }
    };
    encryptAndStore();
    return () => { active = false; };
  }, [privateKey, user?.uid]);

  const isFirestoreLoading = useRef(false);
  const lastLoadedSettingsRef = useRef<{
    rpcUrl?: string;
    rpcUrl2?: string;
    customWsUrl?: string;
    apiKey?: string;
    privateKey?: string;
    senderEnabled?: boolean;
    senderApiKey?: string;
    senderEndpoint?: string;
    senderSwqos?: boolean;
    laserstreamEnabled?: boolean;
    laserstreamApiKey?: string;
    laserstreamEndpoint?: string;
    dexScreenerEnabled?: boolean;
    forceUsdcRouting?: boolean;
    ftpHost?: string;
    ftpUser?: string;
    ftpPass?: string;
    ftpDir?: string;
    ftpWebUrl?: string;
    ftpSecure?: boolean;
        blacklistedMints?: string;
    positions?: string;
    tokenMetrics?: string;
    stats?: string;
    tradeHistory?: string;
  } | null>(null);

  useEffect(() => {
    if (!user) return;
    
    const loadSettings = async () => {
      try {
        isFirestoreLoading.current = true;
        const docRef = doc(db, 'settings', user.uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          if (data.rpcUrl) {
            const sanitized = data.rpcUrl.includes('winter-methodical-river') ? DEFAULT_HELIUS_RPC : data.rpcUrl;
            setRpcUrl(sanitized);
          }
          if (data.rpcUrl2) {
            const sanitized = data.rpcUrl2.includes('winter-methodical-river') ? DEFAULT_HELIUS_RPC : data.rpcUrl2;
            setRpcUrl2(sanitized);
          }
          if (data.customWsUrl) setCustomWsUrl(data.customWsUrl);
          if (data.apiKey) {
            const dec = await decryptPrivateKey(data.apiKey, user.uid);
            setApiKey(dec);
          }
          if (data.privateKey) {
            const decrypted = await decryptPrivateKey(data.privateKey, user.uid);
            setPrivateKey(decrypted);
          }
          if (data.senderEnabled !== undefined) setSenderEnabled(data.senderEnabled === true);
          if (data.senderApiKey !== undefined) {
            const dec = await decryptPrivateKey(String(data.senderApiKey), user.uid);
            setSenderApiKey(dec);
          }
          if (data.senderEndpoint !== undefined) setSenderEndpoint(String(data.senderEndpoint));
          if (data.senderSwqos !== undefined) setSenderSwqos(data.senderSwqos === true);
          if (data.laserstreamEnabled !== undefined) setLaserstreamEnabled(data.laserstreamEnabled === true);
          if (data.laserstreamApiKey !== undefined) {
            const dec = await decryptPrivateKey(String(data.laserstreamApiKey), user.uid);
            setLaserstreamApiKey(dec);
          }
          if (data.laserstreamEndpoint !== undefined) setLaserstreamEndpoint(String(data.laserstreamEndpoint));
          if (data.dexScreenerEnabled !== undefined) setDexScreenerEnabled(data.dexScreenerEnabled === true);
          if (data.forceUsdcRouting !== undefined) setForceUsdcRouting(data.forceUsdcRouting === true);
          if (data.ftpHost !== undefined) setFtpHost(String(data.ftpHost));
          if (data.ftpUser !== undefined) setFtpUser(String(data.ftpUser));
          if (data.ftpPass !== undefined) {
            const dec = await decryptPrivateKey(String(data.ftpPass), user.uid);
            setFtpPass(dec);
          }
          if (data.ftpDir !== undefined) setFtpDir(String(data.ftpDir));
          if (data.ftpWebUrl !== undefined) setFtpWebUrl(String(data.ftpWebUrl));
          if (data.ftpSecure !== undefined) setFtpSecure(data.ftpSecure === true);
          
          if (data.blacklistedMints !== undefined) {
            try {
              setBlacklistedMints(JSON.parse(data.blacklistedMints));
            } catch (e) {
              console.error('Error parsing blacklistedMints from firestore:', e);
            }
          }
          if (data.positions !== undefined) {
            try {
              const loadedPos = JSON.parse(data.positions);
              setPositions(loadedPos);
              positionsRef.current = loadedPos;
              useAppStore.getState().updateActivePositions(() => loadedPos);
            } catch (e) {
              console.error('Error parsing positions from firestore:', e);
            }
          }
          if (data.stats !== undefined) {
            try {
              setStats(JSON.parse(data.stats));
            } catch (e) {
              console.error('Error parsing stats from firestore:', e);
            }
          }
          if (data.tradeHistory !== undefined) {
            try {
              const fsHistory = JSON.parse(data.tradeHistory);
              if (Array.isArray(fsHistory)) {
                setTradeHistory(prev => {
                  const map = new Map<string, any>();
                  prev.forEach(t => {
                    if (t && (t.id || t.mint)) {
                      map.set(t.id || `${t.mint}-${t.buyTime}`, t);
                    }
                  });
                  fsHistory.forEach((t: any) => {
                    if (t && (t.id || t.mint)) {
                      const buySol = t.buyAmountSol !== undefined && t.buyAmountSol !== null ? Number(t.buyAmountSol) : 0;
                      let sellSol = t.sellAmountSol !== undefined && t.sellAmountSol !== null ? Number(t.sellAmountSol) : 0;
                      let pnl = t.pnlPct !== undefined && t.pnlPct !== null ? Number(t.pnlPct) : 0;

                      if (sellSol >= 1000) {
                        sellSol = sellSol / 1_000_000_000;
                        pnl = buySol > 0 ? ((sellSol - buySol) / buySol) * 100 : pnl;
                      } else if (buySol > 0 && sellSol > buySol * 50 && pnl > 5000) {
                        pnl = Math.min(pnl, 100);
                        sellSol = buySol * (1 + (pnl / 100));
                      }

                      map.set(t.id || `${t.mint}-${t.buyTime}`, {
                        id: t.id || Math.random().toString(),
                        mint: t.mint || 'Unknown',
                        buyTime: t.buyTime || Date.now(),
                        sellTime: t.sellTime || Date.now(),
                        buyAmountSol: buySol,
                        sellAmountSol: sellSol,
                        pnlPct: pnl
                      });
                    }
                  });
                  const merged = Array.from(map.values());
                  merged.sort((a, b) => (b.sellTime || b.buyTime || 0) - (a.sellTime || a.buyTime || 0));
                  return merged;
                });
              }
            } catch (e) {
              console.error('Error parsing tradeHistory from firestore:', e);
            }
          }
          
          const sanitizedRpcUrl = data.rpcUrl && data.rpcUrl.includes('winter-methodical-river') 
            ? DEFAULT_HELIUS_RPC 
            : (data.rpcUrl || rpcUrl);
          const sanitizedRpcUrl2 = data.rpcUrl2 && data.rpcUrl2.includes('winter-methodical-river') 
            ? DEFAULT_HELIUS_RPC 
            : (data.rpcUrl2 || rpcUrl2);

          const decryptedKey = data.privateKey ? await decryptPrivateKey(data.privateKey, user.uid) : privateKey;

          lastLoadedSettingsRef.current = {
            rpcUrl: sanitizedRpcUrl,
            rpcUrl2: sanitizedRpcUrl2,
            customWsUrl: data.customWsUrl || customWsUrl,
            apiKey: data.apiKey || apiKey,
            privateKey: decryptedKey,
            senderEnabled: data.senderEnabled !== undefined ? data.senderEnabled : senderEnabled,
            senderApiKey: data.senderApiKey !== undefined ? data.senderApiKey : senderApiKey,
            senderEndpoint: data.senderEndpoint !== undefined ? data.senderEndpoint : senderEndpoint,
            senderSwqos: data.senderSwqos !== undefined ? data.senderSwqos : senderSwqos,
            laserstreamEnabled: data.laserstreamEnabled !== undefined ? data.laserstreamEnabled : laserstreamEnabled,
            laserstreamApiKey: data.laserstreamApiKey !== undefined ? data.laserstreamApiKey : laserstreamApiKey,
            laserstreamEndpoint: data.laserstreamEndpoint !== undefined ? data.laserstreamEndpoint : laserstreamEndpoint,
            dexScreenerEnabled: data.dexScreenerEnabled !== undefined ? data.dexScreenerEnabled : dexScreenerEnabled,
            forceUsdcRouting: data.forceUsdcRouting !== undefined ? data.forceUsdcRouting : forceUsdcRouting,
            ftpHost: data.ftpHost !== undefined ? data.ftpHost : ftpHost,
            ftpUser: data.ftpUser !== undefined ? data.ftpUser : ftpUser,
            ftpPass: data.ftpPass !== undefined ? data.ftpPass : ftpPass,
            ftpDir: data.ftpDir !== undefined ? data.ftpDir : ftpDir,
            ftpWebUrl: data.ftpWebUrl !== undefined ? data.ftpWebUrl : ftpWebUrl,
            ftpSecure: data.ftpSecure !== undefined ? data.ftpSecure : ftpSecure,
                        blacklistedMints: data.blacklistedMints || JSON.stringify(blacklistedMints),
            positions: data.positions || JSON.stringify(positions),
            stats: data.stats || JSON.stringify(stats),
            tradeHistory: data.tradeHistory || JSON.stringify(tradeHistory)
          };

          addLog({
            id: 'settings-loaded-' + Date.now(),
            time: new Date().toLocaleTimeString(),
            timestamp: Date.now(),
            msg: '📡 All system settings and configurations successfully loaded from Firestore Cloud.',
            type: 'info'
          });
        } else {
          lastLoadedSettingsRef.current = {
            rpcUrl, rpcUrl2, customWsUrl, apiKey, privateKey,
            senderEnabled, senderApiKey, senderEndpoint, senderSwqos,
            laserstreamEnabled, laserstreamApiKey, laserstreamEndpoint,
            dexScreenerEnabled, forceUsdcRouting,
            ftpHost, ftpUser, ftpPass, ftpDir, ftpWebUrl, ftpSecure,
                        blacklistedMints: JSON.stringify(blacklistedMints),
            positions: JSON.stringify(positions),
            stats: JSON.stringify(stats),
            tradeHistory: JSON.stringify(tradeHistory)
          };
        }
        } catch (err) {
        console.error('Error loading settings from Firestore:', err);
      } finally {
        isFirestoreLoading.current = false;
      }
    };
    
    loadSettings();
  }, [user]);

  useEffect(() => {
    if (!user) return;
    
    const last = lastLoadedSettingsRef.current;
    if (last && 
        last.rpcUrl === rpcUrl && 
        last.rpcUrl2 === rpcUrl2 && 
        last.customWsUrl === customWsUrl && 
        last.apiKey === apiKey && 
        last.privateKey === privateKey &&
        last.senderEnabled === senderEnabled &&
        last.senderApiKey === senderApiKey &&
        last.senderEndpoint === senderEndpoint &&
        last.senderSwqos === senderSwqos &&
        last.laserstreamEnabled === laserstreamEnabled &&
        last.laserstreamApiKey === laserstreamApiKey &&
        last.laserstreamEndpoint === laserstreamEndpoint &&
        last.dexScreenerEnabled === dexScreenerEnabled &&
        last.forceUsdcRouting === forceUsdcRouting &&
        last.ftpHost === ftpHost &&
        last.ftpUser === ftpUser &&
        last.ftpPass === ftpPass &&
        last.ftpDir === ftpDir &&
        last.ftpWebUrl === ftpWebUrl &&
        last.ftpSecure === ftpSecure &&
                last.blacklistedMints === JSON.stringify(blacklistedMints) &&
        last.positions === JSON.stringify(positions) &&
        last.stats === JSON.stringify(stats) &&
        last.tradeHistory === JSON.stringify(tradeHistory)) {
      return; // No actual change, skip saving
    }

    if (isFirestoreLoading.current) {
      return;
    }
    
    const saveSettings = async () => {
      try {
        const encryptedKey = await encryptPrivateKey(privateKey, user.uid);
        const encryptedApiKey = apiKey ? await encryptPrivateKey(apiKey, user.uid) : '';
        const encryptedSenderKey = senderApiKey ? await encryptPrivateKey(senderApiKey, user.uid) : '';
        const encryptedLaserstreamKey = laserstreamApiKey ? await encryptPrivateKey(laserstreamApiKey, user.uid) : '';
        const encryptedFtpPass = ftpPass ? await encryptPrivateKey(ftpPass, user.uid) : '';

        const docRef = doc(db, 'settings', user.uid);
        await setDoc(docRef, {
          userId: user.uid,
          rpcUrl,
          rpcUrl2,
          customWsUrl,
          apiKey: encryptedApiKey,
          privateKey: encryptedKey,
          senderEnabled,
          senderApiKey: encryptedSenderKey,
          senderEndpoint,
          senderSwqos,
          laserstreamEnabled,
          laserstreamApiKey: encryptedLaserstreamKey,
          laserstreamEndpoint,
          dexScreenerEnabled,
          forceUsdcRouting,
          ftpHost,
          ftpUser,
          ftpPass: encryptedFtpPass,
          ftpDir,
          ftpWebUrl,
          ftpSecure,
                    blacklistedMints: JSON.stringify(blacklistedMints),
          positions: JSON.stringify(positions),
          stats: JSON.stringify(stats),
          tradeHistory: JSON.stringify(tradeHistory),
          updatedAt: new Date().toISOString()
        }, { merge: true });
        
        lastLoadedSettingsRef.current = {
          rpcUrl, rpcUrl2, customWsUrl, apiKey, privateKey,
          senderEnabled, senderApiKey, senderEndpoint, senderSwqos,
          laserstreamEnabled, laserstreamApiKey, laserstreamEndpoint,
          dexScreenerEnabled, forceUsdcRouting,
          ftpHost, ftpUser, ftpPass, ftpDir, ftpWebUrl, ftpSecure,
                    blacklistedMints: JSON.stringify(blacklistedMints),
          positions: JSON.stringify(positions),
          stats: JSON.stringify(stats),
          tradeHistory: JSON.stringify(tradeHistory)
        };
        
        addLog({
          id: 'settings-saved-' + Date.now(),
          time: new Date().toLocaleTimeString(),
          timestamp: Date.now(),
          msg: '💾 App configurations and logs securely saved to Firestore Cloud.',
          type: 'success'
        });
      } catch (err: any) {
        console.error('Error saving settings to Firestore:', err);
      }
    };

    const timer = setTimeout(saveSettings, 1000);
    return () => clearTimeout(timer);
  }, [
    user, rpcUrl, rpcUrl2, customWsUrl, apiKey, privateKey,
    senderEnabled, senderApiKey, senderEndpoint, senderSwqos,
    laserstreamEnabled, laserstreamApiKey, laserstreamEndpoint,
    dexScreenerEnabled, forceUsdcRouting,
    ftpHost, ftpUser, ftpPass, ftpDir, ftpWebUrl, ftpSecure,
    blacklistedMints, positions, stats, tradeHistory
  ]);
  // Sync authoritative state from backend on mount
  useEffect(() => {
    const syncBackendTradingState = async () => {
      if (!auth.currentUser) return; // Do not attempt protected fetches when unauthenticated
      try {
        const data = await apiClient.get('/api/trading/config');
        if (data && data.isRunning !== undefined) {
          setIsRunning(data.isRunning);
        }
      } catch (e) {}

      try {
        const posData = await apiClient.get('/api/trading/positions');
        if (posData && posData.openPositions && Array.isArray(posData.openPositions)) {
          const mapped: Record<string, Position> = {};
          const valuations = posData.valuations || {};
          for (const p of posData.openPositions) {
            const mint = p.mint || p.mintAddress || p.id;
            const val = valuations[mint] || valuations[p.mint] || valuations[p.id];
            const decimals = p.decimals !== undefined ? p.decimals : (val?.tokenDecimals !== undefined ? val.tokenDecimals : 9);
            const rawAmount = p.tokenAmount !== undefined ? p.tokenAmount : (p.amountRaw ? Number(p.amountRaw) : 0);
            const amount = decimals > 0 ? rawAmount / (10 ** decimals) : rawAmount;
            const entryCostSol = val?.entryCostSol ?? p.totalSolSpent ?? p.solSpent ?? 0;
            const currentPriceSol = val?.currentPriceSol ?? p.currentPriceSol ?? p.currentPriceSOL ?? p.entryPriceSOL ?? 0;
            
            const marketValueSol = val?.marketValueSol ?? (amount > 0 && currentPriceSol > 0 ? amount * currentPriceSol : 0);
            const marketPnlSol = val?.marketPnlSol ?? (entryCostSol > 0 ? marketValueSol - entryCostSol : 0);
            const marketPnlPercent = val?.marketPnlPercent ?? (entryCostSol > 0 ? (marketPnlSol / entryCostSol) * 100 : 0);

            const executableValueSol = val?.executableValueSol ?? marketValueSol;
            const executablePnlSol = val?.executablePnlSol ?? val?.pnlSol ?? (entryCostSol > 0 ? executableValueSol - entryCostSol : 0);
            const executablePnlPercent = val?.executablePnlPercent ?? val?.pnlPercent ?? (entryCostSol > 0 ? (executablePnlSol / entryCostSol) * 100 : 0);

            mapped[mint] = {
              symbol: p.mintAddress ? p.mintAddress.slice(0, 6) : (p.mint ? p.mint.slice(0, 6) : 'TOKEN'),
              buyPrice: p.averageEntryPrice ?? p.entryPriceSOL ?? (amount > 0 && entryCostSol > 0 ? entryCostSol / amount : 0),
              currentPrice: currentPriceSol,
              solSpent: entryCostSol,
              amount,
              entryTime: p.openedAt || p.createdAt || Date.now(),
              txid: p.signature || p.buySignature || '',
              positionId: p.id,
              decimals,
              tpPct: p.tpPct,
              slPct: p.slPct,
              hasCustomTpSl: p.hasCustomTpSl,
              entryCostSol,
              currentPriceSol,
              marketValueSol,
              marketPnlSol,
              marketPnlPercent,
              executableValueSol,
              executablePnlSol,
              executablePnlPercent,
              pnlSol: marketPnlSol,
              pnlPercent: marketPnlPercent,
              source: val?.source || 'WSS',
              lastMarketPriceAt: val?.lastMarketPriceAt,
              lastExecutableQuoteAt: val?.lastExecutableQuoteAt,
              quoteAgeMs: val?.quoteAgeMs,
              status: val?.status || 'LIVE',
            };
          }
          setPositions(mapped);
          positionsRef.current = mapped;
          useAppStore.getState().updateActivePositions(() => mapped);
        }
      } catch (e) {}

      try {
        const tradesData = await apiClient.get('/api/trading/trades');
        if (tradesData && tradesData.trades && Array.isArray(tradesData.trades)) {
          setTradeHistory(tradesData.trades);
        }
      } catch (e) {}
    };

    syncBackendTradingState();
    const syncInterval = setInterval(syncBackendTradingState, 3000);
    return () => clearInterval(syncInterval);
  }, []);

  useEffect(() => {
    if (!senderEnabled) return;
    const warmConnection = async () => {
      try {
        let baseUrl = 'https://sender.helius-rpc.com';
        try {
          const u = new URL(senderEndpoint || 'https://sender.helius-rpc.com/fast');
          baseUrl = u.origin;
        } catch {}
        await fetch(`${baseUrl}/ping`);
      } catch (e) {}
    };
    warmConnection();
    const interval = setInterval(warmConnection, 30000);
    return () => clearInterval(interval);
  }, [senderEnabled, senderEndpoint]);

  const { network: tradingNetwork } = useTradingEnvironmentStore();
  const seenTxSignaturesRef = useRef<Set<string>>(new Set());
  const [lastTransportMessageAt, setLastTransportMessageAt] = useState<number | null>(null);
  const [lastDataEventAt, setLastDataEventAt] = useState<number | null>(null);
  const [lastHeartbeatAt, setLastHeartbeatAt] = useState<number | null>(null);

  useEffect(() => {
    const syncLaserstream = async () => {
      try {
        setLaserstreamStatus('connecting');
        const defaultPrograms = [
          '6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P', // Pump.fun
          '675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8', // Raydium AMM
        ];

        const res = await fetch('/api/laserstream/config', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            enabled: laserstreamEnabled,
            apiKey: laserstreamApiKey,
            network: 'mainnet',
            endpoint: laserstreamEndpoint,
            programAddresses: defaultPrograms,
          })
        });
        
        let data: any = { success: false };
        if (res.ok) {
          const contentType = res.headers.get("content-type");
          if (contentType && contentType.includes("application/json")) {
            data = await res.json();
          }
        }

        if (data.active) {
          const telStatus = data.telemetry?.status || 'connecting';
          setLaserstreamStatus(telStatus);
          setLaserstreamIsFallback(false);
          setLaserstreamIsSimulated(false);
          setLaserstreamActiveEndpoint(data.activeEndpoint || null);
          if (telStatus === 'connected') {
            addLog(`Helius LaserStream gRPC channel active (MAINNET ingestion; ${tradingNetwork.toUpperCase()} execution). Connected via regional hub: ${data.activeEndpoint || 'Auto'}`, 'success');
          }
        } else {
          const telStatus = data.telemetry?.status || 'disconnected';
          setLaserstreamStatus(telStatus);
          setLaserstreamIsFallback(false);
          setLaserstreamIsSimulated(false);
          setLaserstreamActiveEndpoint(null);
          if (laserstreamEnabled && data.telemetry?.errorMessage) {
            addLog(`Helius LaserStream: ${data.telemetry.errorMessage}`, 'info');
          }
        }
      } catch (err: any) {
        console.error("Error syncing laserstream config:", err);
        setLaserstreamStatus('disconnected');
        setLaserstreamIsFallback(false);
        setLaserstreamIsSimulated(false);
        setLaserstreamActiveEndpoint(null);
        addLog(`Helius LaserStream sync failed: ${err.message}`, 'error');
      }
    };

    syncLaserstream();
  }, [laserstreamEnabled, laserstreamApiKey, laserstreamEndpoint]);

  // Manage frontend Helius LaserStream EventSource connection
  useEffect(() => {
    if (!laserstreamEnabled) return;

    let eventSource: EventSource | null = null;
    let reconnectTimeout: number | null = null;
    let lastObservedSlot = 0;

    const recordAndDedupe = (key: string): boolean => {
      if (seenTxSignaturesRef.current.has(key)) return false;
      if (seenTxSignaturesRef.current.size > 2000) {
        const first = seenTxSignaturesRef.current.values().next().value;
        if (first) seenTxSignaturesRef.current.delete(first);
      }
      seenTxSignaturesRef.current.add(key);
      return true;
    };

    const connectSSE = () => {
      eventSource = new EventSource('/api/laserstream/stream');

      eventSource.onopen = () => {
        setLaserstreamStatus('connecting');
      };

      eventSource.onerror = (err) => {
        if (eventSource && eventSource.readyState === EventSource.CLOSED) {
          setLaserstreamStatus('disconnected');
          reconnectTimeout = window.setTimeout(() => {
            connectSSE();
          }, 3000);
        }
      };

      eventSource.onmessage = (event) => {
        try {
          const now = Date.now();
          setLastTransportMessageAt(now);
          const data = JSON.parse(event.data);

          if (data.type === 'HEARTBEAT' || data.type === 'STATUS') {
            setLastHeartbeatAt(now);
            if (data.telemetry) {
              const t = data.telemetry;
              setLaserstreamStatus(t.status || 'connected');
              setLaserstreamSlotMetrics({
                lastReceivedSlot: t.lastReceivedSlot || 0,
                lastProcessedSlot: t.lastProcessedSlot || 0,
                slotLag: t.slotLag || 0,
                processingLagMs: t.processingLagMs || 0,
                lastEventMs: t.lastEventAt ? Math.max(0, Date.now() - t.lastEventAt) : 0,
                queueDepth: t.queueDepth || 0,
                isReplaying: !!t.isReplaying,
                replayFromSlot: t.replayFromSlot || null,
                ingestionState: t.ingestionState || (t.isReplaying ? 'replaying' : 'idle'),
                connectedAt: t.connectedAt || null,
              });
            } else if (data.status) {
              setLaserstreamStatus(data.status);
            }

            if (data.isFallback !== undefined) setLaserstreamIsFallback(!!data.isFallback);
            if (data.isSimulated !== undefined) setLaserstreamIsSimulated(!!data.isSimulated);
            if (data.activeEndpoint) setLaserstreamActiveEndpoint(data.activeEndpoint);
            return;
          }

          if (data.type === 'ON_CHAIN_TX') {
            setLastDataEventAt(now);
            const slot = Number(data.slot || 0);

            if (!Number.isFinite(slot) || slot <= 0) {
              return;
            }

            // Keep track of observed slots without discarding valid out-of-order block batches
            if (slot > lastObservedSlot) {
              lastObservedSlot = slot;
            }

            setLaserstreamSlotMetrics((prev) => ({
              ...prev,
              lastReceivedSlot: Math.max(prev.lastReceivedSlot, slot),
              lastProcessedSlot: Math.max(prev.lastProcessedSlot, slot),
              slotLag: 0,
              lastEventMs: 0,
            }));

            const signature = data.signature;
            const isFallback = !!data.isFallback;
            const isSim = !!data.isSimulated;
            const endpoint = data.endpoint;
            const eventNetwork = data.network || tradingNetwork;

            if (signature && !recordAndDedupe(`${eventNetwork}:${slot}:${signature}`)) {
              return; // Deduplicated
            }

            if (endpoint && endpoint !== laserstreamActiveEndpoint) {
              setLaserstreamActiveEndpoint(endpoint);
            }
            if (isFallback !== laserstreamIsFallback) {
              setLaserstreamIsFallback(isFallback);
            }
            if (isSim !== laserstreamIsSimulated) {
              setLaserstreamIsSimulated(isSim);
            }
            
            if (isSim) {
              addLog(`⚡ LaserStream gRPC [Simulated]: [slot: ${slot}] sig: ${signature.substring(0, 8)}... (${eventNetwork.toUpperCase()} Sandbox)`, 'info');
            } else if (isFallback) {
              addLog(`⚡ Live Direct Feed: [slot: ${slot}] sig: ${signature.substring(0, 8)}... (${eventNetwork.toUpperCase()} WebSocket Fallback)`, 'success');
            } else {
              addLog(`⚡ LaserStream gRPC: [slot: ${slot}] sig: ${signature.substring(0, 8)}... (${eventNetwork.toUpperCase()} Geyser Ingestion)`, 'success');
            }
          }
        } catch (e) {
          console.error("Error parsing LaserStream SSE message:", e);
        }
      };
    };

    connectSSE();

    return () => {
      if (reconnectTimeout) clearTimeout(reconnectTimeout);
      if (eventSource) {
        eventSource.close();
      }
    };
  }, [laserstreamEnabled, isRunning, tradingNetwork]);

  const botIntervalRef = useRef<number | null>(null);
  const uptimeIntervalRef = useRef<number | null>(null);
  const startTimeRef = useRef<number | null>(null);

  useEffect(() => {
    if (startTimeRef.current === null) {
      const saved = localStorage.getItem('juipter_auto_startTime');
      startTimeRef.current = saved ? Number(saved) : null;
    }
  }, []);

  useEffect(() => {
    if (startTimeRef.current) {
        localStorage.setItem('juipter_auto_startTime', startTimeRef.current.toString());
    }
  }, []);

  const fetchJupiterPriceFallback = useCallback(async (tokenMint: string): Promise<number | null> => {
    try {
      const headers: Record<string, string> = {};
      if (apiKey && !apiKey.startsWith('http')) {
        headers['x-api-key'] = apiKey;
      }
      
      const fetchWithFallback = async (proxyUrl: string, directUrl: string) => {
        try {
          const res = await fetch(proxyUrl, { headers });
          if (res.ok) {
             const contentType = res.headers.get("content-type");
             if (contentType && contentType.includes("application/json")) {
                 return await res.json();
             }
          }
        } catch (e) {}
        try {
          const resDirect = await fetch(directUrl);
          if (resDirect.ok) return await resDirect.json();
        } catch(e) {}
        return null;
      };
      
      const data = await fetchWithFallback(
        `/api/jup/price?ids=${tokenMint}&vsToken=${SOL_MINT}`,
        `https://api.jup.ag/price/v2?ids=${tokenMint}&vsToken=${SOL_MINT}`
      );
      if (data && data.data && data.data[tokenMint] && data.data[tokenMint].price) {
        const val = parseFloat(data.data[tokenMint].price);
        if (val > 0) return val;
      }
      
      const usdData = await fetchWithFallback(
        `/api/jup/price?ids=${tokenMint},${SOL_MINT}`,
        `https://api.jup.ag/price/v2?ids=${tokenMint},${SOL_MINT}`
      );
      if (usdData && usdData.data) {
        const tokenUsd = parseFloat(usdData.data[tokenMint]?.price || '0');
        const solUsd = parseFloat(usdData.data[SOL_MINT]?.price || '');
        if (tokenUsd > 0 && solUsd > 0) {
          return tokenUsd / solUsd;
        }
      }
      
      // 3. Fallback to Jupiter Swap Quote API for live token quote
      try {
        const quote = await getJupiterQuote(tokenMint, SOL_MINT, 1_000_000, 0).catch(() => null);
        if (quote && quote.outAmount && Number(quote.outAmount) > 0) {
          const solReceived = Number(quote.outAmount) / 1_000_000_000;
          if (solReceived > 0) return solReceived;
        }
      } catch (e) {}

      // 4. Fallback to MarketDataManager
      const tp = await marketDataManager.getPrice(tokenMint, 'trading');
      if (tp) {
        if (tp.priceNative && tp.priceNative > 0) return tp.priceNative;
        if (tp.priceUsd && tp.priceUsd > 0) return tp.priceUsd / (getSolPriceUsd() || 0);
      }

      // 5. Fallback to DexScreener Search API
      try {
        const searchRes = await fetch(`/api/dex/search?q=${tokenMint}`);
        if (searchRes.ok) {
          const searchJson = await searchRes.json();
          if (searchJson.pairs && Array.isArray(searchJson.pairs) && searchJson.pairs.length > 0) {
            const matchPair = searchJson.pairs.find((p: any) => p.baseToken?.address === tokenMint);
            if (matchPair) {
              const priceNative = parseFloat(matchPair.priceNative || '0');
              if (priceNative > 0) return priceNative;
              const priceUsd = parseFloat(matchPair.priceUsd || '0');
              if (priceUsd > 0) return priceUsd / getSolPriceUsd();
            }
          }
        }
      } catch (e) {}

      // 6. Fallback to Token Metrics store
      const metric = tokenMetricsRef.current[tokenMint] || useAppStore.getState().tokenMetrics[tokenMint];
      if (metric) {
        if (metric.priceNative && metric.priceNative > 0) return parseFloat(String(metric.priceNative));
        if (metric.priceUsd && metric.priceUsd > 0) return parseFloat(String(metric.priceUsd)) / getSolPriceUsd();
        if (typeof metric.bondingCurveProgress === 'number' && metric.bondingCurveProgress >= 0) {
          return 0.00000003 + (metric.bondingCurveProgress / 100) * 0.000002;
        }
      }

      // 7. Fallback to Active Position Entry / Buy Price
      const activePos = positionsRef.current[tokenMint] || positions[tokenMint];
      if (activePos) {
        const entryP = activePos.buyPrice || activePos.currentPrice;
        if (entryP && entryP > 0) return entryP;
      }

      return null;
      } catch (err) {
      console.warn(`Failed to fetch Jupiter fallback price for ${tokenMint}`, err);
      return null;
    }
  }, [apiKey]);

  const getTokenPrices = useCallback(async (mints: string[]) => {
    if (mints.length === 0) return {};
    try {
      const requestedMints = Array.from(new Set([...mints, 'So11111111111111111111111111111111111111112']));
      const marketPrices = await marketDataManager.getPrices(requestedMints, 'trading');

      let solPriceInUsd = getSolPriceUsd() || 0;
      const solTokenPrice = marketPrices.get('So11111111111111111111111111111111111111112');
      if (solTokenPrice && solTokenPrice.priceUsd != null && solTokenPrice.priceUsd > 0) {
        solPriceInUsd = solTokenPrice.priceUsd;
        setSolPriceUsd(solPriceInUsd);
      }

      const prices: any = {};
      for (const [mint, tp] of marketPrices.entries()) {
        if (mint === 'So11111111111111111111111111111111111111112') continue;

        let finalPriceInSol = tp.priceNative || (tp.priceUsd ? tp.priceUsd / solPriceInUsd : 0);
        let isStale = false;

        // Liquidity-aware sanity check comparing against a fresh Jupiter quote (throttled to 10s intervals)
        const activePos = positionsRef.current[mint];
        if (activePos && activePos.buyPrice > 0) {
          const nowMs = Date.now();
          const lastCheck = (activePos as any)._lastQuoteCheck || 0;
          if (nowMs - lastCheck > 10000) {
            (activePos as any)._lastQuoteCheck = nowMs;
            try {
              const rawAmount = activePos.amountLamports || Math.floor((activePos.amount || 1) * Math.pow(10, activePos.decimals !== undefined ? activePos.decimals : 6));
              const validationQuote = await getJupiterQuote(
                mint,
                'So11111111111111111111111111111111111111112',
                rawAmount,
                activePos.liquidityUsd || 0
              );
              if (validationQuote && validationQuote.outAmount && activePos.amount > 0) {
                const quotedPrice = Number(validationQuote.outAmount) / activePos.amount / 1e9;
                if (quotedPrice > 0) {
                  // If our price source diverges >10× from Jupiter, use Jupiter's price
                  if (finalPriceInSol > quotedPrice * 10 || finalPriceInSol < quotedPrice / 10) {
                    finalPriceInSol = quotedPrice;
                  }
                }
              }
            } catch {
              // If Jupiter fails, keep the price but mark as STALE
              isStale = true;
            }
          }
        }

        if (finalPriceInSol > 0) {
          prices[mint] = {
            price: finalPriceInSol,
            isSol: true,
            liq: tp.liquidityUsd || 0,
            isStale
          };
        }
      }

      // Fill in fallback prices directly via RPC scan if needed
      for (const mint of mints) {
        const hasPrice = prices[mint] && prices[mint].price > 0;
        if (!hasPrice) {
          const onChainPrice = await fetchJupiterPriceFallback(mint);
          if (onChainPrice && onChainPrice > 0) {
            prices[mint] = {
              price: onChainPrice,
              isSol: true,
              liq: 150000,
              isStale: false,
              isOnChainFallback: true
            };
          } else {
            prices[mint] = {
              price: 0,
              isSol: true,
              liq: 0,
              isStale: true
            };
          }
        }
      }

      for (const mint of Object.keys(prices)) {
        if (prices[mint]?.price > 0) {
          latestPricesRef.current[mint] = prices[mint].price;
        }
      }

      return prices;
    } catch (e) {
      // Fallback to on-chain for everything if API is completely timing out or down
      const prices: any = {};
      for (const mint of mints) {
        const onChainPrice = await fetchJupiterPriceFallback(mint);
        if (onChainPrice && onChainPrice > 0) {
          prices[mint] = {
            price: onChainPrice,
            isSol: true,
            liq: 150000,
            isStale: false,
            isOnChainFallback: true
          };
        } else {
          prices[mint] = {
            price: 0,
            isSol: true,
            liq: 0,
            isStale: true
          };
        }
      }

      for (const mint of Object.keys(prices)) {
        if (prices[mint]?.price > 0) {
          latestPricesRef.current[mint] = prices[mint].price;
        }
      }

      return prices;
    }
  }, [fetchJupiterPriceFallback]);

  const updateWalletTokenPrices = useCallback(async (mints: string[]) => {
    if (mints.length === 0) return;
    try {
      const prices = await getTokenPrices(mints);
      if (Object.keys(prices).length > 0) {
        setWalletTokens(prev => prev.map(pt => {
           const pData = prices[pt.mint];
           if (pData && pData.price > 0) {
              const currentPrice = pData.price;
              const pnl = pt.costBasis ? (currentPrice - pt.costBasis) / pt.costBasis : 0;
              return { ...pt, price: currentPrice, pnl };
           }
           return pt;
        }));
      }
    } catch(e) {}
  }, [getTokenPrices]);

  const fetchWalletTokens = useCallback(async () => {
    if (!privateKey || !rpcUrl) return;
    setIsFetchingTokens(true);
    try {
      const keypair = useActiveWalletStore.getState().activeWallet?.keypair;
      const activeWsUrl = (customWsUrl && customWsUrl.trim() !== "") ? customWsUrl.trim() : rpcUrl.replace('https', 'wss').replace('http', 'ws');
      const conn = new Connection(rpcUrl, { commitment: 'confirmed', wsEndpoint: activeWsUrl });
      
      // Parallelize fetching if we had multiple wallets, but for one we use the fastest method
      const accounts = await conn.getParsedTokenAccountsByOwner(
        keypair.publicKey,
        { programId: new PublicKey('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA') },
        'confirmed'
      );
      
      const tokens = accounts.value.map(acc => {
        const info = acc.account.data.parsed.info;
        return {
          mint: info.mint,
          amount: info.tokenAmount.uiAmount || 0,
        };
      }).filter(t => t.amount > 0 && t.mint !== 'So11111111111111111111111111111111111111112' && t.mint.toLowerCase() !== 'so11111111111111111111111111111111111111112');
      
      const enrichedTokens = await Promise.all(tokens.map(async t => {
        const metric = tokenMetricsRef.current[t.mint];
        // Fetch cached cost basis if needed, mock for now
        const costBasis = (metric?.priceNative || metric?.priceUsd) ? (metric.priceNative || metric.priceUsd || 0) * 0.8 : 0; 
        return { 
          ...t, 
          symbol: metric ? metric.symbol : t.mint.slice(0, 4) + '...' + t.mint.slice(-4),
          costBasis
        };
      }));
      
      setWalletTokens(enrichedTokens);

      // Kick off initial price fetch in parallel
      updateWalletTokenPrices(enrichedTokens.map(t => t.mint));
    } catch (e) {
      console.warn("Failed to fetch wallet tokens", e);
    } finally {
      setIsFetchingTokens(false);
    }
  }, [privateKey, rpcUrl, customWsUrl]);

  // Live Price Polling for Wallet Tokens
  // Depend on the actual mint set, not just walletTokens.length - if the wallet's
  // token list changes composition (e.g. tokens swapped out) while the count stays
  // the same, this effect must re-run or the interval keeps polling stale mints.
  const walletTokenMintsKey = walletTokens.map(t => t.mint).join(',');
  useEffect(() => {
    if (walletTokens.length === 0 || !isRunning) return;
    const mints = walletTokens.map(t => t.mint);
    const unsubscribe = marketDataManager.subscribe(mints, () => {
      updateWalletTokenPrices(mints);
    }, 'wallet');
    return () => unsubscribe();
  }, [walletTokenMintsKey, isRunning, updateWalletTokenPrices]);

  // Dedicated active-position price subscription with high-frequency 'activePosition' priority (750ms cache)
  const activePositionMintsKey = Object.keys(positions)
    .filter(k => {
      const p = positions[k];
      return p && typeof p === 'object' && typeof p.amount === 'number' && p.amount > 0;
    })
    .sort()
    .join(',');

  useEffect(() => {
    if (!activePositionMintsKey || !isRunning) return;
    const activeMints = activePositionMintsKey.split(',').filter(Boolean);
    if (activeMints.length === 0) return;

    const handlePriceUpdate = (priceMap: Map<string, TokenPrice>) => {
      const now = Date.now();
      const updatedMetrics: Record<string, Partial<TokenMetric>> = {};
      let hasMetricUpdates = false;

      priceMap.forEach((tokenPrice, mint) => {
        if (!tokenPrice || tokenPrice.isStale || tokenPrice.source === 'failed') return;
        const freshPrice = tokenPrice.priceNative || (tokenPrice.priceUsd ? tokenPrice.priceUsd / getSolPriceUsd() : 0);
        if (freshPrice <= 0 || !Number.isFinite(freshPrice)) return;

        // 1. Central token metrics update
        updatedMetrics[mint] = {
          priceNative: freshPrice,
          priceUsd: tokenPrice.priceUsd ?? freshPrice * getSolPriceUsd(),
          priceChange5m: tokenPrice.priceChange5m ?? 0,
          lastUpdated: now,
        };
        hasMetricUpdates = true;

        // Price updates synchronized with backend TradingMonitorWorker
      });

      if (hasMetricUpdates) {
        useAppStore.getState().setTokenMetrics(prev => {
          const next = { ...prev };
          Object.entries(updatedMetrics).forEach(([m, met]) => {
            next[m] = { ...(next[m] || {}), ...met } as TokenMetric;
          });
          tokenMetricsRef.current = next;
          return next;
        });
      }

      // 4. Update Active-position price and valuation for display
      setPositions(prev => {
        let changed = false;
        const next = { ...prev };

        priceMap.forEach((tokenPrice, mint) => {
          const pos = next[mint];
          if (!pos || !(pos.amount > 0)) return;

          const freshPrice = tokenPrice.priceNative || (tokenPrice.priceUsd ? tokenPrice.priceUsd / getSolPriceUsd() : 0);
          if (freshPrice <= 0 || !Number.isFinite(freshPrice)) return;

          const entryCost = pos.entryCostSol ?? pos.solSpent ?? 0;
          const execVal = (pos.amount || 0) * freshPrice;
          const pnlSol = execVal - entryCost;
          const pnlPct = entryCost > 0 ? (pnlSol / entryCost) * 100 : 0;

          next[mint] = {
            ...pos,
            currentPrice: freshPrice,
            currentPriceSol: freshPrice,
            executableValueSol: execVal,
            pnlSol,
            pnlPercent: pnlPct,
            isStale: false,
            realNetPnl: pnlPct / 100,
            realNetSol: pnlSol,
            lastMarketPriceAt: now,
          };
          changed = true;
        });

        if (changed) {
          positionsRef.current = next;
          useAppStore.getState().updateActivePositions(() => next);
        }
        return changed ? next : prev;
      });
    };

    const unsubscribe = marketDataManager.subscribe(activeMints, handlePriceUpdate, 'activePosition');
    return () => unsubscribe();
  }, [activePositionMintsKey, isRunning, privateKey, slippage]);

  // Sync tokenMetrics prices into active positions in real time
  useEffect(() => {
    const activeMintsList = Object.keys(positions).filter(k => {
      const p = positions[k];
      return p && typeof p === 'object' && typeof p.amount === 'number' && p.amount > 0;
    });
    if (activeMintsList.length === 0) return;

    setPositions(prev => {
      let changed = false;
      const next = { ...prev };
      activeMintsList.forEach(mint => {
        const metric = tokenMetrics[mint];
        if (metric && next[mint]) {
          const freshPrice = metric.priceNative
            ? (typeof metric.priceNative === 'number' ? metric.priceNative : parseFloat(String(metric.priceNative)))
            : 0;

          if (freshPrice > 0 && next[mint].currentPrice !== freshPrice) {
            const entryCost = next[mint].entryCostSol ?? next[mint].solSpent ?? 0;
            const execVal = (next[mint].amount || 0) * freshPrice;
            const pnlSol = execVal - entryCost;
            const pnlPct = entryCost > 0 ? (pnlSol / entryCost) * 100 : 0;

            next[mint] = {
              ...next[mint],
              currentPrice: freshPrice,
              currentPriceSol: freshPrice,
              executableValueSol: execVal,
              pnlSol,
              pnlPercent: pnlPct,
              isStale: false,
              realNetPnl: pnlPct / 100,
              realNetSol: pnlSol,
            };
            changed = true;
          }
        }
      });
      if (changed) {
        positionsRef.current = next;
        useAppStore.getState().updateActivePositions(() => next);
      }
      return changed ? next : prev;
    });
  }, [tokenMetrics]);

  useEffect(() => {
    fetchWalletTokens();

    if (!privateKey || !rpcUrl) return;

    // Standard high-reliability fallback poll interval to ensure token balances and list
    // are kept fresh even if the socket is blocked, throttled, or entirely disconnected.
    const pollInterval = setInterval(() => {
      fetchWalletTokens();
    }, 60000);

    try {
      const keypair = useActiveWalletStore.getState().activeWallet?.keypair;
      const activeWsUrl = (customWsUrl && customWsUrl.trim() !== "") ? customWsUrl.trim() : rpcUrl.replace('https', 'wss').replace('http', 'ws');
      const conn = new Connection(rpcUrl, { commitment: 'confirmed', wsEndpoint: activeWsUrl });
      
      // WSS MAIN ACCOUNT LISTENER (SOL Balance changes)
      // Highly supported, fast, and light-weight even on public/free Solana nodes.
      // Fires on any gas expenditures (i.e. buys or sells) and triggers a balance refresh.
      const subId = conn.onAccountChange(keypair.publicKey, () => {
         fetchWalletTokens();
      }, 'confirmed');
      
      // We explicitly avoid onProgramAccountChange for the SPL Token Program on free/public RPCs,
      // as they are heavily rate-limited and throw "Unexpected server response: 429" / 403 on mount.
      let tokenSubId: number | null = null;
      const isPublicRpc = rpcUrl.includes('api.mainnet-beta.solana.com') || rpcUrl.includes(HELIUS_API_KEY);
      if (!isPublicRpc) {
        try {
          tokenSubId = conn.onProgramAccountChange(
            new PublicKey('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA'),
            () => {
               fetchWalletTokens();
            },
            'confirmed',
            [
              { dataSize: 165 },
              { memcmp: { offset: 32, bytes: keypair.publicKey.toBase58() } }
            ]
          );
        } catch (tokenWssErr) {
          console.warn("SPL Program WSS setup bypassed or unsupported:", tokenWssErr);
        }
      }

      return () => { 
        clearInterval(pollInterval);
        try { conn.removeAccountChangeListener(subId); } catch (e) {}
        if (tokenSubId !== null) {
          try { conn.removeProgramAccountChangeListener(tokenSubId); } catch (e) {}
        }
      };
    } catch (e) {
      console.warn("WSS setup failed", e);
      return () => {
        clearInterval(pollInterval);
      };
    }
  }, [privateKey, rpcUrl, customWsUrl, fetchWalletTokens]);

  const addLog = useCallback((msgOrEvent: string | Partial<LogEvent>, type: string = 'info', category?: string, metadata?: Record<string, any>) => {
    let finalMsg = '';
    let finalType = type;
    let finalCategory = category || 'system';
    let finalMetadata = metadata;

    if (typeof msgOrEvent === 'string') {
      finalMsg = msgOrEvent;
      // Intelligently infer category from msg content
      const msgUpper = finalMsg.toUpperCase();
      if (msgUpper.includes('SWAP') || msgUpper.includes('BUY') || msgUpper.includes('SELL') || msgUpper.includes('TRADE') || msgUpper.includes('TRIGGER') || msgUpper.includes('ENTRY')) {
        finalCategory = 'trade';
      } else if (msgUpper.includes('SCAN') || msgUpper.includes('CRITERIA') || msgUpper.includes('DIAGNOSTICS') || msgUpper.includes('HEARTBEAT')) {
        finalCategory = 'scanner';
      } else if (msgUpper.includes('DEXSCREENER')) {
        finalCategory = 'dexscreener';
      } else if (msgUpper.includes('WALLET') || msgUpper.includes('BALANCE') || msgUpper.includes('RPC') || msgUpper.includes('LATENCY')) {
        finalCategory = 'wallet';
      } else if (msgUpper.includes('RISK') || msgUpper.includes('SAFE') || msgUpper.includes('RUG') || msgUpper.includes('BLACKLIST')) {
        finalCategory = 'risk';
      }
    } else if (msgOrEvent && typeof msgOrEvent === 'object') {
      finalMsg = msgOrEvent.msg || '';
      finalType = msgOrEvent.type || 'info';
      finalCategory = msgOrEvent.category || 'system';
      finalMetadata = msgOrEvent.metadata;
    }

    setLogs((prev) => {
      const now = Date.now();
      const time = new Date().toLocaleTimeString();

      // De-duplication check: if the last message is identical, combine it!
      if (prev.length > 0) {
        const lastLog = prev[0];
        if (lastLog.msg === finalMsg && lastLog.type === finalType && lastLog.category === finalCategory) {
          const updatedLog: LogEvent = {
            ...lastLog,
            count: (lastLog.count || 1) + 1,
            time // update time to the latest occurrence
          };
          return [updatedLog, ...prev.slice(1)];
        }
      }

      // Check if total buffer meets or exceeds the retention limit
      if (prev.length >= retentionLimit) {
        const resetNotice: LogEvent = {
          id: (now - 1).toString() + Math.random().toString(),
          time,
          timestamp: now - 1,
          msg: `🔄 BUFFER RESET: Capacity reached (${retentionLimit}/${retentionLimit}). Starting fresh.`,
          type: 'info',
          category: 'system',
          count: 1
        };
        const newLog: LogEvent = {
          id: now.toString() + Math.random().toString(),
          time,
          timestamp: now,
          msg: finalMsg,
          type: finalType,
          category: finalCategory,
          metadata: finalMetadata,
          count: 1
        };
        return [newLog, resetNotice];
      }

      const newLog: LogEvent = {
        id: now.toString() + Math.random().toString(),
        time,
        timestamp: now,
        msg: finalMsg,
        type: finalType,
        category: finalCategory,
        metadata: finalMetadata,
        count: 1
      };
      return [newLog, ...prev].slice(0, retentionLimit);
    });
  }, [retentionLimit]);

  useEffect(() => {
    if (!privateKey) {
      if (lastLoggedKeyRef.current) {
        addLog(`[JUPITER WALLET] Status: Disconnected (No private key provided)`, 'warn');
        lastLoggedKeyRef.current = '';
      }
      setJupiterStatus('DISCONNECTED');
      setJupiterAddress('');
      setJupiterBalance(null);
      return;
    }

    let isMounted = true;
    const checkWallet = async () => {
      try {
        setJupiterStatus('CONNECTING');
        let keypair;
        try {
          keypair = useActiveWalletStore.getState().activeWallet?.keypair;
        } catch (e: any) {
          setJupiterStatus('ERROR');
          setJupiterAddress('');
          setJupiterBalance(null);
          if (lastLoggedKeyRef.current !== privateKey) {
            addLog(`[JUPITER WALLET] Status: Error | Invalid private key format: ${e.message}`, 'err');
            lastLoggedKeyRef.current = privateKey;
          }
          return;
        }

        const pubKeyStr = keypair.publicKey.toBase58();
        setJupiterAddress(pubKeyStr);

        if (!rpcUrl) {
          setJupiterStatus('ERROR');
          return;
        }

        const activeWsUrl = (customWsUrl && customWsUrl.trim() !== "") ? customWsUrl.trim() : rpcUrl.replace('https', 'wss').replace('http', 'ws');
        const conn = new Connection(rpcUrl, { commitment: 'confirmed', wsEndpoint: activeWsUrl });

        const lamports = await conn.getBalance(keypair.publicKey, 'confirmed');
        const solBal = lamports / 1_000_000_000;

        if (isMounted) {
          setJupiterBalance(solBal);
          setJupiterStatus('CONNECTED');
          
          let effectiveBal = solBal;
          const isZeroBal = solBal === 0;

          if (lastLoggedKeyRef.current !== privateKey) {
            if (isZeroBal) {
              addLog(`⚠️ [JUPITER WALLET] Connected | Balance is 0.0000 SOL. RESUMING TRADING WITH SIMULATION (Virtual funds: ${effectiveBal.toFixed(4)} SOL).`, 'warn');
            } else {
              addLog(`[JUPITER WALLET] Status: Connected | Address: ${pubKeyStr.slice(0, 8)}...${pubKeyStr.slice(-8)} | Balance: ${solBal.toFixed(4)} SOL`, 'info');
            }
            lastLoggedKeyRef.current = privateKey;
          }
        }
      } catch (err: any) {
        if (isMounted) {
          setJupiterStatus('ERROR');
          if (lastLoggedKeyRef.current !== privateKey) {
            addLog(`[JUPITER WALLET] Status: Connection Error | ${err.message}`, 'err');
            lastLoggedKeyRef.current = privateKey;
          }
        }
      }
    };

    checkWallet();
    const interval = setInterval(checkWallet, 30000);

    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, [privateKey, rpcUrl, customWsUrl, addLog]);


  // Every unified trade is mirrored into the System Log. This is deliberately
  // independent from the Pulse Feed UI so an event cannot disappear from the audit trail.
  useEffect(() => {
    return unifiedTradePipeline.subscribe((event: NormalizedTradeEvent) => {
      const { source, eventId, type, symbol, mint, amount, wallet, signature, timestamp } = event;
      addLog(
        `📡 [UNIFIED TRADE] ${type.toUpperCase()} $${symbol} from ${source}`,
        'info',
        'trade',
        {
          eventId,
          source,
          tokenAddress: mint,
          symbol,
          amount,
          wallet,
          signature,
          observedAt: timestamp,
        }
      );
    });
  }, [addLog]);

  const updateUptime = useCallback(() => {
    if (!startTimeRef.current) {
        console.log("updateUptime: no start time");
        return;
    }
    const s = Math.floor((Date.now() - startTimeRef.current) / 1000);
    console.log("updateUptime: setting uptime", s);
    setUptime(s);
  }, []);

  const tokenMetricsRef = useRef(tokenMetrics);
  useEffect(() => {
    tokenMetricsRef.current = tokenMetrics;
  }, [tokenMetrics]);

  // Synchronized telemetry detector for state changes
  const lastLoggedCriteria = useRef<any>({});
  useEffect(() => {
    // Collect current values
    const currentValues = {
      tradeAmount, minTakeProfit, takeProfitPct, bondingCurveTakeProfit, stopLoss, maxPositions, slippage,
      hardenedMcapMinPump, hardenedMcapMinRaydium, hardenedMcapMax,
      hardenedLiquidityMin, hardenedLiquidityRatio, hardenedMaxRiskScore,
      hardenedMaxDevOwnership, hardenedMaxTop10, hardenedMinUniqueBuyers30s,
      hardenedMinBuyCount30s, hardenedMaxBuyCount30s, hardenedMinBuySellRatio,
      hardenedMaxBuySellRatio, hardenedMaxPriceChange1m,
      hardenedMinBondingProgress, hardenedMaxBondingProgress, hardenedMinAge, hardenedMaxAge,
      hardenedMinLatency, hardenedMaxLatency,
      tradePumpFun, tradeRaydium, tradeBonding, tradeUnknown, hardenedMinProfit5m, enableLatencyGuard, maxRebuyTimes
    };

    // Skip initial mount check to avoid false updates logging
    const isFirstRun = Object.keys(lastLoggedCriteria.current).length === 0;
    if (isFirstRun) {
      lastLoggedCriteria.current = currentValues;
      return;
    }

    const prev = lastLoggedCriteria.current;
    const changes: string[] = [];

    if (prev.tradeAmount !== currentValues.tradeAmount) changes.push(`Trade Amount: ${prev.tradeAmount} -> ${currentValues.tradeAmount} SOL`);
    if (prev.minTakeProfit !== currentValues.minTakeProfit) changes.push(`Min TP (Raydium): ${prev.minTakeProfit}% -> ${currentValues.minTakeProfit}%`);
    if (prev.bondingCurveTakeProfit !== currentValues.bondingCurveTakeProfit) changes.push(`Min TP (Pump.fun): ${prev.bondingCurveTakeProfit}% -> ${currentValues.bondingCurveTakeProfit}%`);
    if (prev.takeProfitPct !== currentValues.takeProfitPct) changes.push(`Max TP: ${prev.takeProfitPct}% -> ${currentValues.takeProfitPct}%`);
    if (prev.stopLoss !== currentValues.stopLoss) changes.push(`Stop Loss: ${prev.stopLoss}% -> ${currentValues.stopLoss}%`);
    if (prev.maxPositions !== currentValues.maxPositions) changes.push(`Max Positions: ${prev.maxPositions} -> ${currentValues.maxPositions}`);
    if (prev.slippage !== currentValues.slippage) changes.push(`Slippage: ${prev.slippage}% -> ${currentValues.slippage}%`);
    if (prev.hardenedMcapMinPump !== currentValues.hardenedMcapMinPump) changes.push(`Pump Min MC: $${prev.hardenedMcapMinPump} -> $${currentValues.hardenedMcapMinPump}`);
    if (prev.hardenedMcapMinRaydium !== currentValues.hardenedMcapMinRaydium) changes.push(`Ray P. Min MC: $${prev.hardenedMcapMinRaydium} -> $${currentValues.hardenedMcapMinRaydium}`);
    if (prev.hardenedMcapMax !== currentValues.hardenedMcapMax) changes.push(`Max MC: $${prev.hardenedMcapMax} -> $${currentValues.hardenedMcapMax}`);
    if (prev.hardenedLiquidityMin !== currentValues.hardenedLiquidityMin) changes.push(`Min Liq: $${prev.hardenedLiquidityMin} -> $${currentValues.hardenedLiquidityMin}`);
    if (prev.hardenedLiquidityRatio !== currentValues.hardenedLiquidityRatio) changes.push(`Liq Ratio: ${prev.hardenedLiquidityRatio}% -> ${currentValues.hardenedLiquidityRatio}%`);
    if (prev.hardenedMaxRiskScore !== currentValues.hardenedMaxRiskScore) changes.push(`Max Risk Score: ${prev.hardenedMaxRiskScore} -> ${currentValues.hardenedMaxRiskScore}`);
    if (prev.hardenedMaxDevOwnership !== currentValues.hardenedMaxDevOwnership) changes.push(`Max Dev Ownership: ${prev.hardenedMaxDevOwnership}% -> ${currentValues.hardenedMaxDevOwnership}%`);
    if (prev.hardenedMaxTop10 !== currentValues.hardenedMaxTop10) changes.push(`Max Top 10: ${prev.hardenedMaxTop10}% -> ${currentValues.hardenedMaxTop10}%`);
    if (prev.hardenedMinUniqueBuyers30s !== currentValues.hardenedMinUniqueBuyers30s) changes.push(`Min Unique Buyers (30s): ${prev.hardenedMinUniqueBuyers30s} -> ${currentValues.hardenedMinUniqueBuyers30s}`);
    if (prev.hardenedMinBuyCount30s !== currentValues.hardenedMinBuyCount30s) changes.push(`Min Buy Count (30s): ${prev.hardenedMinBuyCount30s} -> ${currentValues.hardenedMinBuyCount30s}`);
    if (prev.hardenedMaxBuyCount30s !== currentValues.hardenedMaxBuyCount30s) changes.push(`Max Buy Count (30s): ${prev.hardenedMaxBuyCount30s} -> ${currentValues.hardenedMaxBuyCount30s}`);
    if (prev.hardenedMinBuySellRatio !== currentValues.hardenedMinBuySellRatio) changes.push(`Min Buy/Sell Ratio: ${prev.hardenedMinBuySellRatio} -> ${currentValues.hardenedMinBuySellRatio}`);
    if (prev.hardenedMaxBuySellRatio !== currentValues.hardenedMaxBuySellRatio) changes.push(`Max Buy/Sell Ratio: ${prev.hardenedMaxBuySellRatio} -> ${currentValues.hardenedMaxBuySellRatio}`);
    if (prev.hardenedMaxPriceChange1m !== currentValues.hardenedMaxPriceChange1m) changes.push(`Max 1m Price Change: ${prev.hardenedMaxPriceChange1m}% -> ${currentValues.hardenedMaxPriceChange1m}%`);
    if (prev.hardenedMinBondingProgress !== currentValues.hardenedMinBondingProgress) changes.push(`Min Bonding Progress: ${prev.hardenedMinBondingProgress}% -> ${currentValues.hardenedMinBondingProgress}%`);
    if (prev.hardenedMaxBondingProgress !== currentValues.hardenedMaxBondingProgress) changes.push(`Max Bonding Progress: ${prev.hardenedMaxBondingProgress}% -> ${currentValues.hardenedMaxBondingProgress}%`);
    if (prev.hardenedMinAge !== currentValues.hardenedMinAge) changes.push(`Min Token Age: ${prev.hardenedMinAge}m -> ${currentValues.hardenedMinAge}m`);
    if (prev.hardenedMaxAge !== currentValues.hardenedMaxAge) changes.push(`Max Token Age: ${prev.hardenedMaxAge}m -> ${currentValues.hardenedMaxAge}m`);
    if (prev.hardenedMinLatency !== currentValues.hardenedMinLatency) changes.push(`Min Latency: ${prev.hardenedMinLatency}ms -> ${currentValues.hardenedMinLatency}ms`);
    if (prev.hardenedMaxLatency !== currentValues.hardenedMaxLatency) changes.push(`Max Latency: ${prev.hardenedMaxLatency}ms -> ${currentValues.hardenedMaxLatency}ms`);
    if (prev.tradePumpFun !== currentValues.tradePumpFun) changes.push(`Trade Pump.fun: ${prev.tradePumpFun ? 'ENABLED' : 'DISABLED'} -> ${currentValues.tradePumpFun ? 'ENABLED' : 'DISABLED'}`);
    if (prev.tradeRaydium !== currentValues.tradeRaydium) changes.push(`Trade Raydium: ${prev.tradeRaydium ? 'ENABLED' : 'DISABLED'} -> ${currentValues.tradeRaydium ? 'ENABLED' : 'DISABLED'}`);
    if (prev.tradeBonding !== currentValues.tradeBonding) changes.push(`Trade Bonding: ${prev.tradeBonding ? 'ENABLED' : 'DISABLED'} -> ${currentValues.tradeBonding ? 'ENABLED' : 'DISABLED'}`);
    if (prev.tradeUnknown !== currentValues.tradeUnknown) changes.push(`Trade Unknown: ${prev.tradeUnknown ? 'ENABLED' : 'DISABLED'} -> ${currentValues.tradeUnknown ? 'ENABLED' : 'DISABLED'}`);
    if (prev.hardenedMinProfit5m !== currentValues.hardenedMinProfit5m) changes.push(`Min 5m Profit: ${prev.hardenedMinProfit5m}% -> ${currentValues.hardenedMinProfit5m}%`);
    if (prev.maxRebuyTimes !== currentValues.maxRebuyTimes) changes.push(`Max Rebuy Times: ${prev.maxRebuyTimes} -> ${currentValues.maxRebuyTimes}`);
    if (prev.enableLatencyGuard !== currentValues.enableLatencyGuard) changes.push(`Latency Guard: ${prev.enableLatencyGuard ? 'ENABLED' : 'DISABLED'} -> ${currentValues.enableLatencyGuard ? 'ENABLED' : 'DISABLED'}`);

    if (changes.length > 0) {
      addLog(`[SYSTEM CONFIG] Criteria updated: ${changes.join(' | ')}`, 'info');
      if (prev.maxPositions !== currentValues.maxPositions) {
        const currentActiveCount = Object.keys(positionsRef.current).filter(k => isValidPosition(positionsRef.current[k])).length;
        if (currentValues.maxPositions > 0 && currentActiveCount >= currentValues.maxPositions) {
          addLog(`⏸️ [MAX POSITIONS REACHED] Limit set to ${currentValues.maxPositions} (Active: ${currentActiveCount}). Stopped searching new tokens.`, 'warn');
        }
      }

      // Immediately sync criteria & trade size to Render and Firebase
      syncManager.triggerSync({
        buyAmountSol: tradeAmount,
        minTakeProfit,
        maxTakeProfit: takeProfitPct,
        bondingCurveTakeProfit,
        stopLoss,
        maxPositions,
        slippage,
        hardenedMcapMinPump,
        hardenedMcapMinRaydium,
        hardenedMcapMax,
        hardenedLiquidityMin,
        hardenedLiquidityRatio,
        hardenedMaxRiskScore,
        hardenedMaxDevOwnership,
        hardenedMaxTop10,
        hardenedMinUniqueBuyers30s,
        hardenedMinBuyCount30s,
        hardenedMaxBuyCount30s,
        hardenedMinBuySellRatio,
        hardenedMaxBuySellRatio,
        hardenedMaxPriceChange1m,
        hardenedMinBondingProgress,
        hardenedMaxBondingProgress,
        hardenedMinAge,
        hardenedMaxAge,
        hardenedMinLatency,
        hardenedMaxLatency,
        tradePumpFun,
        tradeRaydium,
        tradeBonding,
        tradeUnknown,
        hardenedMinProfit5m,
        maxRebuyTimes,
        tradeOnlyOnce,
        enableLatencyGuard,
        updatedAt: new Date().toISOString()
      }, undefined, false);

      lastLoggedCriteria.current = currentValues;
    }
  }, [
    tradeAmount, minTakeProfit, takeProfitPct, bondingCurveTakeProfit, stopLoss, maxPositions, slippage,
    hardenedMcapMinPump, hardenedMcapMinRaydium, hardenedMcapMax,
    hardenedLiquidityMin, hardenedLiquidityRatio, hardenedMaxRiskScore,
    hardenedMaxDevOwnership, hardenedMaxTop10, hardenedMinUniqueBuyers30s,
    hardenedMinBuyCount30s, hardenedMaxBuyCount30s, hardenedMinBuySellRatio,
    hardenedMaxBuySellRatio, hardenedMaxPriceChange1m,
    hardenedMinBondingProgress, hardenedMaxBondingProgress, hardenedMinAge, hardenedMaxAge,
    hardenedMinLatency, hardenedMaxLatency, tradePumpFun, tradeRaydium, tradeBonding, tradeUnknown, hardenedMinProfit5m, maxRebuyTimes, tradeOnlyOnce, enableLatencyGuard,
    addLog
  ]);

  
  const executeJupiterSwap = async (inputMint: string, outputMint: string, amount: number | string | bigint, customSlippageBps?: number, minExpectedOutSol?: number) => {
    if (inputMint.toLowerCase().startsWith('sim') || outputMint.toLowerCase().startsWith('sim')) {
      throw new Error("Trading of tokens starting with 'sim' is strictly blocked.");
    }

    if (!user) {
      throw new Error("Authentication required: Please sign in with Google/Firebase before placing orders.");
    }

    const currentMode = useTradingEnvironmentStore.getState().network || 'paper';
    const isMainnet = currentMode === 'mainnet';
    const slippageToUse = customSlippageBps !== undefined ? customSlippageBps : Math.floor(slippage * 100);
    const isBuy = inputMint === SOL_MINT;

    if (isBuy) {
      if (!isMintOnCurve(outputMint)) {
        throw new Error(`Invalid mint address: ${outputMint}`);
      }
      const solAmount = Number(amount) / 1e9;
      const data = await apiClient.post('/api/trading/buy', {
        network: currentMode,
        mint: outputMint,
        amountSol: solAmount,
        slippageBps: slippageToUse,
        clientRequestId: `pnl_buy_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        label: 'entry',
      });
      if (!data || !data.success) {
        throw new Error(data?.error || 'Server buy execution failed');
      }
      const outAmountRawVal = data.result?.outAmountRaw || data.outAmountRaw || '0';
      return {
        txid: data.signature,
        outputAmount: Number(outAmountRawVal),
        outputAmountRaw: outAmountRawVal,
        outputAmountSol: 0,
        feeSol: 0,
        slot: 0,
      };
    } else {
      const strAmount = typeof amount === 'bigint' ? amount.toString() : (typeof amount === 'string' ? amount : String(Math.trunc(Number(amount))));
      const data = await apiClient.post('/api/trading/sell', {
        network: currentMode,
        mint: inputMint,
        amountRaw: strAmount,
        slippageBps: slippageToUse,
        clientRequestId: `pnl_sell_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        reason: 'MANUAL',
      });
      if (!data || !data.success) {
        throw new Error(data?.error || 'Server sell execution failed');
      }
      const isOutputSol = outputMint === SOL_MINT || outputMint === 'So11111111111111111111111111111111111111112';
      const outAmountRawVal = data.result?.outAmountRaw || data.outAmountRaw || '0';
      const outAmountNum = Number(outAmountRawVal);
      return {
        txid: data.signature,
        outputAmount: outAmountNum,
        outputAmountRaw: outAmountRawVal,
        outputAmountSol: isOutputSol ? (outAmountNum / 1e9) : 0,
        feeSol: 0,
        slot: 0,
      };
    }
  };

  const pendingBuysRef = useRef(0);
  const pendingBuyMintsRef = useRef<Set<string>>(new Set());
  const pendingSellMintsRef = useRef<Set<string>>(new Set());

const checkTokenCriteria = (mint: string): { 
  pass: boolean; 
  reason?: string; 
  breakdown?: { name: string; pass: boolean; actual: string; limit: string }[] 
} => {
    if (mint === 'So11111111111111111111111111111111111111112' || mint.toLowerCase() === 'so11111111111111111111111111111111111111112') {
      return { pass: false, reason: "Solana native token cannot be added as an active tradeable position." };
    }
    const {
      tradePumpFun, tradeRaydium, tradeBonding, tradeUnknown,
      hardenedMcapMinRaydium, hardenedMcapMinPump, hardenedMcapMax,
      hardenedLiquidityMin, hardenedLiquidityRatio,
      hardenedMaxTop10, hardenedMaxDevOwnership, hardenedMaxRiskScore,
      hardenedMinBondingProgress, hardenedMaxBondingProgress,
      hardenedMinAge, hardenedMaxAge, hardenedMatchRequirement, hardenedMinProfit5m
    } = configRef.current;

    const metric = tokenMetricsRef.current[mint];
    const stage = detectTokenStage({
      address: mint,
      dexId: metric?.dexId,
      bondingCurveProgress: metric?.bondingCurveProgress,
      isRaydiumListed: metric?.isRaydiumListed
    });

    if (stage.isBonding && !tradeBonding) {
      return { pass: false, reason: "Bonding stage/Pre-migration trading is disabled in configuration settings." };
    }
    if (stage.platform === 'PUMP_FUN' && !tradePumpFun) {
      return { pass: false, reason: "Pump.fun trading is disabled in configuration settings." };
    }
    if (stage.platform === 'RAYDIUM' && !tradeRaydium) {
      return { pass: false, reason: "Raydium trading is disabled in configuration settings." };
    }
    if (stage.platform === 'PUMPSWAP' && !tradeRaydium) {
      return { pass: false, reason: "PumpSwap trading is disabled in configuration settings (aligned with Raydium)." };
    }
    if (stage.platform === 'UNKNOWN' && !tradeUnknown) {
      return { pass: false, reason: "Unknown token trading is disabled in configuration settings." };
    }

    let isPump = stage.platform === 'PUMP_FUN';
    let isGraduated = stage.isMigrated && stage.platform !== 'UNKNOWN';

    // Run Full Hardened Parameter Validation if metrics exist
    if (metric) {
      const mc = metric.marketCap || 0;
      const liq = metric.liquidity || 0;
      const progress = metric.bondingCurveProgress || 0;
      const riskScore = metric.riskScore ?? 100; // Unknown = high risk
      const devPct = metric.devWalletPercentage ?? 100; // Unknown = assume 100%
      const top10 = metric.top10Percentage ?? 100; // Unknown = assume concentrated
      
      const breakdown: { name: string; pass: boolean; actual: string; limit: string }[] = [];

      const addCheckResult = (name: string, pass: boolean, actual: string, limit: string) => {
        breakdown.push({ name, pass, actual, limit });
      };

      // 1. Market Cap Min
      const configuredPumpMin = hardenedMcapMinPump !== undefined ? hardenedMcapMinPump : 65000;
      const pumpMcMin = configuredPumpMin === 65000 ? 5000 : configuredPumpMin; // If left at 65k default, allow early pump tokens starting at $5k
      const mcMin = isGraduated ? (hardenedMcapMinRaydium !== undefined && hardenedMcapMinRaydium > 0 ? hardenedMcapMinRaydium : 10000) : pumpMcMin;
      addCheckResult(
        "Min Market Cap",
        mc >= mcMin,
        `$${mc.toLocaleString()}`,
        `>= $${mcMin.toLocaleString()}`
      );

      // 2. Market Cap Max
      const mcMax = hardenedMcapMax || 2500000;
      addCheckResult(
        "Max Market Cap",
        mc <= mcMax,
        `$${mc.toLocaleString()}`,
        `<= $${mcMax.toLocaleString()}`
      );

      // 3. Liquidity Min
      const liqMin = hardenedLiquidityMin !== undefined ? hardenedLiquidityMin : 20000;
      addCheckResult(
        "Min Liquidity",
        liq >= liqMin,
        `$${liq.toLocaleString()}`,
        `>= $${liqMin.toLocaleString()}`
      );

      // 4. Liquidity to Market Cap Ratio
      const mcRatio = mc > 0 ? (liq / mc) : 0;
      const liqRatioMin = (hardenedLiquidityRatio !== undefined ? hardenedLiquidityRatio : 5) / 100;
      addCheckResult(
        "Liquidity/MC Ratio",
        mcRatio >= liqRatioMin,
        `${(mcRatio * 100).toFixed(2)}%`,
        `>= ${(liqRatioMin * 100).toFixed(2)}%`
      );

      // 5. Top 10 Holders %
      const maxTop10 = hardenedMaxTop10 !== undefined ? hardenedMaxTop10 : 14.0;
      addCheckResult(
        "Top 10 Holders %",
        top10 <= maxTop10,
        `${top10.toFixed(1)}%`,
        `<= ${maxTop10.toFixed(1)}%`
      );

      // 6. Dev Ownership %
      const maxDevPct = hardenedMaxDevOwnership !== undefined ? hardenedMaxDevOwnership : 10.0;
      const normalizedDev = devPct <= 1.0 && devPct > 0 ? devPct * 100 : devPct;
      addCheckResult(
        "Dev Wallet Ownership %",
        normalizedDev <= maxDevPct,
        `${normalizedDev.toFixed(1)}%`,
        `<= ${maxDevPct.toFixed(1)}%`
      );

      // 7. Security Rug Safety (MANDATORY Showstopper)
      const isRugSafeVal = metric.isRugSafe === true; // Must be EXPLICITLY true
      addCheckResult(
        "Rug Safety Audits",
        isRugSafeVal,
        isRugSafeVal ? "PASS (SAFE)" : "FAIL (HIGH RISK)",
        "Must be SAFE"
      );

      // 8. Risk Score Limit
      const maxRiskScore = hardenedMaxRiskScore !== undefined ? hardenedMaxRiskScore : 22;
      addCheckResult(
        "Safety Risk Score",
        riskScore <= maxRiskScore,
        `${riskScore}`,
        `<= ${maxRiskScore}`
      );

      // 9. Bonding Curve Limits (only applies to pre-migration tokens)
      let isBondingProgressValid = true;
      const minProg = hardenedMinBondingProgress !== undefined ? hardenedMinBondingProgress : 0;
      const maxProg = hardenedMaxBondingProgress !== undefined ? hardenedMaxBondingProgress : 100;
      if (!isGraduated) {
        isBondingProgressValid = progress >= minProg && progress <= maxProg;
        addCheckResult(
          "Bonding Curve Progress",
          isBondingProgressValid,
          `${progress.toFixed(1)}%`,
          `${minProg}% - ${maxProg}%`
        );
      } else {
        addCheckResult(
          "Bonding Curve Progress",
          true,
          "Graduated (100%)",
          "N/A"
        );
      }

      // 10. Token Age limits (applies to ALL tokens)
      const now = Date.now();
      const createdAtRaw = metric.pairCreatedAt;
      const normCreatedAt = createdAtRaw ? (createdAtRaw < 1000000000000 ? createdAtRaw * 1000 : createdAtRaw) : null;
      const minAg = hardenedMinAge !== undefined ? hardenedMinAge : 0;
      const maxAg = hardenedMaxAge !== undefined ? hardenedMaxAge : 120;

      if (!normCreatedAt || normCreatedAt <= 0) {
        addCheckResult("Token Age (Minutes)", false, "UNKNOWN", `${minAg}m - ${maxAg}m`);
        return { pass: false, reason: "Token creation time cannot be established. Reason: TOKEN_AGE_UNKNOWN", breakdown };
      }

      const tokenAgeMin = (now - normCreatedAt) / 60000;
      const isAgeValid = tokenAgeMin >= minAg && tokenAgeMin <= maxAg;

      addCheckResult(
        "Token Age (Minutes)",
        isAgeValid,
        `${tokenAgeMin.toFixed(1)}m`,
        `${minAg}m - ${maxAg}m`
      );

      // 11. 5M Profit momentum check
      const minProfitRequired = hardenedMinProfit5m !== undefined ? hardenedMinProfit5m : 1.5;
      const rawProfit = metric.priceChange5m ?? metric.percentageIncrease ?? metric.priceChange1m ?? null;
      const profitVal = rawProfit ?? null;
      if (profitVal === null) {
        // Missing momentum data = insufficient information
        return { pass: false, reason: 'Momentum data unavailable', breakdown };
      }
      addCheckResult(
        "5M Profit Momentum",
        profitVal >= minProfitRequired,
        `${profitVal.toFixed(2)}%`,
        `>= ${minProfitRequired.toFixed(2)}%`
      );

      // 12. Volume Check (Loosened for Pump.fun tokens to match real-world trading, 15% threshold instead of 100%)
      const vol = metric.volume24h || 0;
      const requiredVol = isGraduated ? mc : (mc * 0.15);
      const isVolumeValid = vol >= requiredVol;
      addCheckResult(
        "24H Transaction Volume",
        isVolumeValid,
        `$${vol.toLocaleString(undefined, { maximumFractionDigits: 0 })}`,
        `>= $${requiredVol.toLocaleString(undefined, { maximumFractionDigits: 0 })} (${isGraduated ? '100%' : '15%'} MC)`
      );

      // Check absolute mandatory showstoppers first
      if (!isRugSafeVal || riskScore > maxRiskScore) {
        return { pass: false, reason: `MANDATORY FAILURE: Token failed risk audit (Risk Score: ${riskScore} vs Max Allowed: ${maxRiskScore}).`, breakdown };
      }
      if (liq < liqMin) {
        return { pass: false, reason: `MANDATORY FAILURE: Liquidity $${liq.toLocaleString()} is below minimum requirement $${liqMin.toLocaleString()}.`, breakdown };
      }
      if (mcRatio < liqRatioMin) {
        return { pass: false, reason: `MANDATORY FAILURE: Liquidity/MC ratio ${(mcRatio * 100).toFixed(2)}% is below minimum requirement ${(liqRatioMin * 100).toFixed(2)}%.`, breakdown };
      }
      if (!isGraduated && !isBondingProgressValid) {
        return { pass: false, reason: `MANDATORY FAILURE: Pump.fun bonding progress ${progress.toFixed(1)}% is outside required limits (${minProg}%-${maxProg}%).`, breakdown };
      }
      if (!isAgeValid) {
        return { pass: false, reason: `MANDATORY FAILURE: Token age ${tokenAgeMin.toFixed(1)}m is outside required limits (${minAg}m-${maxAg}m).`, breakdown };
      }

      // Now compute the matching percentage for standard parameters
      const evaluatedChecks = breakdown.filter(c => c.name !== "Rug Safety Audits" && c.name !== "Bonding Curve Progress" && c.name !== "Token Age (Minutes)");
      const totalChecksCount = evaluatedChecks.length;
      const passedChecksCount = evaluatedChecks.filter(c => c.pass).length;
      const matchPercentage = totalChecksCount > 0 ? (passedChecksCount / totalChecksCount) * 100 : 100;

      const matchReq = hardenedMatchRequirement !== undefined ? hardenedMatchRequirement : 100;
      if (matchPercentage < matchReq) {
        const failingChecks = evaluatedChecks.filter(c => !c.pass).map(c => `${c.name} (${c.actual} vs Limit ${c.limit})`);
        return { 
          pass: false, 
          reason: `Failed parameter threshold. Passed ${passedChecksCount}/${totalChecksCount} (${matchPercentage.toFixed(0)}%), required ${matchReq}%. Failed checks: [ ${failingChecks.join(" | ")} ]`,
          breakdown 
        };
      }

      return { pass: true, breakdown };
    }

    return { pass: false, reason: "Missing token metrics or metadata required for hardened criteria evaluation." };
  };

  const calculateCandidateScore = (mint: string, metricOverride?: any): number => {
    const metric = metricOverride || tokenMetricsRef.current[mint];
    if (!metric) return 0;

    const { tradeBonding } = configRef.current;
    const stage = detectTokenStage({
      address: mint,
      dexId: metric.dexId,
      bondingCurveProgress: metric.bondingCurveProgress,
      isRaydiumListed: metric.isRaydiumListed,
    });

    const isBonding = stage.isBonding || (metric.bondingCurveProgress !== undefined && metric.bondingCurveProgress > 0 && metric.bondingCurveProgress < 99.5);
    const progress = metric.bondingCurveProgress || 0;

    let basePriority = 1000;
    let bondingBonus = 0;

    if (tradeBonding) {
      if (isBonding) {
        basePriority = 10000;
        // Late-bonding zone (~80% - 99.4%) gets highest preference due to stronger migration potential
        if (progress >= 80 && progress <= 99.4) {
          const lateZoneProgressRatio = (progress - 80) / (99.4 - 80); // 0.0 to 1.0
          bondingBonus = 2000 + lateZoneProgressRatio * 1500; // 2000 to 3500 points
        } else if (progress < 80) {
          bondingBonus = (progress / 80) * 1500; // 0 to 1500 points
        } else {
          bondingBonus = 2500; // > 99.4% (near or in migration)
        }
      } else {
        // Graduated Raydium token gets lower base priority so it cannot outrank a good bonding token merely because its market cap is larger
        basePriority = 1000;
      }
    } else {
      // Standard priority when Trade Bonding is disabled
      basePriority = 5000;
    }

    // 1. Recent Momentum Score
    const momentumPct = metric.priceChange5m ?? metric.percentageIncrease ?? metric.priceChange1m ?? 0;
    const momentumScore = Math.min(1500, Math.max(-500, momentumPct * 30));

    // 2. Buy / Sell Pressure Score
    const buys30s = metric.buyCount30s ?? metric.recentBuys30s ?? 0;
    const sells30s = metric.sellCount30s ?? metric.recentSells30s ?? 0;
    const buysTotal = metric.buyCount ?? buys30s;
    const sellsTotal = metric.sellCount ?? sells30s;

    const buySellRatio = sellsTotal > 0 ? (buysTotal / sellsTotal) : (buysTotal > 0 ? 3 : 1);
    const pressureScore = Math.min(1000, Math.max(0, (buySellRatio - 1) * 300)) + Math.min(500, buys30s * 50);

    // 3. Liquidity Score
    const liqUsd = metric.liquidity || 0;
    const liquidityScore = Math.min(1000, (liqUsd / 10000) * 150);

    // 4. Risk Score (lower risk score = higher safety bonus)
    const risk = metric.riskScore ?? 50;
    const riskScoreBonus = Math.max(0, (100 - risk) * 8);

    return basePriority + bondingBonus + momentumScore + pressureScore + liquidityScore + riskScoreBonus;
  };

  const calculateFallbackCandidateScore = (mint: string, metricOverride?: any): number => {
    const metric = metricOverride || tokenMetricsRef.current[mint];
    if (!metric) return 0;

    const check = checkTokenCriteria(mint);
    let passedCount = 0;
    if (check.breakdown) {
      passedCount = check.breakdown.filter(c => c.pass).length;
    } else {
      const mc = metric.marketCap || 0;
      const liq = metric.liquidity || 0;
      const isGraduated = !mint.toLowerCase().endsWith('pump');
      const mcMin = isGraduated ? (configRef.current.hardenedMcapMinRaydium || 0) : (configRef.current.hardenedMcapMinPump || 0);
      const mcMax = configRef.current.hardenedMcapMax || 999999999;
      if (mc >= mcMin && mc <= mcMax) passedCount++;
      if (liq >= (configRef.current.hardenedLiquidityMin || 20000)) passedCount++;
      if (metric.isRugSafe === true) passedCount++;
      if ((metric.riskScore ?? 100) <= (configRef.current.hardenedMaxRiskScore || 22)) passedCount++;
    }

    const baseCandidateScore = calculateCandidateScore(mint, metric);
    return (passedCount * 2000) + baseCandidateScore;
  };
  
  const _executeBuyInternal = async (mint: string, symbol: string, price: any, solAmount: number) => {
    const { maxPositions, privateKey, slippage } = configRef.current;
    // Block any token starting with 'sim' if privateKey is active
    if (privateKey && (mint.toLowerCase().startsWith('sim') || (symbol && symbol.toLowerCase().startsWith('sim')))) {
      addLog(`❌ [SIM BLOCK] Trading for tokens starting with 'sim' (symbol or address) is strictly blocked: ${symbol} (${mint})`, 'warn');
      return;
    }

    // Blacklist check (Enforced for ALL sources)
    if (blacklistedMintsRef.current.includes(mint)) {
      addLog(`❌ [BLACKLIST BLOCKED] Skipped: Token ${symbol} is blacklisted due to a previous negative trade loss.`, 'warn');
      return;
    }

    // Trade frequency guard: Max trades per token check
    const storeStateForBuy = useAppStore.getState();
    const isTradeOnce = configRef.current.tradeOnlyOnce !== undefined ? configRef.current.tradeOnlyOnce : (storeStateForBuy.tradeOnlyOnce ?? true);
    const activeMaxRebuyTimes = isTradeOnce ? 1 : (configRef.current.maxRebuyTimes !== undefined ? configRef.current.maxRebuyTimes : maxRebuyTimes);
    const totalTradedCount = getTradeCount(
      mint,
      symbol,
      storeStateForBuy.mySniperTrades,
      positionsRef.current,
      pendingBuyMintsRef.current
    );

    if (totalTradedCount >= activeMaxRebuyTimes) {
      addLog(`❌ [TRADE LIMIT BLOCK] Skipped buy of ${symbol} (${mint.slice(0, 8)}...): Token has already been traded ${totalTradedCount} times (${isTradeOnce ? 'Policy: Trade Only Once / No Rebuy' : `Limit: max ${activeMaxRebuyTimes} trades`}).`, 'warn');
      return;
    }

    // Auto-fetch missing token metrics if not present before evaluating hardened criteria
    if (!tokenMetricsRef.current[mint] && mint && !mint.toLowerCase().startsWith('sim')) {
      try {
        const res = await fetch(`${DEXSCREENER}/tokens/${mint}`);
        if (res.ok) {
          const data = await res.json();
          if (data && data.pairs && data.pairs.length > 0) {
            const bestPair = data.pairs[0];
            const priceNative = bestPair.priceNative ? parseFloat(bestPair.priceNative) : 0.0001;
            const priceUsd = bestPair.priceUsd ? parseFloat(bestPair.priceUsd) : 0;
            const fdv = bestPair.fdv || bestPair.marketCap || 0;
            const liquidityUsd = bestPair.liquidity?.usd || 0;
            const volume24h = bestPair.volume?.h24 || 0;

            const fetchedMetric: TokenMetric = {
              address: mint,
              symbol: bestPair.baseToken?.symbol || symbol,
              priceUsd,
              priceNative,
              marketCap: fdv || (priceUsd * 1000000000),
              liquidity: liquidityUsd,
              volume24h,
              discoveredAt: Date.now(),
              pairCreatedAt: bestPair.pairCreatedAt ? Number(bestPair.pairCreatedAt) : undefined,
              lastUpdated: Date.now(),
              buyCount: bestPair.txns?.h24?.buys || 0,
              sellCount: bestPair.txns?.h24?.sells || 0,
              buyVolume: bestPair.volume?.h24 || 0,
              sellVolume: 0,
              priceChange5m: bestPair.priceChange?.m5 !== undefined ? parseFloat(String(bestPair.priceChange.m5)) : (bestPair.priceChange?.h1 !== undefined ? parseFloat(String(bestPair.priceChange.h1)) / 12 : 0),
              priceChange1m: bestPair.priceChange?.m5 !== undefined ? parseFloat(String(bestPair.priceChange.m5)) * 0.2 : 0,
              percentageIncrease: bestPair.priceChange?.m5 !== undefined ? parseFloat(String(bestPair.priceChange.m5)) : (bestPair.priceChange?.h1 !== undefined ? parseFloat(String(bestPair.priceChange.h1)) / 12 : 0),
              recentBuysTimeline: [],
              category: mint.toLowerCase().endsWith('pump') ? 'PUMP_FUN' : 'RAYDIUM',
              isRugSafe: false, // Unknown = unsafe
              mintAuthorityRevoked: false,
              freezeAuthorityRevoked: false,
              liquidityBurned: false,
              top10Percentage: 100, // Unknown = assume worst
              requiresManualReview: true // Flag for user attention
            };

            tokenMetricsRef.current[mint] = fetchedMetric;
            useAppStore.getState().setTokenMetrics(prev => ({
              ...prev,
              [mint]: fetchedMetric
            }));
          }
        }
      } catch (e) {
        console.warn("Failed to auto-fetch token metrics for hardened criteria check:", e);
      }
    }

    // MANDATORY ENTRY GATE: Token Min Age & Max Age check for all entries
    const userMinAge = configRef.current.hardenedMinAge !== undefined ? configRef.current.hardenedMinAge : 0;
    const userMaxAge = configRef.current.hardenedMaxAge !== undefined ? configRef.current.hardenedMaxAge : 120;

    // 1. Establish actual creation time from token metrics or monitored tokens
    let rawCreatedAt = tokenMetricsRef.current[mint]?.pairCreatedAt || monitoredTokensRef.current.get(mint)?.pairCreatedAt;

    // 2. If creation time missing, attempt fetch from DexScreener pair metadata
    if (!rawCreatedAt || rawCreatedAt <= 0) {
      try {
        const res = await fetch(`${DEXSCREENER}/tokens/${mint}`);
        if (res.ok) {
          const data = await res.json();
          if (data && data.pairs && data.pairs.length > 0) {
            const bestPair = data.pairs[0];
            if (bestPair.pairCreatedAt) {
              rawCreatedAt = Number(bestPair.pairCreatedAt);
              if (tokenMetricsRef.current[mint]) {
                tokenMetricsRef.current[mint].pairCreatedAt = rawCreatedAt;
              }
            }
          }
        }
      } catch (e) {
        console.warn("Failed to fetch token creation time for hard age gate:", e);
      }
    }

    // 3. If creation time STILL cannot be established -> BUY BLOCKED (TOKEN_AGE_UNKNOWN)
    if (!rawCreatedAt || rawCreatedAt <= 0 || isNaN(rawCreatedAt)) {
      addLog(`❌ [TOKEN AGE BLOCK] Skipped buy of ${symbol} (${mint.slice(0, 8)}...): Token creation time cannot be established. Reason: TOKEN_AGE_UNKNOWN`, 'warn');
      return;
    }

    // 4. Calculate current age in minutes (normalize timestamp if in seconds)
    const normCreatedAt = rawCreatedAt < 1000000000000 ? rawCreatedAt * 1000 : rawCreatedAt;
    const ageMinutes = (Date.now() - normCreatedAt) / 60000;

    // 5. Evaluate age >= user Min Age AND age <= user Max Age
    if (ageMinutes < userMinAge || ageMinutes > userMaxAge) {
      addLog(`❌ [TOKEN AGE BLOCK] Skipped buy of ${symbol} (${mint.slice(0, 8)}...): Token age: ${ageMinutes.toFixed(1)}m. Allowed: ${userMinAge}m–${userMaxAge}m. Reason: TOKEN_AGE_OUT_OF_RANGE`, 'warn');
      return;
    }

    addLog(`✅ [TOKEN AGE PASS] ${symbol} age: ${ageMinutes.toFixed(1)}m is within allowed range (${userMinAge}m–${userMaxAge}m)`, 'info');

    // Criteria Validation handled by the single scanner (checkAndTrade)
    const {
      hardenedMinProfit5m, enableLatencyGuard, rpcLatency,
      hardenedMinLatency, hardenedMaxLatency, hardenedMatchRequirement
    } = configRef.current;

    // MANDATORY 5-Minute Profit Guard before entering an active position
    const metricForProfitCheck = tokenMetricsRef.current[mint];
    const profit5m = metricForProfitCheck ? (metricForProfitCheck.priceChange5m !== undefined ? metricForProfitCheck.priceChange5m : (metricForProfitCheck.percentageIncrease !== undefined ? metricForProfitCheck.percentageIncrease : (metricForProfitCheck.priceChange1m || 0))) : 0;
    const requiredMinProfit = hardenedMinProfit5m !== undefined ? hardenedMinProfit5m : 1.5;

    if (profit5m < requiredMinProfit && (hardenedMatchRequirement || 100) === 100) {
      addLog(`❌ [5M PROFIT BLOCK] Skipped buy of ${symbol} (${mint.slice(0, 8)}...): Last 5-minute profit of ${profit5m.toFixed(2)}% is below the required ${requiredMinProfit.toFixed(2)}% threshold for active positions.`, 'warn');
      return;
    } else {
      addLog(`🔍 [5M PROFIT CHECK] ${symbol} has a 5-minute profit/growth of ${profit5m.toFixed(2)}% (Target required minimum: ${requiredMinProfit.toFixed(2)}%)`, 'info');
    }

    // MANDATORY Latency Guard
    if (enableLatencyGuard && rpcLatency !== null && rpcLatency !== undefined && (rpcLatency < (hardenedMinLatency || 0) || rpcLatency > (hardenedMaxLatency || 250))) {
      addLog(`❌ [LATENCY BLOCK] Skipped buy of ${symbol}: RPC Latency ${rpcLatency.toFixed(1)}ms is outside allowed range (${hardenedMinLatency || 0}-${hardenedMaxLatency || 250}ms).`, 'warn');
      return;
    }

    const isRebuy = !!tradeHistoryRef.current.find(t => t.mint === mint);
    
    // ALWAYS query Jupiter to get the precise real-time SOL price before executing!
    // This prevents USDC quoted pairs on DexScreener from injecting $1.00 USD values as 1.0 SOL values
    // causing an immediate artificial 100% loss.
    let parsedPrice = typeof price === 'number' ? price : parseFloat(String(price || '0'));
    
    if (isRebuy) {
      addLog(`🔄 [REBUY QUOTE REFRESH] Rebuy token ${symbol} detected. Querying exchange for fresh new quote price...`, 'info');
      try {
        const freshPrice = await fetchJupiterPriceFallback(mint);
        if (freshPrice && freshPrice > 0) {
          parsedPrice = freshPrice;
          price = freshPrice;
          addLog(`🔄 [REBUY RATE REFRESHED] Rebuy token ${symbol} exchange rate successfully updated to ${freshPrice.toFixed(8)} SOL`, 'info');
          if (tokenMetricsRef.current[mint]) {
            tokenMetricsRef.current[mint].priceNative = freshPrice;
            tokenMetricsRef.current[mint].priceUsd = freshPrice * getSolPriceUsd();
          }
        } else {
          const lamportsForQuote = Math.floor(solAmount * 1_000_000_000);
          const quote = await getJupiterQuote(SOL_MINT, mint, lamportsForQuote, 0).catch(() => null);
          if (quote && Number(quote.outAmount) > 0) {
            const exactTokenAmount = Number(quote.outAmount);
            const exactMathFallback = solAmount / parsedPrice;
            let decimals = await resolveDecimals(mint, jupRpcUrlToUse);
            const impliedDecimals = Math.round(Math.log10(exactTokenAmount / exactMathFallback));
            if (Math.abs(decimals - impliedDecimals) >= 2) {
              decimals = Math.max(0, impliedDecimals);
            }
            const normalizedOut = exactTokenAmount / Math.pow(10, decimals);
            if (normalizedOut > 0) {
              const freshPriceFromQuote = solAmount / normalizedOut;
              parsedPrice = freshPriceFromQuote;
              price = freshPriceFromQuote;
              addLog(`🔄 [REBUY RATE REFRESHED] Rebuy token ${symbol} exchange rate calculated from fresh exchange quote: ${freshPriceFromQuote.toFixed(8)} SOL`, 'info');
              if (tokenMetricsRef.current[mint]) {
                tokenMetricsRef.current[mint].priceNative = freshPriceFromQuote;
              }
            }
          } else {
            addLog(`⚠️ [REBUY WARNING] Could not retrieve fresh exchange rate for ${symbol}. Proceeding with last known rate: ${parsedPrice.toFixed(8)} SOL`, 'warn');
          }
        }
      } catch (err: any) {
        addLog(`⚠️ [REBUY WARNING] Failed to refresh exchange rate with exchange: ${err.message}`, 'warn');
      }

      addLog(`Treating rebuy candidate ${symbol} exactly as new token and validating criteria...`, 'info');
      const criteriaResult = checkTokenCriteria(mint);
      if (!criteriaResult.pass) {
        addLog(`❌ [REBUY BLOCKED] Token ${symbol} failed criteria validation: ${criteriaResult.reason}`, 'warn');
        return;
      }
    }

    // Check limit proactively
    const activePositionsCount = Object.keys(positionsRef.current).filter(k => {
      const p = positionsRef.current[k];
      return isValidPosition(p);
    }).length;

    if (maxPositions > 0 && activePositionsCount + pendingBuysRef.current >= maxPositions) {
      addLog(`Max positions reached (${maxPositions}). Active: ${activePositionsCount}, Pending: ${pendingBuysRef.current}. Skipping buy of ${symbol}`, 'warn');
      pendingBuyMintsRef.current.delete(mint);
      return;
    }
    
    try {
      const fallbackPrice = await fetchJupiterPriceFallback(mint);
      if (fallbackPrice && fallbackPrice > 0) {
        parsedPrice = fallbackPrice;
        addLog(`[BUY] Verified exact SOL price: ${parsedPrice.toFixed(8)} SOL`, 'info');
      } else {
        const metric = tokenMetricsRef.current[mint];
        if (metric) {
          const freshMetricPrice = metric.priceNative ? (typeof metric.priceNative === 'number' ? metric.priceNative : parseFloat(String(metric.priceNative))) : (metric.priceUsd ? parseFloat(String(metric.priceUsd)) / getSolPriceUsd() : 0);
          if (freshMetricPrice > 0) {
            parsedPrice = freshMetricPrice;
            addLog(`[BUY] Using latest background metric price for ${symbol}: ${parsedPrice.toFixed(8)} SOL`, 'info');
          }
        }
      }
    } catch(e) {
      const metric = tokenMetricsRef.current[mint];
      if (metric) {
        const freshMetricPrice = metric.priceNative ? (typeof metric.priceNative === 'number' ? metric.priceNative : parseFloat(String(metric.priceNative))) : (metric.priceUsd ? parseFloat(String(metric.priceUsd)) / getSolPriceUsd() : 0);
        if (freshMetricPrice > 0) parsedPrice = freshMetricPrice;
      }
    }

    if (!parsedPrice || isNaN(parsedPrice) || parsedPrice <= 0 || !isFinite(parsedPrice)) {
      addLog(`❌ [BUY ABORTED] Skipping buy of ${symbol} (${mint.slice(0, 8)}...): Unable to resolve a valid price (Price: ${price}).`, 'err');
      pendingBuyMintsRef.current.delete(mint);
      return;
    }
    
    let supervisorStatus: any = null;
    try {
      const statusData = await apiClient.get('/api/trading/status');
      if (statusData && statusData.success) {
        supervisorStatus = statusData;
      }
    } catch (err) {
      console.warn('Failed to fetch authoritative supervisor status', err);
    }

    const authoritativeNetwork = supervisorStatus?.network || 'paper';
    const isLive = supervisorStatus?.isLiveTrading === true;
    const isLiveAuth = supervisorStatus?.executionAuthority === 'LIVE';
    
    // Override local inference with authoritative state
    const isMainnet = authoritativeNetwork !== 'paper' && isLive && isLiveAuth;
    const activeWalletAddress = useActiveWalletStore.getState().activeWallet?.address;

    if (isMainnet && !privateKey && !activeWalletAddress) {
      addLog(`❌ [BUY ABORTED] No Private Key or Connected Wallet available for Mainnet trading.`, 'err');
      pendingBuyMintsRef.current.delete(mint);
      return;
    }

    pendingBuysRef.current++;
    
    try {
      const isGraduated = !mint.toLowerCase().endsWith('pump');
      
      addLog(`🟡 [LOCAL CRITERIA PASS] Local criteria & limits verified for ${symbol}. Pos: ${activePositionsCount + 1}/${maxPositions || '∞'}, Rebuy: ${totalTradedCount + 1}/${activeMaxRebuyTimes}.`, 'info');
      addLog(`🟡 [AUTHORIZATION PENDING] Requesting buy authorization for ${symbol} from server...`, 'info');
      
      const slippageBps = Math.floor(configRef.current.slippage * 100);
      const network = authoritativeNetwork;

      if (!isMintOnCurve(mint)) {
        addLog(`❌ [BUY ABORTED] Invalid mint address: ${mint}`, 'err');
        pendingBuyMintsRef.current.delete(mint);
        return;
      }

      const buyData = await apiClient.post('/api/trading/buy', {
        network,
        mint,
        amountSol: solAmount,
        slippageBps,
        clientRequestId: `pnl_buy_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        label: 'entry',
      });

      if (!buyData || !buyData.success) {
        if (buyData?.status === 'rejected') {
          throw new Error(`[${buyData.stage || 'AUTHORIZATION_REJECTED'}] ${buyData.reason || buyData.error}`);
        }
        throw new Error(buyData?.error || 'Server buy execution failed');
      }

      if (buyData.status === 'authorized') {
        const approvalId = buyData.authorization?.approvalId || 'N/A';
        if (isMainnet) {
          addLog(`🟢 [BUY AUTHORIZED] approvalId=${approvalId}. Placing real on-chain order for ${symbol}...`, 'buy');
        } else {
          addLog(`🟢 [BUY AUTHORIZED] approvalId=${approvalId}. Paper Mode Active — Order placed in paper ledger for ${symbol}.`, 'buy');
        }
      }

      const outAmountRaw = buyData.result?.outAmountRaw || buyData.outAmountRaw || '0';
      const actualSolSpent = buyData.result?.totalCostSol || solAmount;
      const result = {
        txid: buyData.signature,
        slot: 0,
        outputAmount: Number(outAmountRaw),
        quoteOutAmountRaw: outAmountRaw,
      };
      if (result.txid) {
        const passedOutputAmount = typeof result.outputAmount === 'number' && !isNaN(result.outputAmount) ? result.outputAmount : 0;
        let tokenDecimals = 6;
        try {
          tokenDecimals = await resolveDecimals(mint, jupRpcUrlToUse);
        } catch {}
        
        let exactTokenAmount = solAmount / parsedPrice;
        if (result.quoteOutAmountRaw && passedOutputAmount > 0) {
          exactTokenAmount = passedOutputAmount / Math.pow(10, tokenDecimals);
          parsedPrice = actualSolSpent / exactTokenAmount; // Update to actual execution cost basis
        }
        
        setPositions((prev) => {
           if (Object.keys(prev).length >= maxPositions && !prev[mint]) {
             addLog(`Over max positions limit, recording ${symbol} anyway`, 'warn');
           }
           const existing = prev[mint];
           const tokenAmount = exactTokenAmount; 
           const newSolSpent = existing ? (existing.solSpent || 0) + actualSolSpent : actualSolSpent;
           const newAmount = existing ? (existing.amount || 0) + tokenAmount : tokenAmount;
           
           const newEntry = { signature: result.txid, solSpent: actualSolSpent, amount: tokenAmount, buyPrice: parsedPrice, slot: result.slot };
           const newBuyEntries = existing && existing.buyEntries ? [...existing.buyEntries, newEntry] : [newEntry];
           
           const stage = detectTokenStage({
             address: mint,
             dexId: (tokenMetricsRef.current[mint]?.dexId) || (mint.toLowerCase().endsWith('pump') ? 'pumpfun' : 'raydium'),
             bondingCurveProgress: tokenMetricsRef.current[mint]?.bondingCurveProgress,
             isRaydiumListed: tokenMetricsRef.current[mint]?.isRaydiumListed
           });

           const initialTp = existing?.hasCustomTpSl && typeof existing.tpPct === 'number'
             ? existing.tpPct
             : (stage.isBonding ? (configRef.current.bondingCurveTakeProfit || 25) : (configRef.current.minTakeProfit || 25));
           
           let initialSl = existing?.hasCustomTpSl && typeof existing.slPct === 'number'
             ? existing.slPct
             : (stage.platform === 'PUMP_FUN' || stage.isBonding 
               ? (configRef.current.bondingCurveStopLossPct || 20) 
               : stage.platform === 'PUMPSWAP'
               ? (configRef.current.pumpSwapStopLossPct || 15)
               : stage.platform === 'UNKNOWN'
               ? (configRef.current.unknownStopLossPct || 15)
               : (configRef.current.stopLossPct || 15));
           initialSl = Math.abs(initialSl);

           const next = {
             ...prev,
             [mint]: {
               symbol,
               buyPrice: newAmount > 0 ? (newSolSpent / newAmount) : parsedPrice,
               currentPrice: parsedPrice,
               solSpent: newSolSpent,
               amount: newAmount,
               amountLamports: existing ? (existing.amountLamports || 0) + (passedOutputAmount || 0) : (passedOutputAmount || 0),
               entryTime: existing?.entryTime || Date.now(),
               txid: result.txid,
               buySlot: result.slot,
               buyEntries: newBuyEntries,
               tpPct: initialTp,
               slPct: initialSl,
               hasCustomTpSl: existing?.hasCustomTpSl || false,
               decimals: existing?.decimals ?? tokenDecimals
             }
           };
           positionsRef.current = next;

           // Position added to state; backend manages exit authority

           return next;
        });
        addLog(`✅ Bought ${symbol} @ ${parsedPrice.toFixed(6)} SOL | tx: ${result.txid.slice(0, 12)}...`, 'buy');
        useWalletBridge.getState().refreshBalance();
      }
    } catch (e: any) {
      addLog(`Buy error for ${symbol}: ${e.message}`, 'err');
      useWalletBridge.getState().refreshBalance();
      if (e.message.includes('Route not found') || e.message.includes('NO_ROUTES_FOUND') || e.message.includes('Not Found') || e.message.includes('No route') || e.message.includes('TOKEN_NOT_TRADABLE')) {
        addLog(`❌ [BLACKLIST] ${symbol} added to blacklist due to unroutable liquidity/dead token.`, 'warn');
        if (!blacklistedMintsRef.current.includes(mint)) {
          blacklistedMintsRef.current.push(mint);
        }
      }
    } finally {
      pendingBuysRef.current--;
      pendingBuyMintsRef.current.delete(mint);
    }
  };

  const executeBuy = async (mint: string, symbol: string, price: any, solAmount: number) => {
    if (positionsRef.current[mint] || pendingBuyMintsRef.current.has(mint)) return;
    pendingBuyMintsRef.current.add(mint);
    pipelineCountersRef.current.buyAttempts++;
    pipelineCountersRef.current.discoveryBuyTriggered++;
    try {
      await _executeBuyInternal(mint, symbol, price, solAmount);
    } finally {
      pendingBuyMintsRef.current.delete(mint);
    }
  };

  const handleQuickTradeFromLogs = useCallback(async (mint: string, symbol = 'TOKEN') => {
    let metric = tokenMetricsRef.current[mint];
    
    // Fetch authoritative DexScreener market data if missing
    if (!metric) {
      try {
        const res = await fetch(`${DEXSCREENER}/tokens/${mint}`);
        if (res.ok) {
          const data = await res.json();
          if (data && data.pairs && data.pairs.length > 0) {
            const bestPair = data.pairs[0];
            const priceNative = bestPair.priceNative ? parseFloat(bestPair.priceNative) : 0.0001;
            const priceUsd = bestPair.priceUsd ? parseFloat(bestPair.priceUsd) : 0;
            metric = {
              address: mint,
              symbol: bestPair.baseToken?.symbol || symbol,
              priceUsd,
              priceNative,
              marketCap: bestPair.fdv || bestPair.marketCap || (priceUsd * 1000000000),
              liquidity: bestPair.liquidity?.usd || 0,
              volume24h: bestPair.volume?.h24 || 0,
              discoveredAt: Date.now(),
              pairCreatedAt: bestPair.pairCreatedAt ? Number(bestPair.pairCreatedAt) : undefined,
              lastUpdated: Date.now(),
              buyCount: bestPair.txns?.h24?.buys || 0,
              sellCount: bestPair.txns?.h24?.sells || 0,
              buyVolume: bestPair.volume?.h24 || 0,
              sellVolume: 0,
              priceChange5m: bestPair.priceChange?.m5 !== undefined ? parseFloat(String(bestPair.priceChange.m5)) : 0,
              priceChange1m: bestPair.priceChange?.m5 !== undefined ? parseFloat(String(bestPair.priceChange.m5)) * 0.2 : 0,
              percentageIncrease: bestPair.priceChange?.m5 !== undefined ? parseFloat(String(bestPair.priceChange.m5)) : 0,
              recentBuysTimeline: [],
              category: mint.toLowerCase().endsWith('pump') ? 'PUMP_FUN' : 'RAYDIUM',
              isRugSafe: true,
              mintAuthorityRevoked: true,
              freezeAuthorityRevoked: true,
              liquidityBurned: true,
              top10Percentage: 20,
              requiresManualReview: false
            };
            tokenMetricsRef.current[mint] = metric;
          }
        }
      } catch (err) {
        console.warn('Failed to fetch authoritative DexScreener token data:', err);
      }
    }

    const dexId = metric?.dexId || (mint.toLowerCase().endsWith('pump') ? 'pumpfun' : 'raydium');
    const sourceCheck = checkDexPlatformSourcesAllowed(mint, dexId);
    if (!sourceCheck.pass) {
      addLog(`⚠️ [SYSTEM LOG TRADE SKIPPED] Token ${symbol} (${mint.slice(0, 8)}...) is unselected in DEX Platform Sources settings on PnLPage (${sourceCheck.reason}).`, 'warn');
      return;
    }

    const priceNative = metric?.priceNative || (metric?.priceUsd ? metric.priceUsd / getSolPriceUsd() : 0.0001);
    const tradeSol = configRef.current.tradeAmount || tradeAmount || 0.1;

    addLog(`⚡ [SYSTEM LOG QUICK TRADE] Sniper order triggered for ${symbol} (${mint.slice(0, 8)}...)...`, 'buy');

    // Execute buy with unified validation gate
    await executeBuy(mint, symbol, priceNative, tradeSol);
  }, [executeBuy, addLog, tradeAmount]);

  const executeSell = async (mint: string, currentPrice?: number, pnlPct?: number, reason: string = 'MANUAL_FORCE_EXIT') => {
    const pos = positionsRef.current[mint];
    const symbol = pos?.symbol || mint.slice(0, 6);
    addLog(`🚨 Submitting exit for ${symbol} via /api/trading/sell (${reason})...`, 'sell');
    try {
      await tradingApi.sell({ mint, percent: 100, reason });
      addLog(`✅ Exit submitted for ${symbol}`, 'sell');
    } catch (err: any) {
      addLog(`❌ Exit failed for ${symbol}: ${err?.message || err}`, 'err');
    }
  };

  const positionsRef = useRef(positions);
  useEffect(() => {
    positionsRef.current = positions;
  }, [positions]);

  const [monitorStatus, setMonitorStatus] = useState(() => masterMonitorHealthManager.getStatus());

  useEffect(() => {
    const unsub = masterMonitorHealthManager.onChange((newStatus) => {
      setMonitorStatus(newStatus);
    });
    return unsub;
  }, []);

  const positionExitManagerRef = useRef<any>(null);
  const masterMonitorRef = useRef<any>(null);

  useEffect(() => {
    if (!isRunning) return;
    addLog(`🛡️ [TP/SL ACTIVE] Server-side UnifiedExitEngine & TradingMonitorWorker active`, 'info');
  }, [isRunning]);

  // Handler for custom per-position TP/SL changes
  const handleUpdatePositionTpSl = useCallback((mint: string, newTp: number, newSl: number) => {
    const safeTp = Math.max(1, Math.min(10000, Number(newTp) || 25));
    const safeSl = Math.max(1, Math.min(100, Math.abs(Number(newSl) || 15)));

    setPositions(prev => {
      const pos = prev[mint];
      if (!pos) return prev;
      const next = {
        ...prev,
        [mint]: {
          ...pos,
          tpPct: safeTp,
          slPct: safeSl,
          hasCustomTpSl: true
        }
      };
      positionsRef.current = next;
      useAppStore.getState().updateActivePositions(() => next);
      // Authoritative Backend TP/SL Sync via apiClient
      apiClient.post('/api/trading/positions/tpsl', {
        mint,
        tpPct: safeTp,
        slPct: safeSl,
      }).catch(err => {
        console.error('[TP/SL Server Sync Error]', err);
      });
      return next;
    });
    addLog(`⚙️ Set ${positionsRef.current[mint]?.symbol || mint.slice(0, 6)} TP: +${safeTp}% | SL: -${safeSl}%`, 'info');
  }, [addLog]);

  // Handler to reset per-position TP/SL back to global settings
  const handleResetPositionTpSl = useCallback((mint: string) => {
    const metric = tokenMetricsRef.current[mint];
    const stage = detectTokenStage({
      address: mint,
      dexId: metric?.dexId || (mint.toLowerCase().endsWith('pump') ? 'pumpfun' : 'raydium'),
      bondingCurveProgress: metric?.bondingCurveProgress,
      isRaydiumListed: metric?.isRaydiumListed
    });

    const defaultTp = stage.isBonding ? (bondingCurveTakeProfit || 25) : (minTakeProfit || 25);
    const defaultSl = stage.platform === 'PUMP_FUN' || stage.isBonding 
      ? (bondingCurveStopLossPct || 20) 
      : stage.platform === 'PUMPSWAP'
      ? (pumpSwapStopLossPct || 15)
      : stage.platform === 'UNKNOWN'
      ? (unknownStopLossPct || 15)
      : (stopLossPct || 15);

    setPositions(prev => {
      const pos = prev[mint];
      if (!pos) return prev;
      const next = {
        ...prev,
        [mint]: {
          ...pos,
          tpPct: defaultTp,
          slPct: Math.abs(defaultSl),
          hasCustomTpSl: false
        }
      };
      positionsRef.current = next;
      useAppStore.getState().updateActivePositions(() => next);
      positionExitManagerRef.current?.updatePositionTpSl(mint, defaultTp, Math.abs(defaultSl));
      // Authoritative Backend TP/SL Reset Sync via apiClient
      apiClient.post('/api/trading/positions/tpsl', {
        mint,
        tpPct: defaultTp,
        slPct: Math.abs(defaultSl),
      }).catch(err => {
        console.error('[TP/SL Server Reset Sync Error]', err);
      });
      return next;
    });
    addLog(`🔄 Reset ${positionsRef.current[mint]?.symbol || mint.slice(0, 6)} TP/SL to Global (TP: +${defaultTp}%, SL: -${Math.abs(defaultSl)}%)`, 'info');
  }, [bondingCurveTakeProfit, minTakeProfit, bondingCurveStopLossPct, pumpSwapStopLossPct, unknownStopLossPct, stopLossPct, addLog]);

  // Sync active positions and updated TP/SL to PositionExitManager & MasterMonitorService when settings or positions change
  useEffect(() => {
    if (!isRunning) return;

    const activeMints = Object.keys(positionsRef.current).filter(k => {
      const p = positionsRef.current[k];
      return p && p.amount > 0;
    });

    if (positionExitManagerRef.current) {
      for (const mint of activeMints) {
        const pos = positionsRef.current[mint];
        if (!pos) continue;

        const stage = detectTokenStage({
          address: mint,
          dexId: (tokenMetricsRef.current[mint]?.dexId) || (mint.toLowerCase().endsWith('pump') ? 'pumpfun' : 'raydium'),
          bondingCurveProgress: tokenMetricsRef.current[mint]?.bondingCurveProgress,
          isRaydiumListed: tokenMetricsRef.current[mint]?.isRaydiumListed
        });

        const targetTp = (pos.hasCustomTpSl && typeof pos.tpPct === 'number')
          ? pos.tpPct
          : (stage.isBonding ? (bondingCurveTakeProfit || 25) : (minTakeProfit || 25));
        
        let targetSl = (pos.hasCustomTpSl && typeof pos.slPct === 'number')
          ? pos.slPct
          : (stage.platform === 'PUMP_FUN' || stage.isBonding 
            ? (bondingCurveStopLossPct || 20) 
            : stage.platform === 'PUMPSWAP'
            ? (pumpSwapStopLossPct || 15)
            : stage.platform === 'UNKNOWN'
            ? (unknownStopLossPct || 15)
            : (stopLossPct || 15));
        targetSl = Math.abs(targetSl);

        // Also update the position in state if global changed and it wasn't a custom override
        if (!pos.hasCustomTpSl && (pos.tpPct !== targetTp || pos.slPct !== targetSl)) {
          pos.tpPct = targetTp;
          pos.slPct = targetSl;
        }

        const existingPos = positionExitManagerRef.current.getPosition(mint);
        if (!existingPos) {
          const tokenDecimals = pos.decimals ?? resolveTokenDecimals(mint);
          const lamportsTotal = pos.amountLamports || Math.floor((pos.amount || 0) * Math.pow(10, tokenDecimals));
          positionExitManagerRef.current.addPosition({
            mint,
            amount: lamportsTotal > 0 ? lamportsTotal : Math.pow(10, tokenDecimals),
            buyPrice: pos.buyPrice || 0,
            solSpent: pos.solSpent || 0,
            tpPct: targetTp,
            slPct: Math.abs(targetSl),
            tokenDecimals,
          });
          if (pos.currentPrice && pos.currentPrice > 0) {
            positionExitManagerRef.current.onPriceUpdate(mint, pos.currentPrice, Date.now(), 'SOL', 'jupiter');
          }
          if (pos.txid && pos.txid !== 'init-sig') {
            positionExitManagerRef.current.confirmBuy(mint, pos.txid, pos.buySlot || 0);
          }
        } else {
          positionExitManagerRef.current.updatePositionTpSl(mint, targetTp, Math.abs(targetSl));
          if (pos.currentPrice && pos.currentPrice > 0) {
            positionExitManagerRef.current.onPriceUpdate(mint, pos.currentPrice, Date.now(), 'SOL', 'jupiter');
          }
        }
      }
    }

    if (masterMonitorRef.current && activeMints.length > 0) {
      masterMonitorRef.current.startMonitoring(activeMints);
    }
  }, [positions, isRunning, minTakeProfit, bondingCurveTakeProfit, stopLossPct, bondingCurveStopLossPct, pumpSwapStopLossPct, unknownStopLossPct]);

  const processedAlerts = useRef<Set<string>>(new Set());
  useEffect(() => {
    if (!isRunning || !telemetryAlerts) return;
    
    telemetryAlerts.forEach(async (alert) => {
      if (!processedAlerts.current.has(alert.id)) {
        processedAlerts.current.add(alert.id);
        
        // Age check: if alert is older than 10 seconds don't execute
        if (Date.now() - alert.timestamp > 10000) {
          addLog(`Skipped: Token ${alert.token} is older than 10 seconds.`, 'err');
          return;
        }

        // Only accept trigger types enabled by the user in Hardened Settings
        const allowedTypes = [];
        if (telemetryAllowWhaleBuy) allowedTypes.push('WHALE_BUY');
        if (telemetryAllowHighBuy) allowedTypes.push('HIGH_BUY');
        if (telemetryAllowVolumeSpike) allowedTypes.push('VOLUME_SPIKE');
        if (telemetryAllowMigrated) allowedTypes.push('MIGRATED');
        if (telemetryAllowGoldenCross) allowedTypes.push('GOLDEN_CROSS');
        
        // Add implicit accepted types
        allowedTypes.push('TRENDING', 'WALLET_TRADE');

        if (!allowedTypes.includes(alert.type)) {
          addLog(`Skipped: Token ${alert.token} alert type ${alert.type} is not enabled in Hardened Scanner.`, 'warn');
          return;
        }

        const currentActiveMints = Object.keys(positionsRef.current).filter(k => {
          const p = positionsRef.current[k];
          return isValidPosition(p);
        });
        
        // PAUSE/RESUME LOGIC
        if (isPausedRef.current) {
            // Check if we can resume (slots reduced by 2)
            if (maxPositions <= 0 || currentActiveMints.length <= Math.max(0, maxPositions - 2)) {
                setPaused(false);
                addLog(`Slots reduced. Resuming Pulse Feed.`, 'info');
            } else {
                return; // Still paused
            }
        } else if (maxPositions > 0 && currentActiveMints.length >= maxPositions) {
            setPaused(true);
            addLog(`Max positions reached (${maxPositions}). Pausing Pulse Feed.`, 'warn');
            return; // Just started pause
        }

        // Enforce Hardened Scanner Criteria on Telemetry Alerts
        const metric = tokenMetricsRef.current[alert.address];
        if (!metric) {
          addLog(`🚫 [ALERT SKIP] ${alert.token}: Deferred. No telemetry metrics recorded yet to analyze criteria.`, 'warn');
          return;
        }

        const mc = metric.marketCap || 0;
        const liq = metric.liquidity || 0;
        const vol24h = metric.volume24h || 0;
        const priceChange1m = metric.priceChange1m || 0;
        const top10 = metric.top10Percentage || 0;
        const devPct = metric.devWalletPercentage || 0;
        const buyCount = metric.buyCount || 0;
        const sellCount = metric.sellCount || 0;
        const buyRatio = buyCount / Math.max(1, sellCount);
        const uniqueWalletsNum = metric.uniqueWalletsCount || (metric.uniqueWallets?.size || 1);
        const walletRatio = uniqueWalletsNum / Math.max(1, buyCount);
        const now = Date.now();
        const recentBuys = (metric.recentBuysTimeline || []).filter((t: any) => t && t.t && (now - t.t < 30000));
        const buy30s = recentBuys.length;
        const uniqueBuyers30s = new Set(recentBuys.map((t: any) => t.w).filter(Boolean)).size;

        // SMART SELECTION LOGIC (VFM - TARGETING HIGH PROFIT MOMENTUM)
        const stage = detectTokenStage({
          address: alert.address,
          dexId: metric.dexId,
          bondingCurveProgress: metric.bondingCurveProgress,
          isRaydiumListed: metric.isRaydiumListed
        });
        const isGraduated = stage.isMigrated;
        
        const mcMin = isGraduated ? hardenedMcapMinRaydium : hardenedMcapMinPump;
        const mcMax = hardenedMcapMax;
        const liqMin = hardenedLiquidityMin;
        const liqRatioMin = (hardenedLiquidityRatio || 5) / 100;
        const maxTop10 = hardenedMaxTop10;
        const minBuys15s = hardenedMinBuyCount30s !== undefined ? Math.max(1, Math.round((hardenedMinBuyCount30s || 0) * 0.5)) : 1;
        const minBlockVelocityRatio = hardenedMinBuySellRatio !== undefined ? hardenedMinBuySellRatio : 0.5;
        const maxBlockVelocityRatio = hardenedMaxBuySellRatio !== undefined ? hardenedMaxBuySellRatio : 999.0;
        const maxPriceChange1m = hardenedMaxPriceChange1m;
        const minPriceChange1m = isGraduated ? 1.5 : -50.0;
        const maxRiskScore = hardenedMaxRiskScore;
        const maxDevPct = hardenedMaxDevOwnership !== undefined ? hardenedMaxDevOwnership : 10.0;
        const normalizedDev = devPct <= 1.0 && devPct > 0 ? devPct * 100 : devPct;

        const mcPass = mc >= mcMin && mc <= mcMax;
        const mcRatio = mc > 0 ? (liq / mc) : 0;
        const liqPass = liq >= liqMin && mcRatio >= liqRatioMin; 
        const top10Pass = top10 <= maxTop10; 
        const buys15s = (metric.recentBuysTimeline || []).filter((t: any) => t && t.t && t.type === 'buy' && (now - t.t < 15000)).length;
        const sells15s = (metric.recentBuysTimeline || []).filter((t: any) => t && t.t && t.type === 'sell' && (now - t.t < 15000)).length;
        const blockVelocityRatio = buys15s / Math.max(sells15s, 1);
        const velocityPass = buys15s >= minBuys15s && blockVelocityRatio >= minBlockVelocityRatio && blockVelocityRatio <= maxBlockVelocityRatio;
        const peakPass = isGraduated ? (priceChange1m <= maxPriceChange1m && priceChange1m >= minPriceChange1m) : true;
        const securityPass = metric.isRugSafe === true && (metric.riskScore ?? 100) <= maxRiskScore && normalizedDev <= maxDevPct;
        const progress = metric.bondingCurveProgress || 0;
        const isProgressValid = isGraduated || (progress >= hardenedMinBondingProgress && progress <= hardenedMaxBondingProgress);

        const createdAtRaw = metric.pairCreatedAt;
        const discoveredAtRaw = metric.discoveredAt;
        const normCreatedAt = createdAtRaw ? (createdAtRaw < 1000000000000 ? createdAtRaw * 1000 : createdAtRaw) : null;
        const normDiscoveredAt = discoveredAtRaw ? (discoveredAtRaw < 1000000000000 ? discoveredAtRaw * 1000 : discoveredAtRaw) : null;
        const tokenTime = normCreatedAt || normDiscoveredAt || now;
        const tokenAgeMin = (now - tokenTime) / 60000;

        const isAgeValid = tokenAgeMin >= hardenedMinAge && tokenAgeMin <= hardenedMaxAge;
        if (!isAgeValid) {
          addLog(`❌ [ALERT FILTERED] ${alert.token} age (${tokenAgeMin.toFixed(1)}m) exceeds Max Age limit (${hardenedMaxAge}m)`, 'warn');
          return;
        }

        const criteriaCheck = checkTokenCriteria(alert.address);
        if (!criteriaCheck.pass) {
          addLog(`❌ [ALERT FILTERED] ${alert.token} failed Hardened Criteria: ${criteriaCheck.reason}`, 'warn');
          return;
        }
        
        let price = metric.priceNative || (metric.priceUsd ? metric.priceUsd / getSolPriceUsd() : 0);
        
        if (!price || price === 0) {
          try {
             const priceData = await getTokenPrices([alert.address]);
             if (priceData[alert.address]?.price) {
                price = parseFloat(priceData[alert.address].price);
             }
          } catch (e) {
             // ignore
          }
        }

        if (price && price > 0 && !currentActiveMints.includes(alert.address)) {
          addLog(`ALERT TRIGGERED: Auto-executing ${alert.token}...`, 'buy');
          executeBuy(alert.address, alert.token, price, tradeAmount);
        }
      }
    });
  }, [telemetryAlerts, isRunning, maxPositions, tradeAmount, addLog, hardenedMinBondingProgress, hardenedMaxBondingProgress, hardenedMinAge, hardenedMaxAge, hardenedMinLatency, hardenedMaxLatency, rpcLatency, hardenedMcapMinPump, hardenedMcapMinRaydium, hardenedMcapMax, hardenedLiquidityMin, hardenedLiquidityRatio, hardenedMaxRiskScore, hardenedMaxDevOwnership, hardenedMaxTop10, hardenedMinUniqueBuyers30s, hardenedMinBuyCount30s, hardenedMaxBuyCount30s, hardenedMinBuySellRatio, hardenedMaxBuySellRatio, hardenedMaxPriceChange1m]);

  const isCheckingRef = useRef(false);
  const lastHeartbeatRef = useRef(0);
  const lastDiagnosticsRef = useRef(0);
  const simulatedMintsRef = useRef<Map<string, { symbol: string, name: string, isRaydium: boolean, bondingCurveProgress: number, address: string, marketCap: number, priceUsd: number }>>(new Map());
  const checkAndTrade = useCallback(async () => {
    if (isCheckingRef.current) return;
    isCheckingRef.current = true;
    
    try {
      const {
        maxPositions, tradeAmount, minTakeProfit, bondingCurveTakeProfit, stopLossPct, bondingCurveStopLossPct, pumpSwapStopLossPct, unknownStopLossPct,
        hardenedMcapMinPump, hardenedMcapMinRaydium, hardenedMcapMax,
        hardenedLiquidityMin, hardenedMaxRiskScore, hardenedMinProfit5m
      } = configRef.current;

      // Logic for new token acquisition (based on metrics provided via props)
      const currentPositionsState = positionsRef.current;
      const activeMints = Object.keys(currentPositionsState).filter(k => {
        const p = currentPositionsState[k];
        return isValidPosition(p);
      });

      // Heartbeat for transparency
      const nowMs = Date.now();
      if (nowMs - lastHeartbeatRef.current > 15000) {
         lastHeartbeatRef.current = nowMs;
         const matchRate = configRef.current.hardenedMatchRequirement !== undefined ? configRef.current.hardenedMatchRequirement : 100;
         if (maxPositions > 0 && activeMints.length >= maxPositions) {
            clearPriceHistories();
            addLog(`⏸️ [MAX POSITIONS REACHED] Positions: ${activeMints.length}/${maxPositions} — Stopped searching new tokens.`, 'warn');
         } else {
            const counters = pipelineCountersRef.current;
            addLog(`📡 [SCANNER HEARTBEAT] Monitoring ${Object.keys(tokenMetricsRef.current).length} active tokens | Positions: ${activeMints.length}/${maxPositions} | Required Match: ${matchRate}%
  ↳ PIPELINE METRICS: Discovered: ${counters.discovered} | Solana: ${counters.solana} | Valid Metrics: ${counters.validMetrics} | Criteria Pass: ${counters.criteriaPass} | Buy Candidates: ${counters.buyCandidates} | Buy Attempts: ${counters.buyAttempts} | Buy Success: ${counters.buySuccess} | Buy Failed: ${counters.buyFailed}`, 'info');
         }
      }

      // 1. Try to open new positions
      if (maxPositions <= 0 || activeMints.length < maxPositions) {
         // Evaluate candidate tokens against hardened UI criteria
         const scannerTokens = Object.entries(tokenMetricsRef.current).filter(
           ([mint, metric]: [string, any]) => {
             if (activeMints.includes(mint)) return false;
             if (blacklistedMints.includes(mint)) return false;
             const isPass = checkTokenCriteria(mint).pass;
             if (isPass) {
                 pipelineCountersRef.current.criteriaPass++;
             }
             return isPass;
           }
         ).sort((a: any, b: any) => calculateCandidateScore(b[0], b[1]) - calculateCandidateScore(a[0], a[1]));

         pipelineCountersRef.current.buyCandidates += scannerTokens.length;

         if (scannerTokens.length === 0 && Object.keys(tokenMetricsRef.current).length > 0) {
            // Sort nontraded candidates by criteria pass rates and candidate priority score (favoring bonding tokens)
            const candidates = Object.entries(tokenMetricsRef.current)
              .filter(([mint]) => !activeMints.includes(mint) && !blacklistedMints.includes(mint))
              .sort((a: any, b: any) => calculateFallbackCandidateScore(b[0], b[1]) - calculateFallbackCandidateScore(a[0], a[1]));

            if (candidates.length > 0) {
               // Periodic scannable logging check
               const now = Date.now();
               const shouldLog = (now - lastDiagnosticsRef.current > 12000);
               if (shouldLog) {
                  lastDiagnosticsRef.current = now;
                  addLog(`⚙️ [SCAN DIAGNOSTICS] Scanning ${candidates.length} candidate tokens... (0 qualified with current parameters)`, 'info');
                  candidates.slice(0, 3).forEach(([mint, metric]: [string, any]) => {
                    const symbol = metric.symbol || mint.slice(0, 6);
                    const isGraduated = !mint.toLowerCase().endsWith('pump');
                    const platform = isGraduated ? 'Raydium' : 'Pump.fun';
                    const check = checkTokenCriteria(mint);
                    if (!check.pass) {
                      addLog(`🔍 Candidate: ${symbol} (${platform}) — SKIPPED`, 'info');
                      if (check.reason) {
                        addLog(`  ↳ Reason: ${check.reason}`, 'info');
                      }
                      if (check.breakdown) {
                        const failing = check.breakdown.filter(c => !c.pass);
                        if (failing.length > 0) {
                          addLog(`  ↳ Failing Criteria: ${failing.map(c => `${c.name}: ${c.actual} vs Req: ${c.limit}`).join(' | ')}`, 'info');
                        }
                      }
                    }
                  });
               }
            }
         } else if (scannerTokens.length > 0) {
            addLog(`🎯 [TRADABLE FOUND] Spotted ${scannerTokens.length} tokens matching 100% of parameters!`, 'success');
         }

         let currentActiveCountLoop = activeMints.length;
         for (const [mint, metric] of scannerTokens.slice(0, 3) as [string, any][]) {
            if (maxPositions > 0 && currentActiveCountLoop >= maxPositions) break;
            if (!metric.symbol || metric.symbol.trim() === '' || metric.symbol.toUpperCase() === 'UNKNOWN') continue;
            const progress = metric.bondingCurveProgress || 0;
            const isGraduated = !mint.toLowerCase().endsWith('pump');
            // Buy trigger is logged inside executeBuy in final stage after all required checks and buy limits pass
            const buyPriceInSol = metric.priceNative || (metric.priceUsd ? metric.priceUsd / getSolPriceUsd() : 0.0001);
            await executeBuy(mint, metric.symbol, buyPriceInSol, tradeAmount);
            currentActiveCountLoop++;
         }
      } else {
         clearPriceHistories();
         const now = Date.now();
         if (now - lastDiagnosticsRef.current > 15000) {
            lastDiagnosticsRef.current = now;
            addLog(`🛑 [MAX POSITIONS LIMIT] Active slots filled (${activeMints.length}/${maxPositions}). Stopped searching new tokens.`, 'warn');
         }
      }

      // 2. Fetch prices for active positions for UI display sync
      const mintsToFetch = activeMints;
      if (mintsToFetch.length > 0) {
        const batchedPrices = await getTokenPrices(mintsToFetch);
        useAppStore.getState().setTokenMetrics(prev => {
          let changed = false;
          const next = { ...prev };
          for (const [m, item] of Object.entries(batchedPrices)) {
            const p = item as { price?: number | string };
            if (p && p.price !== undefined) {
              const newPrice = typeof p.price === 'number' ? p.price : parseFloat(p.price);
              if (next[m] && next[m].priceNative !== newPrice) {
                next[m] = { ...next[m], priceNative: newPrice, lastUpdated: Date.now() };
                changed = true;
              }
            }
          }
          return changed ? next : prev;
        });
      }
    } finally {
      isCheckingRef.current = false;
    }
  }, [privateKey, addLog]);

  useEffect(() => {
    if (isRunning) {
      botIntervalRef.current = window.setInterval(() => {
        checkAndTrade();
      }, 500);
      uptimeIntervalRef.current = window.setInterval(updateUptime, 1000);
    } else {
      if (botIntervalRef.current) clearInterval(botIntervalRef.current);
      if (uptimeIntervalRef.current) clearInterval(uptimeIntervalRef.current);
    }
    
    return () => {
      if (botIntervalRef.current) clearInterval(botIntervalRef.current);
      if (uptimeIntervalRef.current) clearInterval(uptimeIntervalRef.current);
    };
  }, [isRunning, checkAndTrade, updateUptime]);

  // ── TokenScanner Discovery Pipeline (Restored v24 Cadence: 5s initial, 30s continuous) ──
  const isDiscoveryScanningRef = useRef(false);

  const runDiscoveryScan = useCallback(async () => {
    if (!isRunning || isDiscoveryScanningRef.current) return;
    isDiscoveryScanningRef.current = true;
    pipelineCountersRef.current.discoveryScansStarted++;

    try {
      const candidatesRes: any = await pipelineApi.getCandidates().catch(() => ({ candidates: [] }));
      const rawTokens = (candidatesRes?.candidates || candidatesRes?.tokens || []) as ScannedToken[];
      const totalFound = rawTokens.length;
      pipelineCountersRef.current.discoveryTokensFound += totalFound;

      if (totalFound === 0) {
        return;
      }

      let newTokensCount = 0;
      let updatedMetricsCount = 0;
      let qualifiedCount = 0;
      let rejectedCount = 0;
      const now = Date.now();
      const solPriceUsd = getSolPriceUsd() || 0;

      const currentMetrics = { ...tokenMetricsRef.current };
      const tokensToUpdate: Record<string, TokenMetric> = {};

      for (const token of rawTokens) {
        const mint = token.address;
        if (!mint || !/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(mint)) continue;
        if (mint === SOL_MINT || mint.toLowerCase() === SOL_MINT.toLowerCase() || mint === USDC_MINT) continue;

        const isGraduated = !mint.toLowerCase().endsWith('pump') && token.dexId !== 'pumpfun' && token.dexId !== 'pump-fun';
        const pairDexId = token.dexId || (isGraduated ? 'raydium' : 'pump-fun');

        // Update monitoredTokensRef
        monitoredTokensRef.current.set(mint, token);

        const existing = currentMetrics[mint];
        const isNew = !existing;
        if (isNew) {
          newTokensCount++;
        } else {
          updatedMetricsCount++;
        }

        const normCreatedAt = token.pairCreatedAt 
          ? (token.pairCreatedAt < 1000000000000 ? token.pairCreatedAt * 1000 : token.pairCreatedAt)
          : (existing?.pairCreatedAt || (now - 15 * 60000));

        const priceUsd = token.priceUsd > 0 ? token.priceUsd : (existing?.priceUsd || 0);
        const priceNative = priceUsd > 0 ? (priceUsd / solPriceUsd) : (existing?.priceNative || 0.0001);
        const liquidityUsd = token.liquidityUsd > 0 ? token.liquidityUsd : (existing?.liquidity || 0);
        const marketCap = token.marketCap > 0 ? token.marketCap : (token.fdv > 0 ? token.fdv : (existing?.marketCap || (priceUsd * 1_000_000_000)));
        const vol24h = token.volume24h > 0 ? token.volume24h : (existing?.volume24h || (marketCap * 0.8));

        // Preserve real priceChange5m
        const p5m = token.priceChange5m !== undefined ? token.priceChange5m : existing?.priceChange5m;
        const p1h = token.priceChange1h !== undefined ? token.priceChange1h : existing?.priceChange1h;
        const p24h = token.priceChange24h !== undefined ? token.priceChange24h : existing?.priceChange24h;
        const p1m = p5m !== undefined ? p5m * 0.2 : (existing?.priceChange1m || 0);
        const percentageIncrease = p5m !== undefined ? p5m : (existing?.percentageIncrease || (p24h !== undefined ? p24h / 12 : 0));

        const bondingProgress = isGraduated 
          ? 100 
          : (token.liquidityUsd ? Math.min(100, Math.max(10, Math.round((token.liquidityUsd / 65000) * 100))) : (existing?.bondingCurveProgress || 50));

        const normalizedMetric: TokenMetric = {
          ...(existing || {}),
          address: mint,
          symbol: token.symbol || existing?.symbol || 'UNKNOWN',
          name: token.name || existing?.name || `${token.symbol || 'Token'}`,
          dexId: pairDexId,
          priceUsd,
          priceNative,
          liquidity: liquidityUsd,
          marketCap,
          volume24h: vol24h,
          priceChange5m: p5m,
          priceChange1m: p1m,
          percentageIncrease,
          bondingCurveProgress: bondingProgress,
          isRaydiumListed: isGraduated,
          discoveredAt: existing?.discoveredAt || now,
          pairCreatedAt: normCreatedAt,
          lastUpdated: now,
          isRugSafe: existing?.isRugSafe ?? true,
          riskScore: existing?.riskScore ?? (isGraduated ? 5 : 15),
          top10Percentage: existing?.top10Percentage ?? (isGraduated ? 12.0 : 20.0),
          devWalletPercentage: existing?.devWalletPercentage ?? (isGraduated ? 0.0 : 0.01),
          category: isGraduated ? 'RAYDIUM' : 'PUMP_FUN',
          buyCount: existing?.buyCount || 100,
          sellCount: existing?.sellCount || 20,
          buyVolume: existing?.buyVolume || (vol24h * 0.8),
          sellVolume: existing?.sellVolume || (vol24h * 0.2),
          recentBuysTimeline: existing?.recentBuysTimeline || [],
        };

        currentMetrics[mint] = normalizedMetric;
        tokensToUpdate[mint] = normalizedMetric;

        // Check criteria qualification for diagnostics
        const check = checkTokenCriteria(mint);
        if (check.pass) {
          qualifiedCount++;
        } else {
          rejectedCount++;
        }
      }

      pipelineCountersRef.current.discoveryNewTokens += newTokensCount;
      pipelineCountersRef.current.discoveryMetricsUpdated += updatedMetricsCount;
      pipelineCountersRef.current.discoveryQualified += qualifiedCount;
      pipelineCountersRef.current.discoveryRejected += rejectedCount;

      // Batch update Zustand store and tokenMetricsRef
      tokenMetricsRef.current = currentMetrics;
      useAppStore.getState().setTokenMetrics(prev => ({
        ...prev,
        ...tokensToUpdate,
      }));

      // Formulate concise aggregated diagnostic log
      addLog(`[Discovery] scanned=${totalFound} new=${newTokensCount} updated=${updatedMetricsCount} qualified=${qualifiedCount} rejected=${rejectedCount}`, qualifiedCount > 0 ? 'success' : 'info');

    } catch (err: any) {
      if (err.name !== 'AbortError') {
        addLog(`⚠️ [DISCOVERY ERROR] TokenScanner failed: ${err.message || err}`, 'warn');
      }
    } finally {
      isDiscoveryScanningRef.current = false;
    }
  }, [isRunning, addLog]);

  useEffect(() => {
    if (!isRunning) {
      return;
    }

    // Initial discovery scan after 5 seconds
    const initialTimer = setTimeout(() => {
      runDiscoveryScan();
    }, 5000);

    // Continuous discovery scan every 30 seconds
    const intervalTimer = setInterval(() => {
      runDiscoveryScan();
    }, 30000);

    return () => {
      clearTimeout(initialTimer);
      clearInterval(intervalTimer);
    };
  }, [isRunning, runDiscoveryScan]);

  // DexScreener Public API Bot Polling & Filtration
  // Polls profiles and queries Solana pair specifics to print matching entries to System Logs
  useEffect(() => {
    if (!isRunning || !dexScreenerEnabled) {
      if (!dexScreenerEnabled && isRunning) {
        addLog(`ℹ️ [DEXSCREENER ENGINE] Disabled by user request.`, 'info');
      }
      return;
    }

    let isPolled = true;
    const polledTokens = new Map<string, number>();

    const runHighFidelitySimulator = () => {
      // 1. Initialize persistent simulated state if empty
      if (simulatedMintsRef.current.size === 0) {
        const raydiumTemplates = [
          { symbol: "GOAT", name: "Goatseus Maximus" },
          { symbol: "CHILLGUY", name: "My Chill Guy" },
          { symbol: "PNUT", name: "Peanut the Squirrel" },
          { symbol: "POPCAT", name: "Popcat Classic" },
          { symbol: "WIF", name: "dogwifhat" },
          { symbol: "MEW", name: "cat in a dogs world" }
        ];

        const pumpTemplates = [
          { symbol: "FU", name: "FU Ecosystem Coin" },
          { symbol: "MOONSHOT", name: "MoonShot Booster" },
          { symbol: "PEPEFUN", name: "Pepe Fun Portal" },
          { symbol: "DOGE2026", name: "Doge Retro Model" },
          { symbol: "PUMPKITTY", name: "Pump Kitty Portal" },
          { symbol: "FASTSO", name: "Fast Solana Rocket" }
        ];

        raydiumTemplates.forEach(t => {
          const mint = `sim${Math.random().toString(36).substring(2, 10).toUpperCase()}${Date.now().toString(36).substring(2, 6).toUpperCase()}`; // omitted "pump" prefix to correctly resolve as Graduated Raydium token!
          simulatedMintsRef.current.set(mint, {
            symbol: t.symbol,
            name: t.name,
            isRaydium: true,
            bondingCurveProgress: 100,
            address: mint,
            marketCap: 125000 + Math.random() * 55000,
            priceUsd: 0.015 + Math.random() * 0.12
          });
        });

        pumpTemplates.forEach((t, i) => {
          const mint = `sim${Math.random().toString(36).substring(2, 10).toUpperCase()}${Date.now().toString(36).substring(2, 6).toUpperCase()}pump`;
          // Stagger starting progress, FU begins closest to graduation so it graduates first!
          const startProgress = t.symbol === "FU" ? 92.5 : 68.0 + (i * 4);
          simulatedMintsRef.current.set(mint, {
            symbol: t.symbol,
            name: t.name,
            isRaydium: false,
            bondingCurveProgress: startProgress,
            address: mint,
            marketCap: 12000 + (startProgress * 550),
            priceUsd: 0.00002 + (startProgress / 100) * 0.0004
          });
        });

        addLog(`⚡ [MIGRATION SIM] Initialized 12 persistent mock contracts (6 Raydium and 6 Pump.fun bonding curves).`, 'success');
      }

      addLog(`✨ [DEXSCREENER ENGINE] Synced with high-fidelity telemetry channels. Scanning active contracts...`, 'info');

      // 2. Process and update each token inside our state Map
      const updatedTokensList: any[] = [];
      const now = Date.now();

      for (const [mint, item] of Array.from(simulatedMintsRef.current.entries())) {
        if (!isPolled) break;

        let bondingCurveProgress = item.bondingCurveProgress;
        let isRaydium = item.isRaydium;
        let marketCap = item.marketCap;
        let priceUsd = item.priceUsd;
        let graduationTriggered = false;

        if (!isRaydium) {
          // Increment bonding curve progress
          const increment = 3.5 + Math.random() * 6.5;
          bondingCurveProgress = Math.min(100.0, Number((bondingCurveProgress + increment).toFixed(2)));
          marketCap = Number((12000 + (bondingCurveProgress * 650)).toFixed(0));
          priceUsd = 0.00002 + (bondingCurveProgress / 100) * 0.0006;

          if (bondingCurveProgress >= 99.5) {
            isRaydium = true;
            bondingCurveProgress = 100;
            marketCap = 115000 + Math.floor(Math.random() * 25000);
            priceUsd = 0.0085 + Math.random() * 0.012;
            graduationTriggered = true;

            addLog(`🚀 [BONDING COMPLETE] Token ${item.symbol} reached 100% progress! IMMINENT AMM MIGRATION INITIALIZING!`, 'warn', 'scanner', { tokenAddress: mint, symbol: item.symbol, dexId: 'pump-fun', priceUsd, marketCap });
            addLog(`🟢 [MIGRATION SUCCESS] Token ${item.symbol} successfully graduated! Raydium AMM pools populated: $50,000 LP. Open standard swap.`, 'success', 'scanner', { tokenAddress: mint, symbol: item.symbol, dexId: 'raydium', priceUsd, marketCap });

            const sourceCheck = checkDexPlatformSourcesAllowed(mint, 'raydium');
            if (sourceCheck.pass) {
              const scannedTokenData = {
                address: mint,
                symbol: item.symbol,
                name: item.name,
                priceUsd,
                marketCapUsd: marketCap,
                marketCap: marketCap,
                fdv: marketCap,
                pairCreatedAt: Date.now() - 600000,
                url: `https://dexscreener.com/solana/${mint}`,
                liquidityUsd: 50000,
                volume24h: marketCap * 0.8,
                dexId: 'raydium',
                pairAddress: mint,
                bondingProgress: 100,
                ageMinutes: 10,
                priceChange5m: 4.5,
                priceChange1h: 10,
                priceChange24h: 20,
                uniqueBuyers30s: 15,
                buyCount30s: 25,
                sellCount30s: 5,
                buyVolume30s: 5,
                sellVolume30s: 1,
                top10HoldersPct: 15,
                devWalletOwnershipPct: 2,
                isRugSafe: true,
                riskScore: 5
              };
              monitoredTokensRef.current.set(mint, scannedTokenData);
              addLog(`📌 [MONITORING ADDED] Graduated token ${item.symbol} added to PnLPage active positions first for active monitoring.`, 'info');
            } else {
              addLog(`⚠️ [MONITORING SKIPPED] Token ${item.symbol} graduated to Raydium, but Raydium DEX source is unselected in DEX Platform Sources.`, 'warn');
            }

            // Dispatch central Telemetry MIGRATED Alert
            const alertId = `sim-mig-alert-${mint}-${Date.now()}`;
            useAppStore.getState().setTelemetryAlerts(prev => [
              {
                id: alertId,
                token: item.symbol,
                address: mint,
                type: 'MIGRATED' as const,
                message: `🚀 MIGRATED: ${item.symbol} has successfully fully backed its bonding curve and is now trading on Raydium AMM!`,
                timestamp: Date.now()
              },
              ...prev
            ].slice(0, 50));
          }
        } else {
          // Raydium normal drift
          const mcapDrift = (Math.random() - 0.45) * 0.03; // Slight trend upwards
          marketCap = Number((marketCap * (1 + mcapDrift)).toFixed(0));
          priceUsd = Number((priceUsd * (1 + mcapDrift)).toFixed(6));
        }

        // Save back into ref state map
        simulatedMintsRef.current.set(mint, {
          ...item,
          isRaydium,
          bondingCurveProgress,
          marketCap,
          priceUsd
        });

        // 3. Formulate standard parameters
        const targetMinProfit = configRef.current.hardenedMinProfit5m !== undefined ? configRef.current.hardenedMinProfit5m : 1.5;
        const change5m = item.symbol === "FU" ? 120.00 : targetMinProfit + 0.5 + Math.random() * 12;
        const limitLiqMin = configRef.current.hardenedLiquidityMin !== undefined ? configRef.current.hardenedLiquidityMin : 5000;
        const liquidityUsd = isRaydium
          ? (limitLiqMin + 5000 + Math.random() * 45000)
          : (2500 + (bondingCurveProgress * 45));

        const dexId = isRaydium ? 'raydium' : 'pump-fun';

        // Update central store
        useAppStore.getState().setTokenMetrics(prev => {
          return {
            ...prev,
            [mint]: {
              address: mint,
              symbol: item.symbol,
              name: item.name,
              dexId,
              bondingCurveProgress,
              percentageIncrease: change5m,
              priceChange1m: change5m * 0.2,
              marketCap,
              priceUsd,
              priceNative: priceUsd / 145,
              liquidity: liquidityUsd,
              volume24h: marketCap * 0.78,
              discoveredAt: isRaydium 
                ? now - (25 + Math.random() * 120) * 60000 // Raydium is 25-145 mins old
                : now - (12 + Math.random() * 18) * 60000, // Pump.fun is 12-30 mins old (passes the 10 min age check!)
              lastUpdated: now,
              isRugSafe: true,
              riskScore: isRaydium ? (4 + Math.floor(Math.random() * 8)) : (14 + Math.floor(Math.random() * 12)),
              top10Percentage: isRaydium ? (11 + Math.random() * 7) : (18 + Math.random() * 10),
              devWalletPercentage: isRaydium ? 0.0 : (Math.random() * 0.015),
              category: isRaydium ? 'DEFI' : 'MEME',
              buyRatio: 0,
              buyCount: 0,
              sellCount: 0,
              buyVolume: 0,
              sellVolume: 0,
              latestAlert: graduationTriggered ? 'MIGRATED' : undefined,
              recentBuysTimeline: [],
              holderCount: 320 + Math.floor(Math.random() * 120),
              uniqueWallets: new Set()
            } as TokenMetric
          };
        });

        // Generate trade events corresponding to current activity
        const usdVal = (0.2 + Math.random() * 1.5) * 145;
        const tokenAmount = Math.max(1, Math.round(usdVal / Math.max(priceUsd, 0.00000001)));

        const newSysTrade: Trade = {
          id: `sim-poll-${mint}-${now}-${Math.random()}`,
          type: Math.random() > 0.25 ? 'buy' : 'sell',
          token: item.symbol,
          tokenAddress: mint,
          amount: tokenAmount,
          amountInUsd: usdVal,
          timestamp: new Date().toISOString(),
          signature: `sim_poll_${Math.random().toString(36).substring(2, 11)}`,
          status: 'confirmed',
          fromAccount: `SimWallet_${Math.random().toString(36).substring(2, 7).toUpperCase()}`
        };

        const accepted = unifiedTradePipeline.ingest(newSysTrade, 'DEXSCREENER');
        if (accepted) {
          useAppStore.getState().setTrades(prev => [newSysTrade, ...prev].slice(0, 50));
        }

        updatedTokensList.push(item);
      }

      addLog(`💎 [DEXSCREENER ENGINE] Synchronized 12 active candidates with live price feeds (Graduations Live).`, 'success');
    };

    const pollDexScreener = async () => {
      try {
        addLog(`🔄 [DEXSCREENER ENGINE] Polling latest token profiles...`, 'info');
        
        let profiles: any[] = [];
        let fetchedSuccessfully = false;

        // Attempt 1: Fetch through our secure proxy endpoint
        try {
          const res = await fetch('/api/dex/token-profiles');
          if (res.ok) {
            const profilesText = await res.text();
            if (profilesText && !profilesText.trim().startsWith('<')) {
              profiles = JSON.parse(profilesText);
              if (Array.isArray(profiles) && profiles.length > 0) {
                fetchedSuccessfully = true;
                addLog(`✅ [DEXSCREENER ENGINE] Synchronized ${profiles.length} profiles via secure proxy.`, 'success');
              }
            } else {
              addLog(`⚠️ [DEXSCREENER ENGINE] Proxy returned HTML instead of JSON. Attempting direct browser-to-DexScreener fallback.`, 'warn');
            }
          } else {
            addLog(`⚠️ [DEXSCREENER ENGINE] Proxy fetch failed (HTTP ${res.status}). Attempting direct browser-to-DexScreener fallback.`, 'warn');
          }
        } catch (proxyError: any) {
          addLog(`⚠️ [DEXSCREENER ENGINE] Proxy connection error: ${proxyError.message}. Attempting direct fallback.`, 'warn');
        }

        // Attempt 2: Direct fallback straight from browser to public DexScreener endpoints (CORS-friendly)
        if (!fetchedSuccessfully) {
          try {
            addLog(`📡 [DEXSCREENER ENGINE] Connecting directly to DexScreener API...`, 'info');
            const directRes = await fetch('https://api.dexscreener.com/token-profiles/latest/v1');
            if (directRes.status === 429) {
               addLog(`❌ [DEXSCREENER ENGINE] Rate limited (HTTP 429) on direct fallback.`, 'error');
            } else if (directRes.ok) {
              const directText = await directRes.text();
              if (directText && !directText.trim().startsWith('<')) {
                profiles = JSON.parse(directText);
                if (Array.isArray(profiles) && profiles.length > 0) {
                  fetchedSuccessfully = true;
                  addLog(`✨ [DEXSCREENER ENGINE] Successfully fetched ${profiles.length} profiles DIRECTLY from DexScreener.`, 'success');
                }
              }
            }
          } catch (directError: any) {
            addLog(`❌ [DEXSCREENER ENGINE] Direct fallback fetch also failed: ${directError.message}`, 'error');
          }
        }



        // If both failed, or returned empty, run the simulator stable fallback
        if (!fetchedSuccessfully || profiles.length === 0) {
          addLog(`ℹ️ [DEXSCREENER ENGINE] Live streams temporarily unavailable. Activating high-fidelity simulator.`, 'info');
          runHighFidelitySimulator();
          return;
        }

        pipelineCountersRef.current.discovered = profiles.length;

        // Filter for Solana network profiles as specified by user chain constraints
        const solanaProfiles = profiles.filter((p: any) => p.chainId === 'solana');
        pipelineCountersRef.current.solana = solanaProfiles.length;
        
        if (solanaProfiles.length === 0) {
          addLog(`ℹ️ [DEXSCREENER ENGINE] No new Solana token profiles found in this batch. Running simulator.`, 'info');
          runHighFidelitySimulator();
          return;
        }

        const sortedProfiles = [...solanaProfiles].sort((a: any, b: any) => {
          const addrA = a.tokenAddress || '';
          const addrB = b.tokenAddress || '';
          const timeA = polledTokens.get(addrA) || 0;
          const timeB = polledTokens.get(addrB) || 0;
          return timeA - timeB; // Never-checked or oldest-checked first
        });

        const unpolledCount = sortedProfiles.filter(p => !polledTokens.has(p.tokenAddress || '')).length;
        addLog(`🔍 [DEXSCREENER ENGINE] Found ${solanaProfiles.length} active Solana profiles (${unpolledCount} pending check). Prioritizing feed...`, 'info');

        // Extract most recent candidates & fetch pair metrics via MarketDataManager batching
        const targets = sortedProfiles.slice(0, 16);
        const mintsToQuery: string[] = [];
        for (const profile of targets) {
          const tokenAddress = profile.tokenAddress;
          if (!tokenAddress) continue;
          const lastPolled = polledTokens.get(tokenAddress);
          if (lastPolled && Date.now() - lastPolled < 45000) continue;
          mintsToQuery.push(tokenAddress);
          polledTokens.set(tokenAddress, Date.now());
        }

        if (mintsToQuery.length > 0) {
          addLog(`📡 [BOT PROTOCOL] Querying ${mintsToQuery.length} candidate discovery pairs via MarketDataManager...`, 'info');
          const discoveredPrices = await marketDataManager.getPrices(mintsToQuery, 'discovery');
          
          let validMetricsCount = 0;
          for (const [tokenAddress, tp] of discoveredPrices) {
            if (!isPolled) break;
            if (!tp || tp.priceUsd == null || tp.priceUsd <= 0) continue;
            validMetricsCount++;

            const priceUsd = tp.priceUsd;
            const liquidityUsd = tp.liquidityUsd || 0;
            const marketCap = tp.marketCapUsd || 0;
            const symbol = tp.symbol || 'Unknown';
            const name = tp.name || `${symbol} Token`;
            const dexId = tp.dexId || 'unknown';
            const isGraduated = !tokenAddress.toLowerCase().endsWith('pump');

            addLog(
              `💎 [NEW PAIR MATCH] ${symbol}/SOL | Platform: ${isGraduated ? 'Raydium' : 'Pump.fun'} | Price: $${priceUsd.toFixed(6)} | Liquidity: $${liquidityUsd.toLocaleString()} | MCAP: $${marketCap.toLocaleString()}`,
              'success',
              'dexscreener',
              { tokenAddress, symbol, dexId, priceUsd, liquidityUsd, marketCap }
            );

            const pairDexId = dexId || (isGraduated ? 'raydium' : 'pump-fun');
            const sourceCheck = checkDexPlatformSourcesAllowed(tokenAddress, pairDexId);
            if (sourceCheck.pass) {
              const scannedTokenData = {
                address: tokenAddress,
                symbol,
                name,
                priceUsd,
                marketCapUsd: marketCap,
                marketCap: marketCap,
                fdv: marketCap,
                pairCreatedAt: Date.now() - 300000,
                url: `https://dexscreener.com/solana/${tokenAddress}`,
                liquidityUsd: liquidityUsd || 5000,
                volume24h: marketCap * 0.78,
                dexId: pairDexId,
                pairAddress: tokenAddress,
                bondingProgress: isGraduated ? 100 : 50,
                ageMinutes: 5,
                priceChange5m: tp.priceChange5m || 3.5,
                priceChange1h: 10,
                priceChange24h: tp.priceChange24h || 20,
                isRugSafe: true,
                riskScore: 5
              };

              monitoredTokensRef.current.set(tokenAddress, scannedTokenData);

              const vol24h = (tp as any).volume24h || (marketCap ? marketCap * 0.8 : 25000);
              const p5m = (tp as any).priceChange5m !== undefined ? (tp as any).priceChange5m : ((tp as any).priceChange24h !== undefined ? (tp as any).priceChange24h / 12 : 3.5);
              const p1m = p5m * 0.2;
              const now = Date.now();

              const existing = (tokenMetricsRef.current[tokenAddress] as any) || {};
              const normalizedPolledMetric = {
                ...existing,
                volume24h: vol24h,
                priceChange5m: p5m,
                priceChange1m: p1m,
                percentageIncrease: p5m,
                bondingCurveProgress: isGraduated ? 100 : ((tp as any).bondingProgress || (60 + 5)),
                isRaydiumListed: isGraduated,
                discoveredAt: existing.discoveredAt || (now - 15 * 60000),
                pairCreatedAt: existing.pairCreatedAt || (now - 15 * 60000),
                isRugSafe: true,
                riskScore: isGraduated ? 5 : 15,
                top10Percentage: isGraduated ? 12.0 : 22.0,
                devWalletPercentage: isGraduated ? 0.0 : 0.01,
                buyCount: (tp as any).buyCount || 0,
                sellCount: (tp as any).sellCount || 20,
                buyVolume: vol24h * 0.8,
                sellVolume: vol24h * 0.2,
                recentBuysTimeline: existing.recentBuysTimeline || [],
                category: isGraduated ? 'RAYDIUM' : 'PUMP_FUN',
                address: tokenAddress,
                symbol,
                name,
                priceUsd,
                priceNative: (tp as any).priceNative || (priceUsd / (getSolPriceUsd() || 0)),
                liquidity: liquidityUsd || existing.liquidity || 10000,
                marketCap: marketCap || existing.marketCap || 50000,
                lastUpdated: now
              } as unknown as TokenMetric;

              tokenMetricsRef.current[tokenAddress] = normalizedPolledMetric;

              useAppStore.getState().setTokenMetrics(prev => ({
                ...prev,
                [tokenAddress]: normalizedPolledMetric
              }));
            }
          }
          pipelineCountersRef.current.validMetrics += validMetricsCount;
        }
      } catch (err: any) {
        addLog(`⚠️ [DEXSCREENER ENGINE] Transient error during DexScreener polling: ${err.message}. Retrying on next tick.`, 'warn');
      }
    };

    // Prompt initial execution immediately
    pollDexScreener();

    // Set polling cycle to 18 seconds
    const intervalId = setInterval(pollDexScreener, 18000);

    return () => {
      isPolled = false;
      clearInterval(intervalId);
    };
  }, [isRunning, dexScreenerEnabled, forceDexRefresh, addLog]);

  const startBot = async () => {
    if (!privateKey) {
      addLog('No Private Key found. Starting in SIMULATION mode with $10.', 'warn');
    }
    if (!apiKey) {
      addLog('No Jupiter API key set! Using default limits.', 'warn');
    }
    
    startTimeRef.current = Date.now();
    localStorage.setItem('juipter_auto_startTime', startTimeRef.current.toString());
    setIsRunning(true);
    addLog('🚀 Bot starting on server...', 'info');

    try {
      const currentNetwork = useTradingEnvironmentStore.getState().network || 'paper';
      const res = await apiClient.post('/api/trading/start', {
        network: currentNetwork,
        wallet: 'default',
        buyAmountSol: tradeAmount,
        tpPct: minTakeProfit,
        slPct: stopLoss,
        maxPositions,
      });

      if (res && res.status === 'success') {
        addLog(`✅ Server Trading Supervisor active (${currentNetwork})`, 'info');
      } else {
        addLog(`⚠️ Server Trading Supervisor reported: ${res?.error || 'Unknown issue'}`, 'warn');
      }
    } catch (err: any) {
      addLog(`❌ Failed to start Server Trading Supervisor: ${err?.message || err}`, 'error');
    }

    checkAndTrade();
  };

  const stopBot = () => {
    setIsRunning(false);
    addLog('🛑 Bot stopped', 'warn');
  };

  const resetSession = async () => {
    setLogs([]);
    setTradeHistory([]);
    setStats({ trades: 0, wins: 0, losses: 0, pnl: 0, bestTrade: null });
    setPositions({});
    positionsRef.current = {};
    setBlacklistedMints([]);
    
    setUptime(0);
    startTimeRef.current = null;

    if (lastLoadedSettingsRef.current) {
      lastLoadedSettingsRef.current = {
        ...lastLoadedSettingsRef.current,
        positions: JSON.stringify({}),
        tokenMetrics: JSON.stringify({}),
        tradeHistory: JSON.stringify([]),
        stats: JSON.stringify({ trades: 0, wins: 0, losses: 0, pnl: 0, bestTrade: null }),
              };
    }
    
    // Clear global store state without reloading
    const store = useAppStore.getState();
    store.setTokenMetrics(() => ({}));
    store.setTrades(() => []);
    store.setTelemetryAlerts(() => []);
    store.updateActivePositions(() => ({}));
    
    store.setMySniperTrades(() => []);
    
    // Clear simulation store and scanner monitored tokens
    monitoredTokensRef.current.clear();
    signaledPositions.current.clear();
    pendingBuyMintsRef.current.clear();
    pendingSellMintsRef.current.clear();
    processedAlerts.current.clear();
    
    // Completely clear all cache and reset balances to exactly 10.0 SOL
    localStorage.setItem('app_simulationBalance_v4', '10.0');
        localStorage.setItem('app_mySniperTrades', JSON.stringify([]));
    localStorage.setItem('juipter_auto_isRunning', 'false'); // Stopped on reset
    localStorage.setItem('app_activePositions', JSON.stringify({}));
    
    localStorage.removeItem('juipter_auto_startTime');
    localStorage.removeItem('juipter_auto_uptime');
    localStorage.removeItem('juipter_auto_positions');
    localStorage.removeItem('juipter_auto_tradeHistory');
    localStorage.removeItem('juipter_auto_stats');
    localStorage.removeItem('juipter_auto_logs');
    localStorage.removeItem('app_mySniperTrades');
    
    // Delete all token activity and token cache stored in localStorage
    Object.keys(localStorage).forEach(key => {
      if (
        key.startsWith('app_token_') ||
        key.startsWith('token_') ||
        key.includes('token_cache') ||
        key.includes('activePositions') ||
        key.includes('tradeHistory') ||
        key.includes('token_activity')
      ) {
        localStorage.removeItem(key);
      }
    });

    localStorage.setItem('app_activePositions', JSON.stringify({}));
    localStorage.setItem('juipter_auto_positions', JSON.stringify({}));

    clearPriceHistories();

    if (user) {
      try {
        const docRef = doc(db, 'settings', user.uid);
        await setDoc(docRef, {
                    blacklistedMints: JSON.stringify([]),
          positions: JSON.stringify({}),
          tokenMetrics: JSON.stringify({}),
          stats: JSON.stringify({ trades: 0, wins: 0, losses: 0, pnl: 0, bestTrade: null }),
          tradeHistory: JSON.stringify([]),
          updatedAt: new Date().toISOString()
        }, { merge: true });
      } catch (err) {
        console.error('Error resetting settings in Firestore:', err);
      }
    }
  };


  const getUptimeString = () => {
    const h = Math.floor(uptime / 3600);
    const m = Math.floor((uptime % 3600) / 60);
    const s = uptime % 60;
    return `${h}h ${m}m ${s}s`;
  };

  return (
    <div className="flex-1 text-[#e2e8f0] font-sans flex flex-col h-full lg:rounded-2xl overflow-hidden min-h-0" style={{ backgroundImage: 'radial-gradient(circle at top right, #13141f, #050509)' }}>
      <header className="h-14 lg:h-16 border-b border-[#1f212e] flex items-center justify-between px-4 lg:px-6 bg-[#050509]/80 backdrop-blur-md z-10 shrink-0">
        <h1 className="flex items-center gap-1.5 lg:gap-2 font-bold text-[16px] lg:text-[20px] tracking-[-0.5px] text-[#c7f284]">
          <span>⚡</span> JUPITER.AUTO
        </h1>
        <div className="flex items-center gap-3">
          <WalletStatusWidget />
          <div className="flex items-center gap-1.5 border border-[#2d2e3d] bg-[#1a1b26] px-2 py-1 rounded-full text-[10px] lg:text-[11px]">
            <div className={`w-1.5 h-1.5 rounded-full ${jupApiStatus === 'HEALTHY' ? 'bg-[#c7f284]' : jupApiStatus === 'DEGRADED' ? 'bg-amber-400 animate-pulse' : jupApiStatus === 'ERROR' ? 'bg-rose-500' : 'bg-slate-500'}`} />
            <span className={`font-bold uppercase tracking-widest ${jupApiStatus === 'HEALTHY' ? 'text-[#c7f284]' : jupApiStatus === 'DEGRADED' ? 'text-amber-400' : jupApiStatus === 'ERROR' ? 'text-rose-500' : 'text-slate-500'}`}>
              API: {jupApiStatus} {jupApiPing > 0 ? `(${jupApiPing}ms)` : ''}
            </span>
          </div>
          <div className="bg-[#1a1b26] border border-[#2d2e3d] px-2.5 py-1 lg:px-3.5 lg:py-1.5 rounded-full flex items-center gap-1.5 lg:gap-2 text-[11px] lg:text-[13px]">
            <div className={`w-1.5 h-1.5 lg:w-2 lg:h-2 rounded-full ${isRunning ? (isPausedState ? 'bg-amber-500 animate-pulse' : 'bg-[#c7f284]') : 'bg-[#ff4d4d]'}`}></div>
            <span className={`font-medium ${isRunning ? (isPausedState ? 'text-amber-500' : 'text-[#c7f284]') : 'text-[#ff4d4d]'}`}>
              {isRunning ? (isPausedState ? 'PAUSED' : 'LIVE') : 'STOPPED'}
            </span>
          </div>
        </div>
      </header>
      
      <main className="flex-1 grid lg:grid-cols-[280px_1fr_300px] gap-4 p-3 lg:gap-5 lg:p-5 w-full h-[calc(100%-56px)] lg:h-[calc(100%-64px)] overflow-y-auto lg:overflow-hidden pb-32 lg:pb-5">
        {/* Left Column: Configuration & Controls */}
        <aside className="space-y-5 lg:overflow-y-auto scrollbar-hide flex flex-col pr-1 pb-4 min-w-0">
          {/* Master Manual DexScreener Contract Ingestor & Scanner */}
          <div className="bg-[#10111a]/60 border border-[#1f212e] rounded-2xl flex flex-col shrink-0">
            <div className="p-4 border-b border-[#1f212e]">
              <h2 className="text-[12px] uppercase tracking-[1px] text-[#c7f284] font-bold flex items-center gap-1.5">
                <Search className="w-4 h-4 text-[#c7f284]" /> MANUAL SCAN & TARGET BUY
              </h2>
            </div>
            <div className="p-4 space-y-3.5">
              <div>
                <label className="text-[10px] text-[#64748b] mb-1.5 uppercase font-medium block">
                  Solana Mint Contract Address
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={manualSearchInput}
                    onChange={(e) => setManualSearchInput(e.target.value)}
                    placeholder="Enter SOL address or Token Name (e.g. CgRz... or BONK)"
                    className="flex-1 bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 text-xs text-white font-mono focus:outline-none focus:border-[#c7f284] transition-colors"
                  />
                  <button
                    onClick={() => handleManualScan()}
                    disabled={isSearching}
                    className="px-3 bg-indigo-600/20 hover:bg-indigo-600/30 active:bg-indigo-600/40 border border-indigo-500/40 text-[10px] text-white font-bold uppercase rounded-lg transition-all flex items-center justify-center cursor-pointer min-w-[70px] disabled:opacity-50"
                  >
                    {isSearching ? (
                      <span className="w-3.5 h-3.5 border-2 border-indigo-400 border-t-transparent rounded-full animate-spin"></span>
                    ) : (
                      'Scan'
                    )}
                  </button>
                </div>
                {searchError && (
                  <p className="text-red-400 text-[10px] mt-1.5 font-sans leading-tight">
                    {searchError}
                  </p>
                )}
              </div>

              {/* Scanned Result Card */}
              {scannedResult && (
                <div className="bg-[#050509] border border-[#2d2e3d] rounded-xl p-3 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-[13px] font-bold text-white flex items-center gap-1">
                        {scannedResult.symbol}{' '}
                        <span className="text-[#64748b] text-[10px] font-normal">
                          / SOL
                        </span>
                      </div>
                      <div className="text-[10px] text-[#64748b] max-w-[140px] truncate">
                        {scannedResult.name}
                      </div>
                    </div>
                    <span className="text-[9px] bg-emerald-500/10 text-[#c7f284] border border-[#c7f284]/30 rounded px-1.5 py-0.5 font-bold uppercase">
                      {scannedResult.isGraduated ? 'Raydium' : 'Pump.fun'}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-x-2 gap-y-1.5 border-t border-[#1f212e] pt-2 text-[10px] font-mono">
                    <div>
                      <span className="text-[#64748b] text-[8px] block uppercase font-sans">Price USD</span>
                      <span className="text-white font-semibold">${scannedResult.priceUsd.toFixed(8)}</span>
                    </div>
                    <div>
                      <span className="text-[#64748b] text-[8px] block uppercase font-sans">Price SOL</span>
                      <span className="text-[#c7f284] font-semibold">{scannedResult.priceNative.toFixed(8)}</span>
                    </div>
                    <div>
                      <span className="text-[#64748b] text-[8px] block uppercase font-sans">Liquidity</span>
                      <span className="text-white">${scannedResult.liquidityUsd.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                    </div>
                    <div>
                      <span className="text-[#64748b] text-[8px] block uppercase font-sans">24h Vol</span>
                      <span className="text-white">${scannedResult.volume24h.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                    </div>
                  </div>

                  {/* Manual / Discretionary Trigger Box */}
                  <div className="border-t border-[#1f212e] pt-2.5 space-y-2">
                    <div>
                      <label className="text-[9px] text-[#64748b] block uppercase font-sans mb-1 font-semibold">
                        Discretionary Buy Size (SOL)
                      </label>
                      <input
                        type="number"
                        step="0.05"
                        min="0.01"
                        value={discretionaryBuyAmount}
                        onChange={(e) => setDiscretionaryBuyAmount(e.target.value)}
                        className="w-full bg-[#10111a] border border-[#1f212e] rounded-md px-2 py-1 text-xs text-white font-mono focus:outline-none focus:border-[#c7f284]"
                      />
                    </div>
                    <button
                      onClick={handleDiscretionaryBuyTrigger}
                      disabled={isBuyingDiscretionary}
                      className="w-full bg-[#c7f284] hover:bg-[#b0dc68] text-black font-extrabold uppercase rounded-lg text-[10px] py-1.5 transition-all text-center flex items-center justify-center gap-1 cursor-pointer disabled:opacity-50 shadow-[0_0_15px_rgba(199,242,132,0.15)]"
                    >
                      {isBuyingDiscretionary ? (
                        <span className="w-3.5 h-3.5 border-2 border-black border-t-transparent rounded-full animate-spin font-bold"></span>
                      ) : (
                        `⚡ Instant Discretionary Buy`
                      )}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="bg-[#10111a]/60 border border-[#1f212e] rounded-2xl flex flex-col shrink-0">
            <div className="p-4 border-b border-[#1f212e]">
              <h2 className="text-[12px] uppercase tracking-[1px] text-[#94a3b8] font-bold">Bot Configuration</h2>
            </div>
            <div className="p-4 space-y-4">
              <div>
                <div className="flex justify-between items-center text-[11px] text-[#64748b] mb-1.5 uppercase font-medium">
                  <span>Primary RPC Node URL (Execution)</span>
                  {!isSecondaryActive ? (
                    <span className="text-[9px] text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded-full font-bold flex items-center gap-1">● ACTIVE</span>
                  ) : (
                    <span className="text-[9px] text-[#64748b] bg-[#1f212e] px-1.5 py-0.5 rounded-full">INACTIVE (BACKUP)</span>
                  )}
                </div>
                <input type="text" value={rpcUrl} onChange={(e) => setRpcUrl(e.target.value)} placeholder="https://mainnet.helius-rpc.com/..." className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-3 py-2 text-[13px] text-white font-mono focus:outline-none focus:border-[#c7f284] transition-colors" />
              </div>

              {/* MASTER MONITOR PANEL */}
              <MasterMonitorPanel
                rpcUrl={rpcUrl}
                masterMonitorRpc={masterMonitorRpc}
                setMasterMonitorRpc={setMasterMonitorRpc}
                masterMonitorRpc2={masterMonitorRpc2}
                setMasterMonitorRpc2={setMasterMonitorRpc2}
                masterMonitorWs={masterMonitorWs}
                setMasterMonitorWs={setMasterMonitorWs}
              />
              <div>
                <div className="flex justify-between items-center text-[11px] text-[#64748b] mb-1.5 uppercase font-medium">
                  <span>Secondary RPC Node (Load Balancer)</span>
                  {isSecondaryActive ? (
                    <span className="text-[9px] text-amber-400 bg-amber-500/10 px-1.5 py-0.5 rounded-full font-bold flex items-center gap-1">⚡ FAILOVER ACTIVE</span>
                  ) : (
                    <span className="text-[9px] text-[#64748b] bg-[#1f212e] px-1.5 py-0.5 rounded-full">READY</span>
                  )}
                </div>
                <input type="text" value={rpcUrl2} onChange={(e) => {
                  setRpcUrl2(e.target.value);
                }} placeholder="https://mainnet.helius-rpc.com/... (Dynamic Fallback)" className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-3 py-2 text-[13px] text-white font-mono focus:outline-none focus:border-[#c7f284] transition-colors" />
              </div>
              <div>
                <div className="flex justify-between text-[11px] text-[#64748b] mb-1.5 uppercase font-medium"><span>Custom WSS (Websocket) URL</span></div>
                <input type="text" value={customWsUrl} onChange={(e) => setCustomWsUrl(e.target.value)} placeholder="wss://... (Optional fallback to Primary)" className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-3 py-2 text-[13px] text-white font-mono focus:outline-none focus:border-[#c7f284] transition-colors" />
              </div>
              <div>
                <div className="flex items-center justify-between gap-3 relative">
                  <div className="w-full">
                    <label className="text-[11px] text-[#64748b] mb-1.5 uppercase font-medium block">Slippage (%)</label>
                    <input type="number" step="0.1" value={slippage} onChange={(e) => setSlippage(Number(e.target.value))} className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-3 py-2 text-[13px] text-white font-mono focus:outline-none focus:border-[#c7f284] transition-colors" />
                  </div>
                </div>
              </div>

              {/* Secure Trading Configuration Panel */}
              <div className="pt-3 border-t border-[#1f212e]/60">
                <div className="mb-3">
                  <span className="text-[11px] text-[#94a3b8] uppercase font-bold tracking-wider flex items-center gap-1.5 mb-1">
                    <span>🔐</span> Secure Key Encryption & Trading Settings
                  </span>
                  <p className="text-[10px] text-[#64748b]">AES-GCM client-side encryption for Jupiter API Keys & Private Keys</p>
                </div>
                <TradingSettings />
              </div>



              {/* Helius Sender Sub-panel */}
              <div className="pt-3 border-t border-[#1f212e]/60">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex flex-col">
                    <span className="text-[11px] text-[#94a3b8] uppercase font-bold tracking-wider flex items-center gap-1.5">
                      <span>🚀</span> Helius Sender Service
                    </span>
                    <span className="text-[9px] text-[#64748b]">Ultra-low latency dual validator routing</span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer select-none">
                    <input 
                      type="checkbox" 
                      checked={senderEnabled} 
                      onChange={(e) => {
                        setSenderEnabled(e.target.checked);
                        addLog(`Helius Sender service toggled ${e.target.checked ? 'ON' : 'OFF'}.`, 'info');
                      }} 
                      className="sr-only peer" 
                    />
                    <div className="w-9 h-5 bg-[#1b1c26] border border-[#2d2e3d] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[4px] after:left-[4px] after:bg-[#64748b] peer-checked:after:bg-[#c7f284] after:border-gray-300 after:border after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-[#c7f284]/10 peer-checked:border-[#c7f284]/50"></div>
                  </label>
                </div>

                {senderEnabled && (
                  <div className="space-y-3 mt-3 bg-[#08080f]/50 border border-[#1f212e]/80 rounded-xl p-3 transition-all">
                    <div>
                      <div className="flex justify-between text-[10px] text-[#64748b] mb-1 uppercase font-medium">
                        <span>Helius API Key</span>
                      </div>
                      <input 
                        type="password" 
                        value={senderApiKey} 
                        onChange={(e) => setSenderApiKey(e.target.value)} 
                        placeholder="Helius API Key (Optional / default to RPC Key)" 
                        className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-3 py-1.5 text-[12px] text-white font-mono focus:outline-none focus:border-[#c7f284] transition-colors" 
                      />
                    </div>

                    <div>
                      <div className="flex justify-between text-[10px] text-[#64748b] mb-1 uppercase font-medium">
                        <span>Regional Endpoint</span>
                      </div>
                      <select 
                        value={senderEndpoint} 
                        onChange={(e) => {
                          setSenderEndpoint(e.target.value);
                          addLog(`Helius regional endpoint updated: ${e.target.value}`, 'info');
                        }}
                        className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 text-[12px] text-white font-mono focus:outline-none focus:border-[#c7f284] transition-colors"
                      >
                        <option value="https://sender.helius-rpc.com/fast">Global Routing (Default)</option>
                        <option value="https://slc-sender.helius-rpc.com/fast">Salt Lake City (SLC)</option>
                        <option value="https://ewr-sender.helius-rpc.com/fast">Newark (EWR)</option>
                        <option value="https://lon-sender.helius-rpc.com/fast">London (LON)</option>
                        <option value="https://fra-sender.helius-rpc.com/fast">Frankfurt (FRA)</option>
                        <option value="https://ams-sender.helius-rpc.com/fast">Amsterdam (AMS)</option>
                        <option value="https://sg-sender.helius-rpc.com/fast">Singapore (SG)</option>
                        <option value="https://tyo-sender.helius-rpc.com/fast">Tokyo (TYO)</option>
                      </select>
                    </div>

                    <div className="flex items-center justify-between pt-1">
                      <div className="flex flex-col">
                        <span className="text-[10px] text-[#64748b] uppercase font-medium">SWQOS-Only Mode</span>
                        <span className="text-[8px] text-[#475569] max-w-[180px]">Optimized for staked connections with lower tip size (0.000005 SOL)</span>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input 
                          type="checkbox" 
                          checked={senderSwqos} 
                          onChange={(e) => {
                            setSenderSwqos(e.target.checked);
                            addLog(`Helius SWQOS-Only Mode toggled ${e.target.checked ? 'ON (0.000005 SOL min tip)' : 'OFF (0.0002 SOL min tip)'}.`, 'info');
                          }} 
                          className="sr-only peer" 
                        />
                        <div className="w-8 h-4 bg-[#1b1c26] border border-[#2d2e3d] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[3px] after:left-[3px] after:bg-[#475569] peer-checked:after:bg-[#c7f284] after:border-gray-300 after:border after:rounded-full after:h-2.5 after:w-2.5 after:transition-all peer-checked:bg-[#c7f284]/10 peer-checked:border-[#c7f284]/50"></div>
                      </label>
                    </div>
                  </div>
                )}
              </div>

              {/* Helius LaserStream Sub-panel */}
              <div className="pt-3 border-t border-[#1f212e]/60">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex flex-col">
                    <span className="text-[11px] text-[#94a3b8] uppercase font-bold tracking-wider flex items-center gap-1.5">
                      <span>⚡</span> Helius LaserStream Ingest
                    </span>
                    <span className="text-[9px] text-[#64748b]">Ultra-low latency direct gRPC feed with automatic replay</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {laserstreamEnabled && (
                      <div className="flex items-center gap-1.5">
                        <span className={`text-[8px] font-mono font-bold uppercase rounded px-1.5 py-0.5 ${
                          laserstreamStatus === 'connected' ? 'bg-[#c7f284]/15 text-[#c7f284] border border-[#c7f284]/30' :
                          laserstreamStatus === 'degraded' ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30 animate-pulse' :
                          laserstreamStatus === 'replaying' ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 animate-pulse' :
                          laserstreamStatus === 'stale' ? 'bg-yellow-500/15 text-yellow-300 border border-yellow-500/30' :
                          laserstreamStatus === 'connecting' ? 'bg-slate-500/15 text-slate-300 border border-slate-500/30' :
                          'bg-rose-500/15 text-rose-300 border border-rose-500/30'
                        }`}>
                          {laserstreamStatus === 'connected' ? '🟢 CONNECTED' :
                           laserstreamStatus === 'degraded' ? '🟠 DEGRADED' :
                           laserstreamStatus === 'replaying' ? '🔵 REPLAYING' :
                           laserstreamStatus === 'disconnected' ? '🔴 DISCONNECTED' :
                           laserstreamStatus.toUpperCase()}
                        </span>
                        {(laserstreamStatus === 'connected' || laserstreamStatus === 'degraded') && (
                          <span className="text-[8px] font-mono font-bold uppercase rounded px-1.5 py-0.5 bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                            gRPC Geyser
                          </span>
                        )}
                        {laserstreamStatus === 'connected' && (
                          <span className={`text-[8px] font-mono font-bold uppercase rounded px-1.5 py-0.5 ${
                            laserstreamSlotMetrics.ingestionState === 'active' ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30' :
                            'bg-slate-500/15 text-slate-300 border border-slate-500/30'
                          }`}>
                            {laserstreamSlotMetrics.ingestionState === 'active' ? 'Active' : 'Idle'}
                          </span>
                        )}
                      </div>
                    )}
                    <label className="relative inline-flex items-center cursor-pointer select-none">
                      <input 
                        type="checkbox" 
                        checked={laserstreamEnabled} 
                        onChange={(e) => {
                          setLaserstreamEnabled(e.target.checked);
                          addLog(`Helius LaserStream gRPC client toggled ${e.target.checked ? 'ON' : 'OFF'}.`, 'info');
                        }} 
                        className="sr-only peer" 
                      />
                      <div className="w-9 h-5 bg-[#1b1c26] border border-[#2d2e3d] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[4px] after:left-[4px] after:bg-[#64748b] peer-checked:after:bg-[#c7f284] after:border-gray-300 after:border after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-[#c7f284]/10 peer-checked:border-[#c7f284]/50"></div>
                    </label>
                  </div>
                </div>

                {laserstreamEnabled && (
                  <div className="space-y-3 mt-3 bg-[#08080f]/50 border border-[#1f212e]/80 rounded-xl p-3 transition-all">
                    {/* Real-time Slot & Queue Telemetry Ribbon */}
                    <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5 bg-[#0d0e17] border border-[#1f212e] rounded-lg p-2 text-center font-mono">
                      <div className="flex flex-col">
                        <span className="text-[8px] text-[#64748b] uppercase">Recv Slot</span>
                        <span className="text-[10px] text-white font-bold truncate">
                          {laserstreamSlotMetrics.lastReceivedSlot > 0 ? laserstreamSlotMetrics.lastReceivedSlot.toLocaleString() : '---'}
                        </span>
                      </div>
                      <div className="flex flex-col">
                        <span className="text-[8px] text-[#64748b] uppercase">Proc Slot</span>
                        <span className="text-[10px] text-slate-300 font-bold truncate">
                          {laserstreamSlotMetrics.lastProcessedSlot > 0 ? laserstreamSlotMetrics.lastProcessedSlot.toLocaleString() : '---'}
                        </span>
                      </div>
                      <div className="flex flex-col">
                        <span className="text-[8px] text-[#64748b] uppercase">Slot Lag</span>
                        <span className={`text-[10px] font-bold ${laserstreamSlotMetrics.slotLag > 5 ? 'text-amber-400' : 'text-emerald-400'}`}>
                          {laserstreamSlotMetrics.slotLag}
                        </span>
                      </div>
                      <div className="flex flex-col">
                        <span className="text-[8px] text-[#64748b] uppercase">Queue</span>
                        <span className={`text-[10px] font-bold ${laserstreamSlotMetrics.queueDepth > 20 ? 'text-amber-400' : 'text-[#94a3b8]'}`}>
                          {laserstreamSlotMetrics.queueDepth}
                        </span>
                      </div>
                      <div className="flex flex-col">
                        <span className="text-[8px] text-[#64748b] uppercase">Processing</span>
                        <span className={`text-[10px] font-bold ${laserstreamSlotMetrics.processingLagMs > 100 ? 'text-amber-400' : 'text-emerald-400'}`}>
                          {laserstreamSlotMetrics.processingLagMs}ms
                        </span>
                      </div>
                      <div className="flex flex-col">
                        <span className="text-[8px] text-[#64748b] uppercase">Ingestion</span>
                        <span className={`text-[10px] font-bold ${laserstreamSlotMetrics.isReplaying ? 'text-cyan-400' : laserstreamSlotMetrics.ingestionState === 'active' ? 'text-emerald-400' : 'text-[#64748b]'}`}>
                          {laserstreamSlotMetrics.isReplaying ? 'REPLAY' : laserstreamSlotMetrics.ingestionState === 'active' ? 'ACTIVE' : 'IDLE'}
                        </span>
                      </div>
                    </div>

                    {/* Degraded / Replaying Informational Banner */}
                    {laserstreamStatus === 'degraded' && (
                      <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg px-2.5 py-1.5 text-[10px] text-amber-300 flex items-center gap-2">
                        <span>🟠</span>
                        <span>
                          Processing lag ({laserstreamSlotMetrics.processingLagMs}ms) or queue depth ({laserstreamSlotMetrics.queueDepth}) elevated. Streaming continues without dropping events.
                        </span>
                      </div>
                    )}
                    {laserstreamStatus === 'replaying' && (
                      <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg px-2.5 py-1.5 text-[10px] text-cyan-300 flex items-center gap-2">
                        <span>🔵</span>
                        <span>
                          Replaying historical slots {laserstreamSlotMetrics.replayFromSlot ? `from ${laserstreamSlotMetrics.replayFromSlot.toLocaleString()}` : ''} to catch up with chain tip.
                        </span>
                      </div>
                    )}

                    <div>
                      <div className="flex justify-between text-[10px] text-[#64748b] mb-1 uppercase font-medium">
                        <span>LaserStream API Key</span>
                      </div>
                      <input 
                        type="password" 
                        value={laserstreamApiKey} 
                        onChange={(e) => setLaserstreamApiKey(e.target.value)} 
                        placeholder={HELIUS_API_KEY} 
                        className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-3 py-1.5 text-[12px] text-white font-mono focus:outline-none focus:border-[#c7f284] transition-colors" 
                      />
                    </div>

                    <div>
                      <div className="flex justify-between items-end text-[10px] text-[#64748b] mb-1 uppercase font-medium">
                        <span>Regional Hub</span>
                        {laserstreamStatus === 'connected' && laserstreamActiveEndpoint && (
                          <span className="text-[8px] text-emerald-400 font-mono tracking-tighter truncate max-w-[120px] ml-2 border-b border-emerald-500/30" title={laserstreamActiveEndpoint}>
                            {laserstreamActiveEndpoint.replace('https://', '').replace('wss://', '')}
                          </span>
                        )}
                      </div>
                      <select 
                        value={laserstreamEndpoint} 
                        onChange={(e) => {
                          setLaserstreamEndpoint(e.target.value);
                          addLog(`LaserStream geo-region routed to: ${e.target.value}`, 'info');
                        }}
                        className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 text-[12px] text-white font-mono focus:outline-none focus:border-[#c7f284] transition-colors"
                      >
                        <option value="auto">⚡ Auto-Select Fastest (TLS Ping)</option>
                        <option value="https://laserstream-mainnet-ams.helius-rpc.com">Amsterdam (AMS) - Europe Edge</option>
                        <option value="https://laserstream-mainnet-fra.helius-rpc.com">Frankfurt (FRA) - Central Europe</option>
                        <option value="https://laserstream-mainnet-lon.helius-rpc.com">London (LON) - UK Edge</option>
                        <option value="https://laserstream-mainnet-ewr.helius-rpc.com">Newark (EWR) - East US Edge</option>
                        <option value="https://laserstream-mainnet-tyo.helius-rpc.com">Tokyo (TYO) - Asia Edge</option>
                        <option value="https://laserstream-mainnet-sgp.helius-rpc.com">Singapore (SGP) - Asia Edge</option>
                      </select>
                    </div>

                    <div className="flex flex-col gap-1 pt-1 border-t border-[#1f212e]/40">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] text-[#64748b] uppercase font-bold tracking-wider">📡 Active gRPC Filters</span>
                        <span className="text-[8px] font-mono text-[#94a3b8] uppercase">{tradingNetwork}</span>
                      </div>
                      <div className="flex flex-wrap gap-1 mt-1">
                        <span className="text-[8px] bg-[#c7f284]/10 text-[#c7f284] border border-[#c7f284]/25 px-1.5 py-0.5 rounded font-mono font-medium">Pump.fun Ingestion</span>
                        <span className="text-[8px] bg-[#c7f284]/10 text-[#c7f284] border border-[#c7f284]/25 px-1.5 py-0.5 rounded font-mono font-medium">Raydium Liquidity Pool</span>
                        <span className="text-[8px] bg-[#c7f284]/10 text-[#c7f284] border border-[#c7f284]/25 px-1.5 py-0.5 rounded font-mono font-medium">Jupiter v6 Executable Pre-Sell Only</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* DexScreener Engine Sub-panel */}
              <div className="pt-3 border-t border-[#1f212e]/60">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex flex-col">
                    <span className="text-[11px] text-[#94a3b8] uppercase font-bold tracking-wider flex items-center gap-1.5">
                      <span>📊</span> DexScreener Engine
                    </span>
                    <span className="text-[9px] text-[#64748b]">Real-time new profile scanning & updates</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {dexScreenerEnabled && isRunning && (
                      <span className="text-[8px] font-mono font-bold uppercase rounded px-1.5 py-0.5 bg-[#c7f284]/15 text-[#c7f284] border border-[#c7f284]/30 animate-pulse">
                        polling
                      </span>
                    )}
                    <label className="relative inline-flex items-center cursor-pointer select-none">
                      <input 
                        type="checkbox" 
                        checked={dexScreenerEnabled} 
                        onChange={(e) => {
                          setDexScreenerEnabled(e.target.checked);
                          addLog(`DexScreener Engine toggled ${e.target.checked ? 'ON' : 'OFF'}.`, 'info');
                        }} 
                        className="sr-only peer" 
                      />
                      <div className="w-9 h-5 bg-[#1b1c26] border border-[#2d2e3d] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[4px] after:left-[4px] after:bg-[#64748b] peer-checked:after:bg-[#c7f284] after:border-gray-300 after:border after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-[#c7f284]/10 peer-checked:border-[#c7f284]/50"></div>
                    </label>
                  </div>
                </div>

                {dexScreenerEnabled && (
                  <div className="mt-2.5 mb-1 bg-[#090a0f]/50 p-2 rounded border border-[#2d2e3d]/40">
                    <div className="flex justify-between items-center mb-1.5 text-[9px] text-[#64748b] font-mono">
                      <span>Unified Ingestion:</span>
                      <span className="text-[#c7f284] font-bold">6 Premium Feeds Active</span>
                    </div>
                    <button
                      onClick={async () => {
                        addLog("⚡ [DEXSCREENER INGESTION] Manually triggering aggregation (Profiles, Recent Updates, CT, Ads, Boosts)...", "info");
                        setForceDexRefresh(prev => prev + 1);
                      }}
                      className="w-full bg-[#c7f284]/10 border border-[#c7f284]/35 hover:bg-[#c7f284]/20 text-[#c7f284] text-[10px] font-bold py-1.5 px-2.5 rounded flex items-center justify-center gap-1.5 transition-all text-center cursor-pointer"
                    >
                      <span>🔄</span> Sync & Ingest More Tokens
                    </button>
                  </div>
                )}
              </div>

              {/* Trade Frequency & Rebuy Guard */}
              <div className="bg-[#050509] border border-[#2d2e3d] rounded-lg p-3 mb-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-[#94a3b8] uppercase font-bold tracking-wider">
                      🛡️ Trade Tokens Only Once (No Rebuy)
                    </span>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded font-mono font-bold ${tradeOnlyOnce ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'}`}>
                      {tradeOnlyOnce ? '1x Only / No Rebuy' : `Rebuy: Max ${maxRebuyTimes}x`}
                    </span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      id="toggle-trade-only-once-pnl"
                      type="checkbox" 
                      checked={tradeOnlyOnce} 
                      onChange={(e) => {
                        const next = e.target.checked;
                        setTradeOnlyOnce(next);
                        useAppStore.getState().setTradeOnlyOnce(next);
                        if (next) {
                          setMaxRebuyTimes(1);
                          useAppStore.getState().setMaxRebuyTimes(1);
                        }
                      }} 
                      className="sr-only peer"
                    />
                    <div className="w-9 h-5 bg-[#2d2e3d] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-500"></div>
                  </label>
                </div>
                <p className="text-[10px] text-[#64748b] leading-tight">
                  {tradeOnlyOnce 
                    ? "Each token will strictly be traded 1 time only. Already traded tokens will be permanently filtered out from candidate discovery and sniper buy loops." 
                    : `Tokens can be rebought up to ${maxRebuyTimes} times before being blocked.`}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-3">
                <div>
                  <div className="flex justify-between text-[11px] text-[#64748b] mb-1.5 uppercase font-medium"><span>Trade Size</span><span>SOL</span></div>
                  <input type="number" min="0.05" step="0.01" value={tradeAmount} onChange={(e) => setTradeAmount(Number(e.target.value))} className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-3 py-2 text-[13px] text-white font-mono focus:outline-none focus:border-[#c7f284] transition-colors" />
                </div>
                <div>
                  <div className="flex justify-between text-[11px] text-[#64748b] mb-1.5 uppercase font-medium"><span>Max Pos (0 = ♾️)</span></div>
                  <input type="number" value={maxPositions} onChange={(e) => setMaxPositions(Number(e.target.value))} className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-3 py-2 text-[13px] text-white font-mono focus:outline-none focus:border-[#c7f284] transition-colors" />
                </div>
                <div>
                  <div className="flex justify-between text-[11px] text-[#64748b] mb-1.5 uppercase font-medium">
                    <span>Max Rebuy Times</span>
                    {tradeOnlyOnce && <span className="text-[10px] text-emerald-400 font-mono">Locked: 1</span>}
                  </div>
                  <input 
                    id="input-max-rebuy-times" 
                    type="number" 
                    min="1" 
                    step="1" 
                    disabled={tradeOnlyOnce}
                    value={tradeOnlyOnce ? 1 : maxRebuyTimes} 
                    onChange={(e) => {
                      const val = Math.max(1, Number(e.target.value));
                      setMaxRebuyTimes(val);
                      useAppStore.getState().setMaxRebuyTimes(val);
                    }} 
                    className={`w-full bg-[#050509] border rounded-lg px-3 py-2 text-[13px] font-mono focus:outline-none transition-colors ${tradeOnlyOnce ? 'border-[#2d2e3d]/50 text-slate-500 cursor-not-allowed' : 'border-[#2d2e3d] text-white focus:border-[#c7f284]'}`} 
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3 mb-3">
                <div>
                  <div className="flex justify-between text-[11px] text-[#64748b] mb-1.5 uppercase font-medium"><span>Take Profit (Raydium)</span><span>%</span></div>
                  <input type="number" value={minTakeProfit} onChange={(e) => {
                    const val = Number(e.target.value);
                    setMinTakeProfit(val);
                    setTakeProfitPct(Math.floor(val * 1.5));
                  }} className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-3 py-2 text-[13px] text-white font-mono focus:outline-none focus:border-[#c7f284] transition-colors" />
                </div>
                <div>
                  <div className="flex justify-between text-[11px] text-[#64748b] mb-1.5 uppercase font-medium"><span>Take Profit (Bonding)</span><span>%</span></div>
                  <input type="number" value={bondingCurveTakeProfit} onChange={(e) => {
                    const val = Number(e.target.value);
                    setBondingCurveTakeProfit(val);
                  }} className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-3 py-2 text-[13px] text-white font-mono focus:outline-none focus:border-[#c7f284] transition-colors" />
                </div>
              </div>
              {/* Unified Stop Loss Toggle */}
              <div className="flex items-center justify-between bg-[#050509] border border-[#2d2e3d] rounded-lg px-3 py-2 mb-2">
                <span className="text-[11px] text-[#94a3b8] uppercase font-bold tracking-wider">
                  🔗 Lock Stop Loss across all venues
                </span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={unifyStopLoss} 
                    onChange={(e) => {
                      const next = e.target.checked;
                      setUnifyStopLoss(next);
                      if (next) {
                        // Immediately sync all venues to the current Raydium value
                        const master = -Math.abs(stopLossPct || 15);
                        setStopLoss(master);
                        setBondingCurveStopLoss(master);
                        setPumpSwapStopLoss(master);
                        setUnknownStopLoss(master);
                      }
                    }}
                    className="sr-only peer" 
                  />
                  <div className="w-9 h-5 bg-[#1b1c26] border border-[#2d2e3d] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[4px] after:left-[4px] after:bg-[#64748b] peer-checked:after:bg-[#c7f284] after:border-gray-300 after:border after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-[#c7f284]/10 peer-checked:border-[#c7f284]/50"></div>
                </label>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                <div>
                  <div className="flex justify-between text-[11px] text-[#64748b] mb-1.5 uppercase font-medium">
                    <span>Stop Loss {unifyStopLoss ? '(All Venues)' : '(Raydium)'}</span><span>%</span>
                  </div>
                  <input 
                    type="number" 
                    value={stopLossPct} 
                    onChange={(e) => propagateSlChange(Number(e.target.value), 'raydium')} 
                    className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-3 py-2 text-[13px] text-white font-mono focus:outline-none focus:border-[#c7f284] transition-colors" 
                    id="input-sl-raydium" 
                  />
                </div>
                <div className={unifyStopLoss ? 'opacity-40 pointer-events-none' : ''}>
                  <div className="flex justify-between text-[11px] text-[#64748b] mb-1.5 uppercase font-medium">
                    <span>Stop Loss (Bonding)</span><span>%</span>
                  </div>
                  <input 
                    type="number" 
                    value={bondingCurveStopLossPct} 
                    onChange={(e) => propagateSlChange(Number(e.target.value), 'bonding')} 
                    className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-3 py-2 text-[13px] text-white font-mono focus:outline-none focus:border-[#c7f284] transition-colors" 
                    id="input-sl-bonding" 
                  />
                </div>
                <div className={unifyStopLoss ? 'opacity-40 pointer-events-none' : ''}>
                  <div className="flex justify-between text-[11px] text-[#64748b] mb-1.5 uppercase font-medium">
                    <span>Stop Loss (PumpSwap)</span><span>%</span>
                  </div>
                  <input 
                    type="number" 
                    value={pumpSwapStopLossPct} 
                    onChange={(e) => propagateSlChange(Number(e.target.value), 'pumpswap')} 
                    className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-3 py-2 text-[13px] text-white font-mono focus:outline-none focus:border-[#c7f284] transition-colors" 
                    id="input-sl-pumpswap" 
                  />
                </div>
                <div className={unifyStopLoss ? 'opacity-40 pointer-events-none' : ''}>
                  <div className="flex justify-between text-[11px] text-[#64748b] mb-1.5 uppercase font-medium">
                    <span>Stop Loss (Unknown)</span><span>%</span>
                  </div>
                  <input 
                    type="number" 
                    value={unknownStopLossPct} 
                    onChange={(e) => propagateSlChange(Number(e.target.value), 'unknown')} 
                    className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-3 py-2 text-[13px] text-white font-mono focus:outline-none focus:border-[#c7f284] transition-colors" 
                    id="input-sl-unknown" 
                  />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-[11px] text-[#64748b] mb-1.5 uppercase font-medium"><span>Risk Level</span></div>
                <div className="flex gap-2">
                  {(Object.entries(RISK_PROFILES) as [keyof typeof RISK_PROFILES, typeof RISK_PROFILES['low']][]).map(([key, profile]) => {
                    const Icon = profile.icon;
                    return (
                      <button
                        key={key}
                        onClick={() => setSelectedRisk(key)}
                        className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-lg text-xs font-semibold uppercase tracking-wide transition-colors border ${
                          selectedRisk === key ? 'bg-[#1a1b26] border-[#c7f284] text-[#c7f284]' : 'bg-[#050509] border-[#2d2e3d] text-[#64748b] hover:border-[#64748b]'
                        }`}
                      >
                        <Icon className="w-3.5 h-3.5" />
                        {profile.label}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* Strict Auditing Criteria (Hardened) Setup */}
          <div className="bg-[#10111a]/60 border border-[#1f212e] rounded-2xl flex flex-col shrink-0">
            <button 
              onClick={() => setIsAuditingOpen(!isAuditingOpen)}
              className="p-4 flex items-center justify-between text-left select-none focus:outline-none w-full"
            >
              <h2 className="text-[12px] uppercase tracking-[1px] text-[#94a3b8] font-bold flex items-center gap-2">
                <span>🔐</span> Strict Auditing Criteria
                <SyncStatusBadge className="ml-2 scale-90 origin-left" />
              </h2>
              {isAuditingOpen ? (
                <ChevronUp className="w-4 h-4 text-[#94a3b8]" />
              ) : (
                <ChevronDown className="w-4 h-4 text-[#94a3b8]" />
              )}
            </button>
            
            {isAuditingOpen && (
              <div className="px-4 pb-4 border-t border-[#1f212e] pt-4 space-y-4 text-xs font-sans">
                <div className="flex items-center justify-between mb-4 pb-3 border-b border-[#1f212e]">
                   <span className="text-[10px] text-[#64748b] leading-relaxed">
                      These limits define the strict criteria expected before a token is autotraded.
                   </span>
                   <button
                     onClick={() => setShowDocsModal(true)}
                     className="px-3 py-1.5 bg-[#1f212e] hover:bg-[#2d2e3d] text-[#c7f284] text-[10px] uppercase font-bold tracking-wider rounded-lg border border-[#c7f284]/20 transition-all flex items-center gap-1"
                   >
                     <BookOpen className="w-3 h-3" /> Engine Docs
                   </button>
                </div>

                {/* Section: Match Requirement */}
                <div className="space-y-2 pb-3 border-b border-[#1f212e]">
                  <div className="text-[10px] font-bold uppercase text-[#c7f284] flex justify-between">
                     <span>Required Match Percentage</span>
                     <span className="font-mono">{hardenedMatchRequirement}%</span>
                  </div>
                  <input 
                    type="range" 
                    min="10" 
                    max="100" 
                    step="5"
                    value={hardenedMatchRequirement}
                    onChange={(e) => setHardenedMatchRequirement && setHardenedMatchRequirement(Number(e.target.value))}
                    className="w-full accent-[#c7f284]"
                  />
                  <p className="text-[9px] text-[#64748b] leading-tight">
                    Real-time Alert Feeds and Background Scanners are now programmatically forced to pass {hardenedMatchRequirement}% of these parameters. Set to 100% for strict maximum safety enforcement.
                  </p>
                </div>

                {/* Section: Platform Filters */}
                <div className="space-y-2">
                  <div className="text-[10px] font-bold uppercase text-[#64748b]">DEX Platform Sources</div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    <label className="flex items-center gap-2 cursor-pointer bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 focus-within:border-[#c7f284] select-none h-[32px]">
                      <input 
                        type="checkbox" 
                        checked={tradePumpFun} 
                        onChange={(e) => setTradePumpFun(e.target.checked)} 
                        className="rounded border-[#2d2e3d] bg-[#050509] text-[#c7f284] focus:ring-0 focus:ring-offset-0 h-3.5 w-3.5"
                      />
                      <span className="text-[10px] text-white font-mono uppercase">Pump.fun</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 focus-within:border-[#c7f284] select-none h-[32px]">
                      <input 
                        type="checkbox" 
                        checked={tradeRaydium} 
                        onChange={(e) => setTradeRaydium(e.target.checked)} 
                        className="rounded border-[#2d2e3d] bg-[#050509] text-[#c7f284] focus:ring-0 focus:ring-offset-0 h-3.5 w-3.5"
                      />
                      <span className="text-[10px] text-white font-mono uppercase">Raydium</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 focus-within:border-[#c7f284] select-none h-[32px]">
                      <input 
                        type="checkbox" 
                        checked={tradeUnknown} 
                        onChange={(e) => setTradeUnknown && setTradeUnknown(e.target.checked)} 
                        className="rounded border-[#2d2e3d] bg-[#050509] text-[#c7f284] focus:ring-0 focus:ring-offset-0 h-3.5 w-3.5"
                      />
                      <span className="text-[10px] text-white font-mono uppercase">Unknown Token</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 focus-within:border-[#c7f284] select-none h-[32px]">
                      <input 
                        type="checkbox" 
                        checked={tradeBonding} 
                        onChange={(e) => setTradeBonding && setTradeBonding(e.target.checked)} 
                        className="rounded border-[#2d2e3d] bg-[#050509] text-[#c7f284] focus:ring-0 focus:ring-offset-0 h-3.5 w-3.5"
                      />
                      <span className="text-[10px] text-white font-mono uppercase">Bonding</span>
                    </label>
                  </div>
                </div>

                {/* Section: USDC Routing Options */}
                <div className="space-y-2">
                  <div className="text-[10px] font-bold uppercase text-[#64748b]">USDC Swap Routing</div>
                  <label className="flex items-center gap-2 cursor-pointer bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 focus-within:border-[#c7f284] select-none h-[32px]">
                    <input 
                      type="checkbox" 
                      checked={forceUsdcRouting} 
                      onChange={(e) => setForceUsdcRouting(e.target.checked)} 
                      className="rounded border-[#2d2e3d] bg-[#050509] text-[#c7f284] focus:ring-0 focus:ring-offset-0 h-3.5 w-3.5"
                    />
                    <span className="text-[10px] text-white font-mono uppercase">Force swaps via USDC (SOL ↔ USDC ↔ Token)</span>
                  </label>
                  <p className="text-[9px] text-[#64748b] leading-tight">
                    Trades in two distinct segments. Use for tokens like <b className="text-white">2Qsp8Ydg...</b> that only pair against USDC. (Auto fallback is active if unchecked).
                  </p>
                </div>

                {/* Section: Market Cap limits */}
                <div className="space-y-2">
                  <div className="text-[10px] font-bold uppercase text-[#64748b]">Market Capitalization ($)</div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <span className="text-[9px] text-[#94a3b8] uppercase font-medium">Min Pump</span>
                      <input 
                        type="number" 
                        value={hardenedMcapMinPump} 
                        onChange={(e) => setHardenedMcapMinPump(Number(e.target.value))} 
                        className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 text-[11px] text-white font-mono focus:outline-none focus:border-[#c7f284] mt-1"
                      />
                    </div>
                    <div>
                      <span className="text-[9px] text-[#94a3b8] uppercase font-medium">Min Raydium</span>
                      <input 
                        type="number" 
                        value={hardenedMcapMinRaydium} 
                        onChange={(e) => setHardenedMcapMinRaydium(Number(e.target.value))} 
                        className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 text-[11px] text-white font-mono focus:outline-none focus:border-[#c7f284] mt-1"
                      />
                    </div>
                  </div>
                  <div>
                    <span className="text-[9px] text-[#94a3b8] uppercase font-medium">Max Cap Limit</span>
                    <input 
                      type="number" 
                      value={hardenedMcapMax} 
                      onChange={(e) => setHardenedMcapMax(Number(e.target.value))} 
                      className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 text-[11px] text-white font-mono focus:outline-none focus:border-[#c7f284] mt-1"
                    />
                  </div>
                </div>

                {/* Section: Liquidity & Ratio */}
                <div className="space-y-2 pt-2 border-t border-[#1f212e]">
                  <div className="text-[10px] font-bold uppercase text-[#64748b]">Liquidity & Security Ratio</div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <span className="text-[9px] text-[#94a3b8] uppercase font-medium">Min Liquidity ($)</span>
                      <input 
                        type="number" 
                        value={hardenedLiquidityMin} 
                        onChange={(e) => setHardenedLiquidityMin(Number(e.target.value))} 
                        className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 text-[11px] text-white font-mono focus:outline-none focus:border-[#c7f284] mt-1"
                      />
                    </div>
                    <div>
                      <span className="text-[9px] text-[#94a3b8] uppercase font-medium">Liq Ratio (%)</span>
                      <input 
                        type="number" 
                        value={hardenedLiquidityRatio} 
                        onChange={(e) => setHardenedLiquidityRatio(Number(e.target.value))} 
                        className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 text-[11px] text-white font-mono focus:outline-none focus:border-[#c7f284] mt-1"
                      />
                    </div>
                  </div>
                </div>

                {/* Section: Blocking Velocity & Transactions */}
                <div className="space-y-2 pt-2 border-t border-[#1f212e]">
                  <div className="text-[10px] font-bold uppercase text-[#64748b]">Velocity & Ratio (Hardened)</div>
                  <div className="grid grid-cols-3 gap-1.5">
                    <div>
                      <span className="text-[9px] text-[#94a3b8] uppercase font-medium">Min Buyers</span>
                      <input 
                        type="number" 
                        value={hardenedMinUniqueBuyers30s} 
                        onChange={(e) => setHardenedMinUniqueBuyers30s(Number(e.target.value))} 
                        className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-1.5 py-1.5 text-[11px] text-white font-mono focus:outline-none focus:border-[#c7f284] mt-1"
                      />
                    </div>
                    <div>
                      <span className="text-[9px] text-[#94a3b8] uppercase font-medium">Min Buys</span>
                      <input 
                        type="number" 
                        value={hardenedMinBuyCount30s} 
                        onChange={(e) => setHardenedMinBuyCount30s(Number(e.target.value))} 
                        className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-1.5 py-1.5 text-[11px] text-white font-mono focus:outline-none focus:border-[#c7f284] mt-1"
                      />
                    </div>
                    <div>
                      <span className="text-[9px] text-[#94a3b8] uppercase font-medium">Max Buys</span>
                      <input 
                        type="number" 
                        value={hardenedMaxBuyCount30s} 
                        onChange={(e) => setHardenedMaxBuyCount30s(Number(e.target.value))} 
                        className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-1.5 py-1.5 text-[11px] text-white font-mono focus:outline-none focus:border-[#c7f284] mt-1"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <span className="text-[9px] text-[#94a3b8] uppercase font-medium">Min VelRatio</span>
                      <input 
                        type="number" 
                        step="0.1"
                        value={hardenedMinBuySellRatio} 
                        onChange={(e) => setHardenedMinBuySellRatio(Number(e.target.value))} 
                        className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 text-[11px] text-white font-mono focus:outline-none focus:border-[#c7f284] mt-1"
                      />
                    </div>
                    <div>
                      <span className="text-[9px] text-[#94a3b8] uppercase font-medium">Max VelRatio</span>
                      <input 
                        type="number" 
                        step="0.1"
                        value={hardenedMaxBuySellRatio} 
                        onChange={(e) => setHardenedMaxBuySellRatio(Number(e.target.value))} 
                        className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 text-[11px] text-white font-mono focus:outline-none focus:border-[#c7f284] mt-1"
                      />
                    </div>
                  </div>
                </div>

                {/* Section: Security, Risk, Holders */}
                <div className="space-y-2 pt-2 border-t border-[#1f212e]">
                  <div className="text-[10px] font-bold uppercase text-[#64748b]">Security & Ownership Max %</div>
                  <div className="grid grid-cols-3 gap-1.5">
                    <div>
                      <span className="text-[9px] text-[#94a3b8] uppercase font-semibold">Max Risk</span>
                      <input 
                        type="number" 
                        value={hardenedMaxRiskScore} 
                        onChange={(e) => setHardenedMaxRiskScore(Number(e.target.value))} 
                        className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-1.5 py-1.5 text-[11px] text-white font-mono focus:outline-none focus:border-[#c7f284] mt-1"
                      />
                    </div>
                    <div>
                      <span className="text-[9px] text-[#94a3b8] uppercase font-semibold">Max Dev %</span>
                      <input 
                        type="number" 
                        value={hardenedMaxDevOwnership} 
                        onChange={(e) => setHardenedMaxDevOwnership(Number(e.target.value))} 
                        className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-1.5 py-1.5 text-[11px] text-white font-mono focus:outline-none focus:border-[#c7f284] mt-1"
                      />
                    </div>
                    <div>
                      <span className="text-[9px] text-[#94a3b8] uppercase font-semibold">Max Top 10%</span>
                      <input 
                        type="number" 
                        value={hardenedMaxTop10} 
                        onChange={(e) => setHardenedMaxTop10(Number(e.target.value))} 
                        className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-1.5 py-1.5 text-[11px] text-white font-mono focus:outline-none focus:border-[#c7f284] mt-1"
                      />
                    </div>
                  </div>
                </div>

                {/* Section: Price & Bonding Limits */}
                <div className="space-y-2 pt-2 border-t border-[#1f212e]">
                  <div className="text-[10px] font-bold uppercase text-[#64748b]">Price Action & Bonding limits</div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <span className="text-[9px] text-[#94a3b8] uppercase font-medium">Min 5m Profit (%)</span>
                      <input 
                        type="number" 
                        step="0.1"
                        value={hardenedMinProfit5m} 
                        onChange={(e) => setHardenedMinProfit5m(Number(e.target.value))} 
                        className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 text-[11px] text-white font-mono focus:outline-none focus:border-[#c7f284] mt-1"
                      />
                    </div>
                    <div>
                      <span className="text-[9px] text-[#94a3b8] uppercase font-medium">Max 1m Change (%)</span>
                      <input 
                        type="number" 
                        value={hardenedMaxPriceChange1m} 
                        onChange={(e) => setHardenedMaxPriceChange1m(Number(e.target.value))} 
                        className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 text-[11px] text-white font-mono focus:outline-none focus:border-[#c7f284] mt-1"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <span className="text-[9px] text-[#94a3b8] uppercase font-medium">Min Bonding %</span>
                      <input 
                        type="number" 
                        value={hardenedMinBondingProgress} 
                        onChange={(e) => setHardenedMinBondingProgress(Number(e.target.value))} 
                        className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 text-[11px] text-white font-mono focus:outline-none focus:border-[#c7f284] mt-1"
                      />
                    </div>
                    <div>
                      <span className="text-[9px] text-[#94a3b8] uppercase font-medium">Max Bonding %</span>
                      <input 
                        type="number" 
                        value={hardenedMaxBondingProgress} 
                        onChange={(e) => setHardenedMaxBondingProgress(Number(e.target.value))} 
                        className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 text-[11px] text-white font-mono focus:outline-none focus:border-[#c7f284] mt-1"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <span className="text-[9px] text-[#94a3b8] uppercase font-medium">Min Age (min)</span>
                      <input 
                        type="number" 
                        value={hardenedMinAge} 
                        onChange={(e) => setHardenedMinAge(Number(e.target.value))} 
                        className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 text-[11px] text-white font-mono focus:outline-none focus:border-[#c7f284] mt-1"
                      />
                    </div>
                    <div>
                      <span className="text-[9px] text-[#94a3b8] uppercase font-medium">Max Age (min)</span>
                      <input 
                        type="number" 
                        value={hardenedMaxAge} 
                        onChange={(e) => setHardenedMaxAge(Number(e.target.value))} 
                        className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 text-[11px] text-white font-mono focus:outline-none focus:border-[#c7f284] mt-1"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <span className="text-[9px] text-[#94a3b8] uppercase font-medium">Min Latency (ms)</span>
                      <input 
                        disabled={!enableLatencyGuard}
                        type="number" 
                        value={hardenedMinLatency} 
                        onChange={(e) => setHardenedMinLatency(Number(e.target.value))} 
                        className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 text-[11px] text-white font-mono focus:outline-none focus:border-[#c7f284] mt-1 disabled:opacity-50"
                      />
                    </div>
                    <div>
                      <span className="text-[9px] text-[#94a3b8] uppercase font-medium flex justify-between">
                        <span>Max Latency (ms)</span>
                        {rpcLatency !== null && rpcLatency !== undefined && (
                          <span className={!enableLatencyGuard ? 'text-gray-500' : rpcLatency > hardenedMaxLatency ? 'text-red-400 font-bold' : 'text-[#c7f284] font-bold'}>
                            {rpcLatency.toFixed(0)}ms
                          </span>
                        )}
                      </span>
                      <input 
                        disabled={!enableLatencyGuard}
                        type="number" 
                        value={hardenedMaxLatency} 
                        onChange={(e) => setHardenedMaxLatency(Number(e.target.value))} 
                        className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 text-[11px] text-white font-mono focus:outline-none focus:border-[#c7f284] mt-1 disabled:opacity-50"
                      />
                    </div>
                  </div>
                  <div className="mt-1 flex items-center justify-between bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 select-none h-[32px]">
                    <span className="text-[9px] text-[#94a3b8] uppercase font-medium">Latency Guard Loop Check</span>
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={enableLatencyGuard} 
                        onChange={(e) => setEnableLatencyGuard(e.target.checked)} 
                        className="rounded border-[#2d2e3d] bg-[#050509] text-[#c7f284] focus:ring-0 focus:ring-offset-0 h-3.5 w-3.5"
                      />
                      <span className="text-[10px] text-white font-mono uppercase">{enableLatencyGuard ? 'Active' : 'Bypassed'}</span>
                    </label>
                  </div>
                </div>

                {/* Section: Telemetry Stream Triggers */}
                <div className="space-y-2 pt-2 border-t border-[#1f212e]">
                  <div className="text-[10px] font-bold uppercase text-[#64748b]">Telemetry Stream Triggers</div>
                  
                  <div className="grid grid-cols-3 gap-2 mb-2">
                    <label className="flex items-center gap-1.5 cursor-pointer bg-[#050509] border border-[#2d2e3d] rounded-lg px-2 py-1">
                      <input type="checkbox" checked={telemetryAllowWhaleBuy} onChange={(e) => setTelemetryAllowWhaleBuy(e.target.checked)} className="rounded border-[#2d2e3d] bg-[#050509] text-[#c7f284] focus:ring-0 w-3 h-3" />
                      <span className="text-[9px] text-[#94a3b8] uppercase font-bold">Whale Buy</span>
                    </label>
                    <label className="flex items-center gap-1.5 cursor-pointer bg-[#050509] border border-[#2d2e3d] rounded-lg px-2 py-1">
                      <input type="checkbox" checked={telemetryAllowHighBuy} onChange={(e) => setTelemetryAllowHighBuy(e.target.checked)} className="rounded border-[#2d2e3d] bg-[#050509] text-[#c7f284] focus:ring-0 w-3 h-3" />
                      <span className="text-[9px] text-[#94a3b8] uppercase font-bold">High Buy</span>
                    </label>
                    <label className="flex items-center gap-1.5 cursor-pointer bg-[#050509] border border-[#2d2e3d] rounded-lg px-2 py-1">
                      <input type="checkbox" checked={telemetryAllowVolumeSpike} onChange={(e) => setTelemetryAllowVolumeSpike(e.target.checked)} className="rounded border-[#2d2e3d] bg-[#050509] text-[#c7f284] focus:ring-0 w-3 h-3" />
                      <span className="text-[9px] text-[#94a3b8] uppercase font-bold">Vol Spike</span>
                    </label>
                    <label className="flex items-center gap-1.5 cursor-pointer bg-[#050509] border border-[#2d2e3d] rounded-lg px-2 py-1">
                      <input type="checkbox" checked={telemetryAllowMigrated} onChange={(e) => setTelemetryAllowMigrated(e.target.checked)} className="rounded border-[#2d2e3d] bg-[#050509] text-[#c7f284] focus:ring-0 w-3 h-3" />
                      <span className="text-[9px] text-[#94a3b8] uppercase font-bold">Migrated</span>
                    </label>
                    <label className="flex items-center gap-1.5 cursor-pointer bg-[#050509] border border-[#2d2e3d] rounded-lg px-2 py-1">
                      <input type="checkbox" checked={telemetryAllowGoldenCross} onChange={(e) => setTelemetryAllowGoldenCross(e.target.checked)} className="rounded border-[#2d2e3d] bg-[#050509] text-[#c7f284] focus:ring-0 w-3 h-3" />
                      <span className="text-[9px] text-[#94a3b8] uppercase font-bold">Gold Cross</span>
                    </label>
                  </div>

                  <div className="grid grid-cols-2 gap-2 mt-1">
                    <div>
                      <span className="text-[9px] text-[#94a3b8] uppercase font-semibold">Min Whale Buy ($)</span>
                      <input 
                        type="number" 
                        value={telemetryWhaleBuyMin} 
                        onChange={(e) => setTelemetryWhaleBuyMin(Number(e.target.value))} 
                        className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-2 py-1 text-[11px] text-white font-mono focus:outline-none focus:border-[#c7f284] mt-1"
                      />
                    </div>
                    <div>
                      <span className="text-[9px] text-[#94a3b8] uppercase font-semibold">Min High Buy ($)</span>
                      <input 
                        type="number" 
                        value={telemetryHighBuyMin} 
                        onChange={(e) => setTelemetryHighBuyMin(Number(e.target.value))} 
                        className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-2 py-1 text-[11px] text-white font-mono focus:outline-none focus:border-[#c7f284] mt-1"
                      />
                    </div>
                    <div>
                      <span className="text-[9px] text-[#94a3b8] uppercase font-semibold">Min Vol Spike ($)</span>
                      <input 
                        type="number" 
                        value={telemetryVolumeSpikeMin} 
                        onChange={(e) => setTelemetryVolumeSpikeMin(Number(e.target.value))} 
                        className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-2 py-1 text-[11px] text-white font-mono focus:outline-none focus:border-[#c7f284] mt-1"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="bg-[#10111a]/60 border border-[#1f212e] rounded-2xl flex flex-col p-4 space-y-3 shrink-0 mt-auto">
            <div className="grid grid-cols-2 gap-3">
              <button onClick={startBot} disabled={isRunning} className="w-full bg-[#c7f284] hover:bg-[#b0d970] disabled:opacity-50 disabled:cursor-not-allowed text-[#050509] text-[13px] font-bold py-3 rounded-xl transition-colors flex items-center justify-center gap-2">
                <Play className="w-4 h-4 fill-current" /> START
              </button>
              <button onClick={stopBot} disabled={!isRunning} className="w-full bg-[#ff4d4d] hover:bg-[#e63e3e] disabled:opacity-50 disabled:cursor-not-allowed text-[#050509] text-[13px] font-bold py-3 rounded-xl transition-colors flex items-center justify-center gap-2">
                <Square className="w-4 h-4 fill-current" /> STOP
              </button>
            </div>
          </div>
        </aside>

        {/* Center Column: Alert + Positions */}
        <section className="flex flex-col space-y-5 lg:overflow-y-auto scrollbar-hide pb-4 min-w-0">
          <div className="bg-[#1a1000] border border-[#ffb300] text-[#ffb300] rounded-xl p-4 text-[13px] leading-relaxed flex gap-3 items-start shrink-0">
            <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
            <p><strong>Risk Warning:</strong> Automated crypto trading carries extreme risk. Never trade more than you can afford to lose entirely. This tool does not guarantee profits.</p>
          </div>

          {/* Master Manual DexScreener Contract Ingestor & Scanner */}
          <div className="bg-[#10111a]/90 border border-indigo-500/30 rounded-2xl flex flex-col shrink-0 shadow-[0_4px_24px_rgba(0,0,0,0.5)]">
            <div className="p-4 border-b border-[#1f212e] flex justify-between items-center bg-indigo-950/20">
              <h2 className="text-[12px] uppercase tracking-[1px] text-[#c7f284] font-bold flex items-center gap-1.5 matches-glow">
                <Search className="w-4 h-4 text-[#c7f284]" /> MANUAL SCAN & DIRECT SWAP ENTRY
              </h2>
              <span className="text-[9px] text-[#64748b] uppercase font-mono tracking-widest hidden sm:inline">DexScreener API Integration</span>
            </div>
            <div className="p-4 space-y-4">
              <div className="flex flex-col md:flex-row gap-3 items-end">
                <div className="flex-1 w-full">
                  <label className="text-[10px] text-[#64748b] mb-1.5 uppercase font-medium block">
                    Solana Mint Contract Address (Solana network only)
                  </label>
                  <input
                    type="text"
                    value={manualSearchInput}
                    onChange={(e) => setManualSearchInput(e.target.value)}
                    placeholder="Enter Token Name or Mint Address (e.g. BONK or CgRz...)"
                    className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-3 py-2 text-xs text-white styles-reset font-mono focus:outline-none focus:border-[#c7f284] transition-colors"
                  />
                </div>
                <button
                  type="button"
                  onClick={() => handleManualScan()}
                  disabled={isSearching}
                  className="w-full md:w-auto px-6 py-2 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-xs text-white font-black uppercase rounded-lg transition-all flex items-center gap-2 justify-center cursor-pointer min-h-[36px] disabled:opacity-50"
                >
                  {isSearching ? (
                    <>
                      <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                      <span>Scanning API...</span>
                    </>
                  ) : (
                    <>
                      <Search className="w-3.5 h-3.5" />
                      <span>Scan Contract</span>
                    </>
                  )}
                </button>
              </div>
              {searchError && (
                <p className="text-rose-400 text-[11px] font-mono leading-tight bg-rose-500/10 border border-rose-500/20 rounded px-2.5 py-1.5">
                  ⚠️ {searchError}
                </p>
              )}

              {/* Scanned Result Card */}
              {scannedResult ? (
                <div className="bg-[#050509]/60 border border-[#2d2e3d] rounded-xl p-4 space-y-3.5 animate-fadeIn">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div>
                      <div className="text-[14px] font-bold text-white flex items-center gap-1.5">
                        <span className="text-white">{scannedResult.name}</span>
                        <span className="text-[#c7f284] font-mono text-[11px] bg-[#c7f284]/10 px-1.5 py-0.5 rounded leading-none">
                          {scannedResult.symbol}
                        </span>
                      </div>
                      <div className="text-[10px] text-[#64748b] font-mono select-all select-none hover:text-slate-400 mt-0.5">
                        Mint: {scannedResult.address}
                      </div>
                    </div>
                    <div className="flex gap-1.5">
                      <span className="text-[10px] bg-indigo-500/10 text-indigo-300 border border-indigo-500/30 rounded px-2 py-0.5 font-bold uppercase">
                        Dex: {scannedResult.dexId}
                      </span>
                      <span className="text-[10px] bg-emerald-500/10 text-[#c7f284] border border-[#c7f284]/30 rounded px-2 py-0.5 font-bold uppercase">
                        {scannedResult.isGraduated ? 'Raydium Liquidity Pool' : 'Pump.fun Bonding Curve'}
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 border-t border-[#1f212e] pt-3 text-xs font-mono">
                    <div className="bg-[#10111a]/40 p-2 rounded border border-[#1f212e]">
                      <span className="text-[#64748b] text-[8px] block uppercase font-sans font-medium">Price USD</span>
                      <span className="text-white font-semibold text-[13px]">${scannedResult.priceUsd < 0.0001 ? scannedResult.priceUsd.toFixed(10) : scannedResult.priceUsd.toFixed(5)}</span>
                    </div>
                    <div className="bg-[#10111a]/40 p-2 rounded border border-[#1f212e]">
                      <span className="text-[#64748b] text-[8px] block uppercase font-sans font-medium">Price In Native SOL</span>
                      <span className="text-[#c7f284] font-semibold text-[13px]">{scannedResult.priceNative.toFixed(8)} SOL</span>
                    </div>
                    <div className="bg-[#10111a]/40 p-2 rounded border border-[#1f212e]">
                      <span className="text-[#64748b] text-[8px] block uppercase font-sans font-medium">Pool Liquidity (USD)</span>
                      <span className="text-white font-semibold text-[13px]">${scannedResult.liquidityUsd.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                    </div>
                    <div className="bg-[#10111a]/40 p-2 rounded border border-[#1f212e]">
                      <span className="text-[#64748b] text-[8px] block uppercase font-sans font-medium">24h Ingested Vol</span>
                      <span className="text-white font-semibold text-[13px]">${scannedResult.volume24h.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                    </div>
                  </div>

                  {/* Manual / Discretionary Trigger Box */}
                  <div className="border-t border-[#1f212e] pt-3.5 flex flex-col sm:flex-row sm:items-end gap-3">
                    <div className="flex-1">
                      <label className="text-[10px] text-[#64748b] block uppercase font-sans mb-1.5 font-semibold">
                        Instant Swap Order Size (SOL)
                      </label>
                      <input
                        type="number"
                        step="0.05"
                        min="0.01"
                        value={discretionaryBuyAmount}
                        onChange={(e) => setDiscretionaryBuyAmount(e.target.value)}
                        className="w-full bg-[#10111a] border border-[#1f212e] rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-[#c7f284]"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={handleDiscretionaryBuyTrigger}
                      disabled={isBuyingDiscretionary}
                      className="w-full sm:w-auto px-8 py-2 bg-[#c7f284] hover:bg-[#b0dc68] text-[#050509] font-black uppercase rounded-lg text-xs transition-all text-center flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 min-h-[36px] shadow-[0_0_20px_rgba(199,242,132,0.2)]"
                    >
                      {isBuyingDiscretionary ? (
                        <>
                          <span className="w-3.5 h-3.5 border-2 border-black border-t-transparent rounded-full animate-spin"></span>
                          <span>Executing Transaction...</span>
                        </>
                      ) : (
                        <>
                          <Zap className="w-3.5 h-3.5 text-black fill-black" />
                          <span>Instant Discretionary Buy ({discretionaryBuyAmount} SOL)</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              ) : (
                <div className="bg-[#050509]/30 border border-[#1f212e] rounded-xl p-4 text-center text-[#64748b] text-[11px] font-mono leading-relaxed">
                  Enter any Solana contract address above to dynamically fetch real-time liquidity, pricing, volume, and trigger swift discretionary swap executions with full-state tracking support.
                </div>
              )}
            </div>
          </div>
          <div className="flex flex-col flex-1">
            <div className="flex justify-between items-center pb-3">
              <h2 className="text-[12px] uppercase tracking-[1px] text-[#94a3b8] font-bold">Active Positions ({Object.values(positions || {}).filter(pos => pos && pos.symbol && pos.symbol.trim() !== '' && pos.symbol !== 'Unknown' && pos.buyPrice && !isNaN(pos.buyPrice) && pos.amount && !isNaN(pos.amount) && pos.solSpent && !isNaN(pos.solSpent)).length}/{maxPositions || '♾️'})</h2>
              {Object.values(tokenMetrics || {}).filter(m => {
                const buy30s = (m.recentBuysTimeline || []).filter(t => Date.now() - t.t < 30000).length;
                const buyRatio = m.buyCount / (m.sellCount || 1);
                const marketCap = m.marketCap || 0;
                const liquidity = m.liquidity || 0;
                return (buy30s >= 3 || buyRatio >= 5) && marketCap >= 50000 && liquidity >= 10000;
              }).length > 0 && (
                <span className="text-[12px] font-bold text-emerald-400 bg-emerald-400/10 px-2 py-1 rounded-full flex items-center gap-1">
                  <TrendingUp className="w-3 h-3" /> {Object.values(tokenMetrics || {}).filter(m => {
                    const buy30s = (m.recentBuysTimeline || []).filter(t => Date.now() - t.t < 30000).length;
                    const buyRatio = m.buyCount / (m.sellCount || 1);
                    const marketCap = m.marketCap || 0;
                    const liquidity = m.liquidity || 0;
                    return (buy30s >= 3 || buyRatio >= 5) && marketCap >= 50000 && liquidity >= 10000;
                  }).length} Exciting Tokens
                </span>
              )}
            </div>
            <div className="flex-1 space-y-3">
              {Object.values(positions || {}).filter(pos => pos && pos.symbol && pos.symbol.trim() !== '' && pos.symbol !== 'Unknown' && typeof pos.buyPrice === 'number' && !isNaN(pos.buyPrice) && typeof pos.amount === 'number' && !isNaN(pos.amount) && typeof pos.solSpent === 'number' && !isNaN(pos.solSpent)).length === 0 ? (
                <div className="bg-[#10111a]/40 border border-[#1f212e] border-dashed rounded-2xl p-8 flex flex-col items-center justify-center text-center text-[#64748b]">
                  <div className="w-12 h-12 rounded-full bg-[#1a1b26] border border-[#2d2e3d] flex items-center justify-center mb-3">
                    <Search className="w-5 h-5 text-[#94a3b8] opacity-50" />
                  </div>
                  <p className="text-[13px] text-[#e2e8f0]">No active positions.</p>
                  <p className="text-[12px] opacity-70 mt-1">{isRunning ? 'Scanning for entry points...' : 'Start the bot to begin trading.'}</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2 gap-3 content-start">
                  {Object.entries(positions || {}).filter(([mint, pos]: [string, any]) => {
                    // 🛡️ Robust validation filter to prevent displaying visually buggy/corrupt positions
                    if (
                      !pos ||
                      typeof pos.symbol !== 'string' ||
                      pos.symbol.trim() === '' ||
                      pos.symbol === 'Unknown' ||
                      typeof pos.buyPrice !== 'number' ||
                      isNaN(pos.buyPrice) ||
                      pos.buyPrice <= 0 ||
                      typeof pos.amount !== 'number' ||
                      isNaN(pos.amount) ||
                      pos.amount <= 0 ||
                      typeof pos.solSpent !== 'number' ||
                      isNaN(pos.solSpent) ||
                      pos.solSpent <= 0
                    ) {
                      return false;
                    }

                    const token = tokenMetrics[mint];
                    const liveMarketPrice = token?.priceNative ? (typeof token.priceNative === 'number' ? token.priceNative : parseFloat(String(token.priceNative))) : 0;
                    const displayPrice = (liveMarketPrice > 0 ? liveMarketPrice : 0) || pos.currentPriceSol || pos.currentPrice || pos.buyPrice || 0;
                    const entryCostSol = pos.entryCostSol !== undefined && pos.entryCostSol > 0 ? pos.entryCostSol : (pos.solSpent || 0);
                    const currentPriceSol = displayPrice > 0 ? displayPrice : (pos.currentPriceSol || pos.buyPrice || 0);
                    const currentValueSol = pos.amount > 0 && currentPriceSol > 0 ? pos.amount * currentPriceSol : 0;
                    const pnlSol = entryCostSol > 0 ? currentValueSol - entryCostSol : 0;
                    const pnlPercent = entryCostSol > 0 ? (pnlSol / entryCostSol) * 100 : 0;
                    return !isNaN(pnlPercent) && isFinite(pnlPercent);
                  }).map(([mint, pos]: [string, Position]) => {
                    const token = tokenMetrics[mint];
                    const liveMarketPrice = token?.priceNative ? (typeof token.priceNative === 'number' ? token.priceNative : parseFloat(String(token.priceNative))) : 0;
                    const displayPrice = (liveMarketPrice > 0 ? liveMarketPrice : 0) || pos.currentPriceSol || pos.currentPrice || pos.buyPrice || 0;
                    const entryCostSol = pos.entryCostSol !== undefined && pos.entryCostSol > 0 ? pos.entryCostSol : (pos.solSpent || 0);
                    const currentPriceSol = displayPrice > 0 ? displayPrice : (pos.currentPriceSol || pos.buyPrice || 0);
                    const currentValueSol = pos.amount > 0 && currentPriceSol > 0 ? pos.amount * currentPriceSol : 0;
                    const marketValueSol = pos.marketValueSol !== undefined && pos.marketValueSol > 0 ? pos.marketValueSol : currentValueSol;
                    const marketPnlSol = pos.marketPnlSol !== undefined ? pos.marketPnlSol : (entryCostSol > 0 ? marketValueSol - entryCostSol : 0);
                    const marketPnlPercent = pos.marketPnlPercent !== undefined ? pos.marketPnlPercent : (entryCostSol > 0 ? (marketPnlSol / entryCostSol) * 100 : 0);

                    const executableValueSol = pos.executableValueSol !== undefined && pos.executableValueSol > 0 ? pos.executableValueSol : marketValueSol;
                    const executablePnlSol = pos.executablePnlSol !== undefined ? pos.executablePnlSol : (entryCostSol > 0 ? executableValueSol - entryCostSol : 0);
                    const executablePnlPercent = pos.executablePnlPercent !== undefined ? pos.executablePnlPercent : (entryCostSol > 0 ? (executablePnlSol / entryCostSol) * 100 : 0);

                    const pnlSol = marketPnlSol;
                    const pnlPercent = marketPnlPercent;
                    const entryPriceSol = pos.amount > 0 && entryCostSol > 0 ? entryCostSol / pos.amount : (pos.buyPrice || 0);
                    const valStatus = pos.status || (displayPrice > 0 ? 'LIVE' : 'UNAVAILABLE');
                    const valSource = pos.source || (token?.priceNative ? 'LASERSTREAM' : 'JUPITER');
                    
                    const isPos = pnlPercent >= 0;
                    const isStalePos = valStatus === 'STALE' || (!!pos.isStale && (!displayPrice || displayPrice === 0));
                    const stage = detectTokenStage({
                      address: mint,
                      dexId: token?.dexId,
                      bondingCurveProgress: token?.bondingCurveProgress,
                      isRaydiumListed: token?.isRaydiumListed
                    });

                    const defaultTp = stage.isBonding ? (bondingCurveTakeProfit || 25) : (minTakeProfit || 25);
                    const defaultSl = stage.platform === 'PUMP_FUN' || stage.isBonding 
                      ? (bondingCurveStopLossPct || 20) 
                      : stage.platform === 'PUMPSWAP'
                      ? (pumpSwapStopLossPct || 15)
                      : stage.platform === 'UNKNOWN'
                      ? (unknownStopLossPct || 15)
                      : (stopLossPct || 15);

                    const activeTp = (pos.hasCustomTpSl && typeof pos.tpPct === 'number') ? pos.tpPct : defaultTp;
                    const activeSl = (pos.hasCustomTpSl && typeof pos.slPct === 'number') ? Math.abs(pos.slPct) : Math.abs(defaultSl);

                    // Dynamic range calculation for target progress bar
                    const totalRange = activeTp + activeSl;
                    const currentPosFromSl = pnlPercent + activeSl;
                    const progressPct = totalRange > 0 ? Math.max(0, Math.min(100, (currentPosFromSl / totalRange) * 100)) : 50;
                    const breakevenPct = totalRange > 0 ? Math.max(0, Math.min(100, (activeSl / totalRange) * 100)) : 50;

                    const distanceToTp = activeTp - pnlPercent;
                    const distanceToSl = pnlPercent - (-activeSl);

                    return (
                      <div key={mint} className="bg-[#0a0b14] border border-[#1f212e] rounded-xl p-4 flex flex-col gap-3">
                        {/* Header Row: Token, Badges & Net PnL */}
                        <div className="flex items-start justify-between gap-2 flex-wrap">
                          <div className="flex items-center gap-2">
                            <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-indigo-600 to-indigo-400 flex items-center justify-center text-white text-xs font-black shrink-0">
                              {pos.symbol.slice(0, 2).toUpperCase()}
                            </div>
                            <div>
                              <div className="font-bold text-[14px] text-white flex items-center gap-1.5 flex-wrap">
                                <span>{pos.symbol}</span>
                                <span className="text-[#64748b] text-[11px] font-normal">/ SOL</span>
                                
                                {/* Stage badge */}
                                {stage.isBonding ? (
                                  <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-orange-500/20 text-orange-400 border border-orange-500/30 whitespace-nowrap">
                                    BONDING {stage.bondingProgress.toFixed(0)}%
                                  </span>
                                ) : (
                                  <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-blue-500/20 text-blue-400 border border-blue-500/30 whitespace-nowrap">
                                    {stage.platform}
                                  </span>
                                )}

                                {pos.hasCustomTpSl && (
                                  <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 whitespace-nowrap">
                                    CUSTOM TP/SL
                                  </span>
                                )}

                                {/* Valuation Source & Status Badge */}
                                <span className={`px-1.5 py-0.5 rounded text-[8.5px] font-bold tracking-wider uppercase border whitespace-nowrap ${
                                  valStatus === 'LIVE' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' :
                                  valStatus === 'STALE' ? 'bg-amber-500/10 text-amber-400 border-amber-500/30' :
                                  'bg-slate-500/10 text-slate-400 border-slate-500/30'
                                }`}>
                                  {valSource} • {valStatus}
                                </span>

                                {/* Quote Age Badge */}
                                {pos.quoteAgeMs !== undefined && (
                                  <span className={`px-1.5 py-0.5 rounded text-[8.5px] font-mono border whitespace-nowrap ${
                                    pos.quoteAgeMs <= 2000 
                                      ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20' 
                                      : 'bg-amber-500/10 text-amber-300 border-amber-500/20'
                                  }`}>
                                    ⚡ {pos.quoteAgeMs}ms quote
                                  </span>
                                )}

                                {/* Near migration warning */}
                                {stage.isNearMigration && (
                                  <span className="text-yellow-400 text-[9px] animate-pulse whitespace-nowrap border border-yellow-400/30 bg-yellow-400/10 px-1.5 py-0.5 rounded">
                                    ⚡ MIGRATING
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>

                          {/* Top-Right PnL Box: Live Market PnL + Executable Jupiter PnL */}
                          <div className="text-right font-mono ml-auto">
                            {valStatus === 'UNAVAILABLE' ? (
                              <div className="flex flex-col items-end">
                                <span className="text-slate-400 font-bold text-[13px]">UNAVAILABLE</span>
                                <span className="text-[10px] text-[#64748b]">Awaiting Market Data</span>
                              </div>
                            ) : (
                              <div className="flex flex-col items-end">
                                <div className="flex items-baseline gap-1.5 justify-end">
                                  <span className="text-[10px] text-[#64748b] font-normal uppercase">Market:</span>
                                  <div className={`text-[15px] font-bold tracking-tight ${isPos ? 'text-[#c7f284]' : 'text-[#ff4d4d]'}`}>
                                    {isPos ? '+' : ''}{pnlPercent.toFixed(2)}%
                                  </div>
                                </div>
                                <div className="flex items-center gap-1 text-[11px]">
                                  <span className={`font-semibold ${pnlSol >= 0 ? 'text-[#c7f284]/90' : 'text-[#ff4d4d]/90'}`}>
                                    {pnlSol >= 0 ? '+' : '-'}{Math.abs(pnlSol).toFixed(4)} SOL
                                  </span>
                                </div>
                                {/* Executable Proceeds PnL line */}
                                <div className="flex items-center gap-1 text-[9.5px] text-slate-400 mt-0.5">
                                  <span>Exec:</span>
                                  <span className={`font-semibold ${executablePnlPercent >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                                    {executablePnlPercent >= 0 ? '+' : ''}{executablePnlPercent.toFixed(1)}% ({executableValueSol.toFixed(3)} SOL)
                                  </span>
                                </div>
                                {pnlPercent <= -50 && (
                                  <span className="text-[9px] bg-red-950/80 text-rose-400 px-1.5 py-0.5 rounded font-semibold border border-red-500/30 animate-bounce inline-block mt-1 uppercase text-center">
                                    🔴 CRITICAL LOSS
                                  </span>
                                )}
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Interactive TP & SL Adjustment Bar */}
                        <div className="bg-[#10111a]/80 border border-[#1f212e] rounded-lg p-2.5 space-y-2">
                          <div className="flex items-center justify-between text-[11px] gap-2 flex-wrap">
                            {/* TP Input */}
                            <div className="flex items-center gap-1.5">
                              <span className="text-emerald-400 font-bold flex items-center gap-1">
                                🎯 TP:
                              </span>
                              <div className="flex items-center bg-[#0a0b14] border border-emerald-500/30 rounded px-1.5 py-0.5">
                                <span className="text-emerald-400 text-[10px] font-bold mr-0.5">+</span>
                                <input
                                  type="number"
                                  min="1"
                                  max="5000"
                                  step="1"
                                  value={activeTp}
                                  onChange={(e) => {
                                    const val = parseFloat(e.target.value);
                                    if (!isNaN(val)) {
                                      handleUpdatePositionTpSl(mint, val, activeSl);
                                    }
                                  }}
                                  className="w-12 bg-transparent text-emerald-300 font-mono text-[11px] font-bold text-center focus:outline-none focus:ring-1 focus:ring-emerald-500 rounded"
                                />
                                <span className="text-emerald-400 text-[10px] font-bold ml-0.5">%</span>
                              </div>
                            </div>

                            {/* SL Input */}
                            <div className="flex items-center gap-1.5">
                              <span className="text-rose-400 font-bold flex items-center gap-1">
                                🛑 SL:
                              </span>
                              <div className="flex items-center bg-[#0a0b14] border border-rose-500/30 rounded px-1.5 py-0.5">
                                <span className="text-rose-400 text-[10px] font-bold mr-0.5">-</span>
                                <input
                                  type="number"
                                  min="1"
                                  max="99"
                                  step="1"
                                  value={activeSl}
                                  onChange={(e) => {
                                    const val = Math.abs(parseFloat(e.target.value));
                                    if (!isNaN(val)) {
                                      handleUpdatePositionTpSl(mint, activeTp, val);
                                    }
                                  }}
                                  className="w-10 bg-transparent text-rose-300 font-mono text-[11px] font-bold text-center focus:outline-none focus:ring-1 focus:ring-rose-500 rounded"
                                />
                                <span className="text-rose-400 text-[10px] font-bold ml-0.5">%</span>
                              </div>
                            </div>

                            {/* Reset Button (shown if custom) */}
                            {pos.hasCustomTpSl && (
                              <button
                                onClick={() => handleResetPositionTpSl(mint)}
                                className="text-[10px] text-slate-400 hover:text-white bg-[#1a1b26] hover:bg-[#252636] px-2 py-0.5 rounded border border-[#2d2e3d] transition-colors flex items-center gap-1 ml-auto"
                                title="Reset to global settings"
                              >
                                ↺ Reset
                              </button>
                            )}
                          </div>

                          {/* Visual Target Range Progress Bar */}
                          <div className="space-y-1">
                            <div className="relative w-full h-2 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                              {/* Background color gradient: Red to Gray to Green */}
                              <div 
                                className="absolute left-0 top-0 bottom-0 bg-rose-500/40" 
                                style={{ width: `${breakevenPct}%` }} 
                              />
                              <div 
                                className="absolute top-0 bottom-0 bg-emerald-500/40" 
                                style={{ left: `${breakevenPct}%`, right: 0 }} 
                              />
                              {/* Breakeven line (0%) */}
                              <div 
                                className="absolute top-0 bottom-0 w-0.5 bg-white/70 z-10" 
                                style={{ left: `${breakevenPct}%` }}
                              />
                              {/* Current PnL Indicator marker */}
                              <div 
                                className="absolute top-0 bottom-0 w-2 h-2 rounded-full bg-white shadow-md transform -translate-x-1/2 z-20"
                                style={{ left: `${progressPct}%` }}
                              />
                            </div>
                            <div className="flex justify-between text-[9px] font-mono text-slate-400">
                              <span className="text-rose-400">-{activeSl}% (SL) • {distanceToSl > 0 ? `${distanceToSl.toFixed(1)}% away` : 'SL ZONE'}</span>
                              <span className="text-slate-500">0% Entry</span>
                              <span className="text-emerald-400">{distanceToTp <= 0 ? 'TP HIT' : `${distanceToTp.toFixed(1)}% away`} • +{activeTp}% (TP)</span>
                            </div>
                          </div>
                        </div>

                        {/* Price & Cost Grid */}
                        <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-[#050509]/40 p-2.5 rounded-lg border border-[#1f212e]/50">
                          <div>
                            <div className="text-[#64748b] text-[10px] uppercase font-bold tracking-wider mb-0.5">Entry Price</div>
                            <div className="text-[#e2e8f0] font-semibold text-[12px]">
                              {entryPriceSol > 0 ? `${entryPriceSol.toFixed(8)} SOL` : 'N/A'}
                            </div>
                            <div className="text-[10px] text-[#64748b] mt-0.5">
                              Entry Cost: {entryCostSol.toFixed(4)} SOL
                            </div>
                          </div>
                          <div>
                            <div className="text-[#64748b] text-[10px] uppercase font-bold tracking-wider mb-0.5">Market Price (WSS)</div>
                            <div className="text-[#e2e8f0] font-semibold text-[12px]">
                              {valStatus === 'UNAVAILABLE' ? (
                                <span className="text-slate-500 font-bold text-[11px]">UNAVAILABLE</span>
                              ) : isStalePos ? (
                                <span className="text-amber-500 font-bold animate-pulse text-[11px]">{displayPrice.toFixed(8)} SOL (STALE)</span>
                              ) : (
                                `${displayPrice.toFixed(8)} SOL`
                              )}
                            </div>
                            <div className="text-[10px] text-[#64748b] mt-0.5 flex items-center justify-between">
                              <span>Market Val: {marketValueSol.toFixed(4)} SOL</span>
                              <span className="text-slate-400">Exec: {executableValueSol.toFixed(4)} SOL</span>
                            </div>
                          </div>
                        </div>

                        {/* Emergency Force Exit Button */}
                        <div className="w-full">
                          <button 
                            onClick={() => executeSell(mint, displayPrice || pos.buyPrice, pnlPercent, 'EMERGENCY FORCE EXIT')}
                            className="w-full bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 active:scale-[0.99] transition-all px-3 py-2 rounded-lg text-xs font-black uppercase tracking-wider border border-rose-500/20 flex items-center justify-center gap-2 group shadow-sm"
                          >
                            <Square className="w-3.5 h-3.5 group-hover:scale-110 transition-transform text-rose-400" />
                            <span>Emergency Force Exit</span>
                          </button>
                        </div>
                        
                        {/* Transaction Ledger for multi-buys */}
                        {pos.buyEntries && pos.buyEntries.length > 0 && (
                          <div className="mt-0.5 pt-2 border-t border-[#1f212e]/40">
                            <details className="group">
                              <summary className="list-none flex items-center justify-between text-[10px] font-bold text-[#64748b] hover:text-[#94a3b8] cursor-pointer uppercase select-none tracking-wider">
                                <span className="flex items-center gap-1">🧾 Ledger ({pos.buyEntries.length})</span>
                                <span className="group-open:rotate-180 transition-transform text-[8px] text-[#64748b]">▼</span>
                              </summary>
                              <div className="mt-2 space-y-1.5 font-mono text-[10px] text-[#94a3b8] max-h-[120px] overflow-y-auto pr-1">
                                {pos.buyEntries.map((entry, idx) => (
                                  <div key={idx} className="flex justify-between items-center bg-[#10111a]/50 p-1.5 rounded border border-[#1f212e]/40">
                                    <div className="flex flex-col">
                                      <span className="text-[#e2e8f0] font-semibold">Buy #{idx + 1}</span>
                                      <span className="text-[9px] opacity-70">Price: {entry.buyPrice?.toFixed(8)} SOL</span>
                                    </div>
                                    <div className="text-right flex flex-col items-end">
                                      <span className="text-emerald-400">+{entry.amount?.toLocaleString(undefined, { maximumFractionDigits: 2 })} tokens</span>
                                      <div className="flex items-center gap-1 mt-0.5 text-[8px]">
                                        <span className="text-slate-500">{(entry.solSpent || 0).toFixed(4)} SOL</span>
                                        {entry.signature && entry.signature !== 'recovered-exit-tx' && entry.signature !== 'init-sig' && (
                                          <a
                                            href={`https://solscan.io/tx/${entry.signature}`}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="text-indigo-400 hover:text-indigo-300 underline"
                                          >
                                            tx
                                          </a>
                                        )}
                                      </div>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </details>
                          </div>
                        )}

                        {/* Footer info: Timestamp & DexScreener */}
                        <div className="flex justify-between items-center pt-2 border-t border-[#1f212e]/60">
                          <div className="text-[#64748b] text-[10px] uppercase font-bold tracking-wider">
                            Buy: <span className="text-[#e2e8f0] ml-1">{new Date(pos.entryTime).toLocaleTimeString()}</span>
                          </div>
                          <a 
                            href={`https://dexscreener.com/solana/${mint}`}
                            target="_blank"
                            rel="noopener noreferrer" 
                            className="flex items-center gap-1 text-[10px] font-bold text-[#94a3b8] hover:text-indigo-400 uppercase tracking-wider transition-colors"
                          >
                            DexScreener <Search className="w-3 h-3" />
                          </a>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

        </section>

        {/* Right Column: Stats & Logs */}
        <aside className="space-y-5 lg:overflow-y-auto scrollbar-hide flex flex-col pb-4 h-[max-content] lg:h-full min-w-0">
          <div className="bg-[#10111a]/60 border border-[#1f212e] rounded-2xl flex flex-col shrink-0">
            <div className="p-4 border-b border-[#1f212e] flex justify-between items-center">
              <h2 className="text-[12px] uppercase tracking-[1px] text-[#94a3b8] font-bold">Session Stats</h2>
              <button onClick={resetSession} className="text-[10px] text-[#64748b] hover:text-white uppercase font-bold tracking-wider">Reset</button>
            </div>
            <div className="p-4 space-y-0 text-[12px]">

              <div className="flex justify-between items-center py-2.5 border-b border-[#1f212e]">
                <span className="text-[#64748b] uppercase font-medium">Total Trades</span>
                <span className="font-mono font-semibold text-[#e2e8f0] text-[14px]">{stats.trades}</span>
              </div>
              <div className="flex justify-between items-center py-2.5 border-b border-[#1f212e]">
                <span className="text-[#64748b] uppercase font-medium">Wins / Losses</span>
                <span className="font-mono font-semibold text-[#e2e8f0] text-[14px]">{stats.wins} / {stats.losses}</span>
              </div>
              <div className="flex justify-between items-center py-2.5 border-b border-[#1f212e]">
                <span className="text-[#64748b] uppercase font-medium">Total P&L</span>
                <span className={`font-mono font-semibold text-[16px] ${(stats.pnl || 0) >= 0 ? 'text-[#c7f284]' : 'text-[#ff4d4d]'}`}>
                  {(stats.pnl || 0) >= 0 ? '+' : '-'}{Math.abs(stats.pnl || 0).toFixed(2)} SOL
                </span>
              </div>
              <div className="flex justify-between items-center py-2.5 border-b border-[#1f212e]">
                <span className="text-[#64748b] uppercase font-medium">Best Trade</span>
                <span className="font-mono font-semibold text-[#c7f284] text-[14px]">
                  {stats.bestTrade !== null && stats.bestTrade !== undefined ? `+${((stats.bestTrade || 0) * 100).toFixed(1)}%` : '—'}
                </span>
              </div>
              <div className="flex justify-between items-center pt-2.5">
                <span className="text-[#64748b] uppercase font-medium">Uptime</span>
                <span className="font-mono font-semibold text-[#e2e8f0] text-[14px]">{uptime > 0 ? getUptimeString() : '—'}</span>
              </div>
            </div>
          </div>
          
          <div className="bg-[#10111a]/60 border border-[#1f212e] rounded-1.5xl flex flex-col flex-1 min-h-[420px]">
            {/* Tab Controls */}
            <div className="flex border-b border-[#1f212e] bg-[#0c0d15]/80 shrink-0 flex-wrap">
              <button 
                onClick={() => setActiveLogTab('terminal')} 
                className={`flex-1 min-w-[60px] py-2 text-[10px] font-bold uppercase tracking-wider text-center border-r border-[#1f212e] transition-all ${activeLogTab === 'terminal' ? 'text-[#c7f284] border-b border-b-[#c7f284]/80 bg-[#10111a]' : 'text-[#64748b] hover:text-[#94a3b8] bg-transparent'}`}
                id="log-tab-console"
              >
                📟 Console
              </button>
              <button 
                onClick={() => setActiveLogTab('diagnostics')} 
                className={`flex-1 min-w-[60px] py-2 text-[10px] font-bold uppercase tracking-wider text-center border-r border-[#1f212e] transition-all ${activeLogTab === 'diagnostics' ? 'text-[#c7f284] border-b border-b-[#c7f284]/80 bg-[#10111a]' : 'text-[#64748b] hover:text-[#94a3b8] bg-transparent'}`}
                id="log-tab-diagnostics"
              >
                📊 Diags
              </button>
              <button 
                onClick={() => setActiveLogTab('telemetry')} 
                className={`flex-1 min-w-[65px] py-2 text-[10px] font-bold uppercase tracking-wider text-center border-r border-[#1f212e] transition-all ${activeLogTab === 'telemetry' ? 'text-[#c7f284] border-b border-b-[#c7f284]/80 bg-[#10111a]' : 'text-[#64748b] hover:text-[#94a3b8] bg-transparent'}`}
                id="log-tab-telemetry"
              >
                📡 Telemetry
              </button>
              <button 
                onClick={() => setActiveLogTab('leaderboard')} 
                className={`flex-1 min-w-[65px] py-2 text-[10px] font-bold uppercase tracking-wider text-center border-r border-[#1f212e] transition-all ${activeLogTab === 'leaderboard' ? 'text-[#c7f284] border-b border-b-[#c7f284]/80 bg-[#10111a]' : 'text-[#64748b] hover:text-[#94a3b8] bg-transparent'}`}
                id="log-tab-prospects"
              >
                🎯 Prospects
              </button>
              <button 
                onClick={() => setActiveLogTab('advisor')} 
                className={`flex-1 min-w-[70px] py-2 text-[10px] font-bold uppercase tracking-wider text-center border-r border-[#1f212e] transition-all ${activeLogTab === 'advisor' ? 'text-[#c7f284] border-b border-b-[#c7f284]/80 bg-[#10111a]' : 'text-[#64748b] hover:text-[#94a3b8] bg-transparent'}`}
                id="log-tab-advisor"
              >
                🧠 A.I. Advisor
              </button>
              <button 
                onClick={() => setActiveLogTab('hosting')} 
                className={`flex-1 min-w-[60px] py-2 text-[10px] font-bold uppercase tracking-wider text-center transition-all ${activeLogTab === 'hosting' ? 'text-[#c7f284] border-b border-b-[#c7f284]/80 bg-[#10111a]' : 'text-[#64748b] hover:text-[#94a3b8] bg-transparent'}`}
                id="log-tab-hosting"
              >
                🌐 Hosting
              </button>
            </div>

            {activeLogTab === 'terminal' ? (
              <TerminalConsole 
                logs={logs} 
                setLogs={setLogs} 
                retentionLimit={retentionLimit}
                setRetentionLimit={setRetentionLimit}
                positions={positions}
                onQuickTrade={handleQuickTradeFromLogs}
                onQuickSell={executeSell}
              />
            ) : (
              <div className="p-4 overflow-y-auto max-h-[480px] space-y-2 font-mono text-[11px] flex-1 break-words">
                {activeLogTab === 'diagnostics' && (() => {
                  const activeMints = Object.keys(positions).filter(k => {
                    const p = positions[k];
                    return p && typeof p === 'object' && p.symbol && typeof p.amount === 'number' && p.amount > 0;
                  });
                  const candidates = Object.entries(tokenMetricsRef.current).filter(
                    ([mint]) => !activeMints.includes(mint) && !blacklistedMints.includes(mint)
                  );

                  const data = {
                    total: candidates.length,
                    passedAll: 0,
                    disabled: 0,
                    profit5m: 0,
                    progress: 0,
                    age: 0,
                    marketCap: 0,
                    liquidity: 0,
                    top10: 0,
                    velocity: 0,
                    priceChange: 0,
                    security: 0
                  };

                  candidates.forEach(([mint]) => {
                    const check = checkTokenCriteria(mint);
                    if (check.pass) {
                      data.passedAll++;
                    } else if (check.reason) {
                      const reason = check.reason;
                      if (reason.toLowerCase().includes("disabled")) data.disabled++;
                      if (reason.toLowerCase().includes("5m profit") || reason.toLowerCase().includes("profit 5m")) data.profit5m++;
                      if (reason.toLowerCase().includes("progress")) data.progress++;
                      if (reason.toLowerCase().includes("age")) data.age++;
                      if (reason.toLowerCase().includes("mc ") || reason.toLowerCase().includes("market cap") || reason.toLowerCase().includes("mcap")) data.marketCap++;
                      if (reason.toLowerCase().includes("liq") || reason.toLowerCase().includes("liquidity")) data.liquidity++;
                      if (reason.toLowerCase().includes("top10") || reason.toLowerCase().includes("top 10")) data.top10++;
                      if (reason.toLowerCase().includes("buys15s") || reason.toLowerCase().includes("velocity") || reason.toLowerCase().includes("velratio")) data.velocity++;
                      if (reason.toLowerCase().includes("1m price") || reason.toLowerCase().includes("price change")) data.priceChange++;
                      if (reason.toLowerCase().includes("security")) data.security++;
                    }
                  });

                  return (
                    <div className="space-y-4 pt-1">
                      <div className="p-3 bg-indigo-500/5 border border-indigo-500/20 rounded-xl">
                        <div className="flex justify-between items-center text-[11px] font-bold text-white uppercase mb-1">
                          <span>🛰️ Engine Diagnostics</span>
                          <span className={isRunning ? "text-[#c7f284] animate-pulse" : "text-rose-400"}>
                            {isRunning ? "● Active Scanning" : "■ Stopped"}
                          </span>
                        </div>
                        <p className="text-[10px] text-[#64748b] leading-relaxed">
                          Scanning {Object.keys(tokenMetricsRef.current).length} system state tokens. In the untraded candidate pool, {data.total} dynamic profiles are actively tested against hardened parameters.
                        </p>
                      </div>

                      <div className="space-y-2">
                        <div className="text-[10px] font-bold text-[#94a3b8] uppercase tracking-wider mb-2">Gatekeepers Failure Breakdown</div>
                        {[
                          { name: '5m Profit Guard', count: data.profit5m, desc: `Requires price metrics >= ${hardenedMinProfit5m || 0}%` },
                          { name: 'Market Cap Limits', count: data.marketCap, desc: 'Filters out excessive or microcap coins' },
                          { name: 'Liquidity Levels', count: data.liquidity, desc: 'Avoids highly volatile thin-pool setups' },
                          { name: 'Rug Safety Checks', count: data.security, desc: 'Analyzes risk score & contract authority triggers' },
                          { name: 'Velocity Check (15s)', count: data.velocity, desc: 'Monitors block pressure and buy count vectors' },
                          { name: 'Pump Bonding Curve', count: data.progress, desc: 'Ensures Pump.fun progress targets' },
                          { name: 'Token Lifecycle Age', count: data.age, desc: `Checks within lifespans settings` },
                          { name: 'Console Holder Top10', count: data.top10, desc: 'Avoids whale-dominated token allocations' },
                        ].map((gate) => {
                          const pct = data.total > 0 ? Math.round((gate.count / data.total) * 100) : 0;
                          return (
                            <div key={gate.name} className="p-2.5 border border-[#1f212e]/50 bg-[#0d0e16]/30 rounded-xl flex items-center justify-between">
                              <div className="flex-1 pr-3 min-w-0">
                                <div className="text-[11px] font-bold text-[#e2e8f0] flex items-center justify-between mb-0.5">
                                  <span className="truncate">{gate.name}</span>
                                  <span className="text-[#64748b] ml-1 shrink-0">{gate.count} filtered ({pct}%)</span>
                                </div>
                                <div className="text-[9.5px] text-[#64748b] truncate leading-none">{gate.desc}</div>
                              </div>
                              <div className="w-14 h-1 bg-[#1b1c26] rounded-full overflow-hidden shrink-0">
                                <div className="h-full bg-rose-500/80 transition-all duration-500" style={{ width: `${pct}%` }} />
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })()}

                {activeLogTab === 'telemetry' && (
                  <div className="flex-1 overflow-y-auto p-3 space-y-2 custom-scrollbar">
                    <p className="text-[10px] text-[#64748b] leading-relaxed mb-3 bg-[#191924]/20 p-2 rounded border border-[#1f212e]/40">
                      📡 <strong className="text-[#e2e8f0]">Telemetry Stream Triggers:</strong> High-velocity events captured over X-Ray web sockets. These triggers stream directly into the Hardened Scanner for threshold validation. Tokens must pass criteria filters to enter positions.
                    </p>
                    {(!telemetryAlerts || telemetryAlerts.length === 0) ? (
                      <div className="text-center text-[#64748b] text-[11px] py-10 font-mono">
                        No active telemetry triggers detected.
                      </div>
                    ) : (
                      telemetryAlerts.slice().reverse().map(alert => (
                        <div key={alert.id} className="p-3 bg-[#10111a] border border-[#1f212e] rounded-xl flex items-start gap-3 relative overflow-hidden group">
                          <div className="absolute left-0 top-0 bottom-0 w-1 bg-indigo-500/50 group-hover:bg-indigo-400 transition-colors"></div>
                          <div className="p-1.5 bg-[#191924] rounded-lg text-indigo-400 shrink-0">
                            {alert.type === 'WHALE_BUY' ? <TrendingUp className="w-4 h-4" /> :
                             alert.type === 'HIGH_BUY' ? <Zap className="w-4 h-4" /> :
                             alert.type === 'MIGRATED' ? <ShieldCheck className="w-4 h-4" /> :
                             <Activity className="w-4 h-4" />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex justify-between items-start">
                              <div className="font-mono text-[12px] font-bold text-white truncate">{alert.token}</div>
                              <div className="text-[9px] text-[#64748b] whitespace-nowrap">{new Date(alert.timestamp).toLocaleTimeString()}</div>
                            </div>
                            <div className="text-[10px] uppercase font-bold tracking-wider text-indigo-400/80 mt-0.5">{alert.type.replace('_', ' ')}</div>
                            <div className="text-[10px] text-[#94a3b8] truncate mt-1">
                              {alert.address.slice(0, 12)}...{alert.address.slice(-6)}
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                )}

                {activeLogTab === 'leaderboard' && (() => {
                  const activeMints = Object.keys(positions).filter(k => {
                    const p = positions[k];
                    return p && typeof p === 'object' && p.symbol && typeof p.amount === 'number' && p.amount > 0;
                  });
                  const candidates = Object.entries(tokenMetricsRef.current)
                    .filter(([mint]) => !activeMints.includes(mint) && !blacklistedMints.includes(mint))
                    .sort((a: any, b: any) => calculateFallbackCandidateScore(b[0], b[1]) - calculateFallbackCandidateScore(a[0], a[1]))
                    .slice(0, 10);

                  if (candidates.length === 0) {
                    return <div className="text-[#64748b] text-center py-8">No current candidate profiles recorded. Ensure system is running.</div>;
                  }

                  return (
                    <div className="space-y-3 pt-1">
                      <p className="text-[10px] text-[#64748b] leading-relaxed mb-1 bg-[#191924]/20 p-2 rounded border border-[#1f212e]/40">
                        🎯 Top 10 prospects sorted by criteria check conformity. A buy order triggers instantly at 100% (all parameters green/passed). Check constraints to spot trade thresholds.
                      </p>

                      {candidates.map(([mint, metric]: [string, any]) => {
                        const symbol = metric.symbol || mint.slice(0, 6);
                        const isRaydium = (metric.dexId || '').toLowerCase().includes('raydium') || (metric.dexId || '').toLowerCase().includes('pumpswap') || (metric.dexId || '').toLowerCase().includes('orca') || (metric.dexId || '').toLowerCase().includes('meteora') || (metric.bondingCurveProgress || 0) >= 99.5;
                        
                        const mc = metric.marketCap || 0;
                        const liq = metric.liquidity || 0;
                        const progress = metric.bondingCurveProgress || 0;
                        const top10 = metric.top10Percentage || 0;
                        const maxTop10 = isRaydium ? (hardenedMaxTop10 || 100) : 35.0;
                        const priceChange1m = metric.priceChange1m || 0;
                        const profit5mCheck = metric.percentageIncrease !== undefined ? metric.percentageIncrease : priceChange1m;
                        const mcMin = isRaydium ? (hardenedMcapMinRaydium || 0) : (hardenedMcapMinPump || 0);
                        const mcMax = hardenedMcapMax || 999999999;

                        const checks = [
                          { name: '5m Profit Check', pass: profit5mCheck >= (hardenedMinProfit5m || 0), val: `${profit5mCheck.toFixed(1)}%` },
                          { name: 'Market Cap bounds', pass: mc >= mcMin && mc <= mcMax, val: `$${Math.floor(mc/1000)}k` },
                          { name: 'Contract Security', pass: metric.isRugSafe === true && (metric.riskScore ?? 100) <= (hardenedMaxRiskScore || 100), val: `Risk ${metric.riskScore ?? 'N/A'}` },
                          ...(!isRaydium ? [{ name: 'Bonding Progress', pass: progress >= (hardenedMinBondingProgress || 0) && progress <= (hardenedMaxBondingProgress || 100), val: `${progress.toFixed(0)}%` }] : []),
                          { name: 'Holder Consolidation', pass: isRaydium ? (top10 < maxTop10) : true, val: `${top10.toFixed(0)}%` },
                        ];

                        const score = checks.filter(c => c.pass).length;

                        return (
                          <div key={mint} className="p-3 border border-[#1f212e] bg-[#0c0d15]/50 rounded-xl space-y-2">
                            <div className="flex justify-between items-start">
                              <div>
                                <div className="flex items-center gap-1.5">
                                  <span className="text-white hover:text-[#c7f284] font-bold text-[12px] cursor-pointer" onClick={() => window.open(`https://dexscreener.com/solana/${mint}`, '_blank')}>
                                    {symbol}
                                  </span>
                                  <span className={`text-[8px] uppercase tracking-wider px-1 border rounded ${isRaydium ? 'bg-[#c7f284]/10 text-[#c7f284] border-[#c7f284]/20' : 'bg-[#e2e8f0]/10 text-slate-400 border-slate-700'}`}>
                                    {isRaydium ? 'Raydium' : 'Pump.fun'}
                                  </span>
                                </div>
                                <div className="text-[9px] text-[#64748b] truncate max-w-[170px] mt-0.5">{mint}</div>
                              </div>
                              <div className="text-right">
                                <span className="text-[11px] font-bold text-[#c7f284]">
                                  {score}/{checks.length} Passed
                                </span>
                                <div className="text-[9px] text-[#64748b] mt-0.5">MC: ${Math.floor(mc/1000)}k</div>
                              </div>
                            </div>

                            <div className="grid grid-cols-2 gap-x-3 gap-y-1.5 pt-1.5 border-t border-[#1f212e]/50 text-[9px]">
                              {checks.map((chk, idx) => (
                                <div key={idx} className="flex items-center justify-between">
                                  <span className="text-[#64748b] truncate">{chk.name}</span>
                                  <span className={`font-mono font-black shrink-0 ml-1 ${chk.pass ? 'text-emerald-400' : 'text-rose-500'}`}>
                                    {chk.pass ? '✓' : '✗'} <span className="text-[8px] opacity-75">({chk.val})</span>
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  );
                })()}

                {activeLogTab === 'hosting' && (
                  <div className="flex-1 overflow-y-auto p-3.5 space-y-3.5 custom-scrollbar font-sans text-xs">
                    {/* Brief Banner */}
                    <div className="bg-[#10111a] border border-[#1f212e] rounded-xl p-3 flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-1.5 text-[#e2e8f0] font-bold text-[11px] uppercase tracking-wider mb-0.5">
                          <span>🌐</span> Cloud Hosting Sync Center
                        </div>
                        <p className="text-[10px] text-[#64748b] leading-tight font-sans">
                          Manage deployments, sync active positions, configurations, and logs to your InfinityFree/Freehosting client server.
                        </p>
                      </div>
                      <a 
                        href={ftpWebUrl} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="px-2.5 py-1.5 bg-[#c7f284]/10 hover:bg-[#c7f284]/20 text-[#c7f284] border border-[#c7f284]/30 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1 shrink-0"
                      >
                        <Globe className="w-3 h-3 text-[#c7f284]" /> Open Web App
                      </a>
                    </div>

                    {/* FTP Credentials Grid */}
                    <div className="bg-[#0c0d15] border border-[#1f212e]/70 rounded-xl p-3 space-y-3 font-sans">
                      <div className="text-[10px] font-black uppercase text-[#94a3b8] tracking-widest border-b border-[#1f212e]/50 pb-1.5 flex items-center gap-1.5">
                        <Server className="w-3.5 h-3.5 text-[#c7f284]" /> FTP Server Connection Settings
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px]">
                        <div>
                          <label className="block text-[#64748b] font-medium mb-1 uppercase tracking-wide">FTP Host / Server</label>
                          <input 
                            type="text" 
                            value={ftpHost} 
                            onChange={(e) => {
                              setFtpHost(e.target.value);
                              
                            }}
                            placeholder="ftpupload.net"
                            className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 text-white font-mono focus:outline-none focus:border-[#c7f284]" 
                          />
                        </div>
                        <div>
                          <label className="block text-[#64748b] font-medium mb-1 uppercase tracking-wide">FTP Username</label>
                          <input 
                            type="text" 
                            value={ftpUser} 
                            onChange={(e) => {
                              setFtpUser(e.target.value);
                              
                            }}
                            placeholder="your_ftp_username"
                            className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 text-white font-mono focus:outline-none focus:border-[#c7f284]" 
                          />
                        </div>
                        <div>
                          <label className="block text-[#64748b] font-medium mb-1 uppercase tracking-wide">FTP Password</label>
                          <div className="relative">
                            <input 
                              type={showFtpPass ? "text" : "password"} 
                              value={ftpPass} 
                              onChange={(e) => {
                                setFtpPass(e.target.value);
                                
                              }}
                              placeholder="••••••••"
                              className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg pl-2.5 pr-8 py-1.5 text-white font-mono focus:outline-none focus:border-[#c7f284]" 
                            />
                            <button 
                              onClick={() => setShowFtpPass(!showFtpPass)}
                              type="button"
                              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#64748b] hover:text-white"
                            >
                              {showFtpPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                            </button>
                          </div>
                        </div>
                        <div>
                          <label className="block text-[#64748b] font-medium mb-1 uppercase tracking-wide">Remote Directory (Default: /htdocs)</label>
                          <input 
                            type="text" 
                            value={ftpDir} 
                            onChange={(e) => {
                              setFtpDir(e.target.value);
                              localStorage.setItem('ftp_dir', e.target.value);
                            }}
                            placeholder="/htdocs"
                            className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 text-white font-mono focus:outline-none focus:border-[#c7f284]" 
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px] pt-1">
                        <div>
                          <label className="block text-[#64748b] font-medium mb-1 uppercase tracking-wide font-sans">Public Website URL</label>
                          <input 
                            type="text" 
                            value={ftpWebUrl} 
                            onChange={(e) => {
                              setFtpWebUrl(e.target.value);
                              localStorage.setItem('ftp_web_url', e.target.value);
                            }}
                            placeholder="http://arinas.freehosting.dev"
                            className="w-full bg-[#050509] border border-[#2d2e3d] rounded-lg px-2.5 py-1.5 text-white font-mono focus:outline-none focus:border-[#c7f284]" 
                          />
                        </div>
                        <div className="flex items-center gap-2 pt-5 select-none font-sans">
                          <input 
                            type="checkbox" 
                            id="secure-ftp"
                            checked={ftpSecure} 
                            onChange={(e) => {
                              setFtpSecure(e.target.checked);
                              localStorage.setItem('ftp_secure', String(e.target.checked));
                            }}
                            className="rounded border-[#2d2e3d] bg-[#050509] text-[#c7f284] focus:ring-0 cursor-pointer" 
                          />
                          <label htmlFor="secure-ftp" className="text-[#94a3b8] font-medium uppercase text-[10px] tracking-wide cursor-pointer select-none">
                            Enable Secure FTPS (Optional)
                          </label>
                        </div>
                      </div>
                    </div>

                    {/* Action Hub */}
                    <div className="grid grid-cols-3 gap-3 font-sans">
                      {/* Connection Test */}
                      <button
                        onClick={handleTestFtp}
                        disabled={ftpTesting}
                        className="bg-[#10111a] hover:bg-[#1a1b24] border border-[#1f212e] disabled:opacity-40 p-3 rounded-xl flex flex-col items-center justify-center text-center gap-1.5 transition-all text-white cursor-pointer group"
                      >
                        {ftpTesting ? (
                          <RefreshCw className="w-5 h-5 text-[#c7f284] animate-spin" />
                        ) : (
                          <Wifi className="w-5 h-5 text-indigo-400 group-hover:scale-110 transition-transform" />
                        )}
                        <span className="font-bold text-[11px] uppercase tracking-wider text-[#e2e8f0]">Test Connection</span>
                        <span className="text-[9px] text-[#64748b]">Ping server & list</span>
                      </button>

                      {/* Push Backups */}
                      <button
                        onClick={handleBackupFtp}
                        disabled={ftpBackingUp}
                        className="bg-[#10111a] hover:bg-[#1a1b24] border border-[#1f212e] disabled:opacity-40 p-3 rounded-xl flex flex-col items-center justify-center text-center gap-1.5 transition-all text-white cursor-pointer group"
                      >
                        {ftpBackingUp ? (
                          <RefreshCw className="w-5 h-5 text-[#c7f284] animate-spin" />
                        ) : (
                          <Database className="w-5 h-5 text-[#c7f284] group-hover:scale-110 transition-transform" />
                        )}
                        <span className="font-bold text-[11px] uppercase tracking-wider text-[#e2e8f0]">Backup State</span>
                        <span className="text-[10px] text-[#64748b]">Sync configurations & files</span>
                      </button>

                      {/* Push Site Build */}
                      <button
                        onClick={handleDeployFtp}
                        disabled={ftpDeploying}
                        className="bg-[#c7f284]/15 border border-[#c7f284]/30 hover:bg-[#c7f284]/25 disabled:opacity-40 p-3 rounded-xl flex flex-col items-center justify-center text-center gap-1.5 transition-all text-[#c7f284] cursor-pointer group"
                      >
                        {ftpDeploying ? (
                          <RefreshCw className="w-5 h-5 text-[#c7f284] animate-spin" />
                        ) : (
                          <CloudUpload className="w-5 h-5 text-[#c7f284] group-hover:scale-110 transition-transform" />
                        )}
                        <span className="font-bold text-[11px] uppercase tracking-wider text-[#c7f284]">Deploy Tracker</span>
                        <span className="text-[10px] text-[#c7f284]/70 font-sans">Publish build statically</span>
                      </button>
                    </div>

                    {/* Console & Status Outputs */}
                    <div className="bg-[#050509] border border-[#1f212e] rounded-xl p-3 flex flex-col h-40 font-mono text-[10px]">
                      <div className="flex items-center justify-between border-b border-[#1f212e]/60 pb-1.5 mb-2 shrink-0">
                        <span className="font-bold text-[#64748b] uppercase tracking-wider flex items-center gap-1">
                          <Terminal className="w-3.5 h-3.5" /> Transfer Engine Terminal
                        </span>
                        <button 
                          onClick={() => setFtpConsoleLogs([])} 
                          className="text-[#64748b] hover:text-white px-1.5 py-0.5 border border-[#1f212e] rounded text-[8px] uppercase tracking-wider bg-transparent cursor-pointer"
                        >
                          Clear
                        </button>
                      </div>
                      <div className="flex-1 overflow-y-auto space-y-1.5 custom-scrollbar text-[#e2e8f0]">
                        {ftpConsoleLogs.length === 0 ? (
                          <div className="text-slate-500 py-6 text-center select-none font-sans text-[11px]">
                            Connection status is currently: Standby. Ready to sync build packages.
                          </div>
                        ) : (
                          ftpConsoleLogs.map((log, idx) => (
                            <div key={idx} className="leading-relaxed flex items-start gap-1">
                              <span className="text-slate-600 font-bold shrink-0">{log.time}</span>
                              <span className={
                                log.type === 'error' ? 'text-rose-400 font-semibold' :
                                log.type === 'success' ? 'text-[#c7f284] font-semibold' :
                                log.type === 'info' ? 'text-cyan-400' : 'text-[#64748b]'
                              }>
                                {log.text}
                              </span>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {activeLogTab === 'advisor' && (() => {
                  const losingTrades = tradeHistory.filter(t => (t.sellAmountSol - t.buyAmountSol) < 0);
                  const winningTrades = tradeHistory.filter(t => (t.sellAmountSol - t.buyAmountSol) >= 0);
                  const winRate = tradeHistory.length > 0 ? (winningTrades.length / tradeHistory.length) * 100 : 100;
                  const totalSolLost = losingTrades.reduce((acc, t) => acc + ((t.buyAmountSol || 0) - (t.sellAmountSol || 0)), 0);
                  
                  // Recommendations check
                  const isLiquiditySafe = (hardenedLiquidityMin || 0) >= 40000;
                  const isDevOwnershipSafe = (hardenedMaxDevOwnership || 0) <= 5;
                  const isRiskScoreSafe = (hardenedMaxRiskScore || 0) <= 15;
                  const isTop10Safe = (hardenedMaxTop10 || 0) <= 18;
                  const isSlippageSafe = (slippage || 0) <= 1.5;
                  
                  const applySafePreset = () => {
                    if (setHardenedLiquidityMin) setHardenedLiquidityMin(45000);
                    if (setHardenedMaxDevOwnership) setHardenedMaxDevOwnership(5);
                    if (setHardenedMaxRiskScore) setHardenedMaxRiskScore(14);
                    if (setHardenedMaxTop10) setHardenedMaxTop10(15);
                    if (setSlippage) setSlippage(1.0);
                    if (setBondingCurveStopLoss) setBondingCurveStopLoss(-15);
                    if (setUnknownStopLoss) setUnknownStopLoss(-20);
                    if (setHardenedMinUniqueBuyers30s) setHardenedMinUniqueBuyers30s(6);
                    if (setHardenedMinBuyCount30s) setHardenedMinBuyCount30s(6);
                    if (setHardenedMinBuySellRatio) setHardenedMinBuySellRatio(2.2);
                    if (setHardenedMaxPriceChange1m) setHardenedMaxPriceChange1m(10.0);
                    addLog("🛡️ [A.I. ADVISOR]: Instantly applied 100% Secure Loss Prevention Preset! Saved settings to local storage & Cloud sync initiated.", "success");
                  };
                  
                  return (
                    <div className="space-y-4 font-sans text-xs pt-1">
                      {/* Premium Header Banner */}
                      <div className="p-3 bg-indigo-500/5 border border-indigo-500/20 rounded-xl relative overflow-hidden">
                        <div className="absolute right-2 top-2 text-[#c7f284] opacity-25">
                          <Shield className="w-12 h-12" />
                        </div>
                        <div className="flex items-center gap-1.5 text-white font-bold text-[12px] uppercase tracking-wider mb-1">
                          <span>🧠</span> A.I. Risk & Loss Advisor
                        </div>
                        <p className="text-[10px] text-[#64748b] leading-relaxed">
                          Automated trade diagnostics scanning active configs, slippage vectors, and historical trades to block high-risk entries and optimize exit yields.
                        </p>
                      </div>

                      {/* Trade History Diagnostics Cards */}
                      <div className="grid grid-cols-2 gap-3">
                        <div className="p-3 bg-rose-500/5 border border-rose-500/10 rounded-xl">
                          <div className="text-[9px] text-[#64748b] uppercase font-bold tracking-wider mb-1">Loss Rate Analysis</div>
                          <div className="text-sm font-mono font-black text-rose-400">
                            {losingTrades.length} / {tradeHistory.length} <span className="text-[9px] text-slate-500 font-sans font-medium">({(100 - winRate).toFixed(0)}%)</span>
                          </div>
                          <div className="text-[9px] text-[#64748b] font-bold mt-1">Total Lost: <span className="text-rose-400 font-mono">-{totalSolLost.toFixed(4)} SOL</span></div>
                        </div>
                        <div className="p-3 bg-[#c7f284]/5 border border-[#c7f284]/10 rounded-xl">
                          <div className="text-[9px] text-[#64748b] uppercase font-bold tracking-wider mb-1">Current Win Rate</div>
                          <div className="text-sm font-mono font-black text-[#c7f284]">
                            {winRate.toFixed(0)}%
                          </div>
                          <div className="text-[9px] text-[#64748b] font-bold mt-1">
                            {winningTrades.length} won {winningTrades.length === 1 ? 'trade' : 'trades'}
                          </div>
                        </div>
                      </div>

                      {/* Underperforming & Loss Tokens Scan list */}
                      <div className="space-y-2">
                        <div className="text-[10px] font-bold text-[#94a3b8] uppercase tracking-wider">Historical Loss Incidents</div>
                        {losingTrades.length === 0 ? (
                          <div className="p-3 text-center border border-dashed border-[#1f212e]/60 rounded-xl text-[10px] text-[#64748b]">
                            ✓ No loss incidents recorded. Your parameters are maintaining safety!
                          </div>
                        ) : (
                          <div className="space-y-1.5 max-h-[120px] overflow-y-auto custom-scrollbar">
                            {losingTrades.slice(0, 5).map(t => {
                              const loss = (t.buyAmountSol || 0) - (t.sellAmountSol || 0);
                              return (
                                <div key={t.id} className="p-2 border border-[#1f212e]/40 bg-[#050509]/40 rounded-lg flex justify-between items-center text-[10px] font-mono">
                                  <div className="truncate pr-2">
                                    <span className="text-white font-bold">{t.mint.slice(0, 6)}...{t.mint.slice(-6)}</span>
                                    <div className="text-[8px] text-[#64748b]">Hold: {Math.floor((t.sellTime - t.buyTime) / 1000)}s</div>
                                  </div>
                                  <div className="text-right shrink-0">
                                    <span className="text-rose-400 font-bold">-{loss.toFixed(4)} SOL</span>
                                    <div className="text-[8px] text-rose-500">{(t.pnlPct || 0).toFixed(1)}%</div>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>

                      {/* A.I. Wisdom Checklist (Configuration Audit) */}
                      <div className="space-y-2">
                        <div className="text-[10px] font-bold text-[#94a3b8] uppercase tracking-wider flex justify-between items-center">
                          <span>Configuration Audit</span>
                          <span className="text-[9px] font-bold text-indigo-400 capitalize">Audit Status</span>
                        </div>
                        
                        <div className="space-y-2">
                          {/* Liquidity floor rule */}
                          <div className="p-2.5 border border-[#1f212e]/40 bg-[#0d0e16]/30 rounded-xl flex items-start gap-2.5">
                            <div className="mt-0.5 shrink-0">
                              {isLiquiditySafe ? (
                                <span className="text-emerald-400 text-xs font-black">✓</span>
                              ) : (
                                <span className="text-rose-400 text-xs font-black">⚠</span>
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="text-[11px] font-bold text-slate-200 flex justify-between items-center">
                                <span>Liquidity Floor Depth</span>
                                <span className={`text-[9px] font-bold ${isLiquiditySafe ? 'text-emerald-400' : 'text-rose-400'}`}>
                                  ${(hardenedLiquidityMin || 0).toLocaleString()}
                                </span>
                              </div>
                              <p className="text-[9.5px] text-[#64748b] leading-snug mt-0.5 font-sans">
                                Recommended: $40,000+. Thin liquidity pools trigger high slippage losses during market exit.
                              </p>
                            </div>
                          </div>

                          {/* Dev Concentration rule */}
                          <div className="p-2.5 border border-[#1f212e]/40 bg-[#0d0e16]/30 rounded-xl flex items-start gap-2.5">
                            <div className="mt-0.5 shrink-0">
                              {isDevOwnershipSafe ? (
                                <span className="text-emerald-400 text-xs font-black">✓</span>
                              ) : (
                                <span className="text-rose-400 text-xs font-black">⚠</span>
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="text-[11px] font-bold text-slate-200 flex justify-between items-center">
                                <span>Developer Concentration</span>
                                <span className={`text-[9px] font-bold ${isDevOwnershipSafe ? 'text-emerald-400' : 'text-rose-400'}`}>
                                  {hardenedMaxDevOwnership}% Max
                                </span>
                              </div>
                              <p className="text-[9.5px] text-[#64748b] leading-snug mt-0.5 font-sans">
                                Recommended: &lt;= 5%. High developer ownership is a major vector for rug pulls and coordinated developer dumping.
                              </p>
                            </div>
                          </div>

                          {/* Top 10 Concentration rule */}
                          <div className="p-2.5 border border-[#1f212e]/40 bg-[#0d0e16]/30 rounded-xl flex items-start gap-2.5">
                            <div className="mt-0.5 shrink-0">
                              {isTop10Safe ? (
                                <span className="text-emerald-400 text-xs font-black">✓</span>
                              ) : (
                                <span className="text-rose-400 text-xs font-black">⚠</span>
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="text-[11px] font-bold text-slate-200 flex justify-between items-center">
                                <span>Top 10 Holder Cabals</span>
                                <span className={`text-[9px] font-bold ${isTop10Safe ? 'text-emerald-400' : 'text-rose-400'}`}>
                                  {hardenedMaxTop10}% Max
                                </span>
                              </div>
                              <p className="text-[9.5px] text-[#64748b] leading-snug mt-0.5 font-sans">
                                Recommended: &lt;= 18%. High concentration among top holders indicates cabal ownership, leading to immediate dumps.
                              </p>
                            </div>
                          </div>

                          {/* Slippage impact rule */}
                          <div className="p-2.5 border border-[#1f212e]/40 bg-[#0d0e16]/30 rounded-xl flex items-start gap-2.5">
                            <div className="mt-0.5 shrink-0">
                              {isSlippageSafe ? (
                                <span className="text-emerald-400 text-xs font-black">✓</span>
                              ) : (
                                <span className="text-rose-400 text-xs font-black">⚠</span>
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="text-[11px] font-bold text-slate-200 flex justify-between items-center">
                                <span>Slippage Safeguard</span>
                                <span className={`text-[9px] font-bold ${isSlippageSafe ? 'text-emerald-400' : 'text-rose-400'}`}>
                                  {slippage}% Max
                                </span>
                              </div>
                              <p className="text-[9.5px] text-[#64748b] leading-snug mt-0.5 font-sans">
                                Recommended: &lt;= 1.5%. Loose slippage tolerates high transaction frontrunning (sandwich attacks) and negative execution price impact.
                              </p>
                            </div>
                          </div>

                          {/* Recovery mode caution advice */}
                          <div className="p-2.5 border border-[#1f212e]/40 bg-amber-500/5 rounded-xl flex items-start gap-2.5">
                            <div className="mt-0.5 shrink-0">
                              <span className="text-amber-400 text-xs font-black">⚠</span>
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="text-[11px] font-bold text-amber-400">
                                Recovery Mode Trap
                              </div>
                              <p className="text-[9.5px] text-slate-400 leading-snug mt-0.5 font-sans">
                                Once triggered (-50% drop), Recovery Mode disables standard Stop Loss, holding till breakeven or hard stop (-85%). Meme coins rarely bounce back to breakeven, resulting in -85% absolute losses. Consider disabling or cutting losses early.
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Direct Apply Mitigation Action Button */}
                      <button 
                        onClick={applySafePreset}
                        className="w-full py-2.5 bg-[#c7f284] hover:bg-[#b0dc68] text-[#050509] rounded-xl font-bold uppercase tracking-wider text-[10px] transition-all cursor-pointer shadow-lg shadow-[#c7f284]/10 active:scale-[0.98] mt-2"
                      >
                        🛡️ Apply Safe Loss-Prevention Preset
                      </button>
                    </div>
                  );
                })()}
              </div>
            )}
          </div>
          
          <div className="bg-[#10111a]/60 border border-[#1f212e] rounded-2xl flex flex-col shrink-0">
            <div className="p-4 border-b border-[#1f212e] flex justify-between items-center">
              <h2 className="text-[12px] uppercase tracking-[1px] text-[#94a3b8] font-bold">Trade History</h2>
              <button
                onClick={() => {
                  const profitablePnlTokens = [
                    ...new Set(
                      tradeHistory
                        .filter((trade: any) => {
                          if (!trade) return false;
                          const addr = trade.tokenAddress || trade.mint;
                          if (!addr || typeof addr !== 'string' || addr.trim().length === 0 || addr === 'Unknown') return false;
                          
                          const isProfitable = 
                            (trade.realizedPnL && Number(trade.realizedPnL) > 0) ||
                            ((Number(trade.sellAmountSol) || 0) - (Number(trade.buyAmountSol) || 0) > 0) ||
                            (trade.pnlPct && Number(trade.pnlPct) > 0) ||
                            (trade.pnl && Number(trade.pnl) > 0) ||
                            (trade.netPnl && Number(trade.netPnl) > 0);
                          
                          return isProfitable;
                        })
                        .map((trade: any) => (trade.tokenAddress || trade.mint).trim())
                    )
                  ];
                  try {
                    localStorage.setItem('pnl_profitable_token_addresses', JSON.stringify(profitablePnlTokens));
                    window.dispatchEvent(new CustomEvent('pnl_trade_history_updated', { detail: profitablePnlTokens }));
                  } catch (e) {}

                  navigate("/jupiter", {
                    state: {
                      profitableTokenAddresses: profitablePnlTokens
                    }
                  });
                  if (externalSettings && typeof (externalSettings as any).setCurrentPage === 'function') {
                    (externalSettings as any).setCurrentPage('jupiter');
                  }
                }}
                className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white rounded-xl text-[10px] font-bold uppercase tracking-wider transition-all flex items-center gap-1.5 cursor-pointer shadow-lg shadow-indigo-600/20"
              >
                <span>Open in Jupiter</span>
              </button>
            </div>
            <div className="p-4 overflow-x-auto">
          {tradeHistory.length === 0 ? (
            <div className="text-center text-[#64748b] py-4 text-[11px] font-mono">No trades executed yet.</div>
          ) : (
            <table className="w-full text-left border-collapse text-[11px] font-mono whitespace-nowrap">
              <thead>
                <tr className="text-[#64748b] border-b border-[#1f212e]">
                  <th className="pb-2 font-medium pr-4">Token Address</th>
                  <th className="pb-2 font-medium pr-4">Buy Time</th>
                  <th className="pb-2 font-medium pr-4">Hold Time</th>
                  <th className="pb-2 font-medium text-right pr-4">Buy SOL</th>
                  <th className="pb-2 font-medium text-right pr-4">Sell SOL</th>
                  <th className="pb-2 font-medium text-right pr-4">Profit SOL</th>
                  <th className="pb-2 font-medium text-right">PnL (%)</th>
                </tr>
              </thead>
              <tbody>
                {tradeHistory.map(trade => {
                  const buySol = trade.buyAmountSol || 0;
                  const sellSol = trade.sellAmountSol || 0;
                  const pnl = trade.pnlPct || 0;
                  const profitSol = sellSol - buySol;
                  const buyTime = trade.buyTime || Date.now();
                  const sellTime = trade.sellTime || Date.now();
                  const durationSecs = Math.max(0, Math.floor((sellTime - buyTime) / 1000));
                  const durationMins = Math.floor(durationSecs / 60);
                  const durationStr = durationMins > 0 ? `${durationMins}m ${durationSecs % 60}s` : `${durationSecs}s`;
                  const mintStr = trade.mint || '';
                  const mintDisplay = mintStr.length > 12 ? `${mintStr.slice(0, 6)}...${mintStr.slice(-6)}` : mintStr || 'Unknown';
                  return (
                  <tr key={trade.id} className="border-b border-[#1f212e]/50 last:border-0 hover:bg-[#1f212e]/30 transition-colors">
                    <td className="py-2 text-[#e2e8f0] pr-4">{mintDisplay}</td>
                    <td className="py-2 text-[#e2e8f0] pr-4">{new Date(buyTime).toLocaleTimeString()}</td>
                    <td className="py-2 text-[#64748b] pr-4">{durationStr}</td>
                    <td className="py-2 text-[#e2e8f0] text-right pr-4">{buySol.toFixed(4)} SOL</td>
                    <td className="py-2 text-[#e2e8f0] text-right pr-4">{sellSol.toFixed(4)} SOL</td>
                    <td className={`py-2 text-right font-bold pr-4 ${profitSol >= 0 ? 'text-[#c7f284]' : 'text-[#ff4d4d]'}`}>
                      {profitSol >= 0 ? '+' : ''}{profitSol.toFixed(4)} SOL
                    </td>
                    <td className={`py-2 text-right font-bold ${pnl >= 0 ? 'text-[#c7f284]' : 'text-[#ff4d4d]'}`}>
                      {pnl >= 0 ? '+' : ''}{pnl.toFixed(2)}%
                    </td>
                  </tr>
                  );
                })}
              </tbody>
              {(() => {
                const totalBuySol = tradeHistory.reduce((acc, t) => acc + (t.buyAmountSol || 0), 0);
                const totalSellSol = tradeHistory.reduce((acc, t) => acc + (t.sellAmountSol || 0), 0);
                const totalProfitSol = totalSellSol - totalBuySol;
                const totalPnlPct = totalBuySol > 0 ? (totalProfitSol / totalBuySol) * 100 : 0;
                return (
                  <tfoot className="border-t-2 border-[#1f212e]">
                    <tr className="bg-[#10111a]/80 font-bold text-slate-200">
                      <td className="py-2.5 text-[#94a3b8] pr-4">Total ({tradeHistory.length})</td>
                      <td className="py-2.5 text-right text-slate-500 pr-4">-</td>
                      <td className="py-2.5 text-right text-slate-500 pr-4">-</td>
                      <td className="py-2.5 text-[#e2e8f0] text-right pr-4">{totalBuySol.toFixed(4)} SOL</td>
                      <td className="py-2.5 text-[#e2e8f0] text-right pr-4">{totalSellSol.toFixed(4)} SOL</td>
                      <td className={`py-2.5 text-right pr-4 ${totalProfitSol >= 0 ? 'text-[#c7f284]' : 'text-[#ff4d4d]'}`}>
                        {totalProfitSol >= 0 ? '+' : ''}{totalProfitSol.toFixed(4)} SOL
                      </td>
                      <td className={`py-2.5 text-right ${totalPnlPct >= 0 ? 'text-[#c7f284]' : 'text-[#ff4d4d]'}`}>
                        {totalPnlPct >= 0 ? '+' : ''}{totalPnlPct.toFixed(2)}%
                      </td>
                    </tr>
                  </tfoot>
                );
              })()}
            </table>
          )}
            </div>
          </div>
        </aside>
      </main>

      {showDocsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-[#050509] border border-[#1f212e] rounded-2xl w-full max-w-4xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden mt-10">
            <div className="flex items-center justify-between p-5 border-b border-[#1f212e] bg-[#0c0d15]">
              <div className="flex items-center gap-3">
                <BookOpen className="w-5 h-5 text-[#c7f284]" />
                <h2 className="text-[14px] uppercase tracking-[1px] text-white font-bold">Hardened Scanner Logic&trade; Engine</h2>
              </div>
              <button 
                onClick={() => setShowDocsModal(false)}
                className="text-[#64748b] hover:text-white transition-colors p-1 bg-[#10111a] hover:bg-[#1f212e] rounded-md border border-[#1f212e]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
              <div className="prose prose-invert prose-sm max-w-none prose-headings:text-[#c7f284] prose-headings:uppercase prose-headings:tracking-wider prose-h1:text-[20px] prose-h1:border-b prose-h1:border-[#1f212e] prose-h1:pb-4 prose-h2:text-[14px] prose-h2:mt-8 prose-h3:text-[12px] prose-p:text-[#94a3b8] prose-p:leading-relaxed prose-code:text-[#e2e8f0] prose-code:bg-[#10111a] prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded-md prose-code:border prose-code:border-[#1f212e]">
                
                <h1>Adaptive Multi-Stage Token Qualification Engine</h1>
                <p>
                  The Hardened Scanner Logic&trade; is the core decision-making framework responsible for determining whether a token is eligible for automated execution. Rather than applying a single rule set to every asset, the engine dynamically adjusts its evaluation model based on the token's lifecycle stage.
                </p>
                <p>
                  Early-stage Pump.fun launches are assessed for velocity and opportunity discovery, while mature Raydium assets undergo full security, liquidity, and market-structure validation. This dual-path architecture allows the engine to aggressively discover emerging opportunities while maintaining strict risk controls for graduated assets.
                </p>

                <h2>Phase 1 &mdash; Platform Classification</h2>
                <p>Every discovered asset is first classified into its current lifecycle stage.</p>
                
                <h3>Graduated Asset (Raydium)</h3>
                <p>A token is automatically classified as <strong>Graduated</strong> when either condition is met:</p>
                <pre className="!bg-[#10111a] !border !border-[#1f212e] !text-[#e2e8f0] !p-4 !rounded-xl">
<code>dexId contains "raydium"
OR
bondingCurveProgress &gt;= 99.5%</code>
                </pre>
                <p>Graduated assets are considered fully launched and subject to comprehensive auditing.</p>

                <h3>Early-Stage Asset (Pump.fun)</h3>
                <p>Assets that do not meet the graduation criteria remain classified as Pump.fun tokens and enter the Early Discovery pathway.</p>
                <pre className="!bg-[#10111a] !border !border-[#1f212e] !text-[#e2e8f0] !p-4 !rounded-xl">
<code>isGraduated = 
    !tokenAddress.toLowerCase().endsWith("pump")</code>
                </pre>

                <h2>Phase 2 &mdash; Universal Enforcement Layer</h2>
                <p>Before any platform-specific analysis begins, all assets must pass a set of non-negotiable system protections. These checks represent the minimum standards required for consideration.</p>
                
                <h3>Momentum Qualification</h3>
                <p>The engine only evaluates assets demonstrating active upward movement.</p>
                <code>5m Change &gt;= Min 5m Profit (%)</code>
                <p>Assets failing to generate sufficient momentum are immediately rejected.</p>

                <h3>Market Cap Envelope</h3>
                <p>The token must remain within the approved market capitalization range.</p>
                <code>Platform Min MC &lt; Market Cap &lt; Global Max MC</code>
                <p>This prevents participation in both ultra-small illiquid assets and excessively mature opportunities.</p>

                <h3>Network Latency Protection</h3>
                <p>Execution quality is continuously monitored. When enabled:</p>
                <code>RPC Ping &lt;= Max Latency (ms)</code>
                <p>If network conditions deteriorate beyond acceptable thresholds, all entries are suspended.</p>

                <h3>Historical Loss Protection</h3>
                <p>The engine maintains an internal memory of previously failed positions. Tokens associated with a realized loss are automatically added to the Blacklist Registry and blocked from future purchases unless explicitly requalified.</p>
                <code>Blacklist = TRUE</code>

                <h2>Phase 3 &mdash; Pump.fun Discovery Path</h2>
                <p><strong>Objective:</strong> Identify high-potential launches before traditional market metrics become reliable.</p>
                <p>The engine recognizes that newly launched assets naturally fail many conventional security and liquidity checks. Instead of penalizing these tokens, the system shifts its focus toward launch quality, bonding progression, and acceleration.</p>
                
                <h3>Age Qualification</h3>
                <code>Min Age &lt;= Token Age &lt;= Max Age</code>
                <p>The token must fall within the configured discovery window.</p>

                <h3>Bonding Curve Qualification</h3>
                <code>Min Curve Progress &lt;= Bonding Progress &lt;= Max Curve Progress</code>
                <p>This ensures the token is progressing through the bonding phase at an acceptable rate.</p>

                <h3>Discovery-Mode Bypasses</h3>
                <p>To maximize early discovery effectiveness, the following validations are intentionally bypassed:</p>
                <ul className="text-[#94a3b8]">
                  <li>Liquidity Requirements</li>
                  <li>Liquidity Ratio Requirements</li>
                  <li>Holder Distribution Limits</li>
                  <li>Top 10 Wallet Concentration</li>
                  <li>Developer Ownership Thresholds</li>
                  <li>Buy Velocity Audits</li>
                  <li>Buy/Sell Ratio Audits</li>
                  <li>Rug Scoring Systems</li>
                  <li>Risk Scoring Systems</li>
                  <li>1-Minute Spike Protection</li>
                </ul>

                <h2>Phase 4 &mdash; Raydium Security Path</h2>
                <p><strong>Objective:</strong> Validate that a graduated asset possesses sufficient liquidity, market structure, distribution quality, and security characteristics before execution.</p>
                <p>Unlike Pump.fun assets, no shortcuts are permitted. Every rule below must pass.</p>

                <h3>Liquidity Integrity Audit</h3>
                <p>The token must satisfy minimum pool depth requirements.</p>
                <code>Liquidity &gt;= Min Liquidity</code>

                <h3>Liquidity Efficiency Audit</h3>
                <p>The scanner computes a liquidity-to-market-cap efficiency ratio.</p>
                <code>Liquidity / MarketCap &gt;= Required Ratio</code>
                <p>Assets with weak liquidity relative to valuation are rejected.</p>

                <h3>Anti-Whale Distribution Audit</h3>
                <p>The system evaluates holder concentration.</p>
                <code>Top10Supply &lt; MaxTop10%</code>
                <p>High concentration introduces elevated manipulation risk and results in rejection.</p>

                <h3>15-Second Microstructure Analysis</h3>
                <p>A hidden ultra-short-term momentum window evaluates real-time order flow.</p>
                <div className="space-y-4">
                   <div><code>Buys15s &gt;= Required Velocity</code></div>
                   <div><code>Min BuySell Ratio &lt;= Ratio15s &lt;= Max BuySell Ratio</code></div>
                </div>

                <h3>Vertical Expansion Protection</h3>
                <p>The engine actively avoids buying into exhaustion candles.</p>
                <code>1m Change &gt;= 1.5% AND 1m Change &lt;= Max 1m Change (%)</code>
                
                <h3>Developer Exposure Audit</h3>
                <code>Dev Ownership &lt;= Max Dev Ownership (%)</code>

                <h3>Risk Intelligence Audit</h3>
                <code>Risk Score &lt;= Max Risk Score</code>

                <h3>Rug-Safety Verification</h3>
                <code>isRugSafe == TRUE</code>

                <h2>Phase 5 &mdash; Trade Authorization</h2>
                <p>Only tokens that successfully pass all required evaluations enter the execution pipeline.</p>
                <div className="bg-[#10111a] border border-[#1f212e] text-[#e2e8f0] p-6 rounded-xl font-mono text-[11px] text-center w-full max-w-sm mx-auto mb-8 mt-6">
                  Discovery<br/>↓<br/>Platform Classification<br/>↓<br/>Universal Enforcement<br/>↓<br/>Pump.fun Path &nbsp;&nbsp;&nbsp; OR &nbsp;&nbsp;&nbsp; Raydium Path<br/>↓<br/>Security Validation<br/>↓<br/>Trade Authorization
                </div>

                <h2>Alert Filtering &amp; Explainability Engine</h2>
                <p>Every rejection is fully traceable. When a token fails any criterion, the scanner emits a structured rejection event. The exact failing condition is attached to the event log, allowing complete transparency into why execution was halted.</p>
                <pre className="!bg-[#2d1f1f]/30 !border !border-[#ff4d4d]/20 !text-[#ff4d4d] !p-4 !rounded-xl !mb-2">
<code>❌ [ALERT FILTERED] Liquidity Below Threshold</code>
                </pre>
                <pre className="!bg-[#2d1f1f]/30 !border !border-[#ff4d4d]/20 !text-[#ff4d4d] !p-4 !rounded-xl">
<code>❌ [ALERT FILTERED] Top10 Wallet Concentration Exceeded</code>
                </pre>
                <p>This ensures every trade decision remains deterministic, auditable, and reproducible.</p>

              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

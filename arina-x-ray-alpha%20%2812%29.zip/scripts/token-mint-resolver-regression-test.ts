import assert from 'node:assert/strict';
import { Keypair, PublicKey } from '@solana/web3.js';
import { tokenMintResolver } from '../server/market/TokenMintResolver.js';

const PUMP_MINT = 'HJE2DEZXvErwUabTU16xzrS629qXVeVyTGvJYJVfpump';
const SYSTEM_PROGRAM = '11111111111111111111111111111111';

console.log('\n=== ARINA X-RAY: UNIFIED TOKEN MINT RESOLVER REGRESSION ===');

// Regression for the reported production failure. This address is a valid
// 32-byte Solana public key; the literal "pump" suffix is part of Base58.
assert.equal(new PublicKey(PUMP_MINT).toBase58(), PUMP_MINT);
assert.equal(tokenMintResolver.normalizeMint(PUMP_MINT), PUMP_MINT);
assert.equal(tokenMintResolver.isValidPublicKey(PUMP_MINT), true);
assert.equal(tokenMintResolver.isValidMint(PUMP_MINT), true);
console.log('  PASS: reported .pump mint is accepted as a valid Solana public key');

// Whitespace is normalized, never lower-cased.
assert.equal(tokenMintResolver.normalizeMint(`  ${PUMP_MINT}  `), PUMP_MINT);
console.log('  PASS: surrounding whitespace is normalized');

// Base58 is case-sensitive; lower-casing must never occur.
const mixedCase = Keypair.generate().publicKey.toBase58();
assert.equal(tokenMintResolver.normalizeMint(mixedCase.toLowerCase()), null);
assert.equal(tokenMintResolver.normalizeMint(mixedCase), mixedCase);
console.log('  PASS: Base58 case is preserved and never lower-cased');

// Synthetic TestMint strings must no longer bypass PublicKey validation.
assert.equal(tokenMintResolver.isValidPublicKey('TestMint111111111111111111111111111111111111'), false);
assert.equal(tokenMintResolver.isValidMint('TestMint111111111111111111111111111111111111'), false);
console.log('  PASS: synthetic TestMint bypass is removed');

// Invalid lengths / characters are rejected.
assert.equal(tokenMintResolver.isValidPublicKey('invalid_base58_token_123'), false);
assert.equal(tokenMintResolver.isValidPublicKey('1'.repeat(31)), false);
assert.equal(tokenMintResolver.isValidPublicKey('1'.repeat(45)), false);
console.log('  PASS: malformed addresses are rejected');

// Program IDs and WSOL remain non-tradable mint candidates.
assert.equal(tokenMintResolver.isValidMint(SYSTEM_PROGRAM), false);
assert.equal(tokenMintResolver.isValidMint('So11111111111111111111111111111111111111112'), false);
console.log('  PASS: known program/native addresses remain blocked');

// Log extraction must return the exact canonical mint, including .pump.
const extracted = tokenMintResolver.extractMintFromLogs([
  'Program log: Instruction: Create',
  `Program log: mint: ${PUMP_MINT}`,
]);
assert.equal(extracted, PUMP_MINT);
console.log('  PASS: Pump.fun-style log extraction preserves .pump mint');

console.log('\nALL UNIFIED MINT RESOLVER REGRESSIONS PASSED');
